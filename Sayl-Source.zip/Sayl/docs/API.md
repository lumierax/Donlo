# Sayl API v1

Single-user, owner-hosted API. JSON uses snake_case; the Swift client decodes with `.convertFromSnakeCase`. Never send raw yt-dlp selectors, filesystem paths, cookies, or executable commands from clients.

All `/v1/*` endpoints require `Authorization: Bearer <SAYL_TOKEN>`. `/health` is a minimal public liveness endpoint. API docs/OpenAPI are disabled. Set HTTPS at your trusted reverse proxy. Body cap: 16 KiB, no chunked request bodies. No wildcard CORS.

| Method | Path | Result |
|---|---|---|
| GET | `/health` | Minimal liveness |
| GET | `/v1/health` | Authenticated tool/environment readiness, not site support |
| POST | `/v1/inspect` | `{ "url": "https://..." }` → inspection + actual options |
| POST | `/v1/jobs` | `{ "inspection_id": "...", "option_id": "..." }` → 202 job |
| GET | `/v1/jobs` | Saved job summaries |
| GET | `/v1/jobs/{id}` | Current job state |
| GET/HEAD | `/v1/jobs/{id}/file` | Authenticated MP4/M4A; supports Range/If-Range |
| DELETE | `/v1/jobs/{id}` | Cancel/delete server copy |

Inspection options include `id`, `label`, `kind`, `ext`, nullable `height`, nullable `bytes_estimate`, and nullable `has_audio` (true/false/unknown). Inspection TTL is 15 minutes. Selectors are stored privately server-side. No illustrative quality options exist in production.

Job states: `queued`, `preparing`, `processing`, `ready`, `failed`, `cancelled`, `expired`. `progress` is nullable and may reflect the current stream, not an aggregate of video/audio/merge. Download occurs in a subprocess, media processing locally, and the file is exposed only after success. Duplicate active creation for the same inspection/option returns the existing job.

Typical errors: 401 missing/invalid token, 410 expired inspection/file, 422 invalid URL/option, 409 file not ready, 429 capacity reached, 413 request too large. Do not interpret a generic networking failure as successful deletion. Retry polling only while the app is active; do not create another job just because polling failed.

The `server/tests/fixture_worker.py` module creates synthetic media offline for integration tests. Production Docker copies only `sayl_server`, never tests, and the worker module is not controlled by an HTTP field or environment variable.
