"""Small HTTP(S) egress proxy with DNS pinning.

Run ONLY on a private Docker network, not as an Internet-facing public proxy.
CONNECT never terminates TLS. Certificates are still verified by yt-dlp.
Each destination is checked and connected using the *validated IP address*.
"""
from __future__ import annotations

import ipaddress
import os
import re
import select
import socket
import socketserver
import time
from urllib.parse import urlsplit

MAX_HEADERS = 32 * 1024
MAX_BODY = 2 * 1024 * 1024
BLOCKED = (".localhost", ".local", ".internal", ".lan", ".home", ".onion")


class Denied(Exception):
    pass


def public_endpoints(host: str, port: int) -> list[tuple]:
    host = host.rstrip(".").lower()
    if port not in {80, 443} or not host or "%" in host or host == "localhost" or host.endswith(BLOCKED):
        raise Denied("Destination denied")
    try:
        answers = socket.getaddrinfo(host, port, type=socket.SOCK_STREAM)
    except socket.gaierror as exc:
        raise Denied("DNS lookup failed") from exc
    validated = []
    for family, socktype, protocol, _, address in answers:
        ip = ipaddress.ip_address(address[0])
        if not ip.is_global or ip.is_multicast or ip.is_unspecified or ip.is_loopback or ip.is_link_local:
            raise Denied("Non-public destination")
        candidate = (family, socktype, protocol, address)
        if candidate not in validated:
            validated.append(candidate)
    if not validated:
        raise Denied("No public address")
    return validated


def connect_pinned(host: str, port: int) -> socket.socket:
    # No second hostname lookup: connect to the previously checked sockaddr.
    for family, socktype, protocol, address in public_endpoints(host, port):
        remote = socket.socket(family, socktype, protocol)
        remote.settimeout(15)
        try:
            remote.connect(address)
            return remote
        except OSError:
            remote.close()
    raise Denied("Destination unreachable")


def relay(left: socket.socket, right: socket.socket, initial: bytes = b"") -> None:
    if initial:
        right.sendall(initial)
    left.settimeout(30)
    right.settimeout(30)
    started = time.monotonic()
    while time.monotonic() - started < 3600:
        readable, _, _ = select.select([left, right], [], [], 60)
        if not readable:
            return
        for source in readable:
            data = source.recv(64 * 1024)
            if not data:
                return
            (right if source is left else left).sendall(data)


class Proxy(socketserver.BaseRequestHandler):
    def handle(self) -> None:
        if not self.server.slots.acquire(blocking=False):
            self.request.sendall(b"HTTP/1.1 503 Busy\r\nConnection: close\r\nContent-Length: 0\r\n\r\n")
            return
        remote = None
        response_started = False
        try:
            self.request.settimeout(15)
            raw = b""
            while b"\r\n\r\n" not in raw:
                block = self.request.recv(4096)
                if not block:
                    return
                raw += block
                if len(raw) > MAX_HEADERS:
                    raise Denied("Headers too large")
            header, rest = raw.split(b"\r\n\r\n", 1)
            lines = header.decode("iso-8859-1").split("\r\n")
            method, target, version = lines[0].split(" ", 2)
            if version not in {"HTTP/1.0", "HTTP/1.1"}:
                raise Denied("Unsupported version")
            if method == "CONNECT":
                parsed = urlsplit("https://" + target)
                if parsed.username is not None or parsed.password is not None or parsed.path or parsed.query or parsed.fragment:
                    raise Denied("Bad CONNECT target")
                host, port = parsed.hostname, parsed.port or 443
                if not host or port != 443:
                    raise Denied("CONNECT requires port 443")
                remote = connect_pinned(host, port)
                self.request.sendall(b"HTTP/1.1 200 Connection Established\r\n\r\n")
                response_started = True
                relay(self.request, remote, rest)
                return
            if method not in {"GET", "HEAD", "POST", "OPTIONS"}:
                raise Denied("Method denied")
            parsed = urlsplit(target)
            if parsed.scheme != "http" or not parsed.hostname or parsed.username is not None or parsed.password is not None:
                raise Denied("Expected absolute HTTP URL")
            if any(c in target for c in "\r\n\\\x00"):
                raise Denied("Invalid request target")
            host, port = parsed.hostname, parsed.port or 80
            headers: dict[str, str] = {}
            for line in lines[1:]:
                if ":" not in line or line.startswith((" ", "\t")):
                    raise Denied("Invalid header")
                name, value = line.split(":", 1)
                name = name.lower()
                if not re.fullmatch(r"[a-z0-9!#$%&'*+.^_`|~-]+", name) or name in headers:
                    raise Denied("Invalid or duplicate header")
                headers[name] = value.strip()
            if "transfer-encoding" in headers:
                raise Denied("Chunked requests are disabled")
            length = int(headers.get("content-length", "0"))
            if not 0 <= length <= MAX_BODY or len(rest) > length:
                raise Denied("Request body too large")
            while len(rest) < length:
                block = self.request.recv(min(65536, length - len(rest)))
                if not block:
                    raise Denied("Incomplete request body")
                rest += block
            hop_headers = {"connection", "proxy-connection", "keep-alive", "proxy-authorization", "proxy-authenticate", "te", "trailer", "upgrade", "host"}
            hop_headers.update(part.strip().lower() for part in headers.get("connection", "").split(","))
            outgoing = [f"{method} {parsed.path or '/'}{'?' + parsed.query if parsed.query else ''} HTTP/1.1"]
            host_field = f"[{host}]" if ":" in host else host
            outgoing += [f"Host: {host_field}" + (f":{port}" if port != 80 else ""), "Connection: close"]
            outgoing += [f"{key}: {value}" for key, value in headers.items() if key not in hop_headers]
            remote = connect_pinned(host, port)
            remote.sendall(("\r\n".join(outgoing) + "\r\n\r\n").encode("iso-8859-1") + rest)
            response_started = True
            # A single origin request only. Never tunnel unparsed HTTP pipelining.
            while True:
                data = remote.recv(64 * 1024)
                if not data:
                    break
                self.request.sendall(data)
        except (Denied, ValueError, UnicodeError, OSError):
            if not response_started:
                try:
                    self.request.sendall(b"HTTP/1.1 403 Forbidden\r\nConnection: close\r\nContent-Length: 0\r\n\r\n")
                except OSError:
                    pass
        finally:
            if remote:
                remote.close()
            self.server.slots.release()


class Server(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True

    def __init__(self, address):
        import threading
        self.slots = threading.BoundedSemaphore(64)
        super().__init__(address, Proxy)


if __name__ == "__main__":
    with Server(("0.0.0.0", int(os.getenv("PORT", "8899")))) as server:
        server.serve_forever()
