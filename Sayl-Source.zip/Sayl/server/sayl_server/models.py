from __future__ import annotations

import re
from typing import Literal
from pydantic import BaseModel, Field, field_validator
from .policy import clean_public_url


class InspectRequest(BaseModel):
    url: str = Field(min_length=8, max_length=8192)

    @field_validator("url")
    @classmethod
    def validate_url(cls, value: str) -> str:
        return clean_public_url(value)


class CreateJobRequest(BaseModel):
    inspection_id: str
    option_id: str

    @field_validator("inspection_id", "option_id")
    @classmethod
    def safe_id(cls, value: str) -> str:
        if not re.fullmatch(r"[a-zA-Z0-9_-]{1,64}", value):
            raise ValueError("معرّف غير صالح")
        return value


class QualityOption(BaseModel):
    id: str
    label: str
    kind: Literal["video", "audio"]
    ext: str
    height: int | None = None
    bytes_estimate: int | None = None
    has_audio: bool | None = None


class Inspection(BaseModel):
    id: str
    title: str
    webpage_url: str
    source: str
    duration: float | None = None
    thumbnail: str | None = None
    options: list[QualityOption]
    expires_at: float


class JobView(BaseModel):
    id: str
    title: str
    state: Literal["queued", "preparing", "processing", "ready", "failed", "cancelled", "expired"]
    progress: float | None = None
    downloaded_bytes: int = 0
    total_bytes: int | None = None
    speed: float | None = None
    error: str | None = None
    created_at: float
    updated_at: float
    kind: Literal["video", "audio"]
    ext: str
    size: int | None = None
