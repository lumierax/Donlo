"""Turn extractor metadata into bounded, honest, server-owned choices."""
from __future__ import annotations

import math
import re
from typing import Any

PROTOCOLS = {"http", "https", "m3u8_native", "http_dash_segments"}


class MediaIssue(Exception):
    def __init__(self, code: str):
        super().__init__(code)
        self.code = code


def finite_number(value: Any) -> float | None:
    if isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value) and value >= 0:
        return float(value)
    return None


def has_video(fmt: dict) -> bool:
    codec = fmt.get("vcodec")
    return codec != "none" and (codec is not None or fmt.get("ext") in {"mp4", "mkv", "webm", "mov", "m4v", "flv", "ts"})


def has_audio(fmt: dict) -> bool:
    codec = fmt.get("acodec")
    return codec != "none" and (codec is not None or fmt.get("ext") in {"m4a", "mp3", "aac", "wav", "ogg", "opus", "flac"})


def _score(fmt: dict) -> tuple:
    codec = str(fmt.get("vcodec", ""))
    compatible = codec.startswith(("avc1", "h264", "hvc1", "hev1", "hevc"))
    return (compatible, fmt.get("ext") in ("mp4", "m4a"), finite_number(fmt.get("tbr")) or 0)


def make_choices(info: dict) -> tuple[list[dict], dict[str, dict]]:
    if info.get("_type") in {"playlist", "multi_video"} or "entries" in info:
        raise MediaIssue("playlist")
    if info.get("is_live") or info.get("live_status") in {"is_live", "is_upcoming", "post_live"}:
        raise MediaIssue("live")
    if info.get("has_drm") is True:
        raise MediaIssue("drm")
    formats = info.get("formats") or [info]
    eligible = []
    for item in formats:
        fid = str(item.get("format_id", ""))
        protocol = item.get("protocol") or ("https" if str(item.get("url", "")).startswith("https:") else "http")
        if item.get("has_drm") or protocol not in PROTOCOLS:
            continue
        if not re.fullmatch(r"[\w.-]{1,120}", fid, flags=re.ASCII):
            continue
        if has_video(item) or has_audio(item):
            eligible.append(item)
    if not eligible:
        raise MediaIssue("unsupported")
    audio = sorted([f for f in eligible if has_audio(f) and not has_video(f)], key=_score, reverse=True)
    grouped: dict[int, dict] = {}
    for fmt in sorted(eligible, key=_score):
        if not has_video(fmt):
            continue
        height = int(finite_number(fmt.get("height")) or 0)
        if height > 2160:
            continue
        grouped[height] = fmt
    public: list[dict] = []
    private: dict[str, dict] = {}
    for height, fmt in sorted(grouped.items(), reverse=True):
        fid = str(fmt["format_id"])
        companion = audio[0] if fmt.get("acodec") == "none" and audio else None
        audio_state = True if has_audio(fmt) or companion else (False if fmt.get("acodec") == "none" else None)
        selector = fid + ("+" + str(companion["format_id"]) if companion else "")
        estimate = finite_number(fmt.get("filesize") or fmt.get("filesize_approx"))
        if estimate and companion:
            extra = finite_number(companion.get("filesize") or companion.get("filesize_approx"))
            estimate = estimate + extra if extra else None
        key = f"video_{height}"
        public.append({"id": key, "label": f"{height}p" if height else "الجودة المتاحة", "kind": "video",
                       "ext": "mp4", "height": height or None,
                       "bytes_estimate": int(estimate) if estimate else None,
                       "has_audio": audio_state})
        private[key] = {"selector": selector, "kind": "video", "ext": "mp4", "require_audio": audio_state is True}
    audio_source = audio[0] if audio else next((f for f in reversed(eligible) if has_audio(f)), None)
    if audio_source:
        key = "audio_m4a"
        public.append({"id": key, "label": "صوت فقط", "kind": "audio", "ext": "m4a",
                       "height": None, "bytes_estimate": None, "has_audio": True})
        private[key] = {"selector": str(audio_source["format_id"]), "kind": "audio", "ext": "m4a"}
    if not public:
        raise MediaIssue("unsupported")
    return public, private
