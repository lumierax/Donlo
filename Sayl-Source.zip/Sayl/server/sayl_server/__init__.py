"""Sayl — a private, single-owner media preparation service."""
__version__ = "1.0.0"
