"""A disposable subprocess: extraction, download and local-only media processing.

No API tokens are passed to this process. In production it lives on Docker's
internal network; ALL external HTTP(S) goes through our DNS-pinning egress proxy.
"""
from __future__ import annotations

import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
from urllib.parse import urlsplit

from .formats import MediaIssue, finite_number, make_choices
from .policy import safe_error


def atomic_json(path: Path, value: dict) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False), encoding="utf-8")
    temporary.chmod(0o600)
    temporary.replace(path)


class QuietLogger:
    def debug(self, message: str) -> None:
        pass

    def warning(self, message: str) -> None:
        pass

    def error(self, message: str) -> None:
        pass


def classify_error(exc: Exception) -> str:
    if isinstance(exc, MediaIssue):
        return exc.code
    # Use the message for classification only; never store or return signed URLs.
    text = str(exc).lower()
    if any(word in text for word in ("sign in", "login", "log in", "cookies", "confirm your age", "captcha")):
        return "authentication"
    if any(word in text for word in ("403", "429", "forbidden", "geo-restricted")):
        return "blocked"
    if any(word in text for word in ("unsupported url", "requested format is not available", "no video formats")):
        return "unsupported"
    if "drm" in text:
        return "drm"
    if "no space left" in text:
        return "disk"
    return "internal"


def probe(path: Path) -> dict:
    process = subprocess.run(
        ["ffprobe", "-v", "error", "-protocol_whitelist", "file,pipe", "-show_streams", "-show_format",
         "-of", "json", str(path)], capture_output=True, timeout=40, check=True,
    )
    return json.loads(process.stdout)


def compatible_file(source: Path, directory: Path, kind: str, progress_path: Path, limit: int, require_audio: bool = False) -> Path:
    if not shutil.which("ffmpeg") or not shutil.which("ffprobe"):
        raise MediaIssue("processing")
    metadata = probe(source)
    streams = metadata.get("streams", [])
    videos = [s for s in streams if s.get("codec_type") == "video" and not s.get("disposition", {}).get("attached_pic")]
    audios = [s for s in streams if s.get("codec_type") == "audio"]
    if (kind == "video" and not videos) or (kind == "audio" and not audios):
        raise MediaIssue("processing")
    if require_audio and not audios:
        raise MediaIssue("processing")
    target = directory / ("ready.m4a" if kind == "audio" else "ready.mp4")
    atomic_json(progress_path, {"state": "processing", "progress": None})
    command = ["ffmpeg", "-hide_banner", "-loglevel", "error", "-nostdin", "-y",
               "-protocol_whitelist", "file,pipe", "-i", str(source)]
    if kind == "audio":
        command += ["-map", "0:a:0", "-vn", "-c:a", "copy" if audios[0].get("codec_name") == "aac" else "aac"]
    else:
        video_codec = videos[0].get("codec_name")
        command += ["-map", "0:v:0", "-map", "0:a:0?", "-sn", "-dn"]
        if video_codec in {"h264", "hevc"}:
            command += ["-c:v", "copy"]
            if video_codec == "hevc":
                command += ["-tag:v", "hvc1"]
        else:
            command += ["-c:v", "libx264", "-preset", "veryfast", "-crf", "20", "-pix_fmt", "yuv420p",
                        "-vf", "scale=trunc(iw/2)*2:trunc(ih/2)*2"]
        command += ["-c:a", "copy" if audios and audios[0].get("codec_name") == "aac" else "aac"]
    # -fs can stop early without a failure exit, so a file touching the cap is rejected below.
    command += ["-movflags", "+faststart", "-map_metadata", "-1", "-fs", str(limit), str(target)]
    process = subprocess.run(command, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=2400)
    if process.returncode != 0 or not target.exists() or target.stat().st_size == 0:
        raise MediaIssue("processing")
    if target.stat().st_size >= limit - min(1024 * 1024, limit // 20):
        raise MediaIssue("too_large")
    final_meta = probe(target)
    final_streams = final_meta.get("streams", [])
    required = "audio" if kind == "audio" else "video"
    if not any(stream.get("codec_type") == required for stream in final_streams):
        raise MediaIssue("processing")
    if require_audio and not any(stream.get("codec_type") == "audio" for stream in final_streams):
        raise MediaIssue("processing")
    # ffprobe duration fields are normally strings.
    try:
        old_duration = float(metadata.get("format", {}).get("duration", 0))
        new_duration = float(final_meta.get("format", {}).get("duration", 0))
        if old_duration > 5 and new_duration < old_duration * 0.97:
            raise MediaIssue("processing")
    except (ValueError, TypeError):
        pass
    return target


def run(action: str, request: dict, directory: Path, progress_path: Path) -> dict:
    try:
        import yt_dlp
    except ImportError as exc:
        raise MediaIssue("missing_engine") from exc
    maximum = int(request["max_bytes"])
    last_write = 0.0
    written_by_file: dict[str, int] = {}

    def hook(data: dict) -> None:
        nonlocal last_write
        if data.get("status") == "downloading":
            amount = int(data.get("downloaded_bytes") or 0)
            written_by_file[str(data.get("filename", "stream"))] = amount
            if sum(written_by_file.values()) > maximum:
                raise MediaIssue("too_large")
            total = finite_number(data.get("total_bytes") or data.get("total_bytes_estimate"))
            if time.monotonic() - last_write >= 0.35:
                atomic_json(progress_path, {
                    "state": "preparing", "downloaded_bytes": amount,
                    "total_bytes": int(total) if total else None,
                    "progress": min(amount / total, 1.0) if total else None,
                    "speed": finite_number(data.get("speed")),
                })
                last_write = time.monotonic()
        elif data.get("status") == "finished":
            atomic_json(progress_path, {"state": "processing", "progress": None})

    def media_filter(info: dict, *, incomplete: bool = False) -> str | None:
        if info.get("is_live") or info.get("live_status") in {"is_live", "is_upcoming", "post_live"}:
            raise MediaIssue("live")
        if info.get("has_drm"):
            raise MediaIssue("drm")
        size = finite_number(info.get("filesize"))
        if size and size > maximum:
            raise MediaIssue("too_large")
        return None

    options = {
        "quiet": True, "no_warnings": True, "logger": QuietLogger(),
        "noplaylist": True, "playlistend": 1, "cachedir": False,
        "socket_timeout": 20, "retries": 2, "fragment_retries": 2,
        "skip_unavailable_fragments": False, "continuedl": True,
        "enable_file_urls": False, "allow_unplayable_formats": False,
        "proxy": request.get("proxy") or "", "js_runtimes": {"node": {}},
        "remote_components": set(), "hls_prefer_native": True,
        "external_downloader": {"default": "native"},
        "match_filter": media_filter, "max_filesize": maximum,
        "progress_hooks": [hook], "overwrites": True,
        "concurrent_fragment_downloads": 2,
    }
    if action == "inspect":
        options["skip_download"] = True
        with yt_dlp.YoutubeDL(options) as downloader:
            info = downloader.extract_info(request["url"], download=False)
        if not isinstance(info, dict):
            raise MediaIssue("unsupported")
        choices, private = make_choices(info)
        thumbnail = info.get("thumbnail")
        if not isinstance(thumbnail, str) or not thumbnail.startswith("https://"):
            thumbnail = None
        return {
            "title": str(info.get("title") or "ملف جديد")[:300],
            "webpage_url": request["url"], "source": urlsplit(request["url"]).hostname or "موقع ويب",
            "duration": finite_number(info.get("duration")), "thumbnail": thumbnail,
            "options": choices, "private_options": private,
        }
    selection = request["selection"]
    options.update({
        "format": selection["selector"],
        "outtmpl": str(directory / "source.%(ext)s"),
        "merge_output_format": "mkv", "writeinfojson": False,
    })
    with yt_dlp.YoutubeDL(options) as downloader:
        info = downloader.extract_info(request["url"], download=True)
    if not isinstance(info, dict) or info.get("_type") in {"playlist", "multi_video"}:
        raise MediaIssue("unsupported")
    candidates = [p for p in directory.glob("source.*")
                  if p.is_file() and p.suffix.lower() in {".mp4", ".mkv", ".webm", ".m4a", ".mp3", ".ogg", ".opus", ".aac", ".mov", ".flv", ".ts", ".wav"}]
    if not candidates:
        raise MediaIssue("unsupported")
    # The merged result takes precedence over component streams.
    candidates.sort(key=lambda p: (p.name == "source.mkv", p.stat().st_size), reverse=True)
    output = compatible_file(candidates[0], directory, selection["kind"], progress_path, maximum, require_audio=bool(selection.get("require_audio")))
    for candidate in candidates:
        candidate.unlink(missing_ok=True)
    return {"path": output.name, "size": output.stat().st_size}


def main() -> None:
    os.umask(0o077)
    action, request_name, result_name, progress_name = sys.argv[1:5]
    request_path, result_path, progress_path = map(Path, (request_name, result_name, progress_name))
    try:
        request = json.loads(request_path.read_text(encoding="utf-8"))
        result = run(action, request, request_path.parent, progress_path)
        atomic_json(result_path, {"ok": True, "result": result})
    except Exception as exc:
        code = classify_error(exc)
        atomic_json(result_path, {"ok": False, "code": code, "error": safe_error(code)})
        sys.exit(1)


if __name__ == "__main__":
    main()
