from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import threading
import time
import uuid

from .config import Settings
from .policy import safe_error
from .store import Store


class ServiceIssue(Exception):
    def __init__(self, status: int, message: str):
        super().__init__(message)
        self.status, self.message = status, message


class Manager:
    def __init__(self, settings: Settings):
        settings.validate()
        self.settings = settings
        self.root = settings.data_dir.resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        self.root.chmod(0o700)
        self.work = self.root / "work"
        self.work.mkdir(exist_ok=True)
        self.store = Store(self.root / "sayl.sqlite3")
        self.pool = ThreadPoolExecutor(max_workers=settings.max_jobs, thread_name_prefix="sayl-job")
        self.inspect_slots = threading.BoundedSemaphore(2)
        self.guard = threading.RLock()
        self.stopping = threading.Event()
        self.processes: dict[str, subprocess.Popen] = {}
        for job in self.store.all():
            if job["state"] not in {"ready", "failed", "cancelled", "expired"}:
                self.store.update(job["id"], state="failed", error=safe_error("interrupted"), progress=None)
                shutil.rmtree(self.work / job["id"], ignore_errors=True)
        # Remove abandoned extraction directories only; never erase valid ready downloads.
        for path in self.work.glob("inspect-*"):
            shutil.rmtree(path, ignore_errors=True)
        self.cleaner = threading.Thread(target=self._janitor, daemon=True, name="sayl-retention")
        self.cleaner.start()

    def _directory(self, key: str) -> Path:
        directory = self.work / key
        directory.mkdir(mode=0o700, exist_ok=True)
        return directory

    def _terminate(self, process: subprocess.Popen) -> None:
        if process.poll() is None:
            try:
                if os.name == "posix":
                    os.killpg(process.pid, signal.SIGKILL)
                else:
                    process.kill()
                process.wait(timeout=5)
            except (ProcessLookupError, subprocess.TimeoutExpired):
                pass

    def _invoke(self, key: str, action: str, payload: dict, timeout: int) -> dict:
        directory = self._directory(key)
        request_file, result_file, progress_file = [directory / name for name in ("request.json", "result.json", "progress.json")]
        payload.update(max_bytes=self.settings.max_bytes, proxy=self.settings.proxy)
        request_file.write_text(json.dumps(payload), encoding="utf-8")
        request_file.chmod(0o600)
        env = os.environ.copy()
        # Children do not need the API token or unrelated host credentials.
        env = {k: v for k, v in env.items() if k in {"PATH", "PYTHONPATH", "LANG", "LC_ALL", "HOME", "SYSTEMROOT"}}
        process = subprocess.Popen(
            [sys.executable, "-m", self.settings.worker_module, action, str(request_file), str(result_file), str(progress_file)],
            stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            env=env, start_new_session=os.name == "posix",
        )
        with self.guard:
            self.processes[key] = process
        started = time.monotonic()
        try:
            while process.poll() is None:
                if self.stopping.is_set():
                    raise ServiceIssue(503, safe_error("interrupted"))
                if time.monotonic() - started > timeout:
                    raise ServiceIssue(504, safe_error("timeout"))
                if action == "download":
                    job = self.store.get(key)
                    if not job or job["state"] == "cancelled":
                        raise ServiceIssue(409, "أُلغي التنزيل")
                    if progress_file.exists():
                        try:
                            progress = json.loads(progress_file.read_text())
                            allowed = {k: v for k, v in progress.items() if k in {"state", "progress", "downloaded_bytes", "total_bytes", "speed"}}
                            if allowed.get("state") in {"preparing", "processing"}:
                                self.store.update(key, if_states={"queued", "preparing", "processing"}, **allowed)
                        except (OSError, ValueError):
                            pass
                total = sum(p.stat().st_size for p in directory.iterdir() if p.is_file())
                if total > self.settings.max_bytes * 3 + 8 * 1024**2:
                    raise ServiceIssue(413, safe_error("too_large"))
                if shutil.disk_usage(self.root).free < 64 * 1024**2:
                    raise ServiceIssue(507, safe_error("disk"))
                time.sleep(0.25)
            if not result_file.exists():
                raise ServiceIssue(502, safe_error("internal"))
            response = json.loads(result_file.read_text())
            if not response.get("ok"):
                raise ServiceIssue(422, response.get("error") or safe_error("internal"))
            return response["result"]
        finally:
            self._terminate(process)
            with self.guard:
                self.processes.pop(key, None)
            request_file.unlink(missing_ok=True)

    def inspect(self, url: str) -> dict:
        if not self.inspect_slots.acquire(blocking=False):
            raise ServiceIssue(429, "المحرك مشغول بفحص روابط أخرى. حاول بعد قليل.")
        key = "inspect-" + uuid.uuid4().hex
        try:
            result = self._invoke(key, "inspect", {"url": url}, self.settings.inspect_timeout)
            result.update(id=uuid.uuid4().hex, expires_at=time.time() + 900)
            self.store.put_inspection(result)
            return result
        finally:
            shutil.rmtree(self.work / key, ignore_errors=True)
            self.inspect_slots.release()

    def create(self, inspection_id: str, option_id: str) -> dict:
        with self.guard:
            active = [j for j in self.store.all() if j["state"] in {"queued", "preparing", "processing"}]
            if len(active) >= self.settings.queue_limit:
                raise ServiceIssue(429, "قائمة الانتظار ممتلئة. انتظر اكتمال بعض التنزيلات.")
            inspection = self.store.inspection(inspection_id)
            if not inspection:
                raise ServiceIssue(410, "انتهت صلاحية الفحص. افحص الرابط مجددًا.")
            selection = inspection.get("private_options", {}).get(option_id)
            if not selection:
                raise ServiceIssue(422, "اختر جودة موجودة في نتيجة الفحص")
            # A retry is an explicit new inspection/job. Repeated taps while pending return the same job.
            for existing in active:
                if existing.get("inspection_id") == inspection_id and existing.get("option_id") == option_id:
                    return existing
            now = time.time()
            key = uuid.uuid4().hex
            job = {"id": key, "title": inspection["title"], "state": "queued", "progress": None,
                   "downloaded_bytes": 0, "total_bytes": None, "speed": None, "error": None,
                   "created_at": now, "updated_at": now, "kind": selection["kind"], "ext": selection["ext"],
                   "size": None, "inspection_id": inspection_id, "option_id": option_id,
                   "source_url": inspection["webpage_url"]}
            self.store.add(job)
            self.pool.submit(self._run_job, key, inspection["webpage_url"], selection)
            return job

    def _run_job(self, key: str, url: str, selection: dict) -> None:
        job = self.store.update(key, if_states={"queued"}, state="preparing")
        if not job or job["state"] != "preparing":
            return
        try:
            result = self._invoke(key, "download", {"url": url, "selection": selection}, self.settings.job_timeout)
            directory = (self.work / key).resolve()
            path = (directory / result["path"]).resolve()
            if path.parent != directory or not path.is_file() or path.is_symlink() or not (0 < path.stat().st_size <= self.settings.max_bytes):
                raise ServiceIssue(502, safe_error("processing"))
            self.store.update(key, if_states={"preparing", "processing"}, state="ready", progress=1.0,
                              path=path.name, size=path.stat().st_size, speed=None)
        except Exception as exc:
            message = exc.message if isinstance(exc, ServiceIssue) else safe_error("internal")
            self.store.update(key, if_states={"queued", "preparing", "processing"}, state="failed", error=message, progress=None, speed=None)
        finally:
            state = (self.store.get(key) or {}).get("state")
            if state != "ready":
                shutil.rmtree(self.work / key, ignore_errors=True)

    def cancel(self, key: str) -> dict:
        with self.guard:
            job = self.store.get(key)
            if not job:
                raise ServiceIssue(404, "التنزيل غير موجود")
            job = self.store.update(key, state="cancelled", progress=None, path=None, size=None, speed=None)
            process = self.processes.get(key)
            if process:
                self._terminate(process)
            else:
                shutil.rmtree(self.work / key, ignore_errors=True)
            return job

    def file(self, key: str) -> tuple[Path, dict]:
        job = self.store.get(key)
        if not job:
            raise ServiceIssue(404, "التنزيل غير موجود")
        if job["state"] == "expired":
            raise ServiceIssue(410, safe_error("expired"))
        if job["state"] != "ready" or not job.get("path"):
            raise ServiceIssue(409, "الملف غير جاهز للنقل بعد")
        directory = (self.work / key).resolve()
        path = (directory / job["path"]).resolve()
        if path.parent != directory or not path.is_file():
            raise ServiceIssue(410, safe_error("expired"))
        return path, job

    def cleanup(self) -> None:
        cutoff = time.time() - self.settings.retention_hours * 3600
        for job in self.store.all():
            if job["state"] in {"ready", "failed", "cancelled"} and job["updated_at"] < cutoff:
                self.store.update(job["id"], state="expired", path=None, size=None, source_url=None, progress=None)
                shutil.rmtree(self.work / job["id"], ignore_errors=True)
        self.store.prune(time.time() - 7 * 86400)

    def _janitor(self) -> None:
        while not self.stopping.wait(60):
            self.cleanup()

    def close(self) -> None:
        self.stopping.set()
        with self.guard:
            for process in list(self.processes.values()):
                self._terminate(process)
        self.pool.shutdown(wait=True, cancel_futures=True)
        self.cleaner.join(timeout=2)
        self.store.close()
