from __future__ import annotations

from contextlib import asynccontextmanager
import hmac
from typing import Annotated

from fastapi import Depends, FastAPI, Header, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse
from starlette.concurrency import run_in_threadpool

from .config import Settings
from .manager import Manager, ServiceIssue
from .models import CreateJobRequest, Inspection, InspectRequest, JobView


def create_app(settings: Settings | None = None) -> FastAPI:
    # Defer environment validation until lifespan startup (keeps module imports testable).
    @asynccontextmanager
    async def lifespan(app: FastAPI):
        app.state.settings = settings or Settings.from_env()
        app.state.manager = Manager(app.state.settings)
        try:
            yield
        finally:
            await run_in_threadpool(app.state.manager.close)

    app = FastAPI(title="Sayl Private API", version="1.0.0", lifespan=lifespan,
                  docs_url=None, redoc_url=None, openapi_url=None)

    def owner(request: Request, authorization: Annotated[str | None, Header()] = None) -> None:
        wanted = "Bearer " + request.app.state.settings.token
        if not authorization or not hmac.compare_digest(authorization.encode(), wanted.encode()):
            raise HTTPException(status_code=401, detail="مفتاح الاتصال غير صحيح", headers={"WWW-Authenticate": "Bearer"})

    secured = [Depends(owner)]

    @app.middleware("http")
    async def security_headers(request: Request, call_next):
        # Small JSON requests only. This is not a multipart upload service.
        length = request.headers.get("content-length")
        if length and (not length.isdigit() or int(length) > 16384):
            return JSONResponse({"detail": "الطلب أكبر من المسموح"}, status_code=413)
        if request.headers.get("transfer-encoding"):
            return JSONResponse({"detail": "أرسل طلبًا بطول معروف"}, status_code=411)
        response = await call_next(request)
        response.headers["Cache-Control"] = "no-store"
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["Referrer-Policy"] = "no-referrer"
        return response

    @app.exception_handler(ServiceIssue)
    async def service_error(request: Request, exc: ServiceIssue):
        return JSONResponse({"detail": exc.message}, status_code=exc.status)

    @app.get("/health")
    def health():
        return {"status": "ok", "service": "sayl", "version": "1.0.0"}

    @app.get("/v1/health", dependencies=secured)
    def private_health(request: Request):
        import importlib.util
        import shutil
        return {"status": "ok", "engine_installed": importlib.util.find_spec("yt_dlp") is not None,
                "ffmpeg_installed": bool(shutil.which("ffmpeg") and shutil.which("ffprobe")),
                "egress_proxy_configured": bool(request.app.state.settings.proxy)}

    @app.post("/v1/inspect", dependencies=secured, response_model=Inspection)
    def inspect(body: InspectRequest, request: Request):
        return request.app.state.manager.inspect(body.url)

    @app.post("/v1/jobs", dependencies=secured, response_model=JobView, status_code=202)
    def create(body: CreateJobRequest, request: Request):
        return request.app.state.manager.create(body.inspection_id, body.option_id)

    @app.get("/v1/jobs", dependencies=secured, response_model=list[JobView])
    def jobs(request: Request):
        return request.app.state.manager.store.all()[:100]

    @app.get("/v1/jobs/{key}", dependencies=secured, response_model=JobView)
    def job(key: str, request: Request):
        result = request.app.state.manager.store.get(key)
        if not result:
            raise HTTPException(404, "التنزيل غير موجود")
        return result

    @app.delete("/v1/jobs/{key}", dependencies=secured, response_model=JobView)
    def cancel(key: str, request: Request):
        return request.app.state.manager.cancel(key)

    @app.api_route("/v1/jobs/{key}/file", methods=["GET", "HEAD"], dependencies=secured)
    def file(key: str, request: Request):
        path, job = request.app.state.manager.file(key)
        mime = "audio/mp4" if job["kind"] == "audio" else "video/mp4"
        # Starlette's FileResponse implements single/multi byte ranges and If-Range.
        return FileResponse(path, media_type=mime, filename=f"Sayl-{job['id']}.{job['ext']}")

    return app


app = create_app()
