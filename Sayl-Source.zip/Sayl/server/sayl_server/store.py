from __future__ import annotations

import json
import sqlite3
import time
from pathlib import Path
from threading import RLock
from typing import Any

TERMINAL = {"ready", "failed", "cancelled", "expired"}


class Store:
    def __init__(self, path: Path):
        path.parent.mkdir(parents=True, exist_ok=True)
        self.connection = sqlite3.connect(path, check_same_thread=False, timeout=15)
        self.connection.row_factory = sqlite3.Row
        self.lock = RLock()
        with self.lock, self.connection:
            self.connection.execute("PRAGMA journal_mode=WAL")
            self.connection.executescript("""
                CREATE TABLE IF NOT EXISTS inspections (id TEXT PRIMARY KEY, expires REAL NOT NULL, payload TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS jobs (id TEXT PRIMARY KEY, state TEXT NOT NULL, updated REAL NOT NULL, payload TEXT NOT NULL);
            """)

    def put_inspection(self, payload: dict) -> None:
        with self.lock, self.connection:
            self.connection.execute("INSERT INTO inspections VALUES (?,?,?)", (payload["id"], payload["expires_at"], json.dumps(payload)))
            self.connection.execute("DELETE FROM inspections WHERE expires < ?", (time.time(),))

    def inspection(self, key: str) -> dict | None:
        with self.lock:
            row = self.connection.execute("SELECT payload FROM inspections WHERE id=? AND expires>?", (key, time.time())).fetchone()
            return json.loads(row["payload"]) if row else None

    def add(self, payload: dict) -> None:
        with self.lock, self.connection:
            self.connection.execute("INSERT INTO jobs VALUES (?,?,?,?)", (payload["id"], payload["state"], payload["updated_at"], json.dumps(payload)))

    def get(self, key: str) -> dict | None:
        with self.lock:
            row = self.connection.execute("SELECT payload FROM jobs WHERE id=?", (key,)).fetchone()
            return json.loads(row["payload"]) if row else None

    def all(self) -> list[dict]:
        with self.lock:
            rows = self.connection.execute("SELECT payload FROM jobs ORDER BY updated DESC LIMIT 1000").fetchall()
            return [json.loads(row["payload"]) for row in rows]

    def update(self, key: str, *, if_states: set[str] | None = None, **changes: Any) -> dict | None:
        with self.lock, self.connection:
            payload = self.get(key)
            if not payload or (if_states is not None and payload["state"] not in if_states):
                return payload
            payload.update(changes)
            payload["updated_at"] = time.time()
            self.connection.execute("UPDATE jobs SET state=?,updated=?,payload=? WHERE id=?",
                                    (payload["state"], payload["updated_at"], json.dumps(payload), key))
            return payload

    def prune(self, older_than: float) -> None:
        with self.lock, self.connection:
            self.connection.execute("DELETE FROM jobs WHERE updated < ? AND state IN ('expired','cancelled','failed')", (older_than,))

    def close(self) -> None:
        with self.lock:
            self.connection.close()
