"""Input policy. The isolated Docker network + egress proxy are the SSRF boundary.

Checking an initial URL alone is NOT enough to protect extractors' nested requests.
"""
from __future__ import annotations

import ipaddress
import re
from urllib.parse import urlsplit, urlunsplit


BLOCKED_SUFFIXES = (".localhost", ".local", ".internal", ".lan", ".home", ".onion")


def clean_public_url(raw: str) -> str:
    raw = raw.strip()
    if re.search(r"[\x00-\x20\x7f\\]", raw):
        raise ValueError("الرابط يحتوي محارف غير صالحة")
    try:
        parts = urlsplit(raw)
        host = parts.hostname
        port = parts.port
    except ValueError as exc:
        raise ValueError("رابط غير صالح") from exc
    if parts.scheme.lower() not in {"https", "http"} or not host:
        raise ValueError("استخدم رابط HTTP أو HTTPS كاملًا")
    if parts.username is not None or parts.password is not None:
        raise ValueError("لا تُضمّن اسم مستخدم أو كلمة مرور في الرابط")
    if port is not None and port not in {80, 443}:
        raise ValueError("لا يُسمح بمنافذ مخصصة")
    host = host.rstrip(".").lower()
    if "%" in host or host == "localhost" or host.endswith(BLOCKED_SUFFIXES):
        raise ValueError("العناوين الداخلية غير مسموحة")
    try:
        address = ipaddress.ip_address(host)
    except ValueError:
        try:
            ascii_host = host.encode("idna").decode("ascii")
        except UnicodeError as exc:
            raise ValueError("اسم النطاق غير صالح") from exc
        if "." not in ascii_host or not re.fullmatch(r"[a-z0-9.-]+", ascii_host):
            raise ValueError("استخدم اسم نطاق عامًا")
    else:
        if not address.is_global or address.is_multicast:
            raise ValueError("العناوين الداخلية غير مسموحة")
    return urlunsplit((parts.scheme.lower(), parts.netloc, parts.path or "/", parts.query, ""))


def safe_error(code: str) -> str:
    return {
        "missing_engine": "محرك yt-dlp غير مثبت على الخادم. راجع دليل التشغيل.",
        "timeout": "استغرقت المهمة وقتًا أطول من الحد المسموح. جرّب جودة أقل أو رابطًا آخر.",
        "too_large": "الملف أكبر من الحد المسموح على الخادم.",
        "unsupported": "لم يُعثر على ملف قابل للتنزيل من هذا الرابط.",
        "playlist": "استخدم رابط مقطع واحد؛ تنزيل القوائم الكاملة غير مفعّل.",
        "live": "تسجيل البث المباشر غير متاح في هذه النسخة.",
        "drm": "هذا المحتوى محمي أو لا يتيح صيغة قابلة للتنزيل.",
        "authentication": "الموقع يطلب تسجيل دخول أو تحققًا. لا تُرسل كلمات مرورك إلى الخدمة.",
        "blocked": "الموقع رفض الطلب من الخادم. قد تكون هناك قيود وصول أو تغييرات في الموقع.",
        "processing": "تعذّر تجهيز ملف متوافق. تحقق من تثبيت FFmpeg ومساحة التخزين.",
        "interrupted": "أُعيد تشغيل الخادم أثناء المهمة. أعد المحاولة من الرابط.",
        "disk": "مساحة التخزين المتاحة على الخادم لا تكفي.",
        "expired": "انتهت مدة الاحتفاظ بالملف على الخادم. أعد فحص الرابط.",
        "internal": "تعذّرت المهمة. جرّب تحديث المحرك أو استخدام رابط آخر.",
    }.get(code, "تعذّرت المهمة. جرّب رابطًا آخر.")
