from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class Settings:
    token: str
    data_dir: Path
    proxy: str = ""
    max_bytes: int = 2 * 1024**3
    max_jobs: int = 2
    queue_limit: int = 12
    inspect_timeout: int = 75
    job_timeout: int = 2700
    retention_hours: int = 24
    worker_module: str = "sayl_server.worker"

    def validate(self) -> None:
        if len(self.token) < 32 or self.token.lower().startswith(("change", "replace")):
            raise ValueError("SAYL_TOKEN must be a randomly generated secret of at least 32 characters")
        if not (1 <= self.max_jobs <= 4):
            raise ValueError("SAYL_MAX_JOBS must be between 1 and 4")
        if not (1 <= self.retention_hours <= 168):
            raise ValueError("SAYL_RETENTION_HOURS must be between 1 and 168")
        if self.max_bytes < 1024 or self.queue_limit < self.max_jobs:
            raise ValueError("Invalid download limits")

    @classmethod
    def from_env(cls) -> "Settings":
        result = cls(
            token=os.getenv("SAYL_TOKEN", ""),
            data_dir=Path(os.getenv("SAYL_DATA_DIR", "./data")).resolve(),
            proxy=os.getenv("SAYL_EGRESS_PROXY", ""),
            max_bytes=int(os.getenv("SAYL_MAX_BYTES", str(2 * 1024**3))),
            max_jobs=int(os.getenv("SAYL_MAX_JOBS", "2")),
            queue_limit=int(os.getenv("SAYL_QUEUE_LIMIT", "12")),
            retention_hours=int(os.getenv("SAYL_RETENTION_HOURS", "24")),
        )
        result.validate()
        return result
