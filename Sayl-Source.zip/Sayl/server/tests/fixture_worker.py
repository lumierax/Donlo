"""Offline subprocess fixture: generates its own media, never contacts a website."""
import json
from pathlib import Path
import subprocess
import sys
import time
from sayl_server.worker import atomic_json
from sayl_server.formats import make_choices


def main():
    action, request_name, result_name, progress_name = sys.argv[1:5]
    request_path = Path(request_name)
    request = json.loads(request_path.read_text())
    if "fail" in request["url"]:
        atomic_json(Path(result_name), {"ok": False, "code": "unsupported", "error": "اختبار فشل مضبوط"})
        return
    if "slow" in request["url"]:
        for _ in range(40):
            atomic_json(Path(progress_name), {"state": "preparing", "progress": 0.2, "downloaded_bytes": 100})
            time.sleep(0.1)
    if action == "inspect":
        options, private = make_choices({"formats": [{"format_id": "v1", "ext": "mp4", "vcodec": "avc1.42001e", "acodec": "mp4a.40.2", "height": 720, "protocol": "https"}]})
        result = {"title": "ملف اختبار محلي", "webpage_url": request["url"], "source": "example.com", "duration": 1,
                  "thumbnail": None, "options": options, "private_options": private}
    else:
        target = request_path.parent / "ready.mp4"
        subprocess.run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-nostdin", "-y",
                        "-f", "lavfi", "-i", "color=c=black:s=160x90:r=12:d=1",
                        "-f", "lavfi", "-i", "sine=frequency=440:duration=1", "-c:v", "libx264", "-pix_fmt", "yuv420p",
                        "-c:a", "aac", "-shortest", "-movflags", "+faststart", str(target)], check=True)
        result = {"path": target.name, "size": target.stat().st_size}
    atomic_json(Path(result_name), {"ok": True, "result": result})


if __name__ == "__main__":
    main()
