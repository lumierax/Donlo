import time
from pathlib import Path
import pytest
from fastapi.testclient import TestClient
from sayl_server.api import create_app
from sayl_server.config import Settings

TOKEN = "test-token-" + "x" * 40
HEADERS = {"Authorization": "Bearer " + TOKEN}


@pytest.fixture
def client(tmp_path):
    settings = Settings(token=TOKEN, data_dir=tmp_path, max_bytes=8 * 1024**2, worker_module="tests.fixture_worker")
    with TestClient(create_app(settings)) as connection:
        yield connection


def inspect(client, url="https://example.com/movie"):
    response = client.post("/v1/inspect", headers=HEADERS, json={"url": url})
    assert response.status_code == 200, response.text
    return response.json()


def create(client, inspection):
    response = client.post("/v1/jobs", headers=HEADERS, json={"inspection_id": inspection["id"], "option_id": inspection["options"][0]["id"]})
    assert response.status_code == 202, response.text
    return response.json()


def wait_state(client, key, states=("ready", "failed")):
    deadline = time.monotonic() + 12
    while time.monotonic() < deadline:
        response = client.get("/v1/jobs/" + key, headers=HEADERS).json()
        if response["state"] in states:
            return response
        time.sleep(0.1)
    raise AssertionError("Fixture job did not settle")


def test_all_sensitive_endpoints_require_token(client):
    for path in ["/v1/health", "/v1/jobs", "/v1/jobs/notreal", "/v1/jobs/notreal/file"]:
        assert client.get(path).status_code == 401
    assert client.post("/v1/inspect", json={"url": "https://example.com/a"}).status_code == 401
    assert client.post("/v1/jobs", json={"inspection_id": "x", "option_id": "y"}).status_code == 401
    assert client.delete("/v1/jobs/x").status_code == 401
    assert client.get("/health").status_code == 200
    assert client.get("/docs").status_code == 404


def test_private_extractor_selectors_do_not_leave_api(client):
    inspection = inspect(client)
    assert "private_options" not in inspection
    assert "selector" not in str(inspection)
    assert inspection["options"][0]["height"] == 720
    assert "no-store" in client.get("/health").headers["cache-control"]


def test_actual_subprocess_job_file_and_range_round_trip(client):
    job = create(client, inspect(client))
    ready = wait_state(client, job["id"])
    assert ready["state"] == "ready", ready
    assert ready["size"] > 100
    assert "path" not in ready and "source_url" not in ready
    route = f"/v1/jobs/{job['id']}/file"
    full = client.get(route, headers=HEADERS)
    assert full.status_code == 200
    assert len(full.content) == ready["size"]
    assert b"ftyp" in full.content[:64]
    assert full.headers["content-type"] == "video/mp4"
    partial = client.get(route, headers={**HEADERS, "Range": "bytes=3-12"})
    assert partial.status_code == 206
    assert partial.content == full.content[3:13]
    assert partial.headers["content-range"] == f"bytes 3-12/{len(full.content)}"
    assert client.head(route, headers=HEADERS).content == b""
    assert client.get(route).status_code == 401
    assert client.get(route, headers={**HEADERS, "Range": f"bytes={len(full.content)+20}-"}).status_code == 416
    cancelled = client.delete(f"/v1/jobs/{job['id']}", headers=HEADERS)
    assert cancelled.json()["state"] == "cancelled"
    assert client.get(route, headers=HEADERS).status_code == 409


def test_expired_inspection_and_selector_injection(client):
    inspection = inspect(client)
    assert client.post("/v1/jobs", headers=HEADERS, json={"inspection_id": "missing", "option_id": "video_720"}).status_code == 410
    assert client.post("/v1/jobs", headers=HEADERS, json={"inspection_id": inspection["id"], "option_id": "../../etc/passwd"}).status_code == 422
    assert client.post("/v1/jobs", headers=HEADERS, json={"inspection_id": inspection["id"], "option_id": "arbitrary"}).status_code == 422


def test_duplicate_active_creation_is_idempotent_and_cancel_is_terminal(client):
    inspection = inspect(client)
    stored = client.app.state.manager.store.inspection(inspection["id"])
    stored["webpage_url"] += "?slow=1"
    # Replace test payload directly; public clients cannot mutate an inspection.
    store = client.app.state.manager.store
    import json
    with store.lock, store.connection:
        store.connection.execute("UPDATE inspections SET payload=? WHERE id=?", (json.dumps(stored), inspection["id"]))
    first = create(client, inspection)
    second = create(client, inspection)
    assert first["id"] == second["id"]
    time.sleep(0.4)
    response = client.delete("/v1/jobs/" + first["id"], headers=HEADERS)
    assert response.json()["state"] == "cancelled"
    time.sleep(0.5)
    assert client.get("/v1/jobs/" + first["id"], headers=HEADERS).json()["state"] == "cancelled"


def test_retention_expires_ready_file(client):
    job = create(client, inspect(client))
    wait_state(client, job["id"])
    store = client.app.state.manager.store
    payload = store.get(job["id"])
    payload["updated_at"] = time.time() - 90_000
    import json
    with store.lock, store.connection:
        store.connection.execute("UPDATE jobs SET updated=?,payload=? WHERE id=?", (payload["updated_at"], json.dumps(payload), job["id"]))
    client.app.state.manager.cleanup()
    assert client.get(f"/v1/jobs/{job['id']}", headers=HEADERS).json()["state"] == "expired"
    assert client.get(f"/v1/jobs/{job['id']}/file", headers=HEADERS).status_code == 410


def test_bad_input_and_bounded_body(client):
    assert client.post("/v1/inspect", headers=HEADERS, json={"url": "file:///etc/passwd"}).status_code == 422
    response = client.post("/v1/inspect", headers={**HEADERS, "Content-Type": "application/json"}, content=b"x" * 17000)
    assert response.status_code == 413


def test_fixture_failure_returns_clean_message(client):
    response = client.post("/v1/inspect", headers=HEADERS, json={"url": "https://example.com/fail"})
    assert response.status_code == 422
    assert response.json()["detail"] == "اختبار فشل مضبوط"


def test_missing_engine_has_honest_health_flag(client):
    result = client.get("/v1/health", headers=HEADERS).json()
    assert isinstance(result["engine_installed"], bool)
    assert result["ffmpeg_installed"] is True


def test_weak_token_rejected(tmp_path):
    with pytest.raises(ValueError):
        Settings(token="short", data_dir=tmp_path).validate()
