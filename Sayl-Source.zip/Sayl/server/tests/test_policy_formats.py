import socket
from unittest.mock import patch
import pytest
from sayl_server.policy import clean_public_url
from sayl_server.formats import MediaIssue, make_choices
from egress.proxy import Denied, public_endpoints


@pytest.mark.parametrize("url", [
    "file:///etc/passwd", "ftp://example.com/a", "https://u:p@example.com/v",
    "http://127.0.0.1/a", "http://10.0.0.1/", "http://192.168.1.1/", "http://169.254.169.254/",
    "http://[::1]/", "http://[::ffff:127.0.0.1]/", "https://localhost/", "https://server.local/a",
    "https://example.com:8765/a", "https://example.com/\nx", "https://example.com\\@evil.test/",
    "https://2130706433/", "https://localhost.localdomain/\x00",
])
def test_rejects_dangerous_initial_urls(url):
    with pytest.raises(ValueError):
        clean_public_url(url)


def test_normalization_keeps_signed_query_and_drops_fragment():
    assert clean_public_url("https://example.com/video?sig=abc#player") == "https://example.com/video?sig=abc"


@pytest.mark.parametrize("ip", ["127.0.0.1", "10.0.0.1", "169.254.169.254", "192.168.1.2", "::1", "fc00::1", "224.0.0.1"])
def test_proxy_rejects_nonpublic_dns(ip):
    answer = [(socket.AF_INET6 if ":" in ip else socket.AF_INET, socket.SOCK_STREAM, 6, "", (ip, 443))]
    with patch("socket.getaddrinfo", return_value=answer), pytest.raises(Denied):
        public_endpoints("example.com", 443)


def test_proxy_rejects_mixed_public_and_private_dns():
    answers = [(socket.AF_INET, socket.SOCK_STREAM, 6, "", (ip, 443)) for ip in ["8.8.8.8", "127.0.0.1"]]
    with patch("socket.getaddrinfo", return_value=answers), pytest.raises(Denied):
        public_endpoints("example.com", 443)


def test_proxy_returns_validated_sockaddr_without_second_resolution():
    answers = [(socket.AF_INET, socket.SOCK_STREAM, 6, "", ("8.8.8.8", 443))]
    with patch("socket.getaddrinfo", return_value=answers) as resolve:
        result = public_endpoints("example.com", 443)
        assert result[0][3] == ("8.8.8.8", 443)
        assert resolve.call_count == 1


def test_proxy_blocks_custom_port_before_dns():
    with patch("socket.getaddrinfo") as resolve, pytest.raises(Denied):
        public_endpoints("example.com", 22)
    resolve.assert_not_called()


def media_format(fid, *, height=None, video="avc1.4", audio="none", ext="mp4", protocol="https", **extra):
    return {"format_id": fid, "height": height, "vcodec": video, "acodec": audio, "ext": ext, "protocol": protocol, **extra}


def test_separate_video_is_paired_with_audio_and_actual_resolutions_only():
    choices, private = make_choices({"formats": [media_format("v720", height=720, filesize=100), media_format("v1080", height=1080, filesize=200),
                                                      media_format("a", video="none", audio="mp4a.40.2", ext="m4a", filesize=50)]})
    assert [x["id"] for x in choices] == ["video_1080", "video_720", "audio_m4a"]
    assert private["video_1080"]["selector"] == "v1080+a"
    assert choices[0]["bytes_estimate"] == 250
    assert choices[0]["has_audio"] is True


def test_no_audio_is_reported_honestly():
    choices, _ = make_choices({"formats": [media_format("v", height=480)]})
    assert choices[0]["has_audio"] is False
    assert len(choices) == 1


def test_unsafe_ids_drm_and_unsupported_protocols_are_filtered():
    choices, private = make_choices({"formats": [media_format("x;touch /tmp/a", height=1080),
                                                  media_format("safe", height=720, audio="aac"),
                                                  media_format("drm", height=2160, has_drm=True),
                                                  media_format("rtmp", height=1080, protocol="rtmp")]})
    assert "video_2160" not in private
    assert "video_1080" not in private
    assert choices[0]["id"] == "video_720"


@pytest.mark.parametrize("value,code", [({"entries": []}, "playlist"), ({"is_live": True}, "live"), ({"has_drm": True}, "drm"), ({"formats": []}, "unsupported")])
def test_rejects_unbounded_and_protected_media(value, code):
    with pytest.raises(MediaIssue) as error:
        make_choices(value)
    assert error.value.code == code


def test_unknown_filesize_stays_unknown_and_huge_resolution_not_offered():
    choices, _ = make_choices({"formats": [media_format("small", height=720), media_format("huge", height=4320)]})
    assert choices[0]["bytes_estimate"] is None
    assert len(choices) == 1


def test_generic_video_with_unknown_codecs_is_offered_without_inventing_audio():
    choices, private = make_choices({"formats": [{"format_id": "generic", "ext": "mp4", "protocol": "https"}]})
    assert choices[0]["id"] == "video_0"
    assert choices[0]["has_audio"] is None
    assert private["video_0"]["require_audio"] is False
    assert len(choices) == 1


def test_advertised_audio_is_required_during_verification():
    choices, private = make_choices({"formats": [media_format("muxed", height=720, audio="aac")]})
    assert choices[0]["has_audio"] is True
    assert private["video_720"]["require_audio"] is True
