"""Exercise the production FFmpeg path, using locally generated media (no website)."""
from pathlib import Path
import subprocess
import pytest
from sayl_server.worker import compatible_file, probe
from sayl_server.formats import MediaIssue

LIMIT = 8 * 1024 * 1024


def generate(directory: Path, *, audio=True, codec="mpeg4") -> Path:
    source = directory / "fixture.mkv"
    command = ["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-f", "lavfi", "-i", "color=c=gray:s=160x90:d=0.6:r=10"]
    if audio:
        command += ["-f", "lavfi", "-i", "sine=frequency=440:duration=0.6", "-shortest", "-c:a", "pcm_s16le"]
    command += ["-c:v", codec, str(source)]
    subprocess.run(command, check=True, timeout=15, capture_output=True)
    return source


def test_real_conversion_preserves_audio_and_makes_iphone_container(tmp_path):
    output = compatible_file(generate(tmp_path), tmp_path, "video", tmp_path / "progress.json", LIMIT, require_audio=True)
    metadata = probe(output)
    assert output.name == "ready.mp4"
    assert {stream["codec_name"] for stream in metadata["streams"]} == {"h264", "aac"}
    assert float(metadata["format"]["duration"]) > 0.4


def test_real_audio_extraction(tmp_path):
    output = compatible_file(generate(tmp_path), tmp_path, "audio", tmp_path / "progress.json", LIMIT)
    assert output.name == "ready.m4a"
    assert {stream["codec_type"] for stream in probe(output)["streams"]} == {"audio"}


def test_real_copy_of_compatible_h264(tmp_path):
    output = compatible_file(generate(tmp_path, codec="libx264"), tmp_path, "video", tmp_path / "progress.json", LIMIT)
    assert "h264" in {stream["codec_name"] for stream in probe(output)["streams"]}


def test_missing_promised_audio_is_not_a_success(tmp_path):
    with pytest.raises(MediaIssue, match="processing"):
        compatible_file(generate(tmp_path, audio=False), tmp_path, "video", tmp_path / "progress.json", LIMIT, require_audio=True)


def test_html_disguised_as_video_is_rejected(tmp_path):
    source = tmp_path / "bad.mp4"
    source.write_text("<html>login required</html>")
    with pytest.raises(subprocess.CalledProcessError):
        compatible_file(source, tmp_path, "video", tmp_path / "progress.json", LIMIT)
