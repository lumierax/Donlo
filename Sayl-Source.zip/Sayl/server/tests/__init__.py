# Test-only fixtures. Not copied into the production Docker image.
