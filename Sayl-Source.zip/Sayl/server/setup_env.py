#!/usr/bin/env python3
"""Create a private local API token. Existing .env files are never overwritten."""
import os
from pathlib import Path
import secrets

path = Path(__file__).parent / ".env"
try:
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, "w") as handle:
        handle.write("SAYL_TOKEN=" + secrets.token_urlsafe(40) + "\n")
        handle.write("SAYL_RETENTION_HOURS=24\nSAYL_MAX_BYTES=2147483648\n")
except FileExistsError:
    raise SystemExit(".env exists; no changes made.")
print("Created server/.env (mode 0600). Copy its SAYL_TOKEN into the iPhone app settings; do not commit or share it.")
