# Source references and third-party notices

## Original implementation

Sayl is a new standalone implementation. No Swift, JavaScript, image, icon, or UI asset was copied from the uploaded Madar archive. The archive's readme, architecture description and platform metadata informed the desired product scope only. It is not distributed in this project.

YTKACE was used as a conceptual reference for quality selection, download queue and local library. Its public README and third-party notices were consulted; the full upstream source was not imported or exhaustively audited. No tweak/hooking/YouTube-injection code was copied. Sayl is not an endorsed fork or a rebranding of YTKACE.

Reference: https://github.com/itzzace/ytkace
Upstream license: https://github.com/itzzace/ytkace/blob/main/LICENSE
Upstream notices: https://github.com/itzzace/ytkace/blob/main/THIRD_PARTY_NOTICES.md

## Runtime dependencies, downloaded separately

The ZIP does not include dependency source distributions, compiled frameworks or container image layers. Docker/pip obtains dependencies when the owner builds. Their own licenses govern those components and must be retained and reviewed when redistributing a built image or binary.

- yt-dlp and its default extras / yt-dlp-ejs: https://github.com/yt-dlp/yt-dlp ; https://github.com/yt-dlp/yt-dlp/wiki/EJS
- FFmpeg/ffprobe: https://ffmpeg.org/legal.html — licensing depends on the actual build configuration, including enabled codecs. The server uses Debian packages and libx264; inspect and comply with the built packages before redistribution. No FFmpeg binary is embedded in the iOS target.
- FastAPI: https://github.com/fastapi/fastapi
- Starlette: https://github.com/Kludex/starlette
- Pydantic: https://github.com/pydantic/pydantic
- Uvicorn: https://github.com/encode/uvicorn
- Python: https://docs.python.org/3/license.html
- Node.js: https://github.com/nodejs/node/blob/main/LICENSE
- Development only: pytest, HTTPX, Playwright, Pillow and Swift/XCTest, each under its upstream license. No font file is bundled.

SwiftUI, Foundation, UIKit, WebKit, LocalAuthentication, Security and AVFoundation are platform frameworks supplied by Apple, not vendored code in this archive.

## Technical references

- Supported site caveat: https://github.com/yt-dlp/yt-dlp/blob/master/supportedsites.md
- yt-dlp requirements and dependency guidance: https://github.com/yt-dlp/yt-dlp#dependencies
- Native downloader selection: https://github.com/yt-dlp/yt-dlp/blob/master/yt_dlp/downloader/__init__.py
- Apple background downloads: https://developer.apple.com/documentation/foundation/downloading-files-in-the-background
- Device distribution/signing: https://developer.apple.com/documentation/xcode/distributing-your-app-to-registered-devices
- Required-reason privacy manifest: https://developer.apple.com/documentation/technotes/tn3183-adding-required-reason-api-entries-to-your-privacy-manifest

Readme pages are not a compatibility certification. Site support changes; build versions and live smoke tests must be recorded for each deployment.
