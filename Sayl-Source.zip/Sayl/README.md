# سَيْل · Sayl

مشروع iPhone مستقل بواجهة عربية، مع محرك تنزيلات موسّع اختياري تستضيفه بنفسك.

**تحديث PiP:** زر صورة داخل صورة مستقل وإصلاح دورة حياة المشغّل وقفل الخلفية. راجع [تفاصيل الإصلاح والاختبارات](docs/PIP_FIX_AR.md). لم يُبنَ التطبيق أو يُختبر على iPhone في هذه البيئة.

ابدأ من [الدليل العربي](README_AR.md). افتح `iOS/Sayl.xcodeproj` على Mac.

- [تقرير الاختبارات وحدود التحقق](docs/TEST_REPORT_AR.md)
- [تشغيل المحرك](docs/SERVER_SETUP_AR.md)
- [حدود الأمان والخصوصية](docs/SECURITY_AR.md)
- [المعاينة التفاعلية](preview/index.html)

Source delivery only. Not a signed IPA. iOS compilation, device behavior and live website extraction were not tested in the delivery environment. Offline test results are documented, not a universal-site guarantee.
