import XCTest
@testable import SaylCore

final class PlaybackLifetimeTests: XCTestCase {
    func testOrdinaryInlineDismissalDoesNotRetainPlayback() {
        let state = PlaybackLifetime()
        XCTAssertEqual(state.phase, .inline)
        XCTAssertFalse(state.retainsSession)
        XCTAssertFalse(state.isTransitioning)
    }
    func testSessionIsRetainedBeforeDidStartArrives() {
        var state = PlaybackLifetime()
        state.willStart()
        XCTAssertEqual(state.phase, .starting)
        XCTAssertTrue(state.retainsSession)
        XCTAssertTrue(state.isTransitioning)
    }
    func testActivePiPRemainsRetainedWithoutBeingATransition() {
        var state = PlaybackLifetime()
        state.willStart()
        state.didStart()
        XCTAssertEqual(state.phase, .active)
        XCTAssertTrue(state.retainsSession)
        XCTAssertFalse(state.isTransitioning)
    }
    func testStopAnimationRetainsTheSourceLayer() {
        var state = PlaybackLifetime()
        state.willStart()
        state.didStart()
        state.willStop()
        XCTAssertEqual(state.phase, .stopping)
        XCTAssertTrue(state.retainsSession)
        XCTAssertTrue(state.isTransitioning)
    }
    func testFailedStartAllowsRetryAndDismissal() {
        var state = PlaybackLifetime()
        state.willStart()
        state.failedToStart()
        XCTAssertEqual(state, PlaybackLifetime())
        state.willStart()
        state.didStart()
        XCTAssertEqual(state.phase, .active)
    }
    func testClosingPiPWithoutRestoringStopsPlayback() {
        var state = PlaybackLifetime()
        state.willStart()
        state.didStart()
        state.willStop()
        XCTAssertTrue(state.didStop())
        XCTAssertEqual(state, PlaybackLifetime())
    }
    func testSystemRestorePreservesInlinePlayback() {
        var state = PlaybackLifetime()
        state.willStart()
        state.didStart()
        state.requestInlineReturn()
        state.willStop()
        XCTAssertFalse(state.didStop())
        XCTAssertEqual(state.phase, .inline)
        XCTAssertFalse(state.retainsSession)
    }
    func testRestoreMayArriveAfterWillStop() {
        var state = PlaybackLifetime()
        state.willStart()
        state.didStart()
        state.willStop()
        state.requestInlineReturn()
        XCTAssertFalse(state.didStop())
    }
    func testFailedRestorationDoesNotLeaveOrphanAudio() {
        var state = PlaybackLifetime()
        state.willStart()
        state.didStart()
        state.requestInlineReturn()
        state.restorationFailed()
        state.willStop()
        XCTAssertTrue(state.didStop())
    }
    func testStartingNewPiPClearsPreviousRestorationIntent() {
        var state = PlaybackLifetime()
        state.requestInlineReturn()
        state.willStart()
        state.didStart()
        XCTAssertFalse(state.returningToInline)
        XCTAssertTrue(state.didStop())
    }
    func testStopResetsRestorationForTheNextSession() {
        var state = PlaybackLifetime()
        state.willStart()
        state.didStart()
        state.requestInlineReturn()
        XCTAssertFalse(state.didStop())
        state.willStart()
        state.didStart()
        XCTAssertTrue(state.didStop())
    }
    func testBackgroundPrivacyLockDoesNotStopAuthorizedPlayback() {
        XCTAssertFalse(PlaybackLifetime.shouldStopForPrivacyLock(unlocked: false, backgroundLocked: true))
    }
    func testManualPrivacyLockStopsPlayback() {
        XCTAssertTrue(PlaybackLifetime.shouldStopForPrivacyLock(unlocked: false, backgroundLocked: false))
    }
    func testUnlockDoesNotStopPlaybackRegardlessOfPublicationOrder() {
        XCTAssertFalse(PlaybackLifetime.shouldStopForPrivacyLock(unlocked: true, backgroundLocked: true))
        XCTAssertFalse(PlaybackLifetime.shouldStopForPrivacyLock(unlocked: true, backgroundLocked: false))
    }
}
