import XCTest
@testable import SaylCore

final class LinkRulesTests: XCTestCase {
    func testNormalizesMissingSchemeAndStripsFragment() throws {
        let url = try LinkRules.parse("  example.com/watch?id=2#player  ")
        XCTAssertEqual(url.absoluteString, "https://example.com/watch?id=2")
    }
    func testRejectsInsecureAndExecutableSchemes() {
        for input in ["http://example.com/a.mp4", "file:///etc/passwd", "javascript:alert(1)", "data:text/html,test", "ftp://example.com/a"] {
            XCTAssertThrowsError(try LinkRules.parse(input), input)
        }
    }
    func testRejectsCredentials() {
        XCTAssertThrowsError(try LinkRules.parse("https://name:secret@example.com/movie.mp4"))
    }
    func testRejectsControlCharactersAndBackslash() {
        XCTAssertThrowsError(try LinkRules.parse("https://exam\nple.com"))
        XCTAssertThrowsError(try LinkRules.parse("https://example.com\\@other.com"))
    }
    func testEmptyAndOverlongURL() {
        XCTAssertThrowsError(try LinkRules.parse(" "))
        XCTAssertThrowsError(try LinkRules.parse("https://example.com/" + String(repeating: "x", count: 9000)))
    }
    func testOriginComparisonIncludesSchemeAndEffectivePort() {
        XCTAssertTrue(LinkRules.sameOrigin(URL(string: "https://EXAMPLE.com/a")!, URL(string: "https://example.com:443/b")!))
        XCTAssertFalse(LinkRules.sameOrigin(URL(string: "https://example.com")!, URL(string: "https://example.com:8443")!))
        XCTAssertFalse(LinkRules.sameOrigin(URL(string: "https://example.com")!, URL(string: "http://example.com")!))
        XCTAssertFalse(LinkRules.sameOrigin(URL(string: "https://example.com")!, URL(string: "https://example.com.evil.test")!))
    }
    func testServerRequiresTLSOutsideExplicitLoopbackDevelopment() throws {
        XCTAssertThrowsError(try LinkRules.server("http://localhost:8765"))
        XCTAssertNoThrow(try LinkRules.server("http://localhost:8765", allowLoopbackHTTP: true))
        XCTAssertThrowsError(try LinkRules.server("http://192.168.1.2:8765", allowLoopbackHTTP: true))
        XCTAssertThrowsError(try LinkRules.server("https://example.com/api"))
        XCTAssertThrowsError(try LinkRules.server("https://example.com?token=secret"))
        XCTAssertEqual(try LinkRules.server("https://example.com/").absoluteString, "https://example.com")
    }
    func testSearchEncodesArabicAndQuerySeparators() throws {
        let query = "تعلم & جودة=1080"
        let url = try LinkRules.searchURL(template: "https://example.com/search?q={query}", query: query)
        let items = URLComponents(url: url, resolvingAgainstBaseURL: false)!.queryItems!
        XCTAssertEqual(items.count, 1)
        XCTAssertEqual(items.first?.value, query)
    }
    func testSearchPlaceholderRestrictions() {
        XCTAssertThrowsError(try LinkRules.searchURL(template: "https://example.com", query: "a"))
        XCTAssertThrowsError(try LinkRules.searchURL(template: "https://{query}.example.com", query: "evil"))
        XCTAssertThrowsError(try LinkRules.searchURL(template: "https://example.com?q={query}&b={query}", query: "a"))
        XCTAssertThrowsError(try LinkRules.searchURL(template: "https://example.com?q={query}", query: " "))
    }
    func testDirectMediaDoesNotInventQuality() throws {
        let result = LinkRules.directInspection(for: try LinkRules.parse("https://cdn.example.com/My%20Video.mp4?sig=1"))
        XCTAssertEqual(result?.title, "My Video")
        XCTAssertEqual(result?.options.count, 1)
        XCTAssertEqual(result?.options.first?.label, "الملف الأصلي")
        XCTAssertNil(result?.options.first?.height)
        XCTAssertNil(result?.options.first?.bytesEstimate)
    }
    func testManifestsAndWebpagesDoNotBecomeFakeMP4Files() throws {
        for path in ["live.m3u8", "stream.mpd", "watch?v=5", "page.html"] {
            XCTAssertNil(LinkRules.directInspection(for: try LinkRules.parse("https://example.com/" + path)))
        }
    }
    func testAudioClassificationAndSafeFilenames() throws {
        XCTAssertEqual(LinkRules.directInspection(for: try LinkRules.parse("https://example.com/a.M4A"))?.options.first?.kind, .audio)
        let id = UUID()
        XCTAssertEqual(LinkRules.safeFilename(id: id, ext: "../../MP4"), id.uuidString + ".mp4")
        XCTAssertFalse(LinkRules.safeFilename(id: id, ext: "../../").contains("/"))
    }
}

final class ModelTests: XCTestCase {
    func testAPIContractDecoding() throws {
        let raw = #"{"id":"abc","title":"مثال","webpage_url":"https://example.com/watch","source":"example.com","duration":6.5,"thumbnail":null,"options":[{"id":"video_720","label":"720p","kind":"video","ext":"mp4","height":720,"bytes_estimate":1234,"has_audio":true}],"expires_at":1900000000}"#
        let decoder = JSONDecoder(); decoder.keyDecodingStrategy = .convertFromSnakeCase
        let media = try decoder.decode(MediaInspection.self, from: Data(raw.utf8))
        XCTAssertEqual(media.options.first?.bytesEstimate, 1234)
        XCTAssertEqual(media.options.first?.hasAudio, true)
        XCTAssertNil(media.options.first?.directUrl)
        XCTAssertFalse(media.isLocal)
    }
    func testRemoteJobContract() throws {
        let raw = #"{"id":"123","title":"a","state":"preparing","progress":null,"downloaded_bytes":0,"total_bytes":null,"speed":null,"error":null,"created_at":1,"updated_at":2,"kind":"video","ext":"mp4","size":null}"#
        let decoder = JSONDecoder(); decoder.keyDecodingStrategy = .convertFromSnakeCase
        let job = try decoder.decode(RemoteJob.self, from: Data(raw.utf8))
        XCTAssertEqual(job.state, "preparing")
        XCTAssertNil(job.progress)
    }
    func testTransferRoundTripPreservesRecoveryContext() throws {
        var record = TransferRecord(title: "فيديو", sourceUrl: URL(string: "https://example.com/watch")!, kind: .video, ext: "mp4")
        record.remoteJobId = "job-1"; record.remoteBaseUrl = URL(string: "https://server.example.com")
        record.stagingName = "stage.mp4"; record.state = .verifying
        let output = try JSONDecoder().decode(TransferRecord.self, from: JSONEncoder().encode(record))
        XCTAssertEqual(output.id, record.id)
        XCTAssertEqual(output.state, .verifying)
        XCTAssertEqual(output.remoteJobId, "job-1")
        XCTAssertEqual(output.stagingName, "stage.mp4")
    }
    func testUnknownAndClampedProgress() {
        var record = TransferRecord(title: "a", sourceUrl: URL(string: "https://example.com/a.mp4")!, kind: .video, ext: "mp4")
        XCTAssertNil(record.progress)
        record.expected = 0; XCTAssertNil(record.progress)
        record.expected = 10; record.received = 20; XCTAssertEqual(record.progress, 1)
        record.received = -2; XCTAssertEqual(record.progress, 0)
    }
    func testOnlyCurrentRunningTaskCanUpdateTransfer() {
        XCTAssertTrue(TransferRules.acceptsNetworkEvent(state: .receiving, currentTaskIdentifier: 7, eventTaskIdentifier: 7))
        XCTAssertFalse(TransferRules.acceptsNetworkEvent(state: .receiving, currentTaskIdentifier: 8, eventTaskIdentifier: 7))
        XCTAssertFalse(TransferRules.acceptsNetworkEvent(state: .receiving, currentTaskIdentifier: nil, eventTaskIdentifier: 7))
        for state: TransferState in [.paused, .cancelled, .completed, .verifying, .queued, .failed] {
            XCTAssertFalse(TransferRules.acceptsNetworkEvent(state: state, currentTaskIdentifier: 7, eventTaskIdentifier: 7))
        }
    }
    func testTerminalAndRetryStateLabels() {
        XCTAssertTrue(TransferState.receiving.isActive)
        XCTAssertFalse(TransferState.completed.isActive)
        XCTAssertTrue(TransferState.failed.canRetry)
        XCTAssertFalse(TransferState.completed.canRetry)
        XCTAssertFalse(TransferState.paused.label.isEmpty)
    }
}

final class DisplayTests: XCTestCase {
    func testUnknownByteCountRemainsUnknown() {
        XCTAssertEqual(DisplayText.bytes(nil), "حجم غير معروف")
        XCTAssertEqual(DisplayText.bytes(-1), "حجم غير معروف")
        XCTAssertEqual(DisplayText.bytes(0), "0 بايت")
        XCTAssertEqual(DisplayText.bytes(1024 * 1024), "1.0 م.ب")
    }
    func testDurationAndNonFiniteValues() {
        XCTAssertEqual(DisplayText.duration(65), "1:05")
        XCTAssertEqual(DisplayText.duration(3661), "1:01:01")
        XCTAssertEqual(DisplayText.duration(.nan), "—")
        XCTAssertEqual(DisplayText.duration(-2), "—")
    }
    func testPercentNeverInventsUnknownProgress() {
        XCTAssertEqual(DisplayText.percent(nil), "—")
        XCTAssertEqual(DisplayText.percent(.infinity), "—")
        XCTAssertEqual(DisplayText.percent(0.5), "50٪")
        XCTAssertEqual(DisplayText.percent(2), "100٪")
    }
}
