import Foundation

public enum LinkRules {
    public static let directExtensions: Set<String> = ["mp4", "mov", "m4v", "m4a", "mp3", "aac", "wav", "caf"]
    public static let manifests: Set<String> = ["m3u8", "mpd"]
    public static let audioExtensions: Set<String> = ["m4a", "mp3", "aac", "wav", "caf"]

    public static func parse(_ input: String) throws -> URL {
        var text = input.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty, text.utf8.count <= 8192,
              !text.contains("\\"), !text.unicodeScalars.contains(where: { CharacterSet.controlCharacters.contains($0) }) else {
            throw SaylError.message("ألصق رابطًا صالحًا أولًا.")
        }
        if !text.contains("://") { text = "https://" + text }
        guard var parts = URLComponents(string: text), parts.scheme?.lowercased() == "https",
              let host = parts.host, !host.isEmpty, host.contains(".") || host.contains(":"),
              parts.user == nil, parts.password == nil else {
            throw SaylError.message("استخدم رابط HTTPS كاملًا، دون كلمات مرور داخل الرابط.")
        }
        parts.fragment = nil
        guard let result = parts.url else { throw SaylError.message("تعذّر قراءة هذا الرابط.") }
        return result
    }

    public static func sameOrigin(_ first: URL, _ second: URL) -> Bool {
        first.scheme?.lowercased() == second.scheme?.lowercased()
        && first.host?.lowercased() == second.host?.lowercased()
        && (first.port ?? (first.scheme == "https" ? 443 : 80)) == (second.port ?? (second.scheme == "https" ? 443 : 80))
    }

    public static func server(_ text: String, allowLoopbackHTTP: Bool = false) throws -> URL {
        guard var parts = URLComponents(string: text.trimmingCharacters(in: .whitespacesAndNewlines)),
              let host = parts.host, !host.isEmpty, parts.user == nil, parts.password == nil,
              parts.query == nil, parts.fragment == nil else {
            throw SaylError.message("أدخل عنوان الخادم كاملًا مثل https://media.example.com")
        }
        let local = ["localhost", "127.0.0.1", "::1"].contains(host.lowercased())
        guard parts.scheme == "https" || (allowLoopbackHTTP && local && parts.scheme == "http") else {
            throw SaylError.message("اتصال الخادم يتطلب HTTPS لحماية مفتاحك وروابطك.")
        }
        if parts.path == "/" { parts.path = "" }
        guard parts.path.isEmpty, let url = parts.url else {
            throw SaylError.message("استخدم عنوان النطاق فقط دون مسار إضافي.")
        }
        return url
    }

    public static func directInspection(for url: URL, title: String? = nil) -> MediaInspection? {
        let ext = url.pathExtension.lowercased()
        guard directExtensions.contains(ext) else { return nil }
        let kind: MediaKind = audioExtensions.contains(ext) ? .audio : .video
        let name = title?.trimmingCharacters(in: .whitespacesAndNewlines)
        let fallback = url.deletingPathExtension().lastPathComponent.removingPercentEncoding ?? "ملف جديد"
        return MediaInspection(id: UUID().uuidString, title: name?.isEmpty == false ? name! : fallback,
                               webpageUrl: url, source: url.host ?? "رابط مباشر",
                               options: [MediaOption(id: "direct", label: "الملف الأصلي", kind: kind,
                                                     ext: ext, directUrl: url)],
                               expiresAt: Date().addingTimeInterval(900).timeIntervalSince1970)
    }

    public static func searchURL(template: String, query: String) throws -> URL {
        let term = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !term.isEmpty, term.count <= 300, template.components(separatedBy: "{query}").count == 2 else {
            throw SaylError.message("أدخل كلمة بحث، وضع {query} مرة واحدة في قالب رابط البحث.")
        }
        let placeholder = try parse(template.replacingOccurrences(of: "{query}", with: "saylquery"))
        let allowed = CharacterSet(charactersIn: "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-._~")
        guard let encoded = term.addingPercentEncoding(withAllowedCharacters: allowed) else {
            throw SaylError.message("تعذّر تجهيز كلمة البحث.")
        }
        let result = try parse(template.replacingOccurrences(of: "{query}", with: encoded))
        guard sameOrigin(placeholder, result), !((placeholder.host ?? "").contains("saylquery")) else {
            throw SaylError.message("موضع {query} يجب أن يكون في المسار أو معاملات البحث، لا في اسم الموقع.")
        }
        return result
    }

    public static func safeFilename(id: UUID, ext: String) -> String {
        let allowed = CharacterSet.alphanumerics
        let cleaned = String(ext.lowercased().unicodeScalars.filter { allowed.contains($0) }.prefix(8))
        return id.uuidString + "." + (cleaned.isEmpty ? "bin" : cleaned)
    }
}
