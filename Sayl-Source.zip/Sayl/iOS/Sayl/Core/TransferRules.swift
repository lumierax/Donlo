import Foundation

public enum TransferRules {
    // Late delegate callbacks from a cancelled/replaced task must never affect its replacement.
    public static func acceptsNetworkEvent(state: TransferState, currentTaskIdentifier: Int?, eventTaskIdentifier: Int) -> Bool {
        state == .receiving && currentTaskIdentifier == eventTaskIdentifier
    }
}
