import Foundation

public enum DisplayText {
    public static func bytes(_ value: Int64?) -> String {
        guard let value, value >= 0 else { return "حجم غير معروف" }
        if value < 1024 { return "\(value) بايت" }
        let units = ["ك.ب", "م.ب", "ج.ب", "ت.ب"]
        var amount = Double(value) / 1024
        var index = 0
        while amount >= 1024 && index < units.count - 1 { amount /= 1024; index += 1 }
        return String(format: amount < 10 ? "%.1f %@" : "%.0f %@", amount, units[index])
    }
    public static func duration(_ seconds: Double?) -> String {
        guard let seconds, seconds.isFinite, seconds >= 0 else { return "—" }
        let integer = Int(min(seconds, 359_999))
        return integer >= 3600
            ? String(format: "%d:%02d:%02d", integer / 3600, (integer % 3600) / 60, integer % 60)
            : String(format: "%d:%02d", integer / 60, integer % 60)
    }
    public static func percent(_ progress: Double?) -> String {
        guard let progress, progress.isFinite else { return "—" }
        return "\(Int(min(max(progress, 0), 1) * 100))٪"
    }
}
