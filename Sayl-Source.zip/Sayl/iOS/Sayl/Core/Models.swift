import Foundation

public enum MediaKind: String, Codable, Sendable, CaseIterable {
    case video, audio
    public var title: String { self == .video ? "فيديو" : "صوت" }
    public var symbol: String { self == .video ? "play.rectangle.fill" : "waveform" }
}

public struct MediaOption: Codable, Identifiable, Hashable, Sendable {
    public var id: String
    public var label: String
    public var kind: MediaKind
    public var ext: String
    public var height: Int?
    public var bytesEstimate: Int64?
    public var hasAudio: Bool?
    public var directUrl: URL?
    public init(id: String, label: String, kind: MediaKind, ext: String, height: Int? = nil,
                bytesEstimate: Int64? = nil, hasAudio: Bool? = nil, directUrl: URL? = nil) {
        self.id = id; self.label = label; self.kind = kind; self.ext = ext
        self.height = height; self.bytesEstimate = bytesEstimate
        self.hasAudio = hasAudio; self.directUrl = directUrl
    }
}

public struct MediaInspection: Codable, Identifiable, Sendable {
    public var id: String
    public var title: String
    public var webpageUrl: URL
    public var source: String
    public var duration: Double?
    public var thumbnail: URL?
    public var options: [MediaOption]
    public var expiresAt: Double
    public var isLocal: Bool { options.contains { $0.directUrl != nil } }
    public init(id: String, title: String, webpageUrl: URL, source: String, duration: Double? = nil,
                thumbnail: URL? = nil, options: [MediaOption], expiresAt: Double) {
        self.id = id; self.title = title; self.webpageUrl = webpageUrl; self.source = source
        self.duration = duration; self.thumbnail = thumbnail; self.options = options; self.expiresAt = expiresAt
    }
}

public enum TransferState: String, Codable, Sendable {
    case queued, preparing, receiving, paused, verifying, completed, failed, cancelled
    public var label: String {
        switch self {
        case .queued: return "في الانتظار"
        case .preparing: return "يُجهّز على الخادم"
        case .receiving: return "جارٍ النقل إلى جهازك"
        case .paused: return "متوقف مؤقتًا"
        case .verifying: return "التحقق من الملف"
        case .completed: return "حُفظ في المكتبة"
        case .failed: return "تعذّر التنزيل"
        case .cancelled: return "ملغي"
        }
    }
    public var isActive: Bool { [.queued, .preparing, .receiving, .verifying].contains(self) }
    public var canRetry: Bool { [.failed, .cancelled].contains(self) }
}

public struct TransferRecord: Codable, Identifiable, Sendable {
    public var id = UUID()
    public var title: String
    public var sourceUrl: URL
    public var directUrl: URL?
    public var requestHeaders: [String: String] = [:]
    public var expectedAudio: Bool?
    public var remoteBaseUrl: URL?
    public var remoteJobId: String?
    public var kind: MediaKind
    public var ext: String
    public var folderId: UUID?
    public var state: TransferState = .queued
    public var received: Int64 = 0
    public var expected: Int64?
    public var remoteProgress: Double?
    public var speed: Double?
    public var error: String?
    public var createdAt = Date()
    public var stagingName: String?
    public var progress: Double? {
        guard let expected, expected > 0 else { return nil }
        return min(max(Double(received) / Double(expected), 0), 1)
    }
    public init(title: String, sourceUrl: URL, directUrl: URL? = nil, kind: MediaKind,
                ext: String, folderId: UUID? = nil) {
        self.title = title; self.sourceUrl = sourceUrl; self.directUrl = directUrl
        self.kind = kind; self.ext = ext; self.folderId = folderId
    }
}

public struct LibraryItem: Codable, Identifiable, Sendable {
    public var id: UUID
    public var title: String
    public var filename: String
    public var sourceHost: String
    public var kind: MediaKind
    public var bytes: Int64
    public var duration: Double?
    public var folderId: UUID?
    public var favorite = false
    public var createdAt = Date()
    public init(id: UUID, title: String, filename: String, sourceHost: String, kind: MediaKind,
                bytes: Int64, duration: Double? = nil, folderId: UUID? = nil) {
        self.id = id; self.title = title; self.filename = filename; self.sourceHost = sourceHost
        self.kind = kind; self.bytes = bytes; self.duration = duration; self.folderId = folderId
    }
}

public struct MediaFolder: Codable, Identifiable, Hashable, Sendable {
    public var id = UUID()
    public var name: String
    public init(name: String) { self.name = name }
}

public struct RemoteJob: Codable, Sendable {
    public var id: String
    public var title: String
    public var state: String
    public var progress: Double?
    public var downloadedBytes: Int64
    public var totalBytes: Int64?
    public var speed: Double?
    public var error: String?
    public var createdAt: Double
    public var updatedAt: Double
    public var kind: MediaKind
    public var ext: String
    public var size: Int64?
}

public enum SaylError: LocalizedError, Sendable {
    case message(String)
    public var errorDescription: String? {
        switch self { case .message(let value): return value }
    }
}
