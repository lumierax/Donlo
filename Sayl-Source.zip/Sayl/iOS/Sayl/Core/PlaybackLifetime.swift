/// Platform-independent decisions shared by the player and its regression tests.
/// A PiP transition is not a dismissal of the user's playback session.
struct PlaybackLifetime: Equatable {
    enum Phase: Equatable { case inline, starting, active, stopping }
    private(set) var phase: Phase = .inline
    private(set) var returningToInline = false

    var retainsSession: Bool { phase != .inline }
    var isTransitioning: Bool { phase == .starting || phase == .stopping }

    mutating func willStart() {
        phase = .starting
        returningToInline = false
    }
    mutating func didStart() { phase = .active }
    mutating func willStop() { phase = .stopping }
    mutating func requestInlineReturn() { returningToInline = true }
    mutating func restorationFailed() { returningToInline = false }
    mutating func failedToStart() { self = Self() }

    /// The PiP close button must stop playback; restoring the inline UI must not.
    mutating func didStop() -> Bool {
        let shouldClosePlayback = !returningToInline
        self = Self()
        return shouldClosePlayback
    }

    static func shouldStopForPrivacyLock(unlocked: Bool, backgroundLocked: Bool) -> Bool {
        !unlocked && !backgroundLocked
    }
}
