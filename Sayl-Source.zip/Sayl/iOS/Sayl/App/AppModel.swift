import Foundation
import Combine

@MainActor
final class AppModel: ObservableObject {
    static let shared = AppModel()
    enum Tab: String, CaseIterable {
        case home, browser, downloads, library
        var title: String {
            switch self { case .home: return "الرئيسية"; case .browser: return "المتصفح"; case .downloads: return "التنزيلات"; case .library: return "المكتبة" }
        }
        var symbol: String {
            switch self { case .home: return "square.grid.2x2.fill"; case .browser: return "globe"; case .downloads: return "arrow.down.to.line"; case .library: return "rectangle.stack.fill" }
        }
    }
    let settings: SettingsStore
    let library: LibraryStore
    let downloads: DownloadCenter
    let browser: BrowserModel
    let privacy: PrivacyGate
    @Published var tab: Tab = .home
    @Published var linkText = ""
    @Published var resolving = false
    @Published var inspection: MediaInspection?
    @Published var message: String?
    @Published var showSettings = false
    @Published var needsEngine = false
    private var inspectionHeaders: [String: String] = [:]
    private var resolveTask: Task<Void, Never>?
    private var generation = UUID()

    private init() {
        settings = SettingsStore(); library = LibraryStore()
        downloads = DownloadCenter(library: library, settings: settings)
        browser = BrowserModel(proxyConfigurations: settings.proxyConfigurations); privacy = PrivacyGate()
    }
    func inspect(_ text: String, candidate: BrowserCandidate? = nil) {
        resolveTask?.cancel(); generation = UUID()
        let ticket = generation
        resolving = true; message = nil; needsEngine = false
        resolveTask = Task {
            defer { if ticket == generation { resolving = false } }
            do {
                let url = try LinkRules.parse(text)
                let local = candidate.flatMap { browser.localInspection($0) } ?? LinkRules.directInspection(for: url)
                let result: MediaInspection
                var headers: [String: String] = [:]
                if let local {
                    result = local
                    if let candidate { headers = await browser.headers(for: candidate.url) }
                } else {
                    guard let connection = settings.connection else {
                        needsEngine = true
                        throw SaylError.message("صفحات المواقع والبث المجزأ تحتاج المحرك الموسّع. أضف عنوان خادمك ومفتاحه من الإعدادات، أو جرّب رابط ملف مباشر من المتصفح.")
                    }
                    result = try await APIClient(connection: connection, proxyConfigurations: settings.proxyConfigurations).inspect(url)
                }
                try Task.checkCancellation()
                guard ticket == generation else { return }
                inspectionHeaders = headers
                inspection = result
            } catch is CancellationError { }
            catch { if ticket == generation { message = error.localizedDescription } }
        }
    }
    func cancelInspection() { resolveTask?.cancel(); generation = UUID(); resolving = false }
    func enqueue(_ media: MediaInspection, option: MediaOption, folderId: UUID?) async throws {
        try await downloads.enqueue(inspection: media, option: option, folderId: folderId, headers: inspectionHeaders)
        inspection = nil; inspectionHeaders = [:]; tab = .downloads
    }
    func browse(_ url: URL) { browser.open(url); tab = .browser }
    func handle(_ url: URL) {
        guard url.scheme == "sayl", url.host == "download",
              let components = URLComponents(url: url, resolvingAgainstBaseURL: false),
              let source = components.queryItems?.first(where: { $0.name == "url" })?.value else { return }
        linkText = source; tab = .home
        // Incoming links are filled but not sent to a server until the user taps Analyze.
    }
}
