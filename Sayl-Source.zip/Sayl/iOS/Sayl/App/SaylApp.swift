import SwiftUI
import UIKit

@MainActor
final class AppDelegate: NSObject, UIApplicationDelegate {
    func application(_ application: UIApplication, handleEventsForBackgroundURLSession identifier: String,
                     completionHandler: @escaping () -> Void) {
        guard identifier == DownloadCenter.sessionIdentifier || identifier == DownloadCenter.proxySessionIdentifier else {
            completionHandler(); return
        }
        AppModel.shared.downloads.backgroundCompletion = completionHandler
    }
}

@main
struct SaylApp: App {
    @UIApplicationDelegateAdaptor(AppDelegate.self) private var delegate
    @StateObject private var model = AppModel.shared
    @Environment(\.scenePhase) private var scenePhase
    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(model)
                .environmentObject(model.settings)
                .environmentObject(model.library)
                .environmentObject(model.downloads)
                .environmentObject(model.browser)
                .environmentObject(model.privacy)
                .environmentObject(model.playback)
                .environment(\.layoutDirection, .rightToLeft)
                .environment(\.locale, Locale(identifier: "ar"))
                .preferredColorScheme(.dark)
                .tint(SaylTheme.accent)
                .onOpenURL { model.handle($0) }
                .onReceive(NotificationCenter.default.publisher(for: UIApplication.protectedDataDidBecomeAvailableNotification)) { _ in
                    model.downloads.resumeFinalization()
                }
                .onChange(of: scenePhase, initial: true) { _, phase in
                    model.downloads.setForeground(phase == .active)
                    if phase == .background {
                        model.playback.checkpoint()
                        model.privacy.lock(forBackground: true)
                    }
                    // Keep the reason for the lock until authentication or a manual lock.
                    // Returning from PiP must not turn a background lock into a stop command.
                }
                .overlay {
                    if scenePhase != .active {
                        ZStack {
                            SaylTheme.background.ignoresSafeArea()
                            VStack(spacing: 20) { BrandMark(size: 70); Text("مساحتك تبقى لك").font(.title3.weight(.semibold)) }
                        }.accessibilityHidden(true)
                    }
                }
        }
    }
}
