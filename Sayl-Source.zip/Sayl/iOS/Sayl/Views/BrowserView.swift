import SwiftUI
import WebKit

private struct EmbeddedBrowser: UIViewRepresentable {
    let webView: WKWebView
    func makeUIView(context: Context) -> WKWebView { webView }
    func updateUIView(_ uiView: WKWebView, context: Context) { }
}
struct BrowserView: View {
    @EnvironmentObject private var browser: BrowserModel
    @EnvironmentObject private var model: AppModel
    @State private var showCandidates = false
    @State private var selectedCandidate: BrowserCandidate?
    @State private var showClear = false
    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 12) {
                Image(systemName: "lock.shield").font(.subheadline).foregroundStyle(SaylTheme.accent)
                TextField("https://example.com", text: $browser.address)
                    .keyboardType(.URL).textInputAutocapitalization(.never).autocorrectionDisabled()
                    .environment(\.layoutDirection, .leftToRight).font(.system(size: 14))
                    .submitLabel(.go).onSubmit { browser.openAddress() }
                Button { browser.openAddress() } label: { Image(systemName: "arrow.turn.down.left").frame(width: 32, height: 40) }
                    .accessibilityLabel("افتح العنوان")
            }.padding(.horizontal, 14).background(SaylTheme.surface, in: RoundedRectangle(cornerRadius: 17)).padding(16)
            if browser.progress > 0 && browser.progress < 1 { ProgressView(value: browser.progress).tint(SaylTheme.accent) }
            if let error = browser.error { InlineMessage(text: error).padding(.horizontal, 16).padding(.bottom, 10) }
            ZStack {
                if browser.address.isEmpty && browser.currentUrl == nil {
                    VStack {
                        Spacer()
                        EmptyState(icon: "globe", title: "تصفّح. اكتشف. احفظ.", detail: "افتح موقعًا، ثم صفحة المقطع. افحص الصفحة بالمحرك الموسّع، أو اختر ملفًا مباشرًا من الوسائط المكتشفة.")
                        Text("تسجيل الدخول والتحقق يتمان يدويًا داخل صفحة الموقع.")
                            .font(.caption).foregroundStyle(SaylTheme.secondary).multilineTextAlignment(.center).padding(.horizontal, 26)
                        Spacer()
                    }
                } else { EmbeddedBrowser(webView: browser.webView).environment(\.layoutDirection, .leftToRight) }
            }.frame(maxWidth: .infinity, maxHeight: .infinity)
            VStack(spacing: 10) {
                HStack(spacing: 14) {
                    Button { browser.webView.goBack() } label: { Image(systemName: "chevron.backward").frame(width: 40, height: 40) }
                        .disabled(!browser.canGoBack).accessibilityLabel("الصفحة السابقة")
                    Button { browser.webView.goForward() } label: { Image(systemName: "chevron.forward").frame(width: 40, height: 40) }
                        .disabled(!browser.canGoForward).accessibilityLabel("الصفحة التالية")
                    Button { browser.webView.reload() } label: { Image(systemName: "arrow.clockwise").frame(width: 40, height: 40) }
                        .accessibilityLabel("تحديث الصفحة")
                    Spacer()
                    Button { showClear = true } label: { Image(systemName: "eraser").frame(width: 40, height: 40) }.accessibilityLabel("مسح جلسة التصفح")
                }.foregroundStyle(SaylTheme.secondary)
                HStack(spacing: 10) {
                    Button { browser.scan(); showCandidates = true } label: {
                        Label("المكتشف \(browser.candidates.count)", systemImage: "play.rectangle.on.rectangle")
                            .font(.caption.weight(.semibold)).frame(maxWidth: .infinity).padding(.vertical, 14)
                            .background(SaylTheme.surface, in: RoundedRectangle(cornerRadius: 14))
                    }.buttonStyle(.plain)
                    Button {
                        if let url = browser.currentUrl { model.inspect(url.absoluteString) }
                    } label: {
                        Label("فحص الصفحة", systemImage: "sparkle.magnifyingglass")
                            .font(.caption.weight(.bold)).frame(maxWidth: .infinity).padding(.vertical, 14)
                            .foregroundStyle(SaylTheme.ink).background(SaylTheme.accent, in: RoundedRectangle(cornerRadius: 14))
                    }.buttonStyle(.plain).disabled(browser.currentUrl == nil || model.resolving)
                }
            }.padding(.horizontal, 16).padding(.bottom, 8).background(SaylTheme.background)
        }
        .sheet(isPresented: $showCandidates, onDismiss: {
            if let candidate = selectedCandidate {
                selectedCandidate = nil
                model.inspect(candidate.url.absoluteString, candidate: candidate)
            }
        }) {
            NavigationStack {
                ScrollView {
                    VStack(spacing: 14) {
                        if browser.candidates.isEmpty {
                            EmptyState(icon: "sparkle.magnifyingglass", title: "لم يظهر ملف مباشر بعد", detail: "شغّل المقطع داخل الصفحة ثم أعد الفحص. روابط blob والمشغّلات المحمية لا تتحول إلى ملفات بمجرد ظهورها.")
                        } else {
                            Text("روابط كشفتها الصفحة؛ ليست ضمانًا بأن المصدر يسمح بالتنزيل.")
                                .font(.footnote).foregroundStyle(SaylTheme.secondary).padding(.bottom, 8)
                            ForEach(browser.candidates) { candidate in
                                Button {
                                    selectedCandidate = candidate; showCandidates = false
                                } label: {
                                    HStack(spacing: 12) {
                                        Image(systemName: "play.rectangle").font(.title2).foregroundStyle(SaylTheme.accent)
                                        VStack(alignment: .leading, spacing: 8) {
                                            Text(candidate.title).font(.subheadline.weight(.semibold)).lineLimit(2)
                                            Text((candidate.url.host ?? "") + " · " + candidate.url.pathExtension.uppercased())
                                                .font(.caption).foregroundStyle(SaylTheme.secondary)
                                        }.frame(maxWidth: .infinity, alignment: .leading)
                                        Image(systemName: "chevron.forward").font(.caption)
                                    }.saylCard()
                                }.buttonStyle(.plain)
                            }
                        }
                    }.padding(22)
                }.background(SaylTheme.background).navigationTitle("وسائط الصفحة").navigationBarTitleDisplayMode(.inline)
                    .toolbar { ToolbarItem(placement: .cancellationAction) { Button("إغلاق") { showCandidates = false } } }
            }.environment(\.layoutDirection, .rightToLeft).presentationDragIndicator(.visible)
        }
        .confirmationDialog("مسح جلسة التصفح وتسجيلات الدخول؟", isPresented: $showClear, titleVisibility: .visible) {
            Button("مسح الجلسة", role: .destructive) { Task { await browser.clearSession() } }
            Button("إلغاء", role: .cancel) { }
        }
    }
}
