import SwiftUI

struct MediaSheet: View {
    let media: MediaInspection
    @EnvironmentObject private var model: AppModel
    @EnvironmentObject private var library: LibraryStore
    @Environment(\.dismiss) private var dismiss
    @State private var selected: String
    @State private var folderId: UUID?
    @State private var adding = false
    @State private var error: String?
    @State private var showFolder = false
    @State private var folderName = ""
    init(media: MediaInspection) {
        self.media = media
        _selected = State(initialValue: media.options.first?.id ?? "")
    }
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 24) {
                    VStack(alignment: .leading, spacing: 16) {
                        MediaArtwork(kind: media.options.first?.kind ?? .video).frame(height: 145).clipShape(RoundedRectangle(cornerRadius: 22))
                        Text(media.title).font(.title3.weight(.bold)).lineSpacing(4)
                        HStack {
                            Pill(text: media.source, icon: "globe")
                            if media.duration != nil { Pill(text: DisplayText.duration(media.duration), icon: "clock") }
                        }
                    }
                    SectionHeading(title: "كيف تحب أن تحفظه؟", subtitle: "الجودات التي كشفها المصدر لهذا الرابط")
                    VStack(spacing: 10) {
                        ForEach(media.options) { option in quality(option) }
                    }
                    VStack(alignment: .leading, spacing: 12) {
                        HStack {
                            SectionHeading(title: "إلى أي مجلد؟")
                            Button { showFolder = true } label: { Image(systemName: "folder.badge.plus").frame(width: 44, height: 44) }
                                .accessibilityLabel("إنشاء مجلد")
                        }
                        Picker("المجلد", selection: $folderId) {
                            Text("الوارد").tag(nil as UUID?)
                            ForEach(library.folders) { folder in Text(folder.name).tag(Optional(folder.id)) }
                        }.tint(SaylTheme.text).frame(maxWidth: .infinity, alignment: .leading).padding(10)
                            .background(SaylTheme.surface, in: RoundedRectangle(cornerRadius: 15))
                    }
                    if let error { InlineMessage(text: error) }
                    Text(media.isLocal ? "سيُنقل الملف مباشرة إلى جهازك. يتأكد سَيْل من قابليته للتشغيل قبل إضافته إلى المكتبة." : "يُنزّل خادمك المقطع ويجهّزه أولًا، ثم ينقله التطبيق إلى جهازك. الحجم المعروض تقديري وقد يتغير بعد المعالجة.")
                        .font(.footnote).foregroundStyle(SaylTheme.secondary).lineSpacing(5)
                }.padding(24)
            }
            .background(SaylTheme.background)
            .navigationTitle("تفاصيل الحفظ").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("إغلاق") { dismiss() }.disabled(adding) } }
            .safeAreaInset(edge: .bottom) {
                VStack(spacing: 9) {
                    PrimaryButton(title: "حفظ في المكتبة", busy: adding) { enqueue() }
                        .disabled(!media.options.contains { $0.id == selected })
                    Text("محلي · دون إضافة إلى ألبوم الصور تلقائيًا").font(.caption2).foregroundStyle(SaylTheme.secondary)
                }.padding(20).background(.ultraThinMaterial)
            }
            .interactiveDismissDisabled(adding)
            .alert("مجلد جديد", isPresented: $showFolder) {
                TextField("اسم المجلد", text: $folderName)
                Button("إنشاء") {
                    do { folderId = try library.createFolder(folderName); folderName = "" }
                    catch { self.error = error.localizedDescription }
                }
                Button("إلغاء", role: .cancel) { }
            }
        }.environment(\.layoutDirection, .rightToLeft)
    }
    private func quality(_ option: MediaOption) -> some View {
        let isSelected = selected == option.id
        return Button { selected = option.id } label: {
            HStack(spacing: 14) {
                Image(systemName: option.kind.symbol).font(.title3).foregroundStyle(isSelected ? SaylTheme.accent : SaylTheme.secondary)
                    .frame(width: 34)
                VStack(alignment: .leading, spacing: 6) {
                    HStack {
                        Text(option.label).font(.headline).environment(\.layoutDirection, option.height == nil ? .rightToLeft : .leftToRight)
                        if option.kind == .audio { Pill(text: "صوت", color: SaylTheme.violet) }
                    }
                    Text(option.ext.uppercased() + (option.kind == .video ? (option.hasAudio == true ? " · يتضمن الصوت" : option.hasAudio == false ? " · بدون مسار صوتي" : " · يُفحص الصوت بعد النقل") : " · ملف صوتي"))
                        .font(.caption).foregroundStyle(SaylTheme.secondary)
                    if let estimate = option.bytesEstimate { Text("نحو " + DisplayText.bytes(estimate)).font(.caption2).foregroundStyle(SaylTheme.secondary) }
                }
                Spacer(minLength: 0)
                Image(systemName: isSelected ? "checkmark.circle.fill" : "circle").font(.title3)
                    .foregroundStyle(isSelected ? SaylTheme.accent : SaylTheme.secondary.opacity(0.5))
            }.padding(16).background(isSelected ? SaylTheme.accent.opacity(0.07) : SaylTheme.surface, in: RoundedRectangle(cornerRadius: 18))
                .overlay(RoundedRectangle(cornerRadius: 18).stroke(isSelected ? SaylTheme.accent.opacity(0.5) : SaylTheme.stroke))
        }.buttonStyle(.plain).accessibilityAddTraits(isSelected ? .isSelected : [])
    }
    private func enqueue() {
        guard let option = media.options.first(where: { $0.id == selected }) else { return }
        adding = true; error = nil
        Task {
            defer { adding = false }
            do { try await model.enqueue(media, option: option, folderId: folderId) }
            catch { self.error = error.localizedDescription }
        }
    }
}
