import SwiftUI

struct DownloadsView: View {
    @EnvironmentObject private var downloads: DownloadCenter
    @EnvironmentObject private var model: AppModel
    @State private var activeOnly = false
    private var visible: [TransferRecord] { downloads.records.filter { !activeOnly || $0.state.isActive || $0.state == .paused } }
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                HStack {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("التنزيلات").font(.largeTitle.weight(.bold))
                        Text(downloads.activeCount == 0 ? "مساحة لكل ما يستحق الحفظ." : "\(downloads.activeCount) مهمة قيد العمل")
                            .font(.subheadline).foregroundStyle(SaylTheme.secondary)
                    }
                    Spacer()
                    Menu {
                        Button("تنظيف المكتمل والملغي", systemImage: "sparkles") { downloads.clearFinished() }
                    } label: { Image(systemName: "ellipsis").font(.title3).frame(width: 44, height: 44).background(SaylTheme.surface, in: Circle()) }
                        .accessibilityLabel("خيارات سجل التنزيل")
                }
                HStack(spacing: 10) {
                    filter("الكل", active: !activeOnly) { activeOnly = false }
                    filter("قيد العمل", active: activeOnly) { activeOnly = true }
                    Spacer()
                    Pill(text: "نقلان بالتوازي", icon: "arrow.down", color: SaylTheme.secondary)
                }
                if let notice = downloads.notice {
                    InlineMessage(text: notice)
                    Button("إخفاء التنبيه") { downloads.notice = nil }.font(.caption)
                }
                if visible.isEmpty {
                    EmptyState(icon: "arrow.down.to.line", title: "مكان لشيء جديد", detail: "أضف رابطًا واختر الجودة. ستجد تقدم كل مهمة هنا، وملفاتك المكتملة في المكتبة.")
                    PrimaryButton(title: "أضف رابطًا", icon: "plus") { model.tab = .home }
                } else {
                    LazyVStack(spacing: 14) { ForEach(visible) { record in card(record) } }
                }
                Text("قد لا يسمح المصدر بالاستكمال. تجهيز الخادم يستمر مستقلًا؛ يبدأ النقل إلى الآيفون عند فتح التطبيق ومزامنة الحالة.")
                    .font(.caption).foregroundStyle(SaylTheme.secondary).lineSpacing(5).padding(.bottom, 12)
            }.padding(24)
        }
    }
    private func filter(_ title: String, active: Bool, action: @escaping () -> Void) -> some View {
        Button(action: action) { Text(title).font(.subheadline.weight(.semibold)).padding(.horizontal, 17).padding(.vertical, 10)
            .foregroundStyle(active ? SaylTheme.ink : SaylTheme.secondary)
            .background(active ? SaylTheme.accent : SaylTheme.surface, in: Capsule()) }.buttonStyle(.plain)
    }
    private func card(_ record: TransferRecord) -> some View {
        VStack(alignment: .leading, spacing: 18) {
            HStack(alignment: .top, spacing: 14) {
                Image(systemName: record.kind.symbol).font(.title2).foregroundStyle(SaylTheme.accent)
                    .frame(width: 52, height: 56).background(SaylTheme.accent.opacity(0.08), in: RoundedRectangle(cornerRadius: 17))
                VStack(alignment: .leading, spacing: 7) {
                    Text(record.title).font(.subheadline.weight(.bold)).lineLimit(2).lineSpacing(3)
                    Text(record.sourceUrl.host ?? "المصدر").font(.caption).foregroundStyle(SaylTheme.secondary)
                    Text(record.state.label).font(.caption.weight(.semibold))
                        .foregroundStyle(record.state == .completed ? SaylTheme.mint : SaylTheme.accent)
                }
                Spacer(minLength: 0)
                if record.state == .completed { Image(systemName: "checkmark.circle.fill").foregroundStyle(SaylTheme.mint) }
            }
            if record.state == .receiving || record.state == .paused {
                if let progress = record.progress { ProgressView(value: progress).tint(SaylTheme.accent) }
                else { ProgressView().tint(SaylTheme.accent).frame(maxWidth: .infinity, alignment: .leading) }
                HStack {
                    Text(DisplayText.bytes(record.received) + " / " + DisplayText.bytes(record.expected))
                    Spacer()
                    if let speed = record.speed { Text(DisplayText.bytes(Int64(max(0, speed))) + "/ث") }
                }.font(.caption2.monospacedDigit()).foregroundStyle(SaylTheme.secondary)
            } else if record.state == .preparing || record.state == .verifying || record.state == .queued {
                HStack(spacing: 10) {
                    ProgressView().tint(SaylTheme.accent)
                    Text(record.state == .verifying ? "نتأكد من الملف قبل إضافته إلى مكتبتك" : (record.state == .queued ? "يبدأ النقل عندما يتوفر مكان" : "استخراج المصدر ودمج الصوت والفيديو"))
                        .font(.caption).foregroundStyle(SaylTheme.secondary)
                }
            }
            if let error = record.error { Text(error).font(.caption).foregroundStyle(SaylTheme.accent).lineSpacing(4) }
            HStack(spacing: 18) {
                switch record.state {
                case .receiving:
                    Button("إيقاف مؤقت", systemImage: "pause.fill") { downloads.pause(record.id) }
                case .paused:
                    Button("متابعة", systemImage: "play.fill") { downloads.resume(record.id) }
                    Button("ابدأ من جديد", systemImage: "arrow.clockwise") { downloads.restart(record.id) }
                case .failed, .cancelled:
                    if record.directUrl != nil { Button("إعادة النقل", systemImage: "arrow.clockwise") { downloads.restart(record.id) } }
                    Button("فحص المصدر", systemImage: "sparkle.magnifyingglass") { model.inspect(record.sourceUrl.absoluteString) }
                case .completed:
                    Button("افتح المكتبة", systemImage: "rectangle.stack") { model.tab = .library }
                default: EmptyView()
                }
                Spacer(minLength: 0)
                if (record.state.isActive && record.state != .verifying) || record.state == .paused || record.state == .failed {
                    Button(role: .destructive) { downloads.cancel(record.id) } label: { Image(systemName: "xmark").frame(width: 35, height: 32) }
                        .accessibilityLabel("إلغاء التنزيل")
                }
            }.font(.caption.weight(.semibold)).tint(SaylTheme.accent)
        }.saylCard(highlighted: record.state == .receiving)
    }
}
