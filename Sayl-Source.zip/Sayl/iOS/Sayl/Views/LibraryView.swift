import SwiftUI
import AVFoundation

struct LibraryView: View {
    @EnvironmentObject private var library: LibraryStore
    @EnvironmentObject private var privacy: PrivacyGate
    @State private var query = ""
    @State private var category = "all"
    @State private var folder = "all"
    @State private var grid = true
    @State private var selected: LibraryItem?
    @State private var renaming: LibraryItem?
    @State private var renameText = ""
    @State private var showRename = false
    @State private var showFolder = false
    @State private var newFolderName = ""
    @State private var deleting: LibraryItem?
    @State private var showDelete = false
    @State private var error: String?
    private var visible: [LibraryItem] {
        library.items.filter { item in
            (query.isEmpty || item.title.localizedCaseInsensitiveContains(query))
            && (category == "all" || category == item.kind.rawValue || (category == "favorites" && item.favorite))
            && (folder == "all" || (folder == "inbox" && item.folderId == nil) || item.folderId?.uuidString == folder)
        }
    }
    var body: some View {
        Group {
            if privacy.unlocked { unlockedContent }
            else { lockedContent }
        }
        .sheet(item: $selected) { item in PlayerView(item: item) }
        .onChange(of: privacy.unlocked) { _, unlocked in
            if !unlocked && !privacy.backgroundLocked { selected = nil; query = "" }
        }
        .alert("إعادة التسمية", isPresented: $showRename) {
            TextField("الاسم الجديد", text: $renameText)
            Button("حفظ") { if let item = renaming { perform { try library.rename(item.id, title: renameText) } } }
            Button("إلغاء", role: .cancel) { }
        }
        .alert("مجلد جديد", isPresented: $showFolder) {
            TextField("اسم المجلد", text: $newFolderName)
            Button("إنشاء") { perform { _ = try library.createFolder(newFolderName) }; newFolderName = "" }
            Button("إلغاء", role: .cancel) { }
        }
        .confirmationDialog("حذف الملف من الجهاز؟ لا يمكن التراجع.", isPresented: $showDelete, titleVisibility: .visible) {
            Button("حذف الملف", role: .destructive) { if let deleting { perform { try library.remove(deleting) } } }
            Button("إلغاء", role: .cancel) { }
        }
    }
    private var lockedContent: some View {
        VStack(spacing: 26) {
            Spacer()
            ZStack {
                Circle().stroke(SaylTheme.stroke, lineWidth: 1).frame(width: 160, height: 160)
                Circle().stroke(SaylTheme.stroke, lineWidth: 1).frame(width: 120, height: 120)
                Image(systemName: "lock.shield").font(.system(size: 46, weight: .light)).foregroundStyle(SaylTheme.accent)
            }.accessibilityHidden(true)
            Text("مكتبتك.\nلك وحدك.").font(.system(size: 36, weight: .bold, design: .rounded)).multilineTextAlignment(.center).lineSpacing(7)
            Text("ما حفظته هنا يبقى على جهازك.\nافتح مساحتك بمصادقة الآيفون.")
                .font(.subheadline).foregroundStyle(SaylTheme.secondary).multilineTextAlignment(.center).lineSpacing(6)
            if let error = privacy.error { InlineMessage(text: error) }
            PrimaryButton(title: "افتح المكتبة", icon: "faceid", busy: privacy.authenticating) { Task { await privacy.unlock() } }
            Pill(text: "Face ID أو رمز الجهاز", icon: "lock", color: SaylTheme.secondary)
            Spacer()
        }.padding(.horizontal, 34)
    }
    private var unlockedContent: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 22) {
                HStack {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("مكتبتك").font(.largeTitle.weight(.bold))
                        Text("\(library.items.count) ملف · \(DisplayText.bytes(library.totalBytes)) على جهازك")
                            .font(.caption).foregroundStyle(SaylTheme.secondary)
                    }
                    Spacer()
                    IconButton(icon: "folder.badge.plus", label: "مجلد جديد") { showFolder = true }
                    IconButton(icon: "lock", label: "قفل المكتبة") { privacy.lock() }
                }
                HStack(spacing: 12) {
                    Image(systemName: "magnifyingglass").foregroundStyle(SaylTheme.secondary)
                    TextField("ابحث في محفوظاتك", text: $query).font(.subheadline)
                    Button { grid.toggle() } label: { Image(systemName: grid ? "list.bullet" : "square.grid.2x2").frame(width: 35, height: 40) }
                        .accessibilityLabel(grid ? "عرض كقائمة" : "عرض كشبكة")
                }.padding(.horizontal, 15).padding(.vertical, 5).background(SaylTheme.surface, in: RoundedRectangle(cornerRadius: 16))
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 8) {
                        categoryPill("الكل", value: "all")
                        categoryPill("فيديو", value: "video")
                        categoryPill("صوت", value: "audio")
                        categoryPill("المفضلة", value: "favorites")
                    }
                }
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 12) {
                        folderButton("كل المجلدات", value: "all")
                        folderButton("الوارد", value: "inbox")
                        ForEach(library.folders) { folder in folderButton(folder.name, value: folder.id.uuidString) }
                    }
                }
                if let error = error ?? library.error {
                    InlineMessage(text: error)
                    Button("إعادة قراءة الفهرس") { library.reload(); self.error = nil }.font(.caption)
                }
                if visible.isEmpty {
                    EmptyState(icon: "rectangle.stack", title: library.items.isEmpty ? "أول ملف، بداية مكتبتك" : "لا توجد نتائج هنا",
                               detail: library.items.isEmpty ? "ستظهر ملفاتك بعد اكتمال تنزيلها والتحقق منها. لا نضيف عناصر تجريبية إلى مكتبتك." : "جرّب اسمًا آخر أو غيّر المجلد ونوع الوسائط.")
                } else if grid {
                    LazyVGrid(columns: [GridItem(.flexible(), spacing: 14), GridItem(.flexible(), spacing: 14)], spacing: 18) {
                        ForEach(visible) { item in tile(item) }
                    }
                } else {
                    LazyVStack(spacing: 12) { ForEach(visible) { item in row(item) } }
                }
            }.padding(24)
        }.scrollDismissesKeyboard(.interactively)
    }
    private func categoryPill(_ title: String, value: String) -> some View {
        Button { category = value } label: {
            Text(title).font(.caption.weight(.semibold)).padding(.horizontal, 18).padding(.vertical, 11)
                .foregroundStyle(category == value ? SaylTheme.ink : SaylTheme.secondary)
                .background(category == value ? SaylTheme.accent : SaylTheme.surface, in: Capsule())
        }.buttonStyle(.plain)
    }
    private func folderButton(_ title: String, value: String) -> some View {
        Button { folder = value } label: {
            Label(title, systemImage: "folder").font(.caption).foregroundStyle(folder == value ? SaylTheme.accent : SaylTheme.secondary)
                .padding(.vertical, 9)
        }.buttonStyle(.plain)
    }
    private func tile(_ item: LibraryItem) -> some View {
        Button { selected = item } label: {
            VStack(alignment: .leading, spacing: 12) {
                ZStack(alignment: .bottomTrailing) {
                    FileThumbnail(item: item, url: library.file(item)).frame(height: 120)
                    Text(DisplayText.duration(item.duration)).font(.system(size: 10, weight: .medium, design: .monospaced))
                        .padding(5).background(.black.opacity(0.55), in: RoundedRectangle(cornerRadius: 6)).padding(8)
                }.clipShape(RoundedRectangle(cornerRadius: 18))
                Text(item.title).font(.subheadline.weight(.semibold)).lineLimit(2).frame(maxWidth: .infinity, alignment: .leading)
                HStack {
                    Text(DisplayText.bytes(item.bytes)).font(.caption2).foregroundStyle(SaylTheme.secondary)
                    Spacer()
                    if item.favorite { Image(systemName: "heart.fill").font(.caption2).foregroundStyle(SaylTheme.accent) }
                    Image(systemName: item.kind.symbol).font(.caption2).foregroundStyle(SaylTheme.secondary)
                }
            }.padding(10).background(SaylTheme.surface, in: RoundedRectangle(cornerRadius: 24))
        }.buttonStyle(.plain).contextMenu { actions(item) }
    }
    private func row(_ item: LibraryItem) -> some View {
        Button { selected = item } label: {
            HStack(spacing: 14) {
                FileThumbnail(item: item, url: library.file(item)).frame(width: 78, height: 72).clipShape(RoundedRectangle(cornerRadius: 15))
                VStack(alignment: .leading, spacing: 8) {
                    Text(item.title).font(.subheadline.weight(.semibold)).lineLimit(2)
                    Text(DisplayText.bytes(item.bytes) + " · " + DisplayText.duration(item.duration)).font(.caption).foregroundStyle(SaylTheme.secondary)
                }.frame(maxWidth: .infinity, alignment: .leading)
                Image(systemName: "play.circle").foregroundStyle(SaylTheme.accent)
            }.padding(12).background(SaylTheme.surface, in: RoundedRectangle(cornerRadius: 20))
        }.buttonStyle(.plain).contextMenu { actions(item) }
    }
    @ViewBuilder private func actions(_ item: LibraryItem) -> some View {
        Button("تشغيل", systemImage: "play") { selected = item }
        Button(item.favorite ? "إزالة من المفضلة" : "إضافة إلى المفضلة", systemImage: item.favorite ? "heart.slash" : "heart") {
            perform { try library.favorite(item.id) }
        }
        Button("إعادة التسمية", systemImage: "pencil") { renaming = item; renameText = item.title; showRename = true }
        Menu("نقل إلى مجلد", systemImage: "folder") {
            Button("الوارد") { perform { try library.move(item.id, folderId: nil) } }
            ForEach(library.folders) { folder in Button(folder.name) { perform { try library.move(item.id, folderId: folder.id) } } }
        }
        ShareLink(item: library.file(item)) { Label("تصدير نسخة", systemImage: "square.and.arrow.up") }
        Button("حذف", systemImage: "trash", role: .destructive) { deleting = item; showDelete = true }
    }
    private func perform(_ action: () throws -> Void) {
        do { try action() } catch { self.error = error.localizedDescription }
    }
}

private struct FileThumbnail: View {
    let item: LibraryItem
    let url: URL
    @State private var image: UIImage?
    var body: some View {
        ZStack {
            MediaArtwork(kind: item.kind)
            if let image { Image(uiImage: image).resizable().scaledToFill() }
        }.clipped().task(id: item.id) {
            guard item.kind == .video else { return }
            let generator = AVAssetImageGenerator(asset: AVURLAsset(url: url))
            generator.appliesPreferredTrackTransform = true
            generator.maximumSize = CGSize(width: 360, height: 240)
            if let generated = try? await generator.image(at: CMTime(seconds: min(1, (item.duration ?? 1) / 2), preferredTimescale: 600)),
               !Task.isCancelled { image = UIImage(cgImage: generated.image) }
        }
    }
}
