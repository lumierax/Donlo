import SwiftUI

enum SaylTheme {
    static let background = Color(hex: 0x101216)
    static let surface = Color(hex: 0x1B1E24)
    static let elevated = Color(hex: 0x252932)
    static let accent = Color(hex: 0xFFA17B)
    static let ink = Color(hex: 0x1E1714)
    static let text = Color(hex: 0xF7F4ED)
    static let secondary = Color(hex: 0xA6AAB5)
    static let mint = Color(hex: 0xAFE0CD)
    static let violet = Color(hex: 0xB7B1EA)
    static let stroke = Color.white.opacity(0.075)
}
extension Color {
    init(hex: UInt32) {
        self.init(.sRGB, red: Double((hex >> 16) & 255) / 255,
                  green: Double((hex >> 8) & 255) / 255, blue: Double(hex & 255) / 255, opacity: 1)
    }
}
private struct SaylCard: ViewModifier {
    var highlighted: Bool
    func body(content: Content) -> some View {
        content.padding(20)
            .background(highlighted ? SaylTheme.accent.opacity(0.08) : SaylTheme.surface, in: RoundedRectangle(cornerRadius: 24))
            .overlay(RoundedRectangle(cornerRadius: 24).stroke(highlighted ? SaylTheme.accent.opacity(0.25) : SaylTheme.stroke, lineWidth: 1))
    }
}
extension View {
    func saylCard(highlighted: Bool = false) -> some View { modifier(SaylCard(highlighted: highlighted)) }
}
struct BrandMark: View {
    var size: CGFloat = 44
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: size * 0.3).fill(LinearGradient(colors: [Color(hex: 0xFFC7A6), SaylTheme.accent], startPoint: .topLeading, endPoint: .bottomTrailing))
            Image(systemName: "arrow.down.to.line").font(.system(size: size * 0.47, weight: .bold)).foregroundStyle(SaylTheme.ink)
                .rotationEffect(.degrees(-15))
        }.frame(width: size, height: size).accessibilityHidden(true)
    }
}
struct IconButton: View {
    let icon: String
    let label: String
    var action: () -> Void
    var body: some View {
        Button(action: action) { Image(systemName: icon).font(.system(size: 18, weight: .medium)).frame(width: 44, height: 44)
            .background(SaylTheme.elevated, in: Circle()) }
            .buttonStyle(.plain).accessibilityLabel(label)
    }
}
struct PrimaryButton: View {
    let title: String
    var icon: String = "arrow.down.to.line"
    var busy = false
    var action: () -> Void
    var body: some View {
        Button(action: action) {
            HStack(spacing: 10) {
                if busy { ProgressView().tint(SaylTheme.ink) }
                else { Image(systemName: icon).fontWeight(.semibold) }
                Text(title).font(.system(.body, design: .rounded, weight: .bold))
            }.frame(maxWidth: .infinity).padding(.vertical, 17)
                .foregroundStyle(SaylTheme.ink).background(SaylTheme.accent, in: RoundedRectangle(cornerRadius: 18))
        }.buttonStyle(.plain).disabled(busy)
    }
}
struct Pill: View {
    let text: String
    var icon: String? = nil
    var color: Color = SaylTheme.secondary
    var body: some View {
        HStack(spacing: 5) { if let icon { Image(systemName: icon) }; Text(text) }
            .font(.system(size: 11, weight: .semibold)).foregroundStyle(color)
            .padding(.horizontal, 10).padding(.vertical, 7)
            .background(color.opacity(0.10), in: Capsule())
    }
}
struct SectionHeading: View {
    let title: String
    var subtitle: String? = nil
    var body: some View {
        VStack(alignment: .leading, spacing: 5) {
            Text(title).font(.system(.title3, design: .rounded, weight: .bold)).foregroundStyle(SaylTheme.text)
            if let subtitle { Text(subtitle).font(.subheadline).foregroundStyle(SaylTheme.secondary) }
        }.frame(maxWidth: .infinity, alignment: .leading)
    }
}
struct EmptyState: View {
    let icon: String
    let title: String
    let detail: String
    var body: some View {
        VStack(spacing: 16) {
            Image(systemName: icon).font(.system(size: 32, weight: .light)).foregroundStyle(SaylTheme.accent)
                .frame(width: 82, height: 82).background(SaylTheme.accent.opacity(0.08), in: RoundedRectangle(cornerRadius: 26))
            Text(title).font(.title3.weight(.bold)).foregroundStyle(SaylTheme.text)
            Text(detail).font(.subheadline).foregroundStyle(SaylTheme.secondary).multilineTextAlignment(.center).lineSpacing(5)
        }.padding(.vertical, 30).padding(.horizontal, 20).frame(maxWidth: .infinity)
    }
}
struct InlineMessage: View {
    let text: String
    var body: some View {
        Label { Text(text).font(.footnote).lineSpacing(4) } icon: { Image(systemName: "info.circle") }
            .foregroundStyle(SaylTheme.accent).padding(14)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(SaylTheme.accent.opacity(0.07), in: RoundedRectangle(cornerRadius: 16))
    }
}
struct MediaArtwork: View {
    var kind: MediaKind = .video
    var body: some View {
        GeometryReader { geometry in
            ZStack {
                LinearGradient(colors: kind == .video ? [Color(hex: 0x4A454C), Color(hex: 0x292F3D)] : [Color(hex: 0x4C3D33), Color(hex: 0x252C32)], startPoint: .topLeading, endPoint: .bottomTrailing)
                Circle().stroke(Color.white.opacity(0.055), lineWidth: 1).frame(width: geometry.size.width * 0.85)
                Circle().stroke(Color.white.opacity(0.06), lineWidth: 1).frame(width: geometry.size.width * 0.6)
                Image(systemName: kind == .video ? "play.fill" : "waveform").font(.system(size: 26, weight: .medium))
                    .foregroundStyle(SaylTheme.text.opacity(0.9))
                    .frame(width: 62, height: 62).background(.white.opacity(0.09), in: Circle())
            }
        }.clipped().accessibilityHidden(true)
    }
}
