import SwiftUI

struct HomeView: View {
    @EnvironmentObject private var model: AppModel
    @EnvironmentObject private var settings: SettingsStore
    @EnvironmentObject private var library: LibraryStore
    @EnvironmentObject private var privacy: PrivacyGate
    @State private var searchMode = false
    @State private var query = ""
    private let sites: [(String, String, String)] = [
        ("YouTube", "play.rectangle.fill", "https://www.youtube.com"),
        ("Vimeo", "play.circle.fill", "https://vimeo.com"),
        ("SoundCloud", "waveform", "https://soundcloud.com"),
        ("Archive", "building.columns", "https://archive.org")
    ]
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 28) {
                header
                hero
                linkCard
                shortcuts
                if settings.connection == nil { engineCard }
                libraryCard
                HStack(spacing: 6) {
                    Image(systemName: "hand.raised")
                    Text("احفظ فقط ما تملكه أو يُسمح لك بتنزيله.")
                }.font(.caption2).foregroundStyle(SaylTheme.secondary).frame(maxWidth: .infinity).padding(.bottom, 12)
            }.padding(.horizontal, 24).padding(.top, 20)
        }.scrollDismissesKeyboard(.interactively)
    }
    private var header: some View {
        HStack(spacing: 12) {
            BrandMark()
            VStack(alignment: .leading, spacing: 2) {
                Text("سَيْل").font(.system(size: 28, weight: .bold, design: .rounded))
                Text("مساحتك، بلا اتصال.").font(.caption2).foregroundStyle(SaylTheme.secondary)
            }
            Spacer()
            IconButton(icon: "slider.horizontal.3", label: "الإعدادات") { model.showSettings = true }
        }
    }
    private var hero: some View {
        VStack(alignment: .leading, spacing: 16) {
            Pill(text: settings.connection == nil ? "على جهازك، لك وحدك" : "المحرك الموسّع مُعدّ", icon: "sparkle", color: SaylTheme.accent)
            HStack(alignment: .center, spacing: 4) {
                VStack(alignment: .leading, spacing: 12) {
                    Text("كل روابطك.\nفي مكان واحد.")
                        .font(.system(size: 35, weight: .bold, design: .rounded)).lineSpacing(5).fixedSize(horizontal: false, vertical: true)
                    Text("فيديو، صوت، ولحظات تستحق الاحتفاظ.")
                        .font(.subheadline).foregroundStyle(SaylTheme.secondary).lineSpacing(4)
                }.frame(maxWidth: .infinity, alignment: .leading)
                ZStack {
                    Circle().stroke(SaylTheme.stroke, lineWidth: 1).frame(width: 96, height: 96)
                    Circle().stroke(SaylTheme.stroke, lineWidth: 1).frame(width: 70, height: 70)
                    BrandMark(size: 50).rotationEffect(.degrees(12))
                    Circle().fill(SaylTheme.mint).frame(width: 8, height: 8).offset(x: 36, y: -32)
                    Circle().fill(SaylTheme.violet).frame(width: 5, height: 5).offset(x: -38, y: 22)
                }.frame(width: 98, height: 110).accessibilityHidden(true)
            }
        }
    }
    private var linkCard: some View {
        VStack(alignment: .leading, spacing: 18) {
            HStack(spacing: 6) {
                modeButton("رابط مباشر", systemImage: "link", selected: !searchMode) { searchMode = false }
                modeButton("تصفح أو بحث", systemImage: "magnifyingglass", selected: searchMode) { searchMode = true }
            }.padding(4).background(SaylTheme.background.opacity(0.65), in: Capsule())
            if searchMode {
                Text("اكتب موقعًا أو عبارة بحث").font(.subheadline.weight(.semibold))
                TextField("example.com أو عبارة بحث", text: $query)
                    .padding(16).background(SaylTheme.background, in: RoundedRectangle(cornerRadius: 14))
                    .submitLabel(.search).onSubmit(search)
                Text("العناوين تُفتح مباشرة، والكلمات تُرسل إلى محرك البحث المحدد.").font(.caption).foregroundStyle(SaylTheme.secondary)
                PrimaryButton(title: "فتح", icon: "magnifyingglass", action: search)
                    .disabled(query.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
            } else {
                HStack {
                    Text("ابدأ برابط").font(.subheadline.weight(.semibold))
                    Spacer()
                    PasteButton(payloadType: String.self) { values in
                        if let text = values.first { model.linkText = text }
                    }.labelStyle(.iconOnly).tint(SaylTheme.elevated).buttonBorderShape(.capsule)
                        .accessibilityLabel("لصق رابط من الحافظة")
                }
                TextField("https://…", text: $model.linkText, axis: .vertical)
                    .font(.system(size: 15, design: .monospaced)).lineLimit(1...3)
                    .keyboardType(.URL).textInputAutocapitalization(.never).autocorrectionDisabled()
                    .environment(\.layoutDirection, .leftToRight)
                    .padding(16).background(SaylTheme.background, in: RoundedRectangle(cornerRadius: 14))
                PrimaryButton(title: model.resolving ? "نكتشف الجودات…" : "حلّل الرابط", icon: "sparkle.magnifyingglass", busy: model.resolving) {
                    model.inspect(model.linkText)
                }.disabled(model.linkText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                HStack {
                    if model.resolving { Button("إلغاء الفحص") { model.cancelInspection() }.font(.caption) }
                    else { Text("اختر الجودة ومكان الحفظ بعد الفحص.").font(.caption).foregroundStyle(SaylTheme.secondary) }
                    Spacer()
                    Image(systemName: "lock.shield").foregroundStyle(SaylTheme.secondary).font(.caption)
                }
            }
        }.saylCard()
    }
    private func modeButton(_ title: String, systemImage: String, selected: Bool, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Label(title, systemImage: systemImage).font(.system(size: 12, weight: .semibold))
                .frame(maxWidth: .infinity).padding(.vertical, 12)
                .foregroundStyle(selected ? SaylTheme.text : SaylTheme.secondary)
                .background(selected ? SaylTheme.elevated : Color.clear, in: Capsule())
        }.buttonStyle(.plain)
    }
    private func search() {
        let text = query.trimmingCharacters(in: .whitespacesAndNewlines)
        do {
            if text.contains(".") && !text.contains(" ") {
                model.browse(try LinkRules.parse(text))
            } else {
                model.browse(try LinkRules.searchURL(template: settings.searchTemplate, query: text))
            }
        } catch { model.message = error.localizedDescription }
    }
    private var shortcuts: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack { SectionHeading(title: "من أين نبدأ؟"); Text("تصفّح").font(.caption).foregroundStyle(SaylTheme.secondary) }
            HStack(spacing: 12) {
                ForEach(sites, id: \.0) { item in
                    Button {
                        if let url = URL(string: item.2) { model.browse(url) }
                    } label: {
                        VStack(spacing: 10) {
                            Image(systemName: item.1).font(.system(size: 23)).frame(maxWidth: .infinity).frame(height: 58)
                                .background(SaylTheme.surface, in: RoundedRectangle(cornerRadius: 18))
                            Text(item.0).font(.system(size: 10, weight: .medium)).foregroundStyle(SaylTheme.secondary)
                        }.frame(maxWidth: .infinity)
                    }.buttonStyle(.plain).accessibilityLabel("تصفح " + item.0)
                }
            }
        }
    }
    private var engineCard: some View {
        Button { model.showSettings = true } label: {
            HStack(spacing: 14) {
                Image(systemName: "server.rack").font(.title2).foregroundStyle(SaylTheme.violet)
                    .frame(width: 44, height: 50)
                VStack(alignment: .leading, spacing: 7) {
                    Text("أبعد من الرابط المباشر").font(.subheadline.weight(.bold))
                    Text("اربط محركك الموسّع لصفحات المواقع والجودات المنفصلة.").font(.caption).foregroundStyle(SaylTheme.secondary).lineSpacing(3)
                }
                Spacer(minLength: 0)
                Image(systemName: "chevron.forward").font(.caption).foregroundStyle(SaylTheme.secondary)
            }.saylCard()
        }.buttonStyle(.plain)
    }
    private var libraryCard: some View {
        Button { model.tab = .library } label: {
            HStack(spacing: 15) {
                Image(systemName: privacy.unlocked ? "rectangle.stack.fill" : "lock.fill")
                    .foregroundStyle(SaylTheme.mint).frame(width: 45, height: 45)
                    .background(SaylTheme.mint.opacity(0.08), in: RoundedRectangle(cornerRadius: 15))
                VStack(alignment: .leading, spacing: 7) {
                    Text(privacy.unlocked ? "مكتبتك معك" : "مكتبتك تبقى لك").font(.subheadline.weight(.bold))
                    Text(privacy.unlocked ? "\(library.items.count) ملف · \(DisplayText.bytes(library.totalBytes))" : "افتحها باستخدام Face ID أو رمز الجهاز")
                        .font(.caption).foregroundStyle(SaylTheme.secondary)
                }
                Spacer(minLength: 0)
                Image(systemName: "chevron.forward").font(.caption).foregroundStyle(SaylTheme.secondary)
            }.saylCard()
        }.buttonStyle(.plain)
    }
}
