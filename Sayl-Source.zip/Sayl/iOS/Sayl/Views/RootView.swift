import SwiftUI

struct RootView: View {
    @EnvironmentObject private var model: AppModel
    @EnvironmentObject private var downloads: DownloadCenter
    var body: some View {
        ZStack {
            SaylTheme.background.ignoresSafeArea()
            Group {
                switch model.tab {
                case .home: HomeView()
                case .browser: BrowserView()
                case .downloads: DownloadsView()
                case .library: LibraryView()
                }
            }
        }
        .foregroundStyle(SaylTheme.text)
        .safeAreaInset(edge: .bottom, spacing: 0) { tabBar }
        .sheet(item: $model.inspection) { item in
            MediaSheet(media: item).presentationDragIndicator(.visible).presentationCornerRadius(30)
        }
        .sheet(isPresented: $model.showSettings) { SettingsView().presentationDragIndicator(.visible) }
        .alert("تعذّر فحص الرابط", isPresented: Binding(get: { model.message != nil }, set: { if !$0 { model.message = nil } })) {
            if model.needsEngine { Button("إعداد المحرك") { model.showSettings = true } }
            Button("حسنًا", role: .cancel) { model.message = nil }
        } message: { Text(model.message ?? "") }
        .overlay(alignment: .top) {
            if model.resolving && model.tab != .home {
                HStack(spacing: 12) {
                    ProgressView().tint(SaylTheme.accent)
                    Text("نبحث عن الجودات المتاحة…").font(.subheadline)
                    Spacer()
                    Button("إلغاء") { model.cancelInspection() }.font(.footnote)
                }.padding(16).background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 18)).padding()
            }
        }
    }
    private var tabBar: some View {
        HStack(spacing: 4) {
            ForEach(AppModel.Tab.allCases, id: \.self) { tab in
                let selected = model.tab == tab
                Button { withAnimation(.easeOut(duration: 0.18)) { model.tab = tab } } label: {
                    VStack(spacing: 7) {
                        ZStack(alignment: .topTrailing) {
                            Image(systemName: tab.symbol).font(.system(size: 20, weight: selected ? .semibold : .regular))
                            if tab == .downloads && downloads.activeCount > 0 {
                                Circle().fill(SaylTheme.accent).frame(width: 6, height: 6).offset(x: 6, y: -2)
                            }
                        }
                        Text(tab.title).font(.system(size: 10, weight: selected ? .bold : .medium))
                    }.foregroundStyle(selected ? SaylTheme.accent : SaylTheme.secondary)
                        .frame(maxWidth: .infinity).padding(.vertical, 12)
                        .background(selected ? SaylTheme.accent.opacity(0.08) : Color.clear, in: RoundedRectangle(cornerRadius: 20))
                }.buttonStyle(.plain).accessibilityAddTraits(selected ? .isSelected : [])
            }
        }.padding(7).background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 28))
            .overlay(RoundedRectangle(cornerRadius: 28).stroke(SaylTheme.stroke))
            .padding(.horizontal, 18).padding(.top, 8).padding(.bottom, 6)
            .background(SaylTheme.background.opacity(0.94))
    }
}
