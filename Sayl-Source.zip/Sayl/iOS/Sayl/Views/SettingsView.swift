import SwiftUI

struct SettingsView: View {
    @EnvironmentObject private var settings: SettingsStore
    @EnvironmentObject private var downloads: DownloadCenter
    @EnvironmentObject private var browser: BrowserModel
    @EnvironmentObject private var privacy: PrivacyGate
    @Environment(\.dismiss) private var dismiss
    @State private var address = ""
    @State private var token = ""
    @State private var testing = false
    @State private var status: String?
    @State private var proxyHost = ""
    @State private var proxyPort = ""
    @State private var proxyProtocol: SaylProxyProtocol = .httpConnect
    @State private var proxyUsername = ""
    @State private var proxyPassword = ""
    @State private var proxyBusy = false
    @State private var proxyStatus: String?
    @State private var freeProxyKind: SaylFreeProxyKind = .http
    @State private var freeProxyCountry = ""
    @State private var freeProxyResults: [SaylFreeProxyEndpoint] = []
    @State private var freeProxySearching = false
    @State private var freeProxyStatus: String?
    var body: some View {
        NavigationStack {
            Form {
                Section {
                    HStack(spacing: 16) {
                        BrandMark(size: 54)
                        VStack(alignment: .leading, spacing: 7) {
                            Text("سَيْل").font(.title2.weight(.bold))
                            Text("محتواك أقرب إليك.").font(.subheadline).foregroundStyle(SaylTheme.secondary)
                        }
                        Spacer()
                        Pill(text: "1.0", color: SaylTheme.accent)
                    }.padding(.vertical, 10)
                }.listRowBackground(SaylTheme.surface)
                Section {
                    TextField("https://media.example.com", text: $address)
                        .keyboardType(.URL).textInputAutocapitalization(.never).autocorrectionDisabled()
                        .environment(\.layoutDirection, .leftToRight)
                        .accessibilityLabel("عنوان خادمك")
                    SecureField(settings.connection == nil ? "مفتاح الاتصال السري" : "مفتاح جديد، أو اتركه دون تغيير", text: $token)
                        .textInputAutocapitalization(.never).autocorrectionDisabled()
                        .environment(\.layoutDirection, .leftToRight)
                    Button {
                        do {
                            let connection = try draftConnection()
                            try settings.save(address: connection.base.absoluteString, token: connection.token)
                            token = ""; status = "حُفظ الاتصال. استخدم زر الاختبار للتحقق من جاهزية الخادم."
                        } catch { status = error.localizedDescription }
                    } label: { Label("حفظ الاتصال", systemImage: "checkmark.circle") }
                    Button {
                        testing = true; status = nil
                        Task {
                            defer { testing = false }
                            do {
                                let result = try await APIClient(connection: draftConnection(),
                                                                  proxyConfigurations: settings.proxyConfigurations).health()
                                if result.engineInstalled && result.ffmpegInstalled {
                                    status = result.egressProxyConfigured ? "الاتصال يعمل والمحرك متاح. اختبر رابطك الفعلي للتأكد من دعم موقعه." : "الاتصال يعمل، لكن وكيل الخروج غير مُعدّ. استخدم Docker المعزول قبل استقبال روابط غير موثوقة."
                                } else { status = "الخادم يستجيب، لكن yt-dlp أو FFmpeg غير مثبت. راجع دليل تشغيل الخادم." }
                            } catch { status = error.localizedDescription }
                        }
                    } label: {
                        HStack { Label("اختبار الاتصال", systemImage: "network"); Spacer(); if testing { ProgressView() } }
                    }.disabled(testing)
                    if let status { Text(status).font(.footnote).foregroundStyle(SaylTheme.accent).lineSpacing(4) }
                    if settings.connection != nil {
                        Button("فصل المحرك", role: .destructive) { settings.disconnect(); address = ""; token = ""; status = "فُصل المحرك. يبقى التنزيل المباشر متاحًا." }
                            .disabled(downloads.activeCount > 0)
                    }
                } header: { Text("المحرك الموسّع · اختياري") } footer: {
                    Text("الملفات المباشرة لا تحتاج خادمًا. صفحات المواقع وHLS وDASH تُجهّز على خادمك بواسطة yt-dlp وFFmpeg. لا يوجد خادم عام أو مفتاح مرفق.")
                }.listRowBackground(SaylTheme.surface)
                Section {
                    Picker("نوع النتائج", selection: $freeProxyKind) {
                        ForEach(SaylFreeProxyKind.allCases) { kind in
                            Text(kind.title).tag(kind)
                        }
                    }
                    TextField("رمز الدولة اختياري، مثل SA", text: $freeProxyCountry)
                        .textInputAutocapitalization(.characters).autocorrectionDisabled()
                        .environment(\.layoutDirection, .leftToRight)
                    Button {
                        freeProxySearching = true; freeProxyStatus = "يجري جلب القائمة وفحص أفضل المرشحين تلقائيًا…"
                        Task {
                            defer { freeProxySearching = false }
                            do {
                                let result = try await settings.connectBestFreeProxy(
                                    kind: freeProxyKind, country: freeProxyCountry
                                )
                                proxyHost = result.0.host
                                proxyPort = String(result.0.port)
                                proxyProtocol = result.0.proxyProtocol
                                proxyUsername = ""; proxyPassword = ""
                                try downloads.applyProxySettings()
                                browser.applyProxyConfigurations(settings.proxyConfigurations)
                                freeProxyStatus = "تم الاتصال بأفضل عنوان ناجح في العينة: \(result.0.address) · نحو \(result.1) ms"
                            } catch {
                                settings.disconnectProxy()
                                try? downloads.applyProxySettings()
                                browser.applyProxyConfigurations(settings.proxyConfigurations)
                                freeProxyStatus = error.localizedDescription
                            }
                        }
                    } label: {
                        HStack {
                            Label("اختيار واتصال تلقائي مجاني", systemImage: "wand.and.stars")
                            Spacer()
                            if freeProxySearching { ProgressView() }
                        }
                    }.disabled(freeProxySearching || settings.proxyEnabled || downloads.activeCount > 0 || proxyBusy)
                    Button {
                        freeProxySearching = true; freeProxyStatus = nil
                        Task {
                            defer { freeProxySearching = false }
                            do {
                                freeProxyResults = try await settings.searchFreeProxies(
                                    kind: freeProxyKind, country: freeProxyCountry
                                )
                                freeProxyStatus = "عُثر على \(freeProxyResults.count) عنوانًا. لم يُختبر توفرها بعد."
                            } catch {
                                freeProxyResults = []
                                freeProxyStatus = error.localizedDescription
                            }
                        }
                    } label: {
                        HStack {
                            Label("ابحث في القائمة المجانية", systemImage: "magnifyingglass")
                            Spacer()
                            if freeProxySearching { ProgressView() }
                        }
                    }.disabled(freeProxySearching)
                    if settings.proxyScanWorking && settings.proxyScanTotal > 0 {
                        VStack(alignment: .leading, spacing: 6) {
                            ProgressView(value: Double(settings.proxyScanChecked), total: Double(settings.proxyScanTotal))
                            Text("فحص \(settings.proxyScanChecked) من \(settings.proxyScanTotal) · اختبار HTTPS وزمن الاستجابة بالتوازي")
                                .font(.caption).foregroundStyle(SaylTheme.secondary)
                        }
                    }
                    if let freeProxyStatus {
                        Text(freeProxyStatus).font(.footnote).foregroundStyle(SaylTheme.accent)
                    }
                    ForEach(freeProxyResults) { endpoint in
                        HStack(spacing: 12) {
                            VStack(alignment: .leading, spacing: 4) {
                                Text(endpoint.address).font(.system(.footnote, design: .monospaced))
                                    .environment(\.layoutDirection, .leftToRight)
                                Text(endpoint.kind.title).font(.caption).foregroundStyle(SaylTheme.secondary)
                            }
                            Spacer(minLength: 4)
                            Button("حفظ واختيار") {
                                do {
                                    try settings.registerFreeProxy(endpoint)
                                    try settings.useFreeProxy(endpoint)
                                    proxyHost = endpoint.host
                                    proxyPort = String(endpoint.port)
                                    proxyProtocol = endpoint.proxyProtocol
                                    proxyUsername = ""; proxyPassword = ""
                                    freeProxyStatus = "حُفظ العنوان في القائمة واختير لإعداد Sayl. اختبره قبل التفعيل."
                                } catch { freeProxyStatus = error.localizedDescription }
                            }
                            .font(.footnote.weight(.semibold))
                            .disabled(settings.proxyEnabled || downloads.activeCount > 0 || proxyBusy)
                        }
                    }
                    DisclosureGroup("العناوين المحفوظة (\(settings.savedFreeProxies.count))") {
                        if settings.savedFreeProxies.isEmpty {
                            Text("لم تحفظ عناوين بعد.")
                                .font(.footnote).foregroundStyle(SaylTheme.secondary)
                        }
                        ForEach(settings.savedFreeProxies) { endpoint in
                            HStack(spacing: 8) {
                                VStack(alignment: .leading, spacing: 4) {
                                    Text(endpoint.address).font(.system(.footnote, design: .monospaced))
                                        .environment(\.layoutDirection, .leftToRight)
                                    Text(endpoint.kind.title).font(.caption).foregroundStyle(SaylTheme.secondary)
                                }
                                Spacer(minLength: 4)
                                Button("استخدام") {
                                    do {
                                        try settings.useFreeProxy(endpoint)
                                        proxyHost = endpoint.host
                                        proxyPort = String(endpoint.port)
                                        proxyProtocol = endpoint.proxyProtocol
                                        proxyUsername = ""; proxyPassword = ""
                                        proxyStatus = "اختير العنوان المحفوظ. اختبره قبل التفعيل."
                                    } catch { proxyStatus = error.localizedDescription }
                                }
                                .font(.footnote.weight(.semibold))
                                .disabled(settings.proxyEnabled || downloads.activeCount > 0 || proxyBusy)
                                Button(role: .destructive) {
                                    settings.removeFreeProxy(endpoint)
                                } label: {
                                    Image(systemName: "trash")
                                }
                                .buttonStyle(.borderless)
                                .accessibilityLabel("حذف \(endpoint.address) من القائمة المحفوظة")
                            }
                        }
                    }
                    Link("المصدر: ProxyScrape Public API",
                         destination: URL(string: "https://docs.proxyscrape.com/api-reference/public-api/get-proxy-list")!)
                        .font(.footnote)
                    Text("عند الاتصال التلقائي يجلب Sayl قائمة حديثة، يقدّم العناوين المحفوظة سابقًا، يفحص حتى 24 مرشحًا بالتوازي، ثم يفعّل الأقل زمنًا بين الناجحين. البروكسيات العامة غير موثوقة؛ لا تستخدمها للحسابات أو البيانات الحساسة.")
                        .font(.footnote).foregroundStyle(SaylTheme.secondary).lineSpacing(4)
                } header: {
                    Text("البحث عن بروكسيات مجانية")
                } footer: {
                    Text("يتصل Sayl بـProxyScrape لجلب القائمة، وقد يرى المصدر عنوان IP المستخدم للاتصال. النتائج عامة وقد تتوقف؛ حفظها لا يفعّلها. افحص العنوان يدويًا قبل الاستخدام.")
                }.listRowBackground(SaylTheme.surface)
                Section {
                    Picker("نوع البروكسي", selection: $proxyProtocol) {
                        ForEach(SaylProxyProtocol.allCases) { value in
                            Text(value.title).tag(value)
                        }
                    }
                    TextField("عنوان الخادم، مثل proxy.example.com", text: $proxyHost)
                        .textInputAutocapitalization(.never).autocorrectionDisabled()
                        .environment(\.layoutDirection, .leftToRight)
                    TextField("المنفذ", text: $proxyPort)
                        .keyboardType(.numberPad).environment(\.layoutDirection, .leftToRight)
                    TextField("اسم المستخدم (اختياري)", text: $proxyUsername)
                        .textInputAutocapitalization(.never).autocorrectionDisabled()
                        .environment(\.layoutDirection, .leftToRight)
                    SecureField("كلمة مرور البروكسي", text: $proxyPassword)
                        .textInputAutocapitalization(.never).autocorrectionDisabled()
                        .environment(\.layoutDirection, .leftToRight)
                    Button {
                        do {
                            try settings.saveProxy(host: proxyHost, port: proxyPort, proxyType: proxyProtocol,
                                                   username: proxyUsername, password: proxyPassword)
                            proxyPassword = ""
                            proxyStatus = "حُفظ إعداد البروكسي. اضغط اتصال لاختباره وتشغيله."
                        } catch { proxyStatus = error.localizedDescription }
                    } label: { Label("حفظ إعداد البروكسي", systemImage: "square.and.arrow.down") }
                        .disabled(proxyBusy || downloads.activeCount > 0 || settings.proxyEnabled)
                    if settings.proxyEnabled {
                        Button("فصل البروكسي", systemImage: "wifi.slash", role: .destructive) {
                            settings.disconnectProxy()
                            do {
                                try downloads.applyProxySettings()
                                browser.applyProxyConfigurations(settings.proxyConfigurations)
                                proxyStatus = "فُصل بروكسي Sayl؛ الاتصالات الجديدة ستستخدم إعداد الشبكة الافتراضي."
                            } catch { proxyStatus = error.localizedDescription }
                        }.disabled(proxyBusy || downloads.activeCount > 0)
                    } else {
                        Button {
                            proxyBusy = true; proxyStatus = nil
                            Task {
                                defer { proxyBusy = false }
                                do {
                                    try await settings.connectProxy(host: proxyHost, port: proxyPort,
                                                                    proxyType: proxyProtocol, username: proxyUsername,
                                                                    password: proxyPassword)
                                    try downloads.applyProxySettings()
                                    browser.applyProxyConfigurations(settings.proxyConfigurations)
                                    proxyPassword = ""
                                    proxyStatus = "نجح اختبار HTTPS؛ بروكسي Sayl مفعّل للطلبات الجديدة."
                                } catch {
                                    settings.disconnectProxy()
                                    try? downloads.applyProxySettings()
                                    browser.applyProxyConfigurations(settings.proxyConfigurations)
                                    proxyStatus = error.localizedDescription
                                }
                            }
                        } label: {
                            HStack {
                                Label("اختبار البروكسي والاتصال", systemImage: "bolt.horizontal.circle")
                                Spacer()
                                if proxyBusy { ProgressView() }
                            }
                        }.disabled(proxyBusy || downloads.activeCount > 0)
                    }
                    if let proxyStatus {
                        Text(proxyStatus).font(.footnote).foregroundStyle(SaylTheme.accent).lineSpacing(4)
                    }
                    Text("يؤثر على المتصفح وطلبات Sayl فقط، وليس بقية الآيفون. القائمة المجانية عامة ومجهولة؛ لا تستخدمها للحسابات أو البيانات الحساسة. بيانات الدخول اليدوية تحفظ في Keychain. HTTP CONNECT وSOCKS5 العاديان لا يشفّران وصلة الجهاز إلى البروكسي.")
                        .font(.footnote).foregroundStyle(SaylTheme.secondary).lineSpacing(4)
                } header: {
                    HStack {
                        Text("البروكسي")
                        Spacer()
                        Text(settings.proxyEnabled ? "مفعّل" : "متوقف")
                            .foregroundStyle(settings.proxyEnabled ? SaylTheme.accent : SaylTheme.secondary)
                    }
                } footer: {
                    Text("يدعم HTTP CONNECT وHTTPS CONNECT وSOCKS5. الاختبار يرسل طلب HTTPS بسيطًا إلى example.com عبر البروكسي. السرعة والتوفر يعتمدان على مزوّد البروكسي؛ فحص المواقع الذي ينفذه محركك الموسّع يخرج من خادمك، لا من بروكسي الآيفون.")
                }.listRowBackground(SaylTheme.surface)
                if downloads.activeCount > 0 {
                    Text("أوقف التنزيلات النشطة قبل تغيير البروكسي حتى لا يختلط الاتصال القديم بالجديد.")
                        .font(.footnote).foregroundStyle(SaylTheme.secondary)
                        .listRowBackground(SaylTheme.surface)
                }
                Section("التنزيل والتخزين") {
                    Toggle("النقل إلى الآيفون عبر Wi-Fi فقط", isOn: $settings.wifiOnly)
                    Toggle("حذف نسخة الخادم بعد الحفظ الناجح", isOn: $settings.removeServerCopy)
                    LabeledContent("حد الملف", value: "2 ج.ب")
                    LabeledContent("النقل المتوازي", value: "ملفان")
                    Text("إعداد Wi-Fi يخص نقل الملفات إلى جهازك، لا طلبات الفحص وتحديث الحالة. الملفات ونقاط الاستكمال القائمة قد تحتفظ بإعداد الشبكة الذي بدأت به.")
                        .font(.footnote).foregroundStyle(SaylTheme.secondary)
                }.listRowBackground(SaylTheme.surface)
                Section {
                    TextField("رابط بحث يحتوي {query}", text: $settings.searchTemplate, axis: .vertical)
                        .keyboardType(.URL).textInputAutocapitalization(.never).autocorrectionDisabled()
                        .environment(\.layoutDirection, .leftToRight).font(.system(.footnote, design: .monospaced))
                } header: { Text("البحث داخل موقع") } footer: {
                    Text("ضع {query} مرة واحدة مكان كلمة البحث. يفتح التطبيق صفحة النتائج لتتصفحها؛ لا يدّعي استخراج نتائج كل موقع تلقائيًا.")
                }.listRowBackground(SaylTheme.surface)
                Section("خصوصيتك") {
                    Label("Face ID أو رمز قفل الجهاز للمكتبة", systemImage: "faceid")
                    Label("قفل تلقائي عند انتقال التطبيق للخلفية", systemImage: "lock.shield")
                    Button("قفل المكتبة الآن", systemImage: "lock") { privacy.lock() }
                    Text("الحماية تعتمد على مصادقة الجهاز وحماية ملفات iOS؛ ليست خزنة بتشفير مستقل. قد تبقى الملفات المرحلية متاحة للنظام بعد أول فتح للجهاز حتى تُستورد إلى المكتبة.")
                        .font(.footnote).foregroundStyle(SaylTheme.secondary).lineSpacing(4)
                }.listRowBackground(SaylTheme.surface)
                Section("قبل أن تعتمد عليه") {
                    Text("لا يوجد دعم مضمون لجميع المواقع، ولا تجاوز لحماية DRM أو الاشتراكات. تسجيل الدخول في المتصفح لا ينقل الكوكيز إلى الخادم.")
                    Text("الروابط التي تفحصها بالمحرك تُرسل إلى خادمك. قد تبقى نسخة الملف هناك حتى حذفه أو انتهاء مدة الاحتفاظ الافتراضية: 24 ساعة.")
                    Text("المكتبة مستبعدة من النسخ الاحتياطي. صدّر نسخة مهمة عبر المشاركة؛ حذف التطبيق قد يحذف ملفاتك.")
                    Text("التطبيق لا يقرأ الحافظة تلقائيًا، ولا يحتوي إعلانات أو تحليلات استخدام.")
                }.font(.footnote).foregroundStyle(SaylTheme.secondary).listRowBackground(SaylTheme.surface)
            }.scrollContentBackground(.hidden).background(SaylTheme.background)
                .navigationTitle("على طريقتك").navigationBarTitleDisplayMode(.inline)
                .toolbar { ToolbarItem(placement: .confirmationAction) { Button("تم") { dismiss() } } }
                .onAppear {
                    address = settings.serverAddress
                    proxyHost = settings.proxyHost
                    proxyPort = settings.proxyPort
                    proxyProtocol = settings.proxyProtocol
                    proxyUsername = settings.proxyUsername
                    proxyPassword = ""
                }
        }.environment(\.layoutDirection, .rightToLeft)
    }
    private func draftConnection() throws -> ServerConnection {
        let base = try settings.validatedServer(address)
        let secret = token.trimmingCharacters(in: .whitespacesAndNewlines)
        let saved = settings.connection(for: base)?.token
        guard let value = secret.isEmpty ? saved : secret, value.count >= 32 else {
            throw SaylError.message("أدخل مفتاحًا صالحًا من إعداد خادمك، بطول 32 محرفًا على الأقل.")
        }
        return ServerConnection(base: base, token: value)
    }
}
