import SwiftUI

struct SettingsView: View {
    @EnvironmentObject private var settings: SettingsStore
    @EnvironmentObject private var downloads: DownloadCenter
    @EnvironmentObject private var privacy: PrivacyGate
    @Environment(\.dismiss) private var dismiss
    @State private var address = ""
    @State private var token = ""
    @State private var testing = false
    @State private var status: String?
    var body: some View {
        NavigationStack {
            Form {
                Section {
                    HStack(spacing: 16) {
                        BrandMark(size: 54)
                        VStack(alignment: .leading, spacing: 7) {
                            Text("سَيْل").font(.title2.weight(.bold))
                            Text("محتواك أقرب إليك.").font(.subheadline).foregroundStyle(SaylTheme.secondary)
                        }
                        Spacer()
                        Pill(text: "1.0", color: SaylTheme.accent)
                    }.padding(.vertical, 10)
                }.listRowBackground(SaylTheme.surface)
                Section {
                    TextField("https://media.example.com", text: $address)
                        .keyboardType(.URL).textInputAutocapitalization(.never).autocorrectionDisabled()
                        .environment(\.layoutDirection, .leftToRight)
                        .accessibilityLabel("عنوان خادمك")
                    SecureField(settings.connection == nil ? "مفتاح الاتصال السري" : "مفتاح جديد، أو اتركه دون تغيير", text: $token)
                        .textInputAutocapitalization(.never).autocorrectionDisabled()
                        .environment(\.layoutDirection, .leftToRight)
                    Button {
                        do {
                            let connection = try draftConnection()
                            try settings.save(address: connection.base.absoluteString, token: connection.token)
                            token = ""; status = "حُفظ الاتصال. استخدم زر الاختبار للتحقق من جاهزية الخادم."
                        } catch { status = error.localizedDescription }
                    } label: { Label("حفظ الاتصال", systemImage: "checkmark.circle") }
                    Button {
                        testing = true; status = nil
                        Task {
                            defer { testing = false }
                            do {
                                let result = try await APIClient(connection: draftConnection()).health()
                                if result.engineInstalled && result.ffmpegInstalled {
                                    status = result.egressProxyConfigured ? "الاتصال يعمل والمحرك متاح. اختبر رابطك الفعلي للتأكد من دعم موقعه." : "الاتصال يعمل، لكن وكيل الخروج غير مُعدّ. استخدم Docker المعزول قبل استقبال روابط غير موثوقة."
                                } else { status = "الخادم يستجيب، لكن yt-dlp أو FFmpeg غير مثبت. راجع دليل تشغيل الخادم." }
                            } catch { status = error.localizedDescription }
                        }
                    } label: {
                        HStack { Label("اختبار الاتصال", systemImage: "network"); Spacer(); if testing { ProgressView() } }
                    }.disabled(testing)
                    if let status { Text(status).font(.footnote).foregroundStyle(SaylTheme.accent).lineSpacing(4) }
                    if settings.connection != nil {
                        Button("فصل المحرك", role: .destructive) { settings.disconnect(); address = ""; token = ""; status = "فُصل المحرك. يبقى التنزيل المباشر متاحًا." }
                            .disabled(downloads.activeCount > 0)
                    }
                } header: { Text("المحرك الموسّع · اختياري") } footer: {
                    Text("الملفات المباشرة لا تحتاج خادمًا. صفحات المواقع وHLS وDASH تُجهّز على خادمك بواسطة yt-dlp وFFmpeg. لا يوجد خادم عام أو مفتاح مرفق.")
                }.listRowBackground(SaylTheme.surface)
                Section("التنزيل والتخزين") {
                    Toggle("النقل إلى الآيفون عبر Wi-Fi فقط", isOn: $settings.wifiOnly)
                    Toggle("حذف نسخة الخادم بعد الحفظ الناجح", isOn: $settings.removeServerCopy)
                    LabeledContent("حد الملف", value: "2 ج.ب")
                    LabeledContent("النقل المتوازي", value: "ملفان")
                    Text("إعداد Wi-Fi يخص نقل الملفات إلى جهازك، لا طلبات الفحص وتحديث الحالة. الملفات ونقاط الاستكمال القائمة قد تحتفظ بإعداد الشبكة الذي بدأت به.")
                        .font(.footnote).foregroundStyle(SaylTheme.secondary)
                }.listRowBackground(SaylTheme.surface)
                Section {
                    TextField("رابط بحث يحتوي {query}", text: $settings.searchTemplate, axis: .vertical)
                        .keyboardType(.URL).textInputAutocapitalization(.never).autocorrectionDisabled()
                        .environment(\.layoutDirection, .leftToRight).font(.system(.footnote, design: .monospaced))
                } header: { Text("البحث داخل موقع") } footer: {
                    Text("ضع {query} مرة واحدة مكان كلمة البحث. يفتح التطبيق صفحة النتائج لتتصفحها؛ لا يدّعي استخراج نتائج كل موقع تلقائيًا.")
                }.listRowBackground(SaylTheme.surface)
                Section("خصوصيتك") {
                    Label("Face ID أو رمز قفل الجهاز للمكتبة", systemImage: "faceid")
                    Label("قفل تلقائي عند انتقال التطبيق للخلفية", systemImage: "lock.shield")
                    Button("قفل المكتبة الآن", systemImage: "lock") { privacy.lock() }
                    Text("الحماية تعتمد على مصادقة الجهاز وحماية ملفات iOS؛ ليست خزنة بتشفير مستقل. قد تبقى الملفات المرحلية متاحة للنظام بعد أول فتح للجهاز حتى تُستورد إلى المكتبة.")
                        .font(.footnote).foregroundStyle(SaylTheme.secondary).lineSpacing(4)
                }.listRowBackground(SaylTheme.surface)
                Section("قبل أن تعتمد عليه") {
                    Text("لا يوجد دعم مضمون لجميع المواقع، ولا تجاوز لحماية DRM أو الاشتراكات. تسجيل الدخول في المتصفح لا ينقل الكوكيز إلى الخادم.")
                    Text("الروابط التي تفحصها بالمحرك تُرسل إلى خادمك. قد تبقى نسخة الملف هناك حتى حذفه أو انتهاء مدة الاحتفاظ الافتراضية: 24 ساعة.")
                    Text("المكتبة مستبعدة من النسخ الاحتياطي. صدّر نسخة مهمة عبر المشاركة؛ حذف التطبيق قد يحذف ملفاتك.")
                    Text("التطبيق لا يقرأ الحافظة تلقائيًا، ولا يحتوي إعلانات أو تحليلات استخدام.")
                }.font(.footnote).foregroundStyle(SaylTheme.secondary).listRowBackground(SaylTheme.surface)
            }.scrollContentBackground(.hidden).background(SaylTheme.background)
                .navigationTitle("على طريقتك").navigationBarTitleDisplayMode(.inline)
                .toolbar { ToolbarItem(placement: .confirmationAction) { Button("تم") { dismiss() } } }
                .onAppear { address = settings.serverAddress }
        }.environment(\.layoutDirection, .rightToLeft)
    }
    private func draftConnection() throws -> ServerConnection {
        let base = try settings.validatedServer(address)
        let secret = token.trimmingCharacters(in: .whitespacesAndNewlines)
        let saved = settings.connection(for: base)?.token
        guard let value = secret.isEmpty ? saved : secret, value.count >= 32 else {
            throw SaylError.message("أدخل مفتاحًا صالحًا من إعداد خادمك، بطول 32 محرفًا على الأقل.")
        }
        return ServerConnection(base: base, token: value)
    }
}
