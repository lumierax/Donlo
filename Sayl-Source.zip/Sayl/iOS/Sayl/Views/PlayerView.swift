import SwiftUI
import AVKit

struct PlayerView: View {
    let item: LibraryItem
    @EnvironmentObject private var library: LibraryStore
    @EnvironmentObject private var privacy: PrivacyGate
    @Environment(\.dismiss) private var dismiss
    @Environment(\.scenePhase) private var phase
    @State private var player: AVPlayer?
    @State private var speed: Float = 1
    @State private var issue: String?
    var body: some View {
        NavigationStack {
            VStack(spacing: 25) {
                Spacer(minLength: 10)
                if item.kind == .audio {
                    MediaArtwork(kind: .audio).frame(height: 180).clipShape(RoundedRectangle(cornerRadius: 30)).padding(.horizontal, 30)
                }
                if let player { VideoPlayer(player: player).frame(minHeight: item.kind == .audio ? 110 : 240).clipShape(RoundedRectangle(cornerRadius: 20)) }
                Text(item.title).font(.title3.weight(.bold)).multilineTextAlignment(.center).lineSpacing(4).padding(.horizontal)
                HStack(spacing: 24) {
                    IconButton(icon: "gobackward.10", label: "رجوع عشر ثوانٍ") { seek(-10) }
                    IconButton(icon: "playpause.fill", label: "تشغيل أو إيقاف") {
                        guard let player else { return }
                        if player.rate == 0 { player.playImmediately(atRate: speed) } else { player.pause() }
                    }
                    IconButton(icon: "goforward.10", label: "تقديم عشر ثوانٍ") { seek(10) }
                }.environment(\.layoutDirection, .leftToRight)
                Menu {
                    ForEach([Float(0.75), 1, 1.25, 1.5, 2], id: \.self) { value in
                        Button(String(format: "%.2g×", value)) { speed = value; if player?.rate != 0 { player?.rate = value } }
                    }
                } label: { Pill(text: String(format: "السرعة %.2g×", speed), icon: "speedometer", color: SaylTheme.accent) }
                if let issue { InlineMessage(text: issue) }
                Text("يتوقف التشغيل عند قفل المكتبة أو مغادرة التطبيق.").font(.caption).foregroundStyle(SaylTheme.secondary)
                Spacer(minLength: 20)
            }.padding(18).background(SaylTheme.background)
                .navigationTitle(item.kind.title).navigationBarTitleDisplayMode(.inline)
                .toolbar { ToolbarItem(placement: .cancellationAction) { Button("إغلاق") { dismiss() } } }
                .task {
                    guard privacy.unlocked else { dismiss(); return }
                    do {
                        try AVAudioSession.sharedInstance().setCategory(.playback, mode: item.kind == .audio ? .default : .moviePlayback)
                        try AVAudioSession.sharedInstance().setActive(true)
                        let asset = AVURLAsset(url: library.file(item))
                        guard try await asset.load(.isPlayable) else { issue = "تعذّر تشغيل هذا الملف على الجهاز."; return }
                        let instance = AVPlayer(playerItem: AVPlayerItem(asset: asset))
                        let saved = UserDefaults.standard.double(forKey: "position-" + item.id.uuidString)
                        if saved > 0, saved < (item.duration ?? .greatestFiniteMagnitude) - 2 {
                            await instance.seek(to: CMTime(seconds: saved, preferredTimescale: 600))
                        }
                        guard privacy.unlocked, !Task.isCancelled else { return }
                        player = instance; instance.play()
                    } catch { issue = error.localizedDescription }
                }
                .onReceive(NotificationCenter.default.publisher(for: .AVPlayerItemFailedToPlayToEndTime)) { notification in
                    if let failed = notification.object as? AVPlayerItem, failed === player?.currentItem {
                        issue = "توقف تشغيل الملف بسبب خطأ في الوسائط."; player?.pause()
                    }
                }
                .onChange(of: privacy.unlocked) { _, unlocked in if !unlocked { stop(); dismiss() } }
                .onChange(of: phase) { _, value in if value != .active { stop() } }
                .onDisappear { stop(); player = nil }
        }.environment(\.layoutDirection, .rightToLeft)
    }
    private func seek(_ offset: Double) {
        guard let player else { return }
        let current = player.currentTime().seconds
        guard current.isFinite else { return }
        player.seek(to: CMTime(seconds: max(0, min(current + offset, item.duration ?? current + offset)), preferredTimescale: 600))
    }
    private func stop() {
        guard let player else { return }
        let seconds = player.currentTime().seconds
        if seconds.isFinite, seconds >= 0 { UserDefaults.standard.set(seconds, forKey: "position-" + item.id.uuidString) }
        player.pause()
        try? AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
    }
}
