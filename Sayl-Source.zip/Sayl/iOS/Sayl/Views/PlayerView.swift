import SwiftUI
import AVKit

struct PlayerView: View {
    @EnvironmentObject private var playback: PlaybackSession
    @State private var scrubPosition: Double = 0
    @State private var isScrubbing = false

    var body: some View {
        NavigationStack {
            if let item = playback.item {
                ScrollView {
                    VStack(spacing: 22) {
                        if item.kind == .audio {
                            MediaArtwork(kind: .audio)
                                .frame(height: 180)
                                .clipShape(RoundedRectangle(cornerRadius: 30))
                                .padding(.horizontal, 30)
                        } else {
                            // This is the SAME visible AVPlayerLayer used by PiP. Do not
                            // create an AVPlayerViewController with a second PiP owner.
                            PlaybackSurface(view: playback.videoView)
                                .aspectRatio(16 / 9, contentMode: .fit)
                                .frame(minHeight: 200)
                                .clipShape(RoundedRectangle(cornerRadius: 20))
                        }
                        if playback.isLoading { ProgressView("جارٍ تجهيز الملف…") }
                        Text(item.title)
                            .font(.title3.weight(.bold))
                            .multilineTextAlignment(.center)
                            .lineSpacing(4)
                        if playback.duration > 0 {
                            VStack(spacing: 4) {
                                Slider(value: Binding(
                                    get: { isScrubbing ? scrubPosition : min(playback.elapsed, playback.duration) },
                                    set: { scrubPosition = $0 }
                                ), in: 0...max(1, playback.duration), onEditingChanged: { editing in
                                    if editing { scrubPosition = playback.elapsed }
                                    else { playback.seek(to: scrubPosition) }
                                    isScrubbing = editing
                                })
                                .accessibilityLabel("موضع التشغيل")
                                HStack {
                                    Text(DisplayText.duration(isScrubbing ? scrubPosition : playback.elapsed))
                                    Spacer()
                                    Text(DisplayText.duration(playback.duration))
                                }.font(.caption.monospacedDigit()).foregroundStyle(SaylTheme.secondary)
                            }.environment(\.layoutDirection, .leftToRight)
                        }
                        HStack(spacing: 24) {
                            IconButton(icon: "gobackward.10", label: "رجوع عشر ثوانٍ") { playback.seek(by: -10) }
                            IconButton(icon: playback.isPlaying ? "pause.fill" : "play.fill", label: "تشغيل أو إيقاف") {
                                playback.togglePlayback()
                            }
                            IconButton(icon: "goforward.10", label: "تقديم عشر ثوانٍ") { playback.seek(by: 10) }
                        }
                        .disabled(playback.isLoading)
                        .environment(\.layoutDirection, .leftToRight)
                        Menu {
                            ForEach([Float(0.75), 1, 1.25, 1.5, 2], id: \.self) { value in
                                Button(String(format: "%.2g×", value)) { playback.setSpeed(value) }
                            }
                        } label: {
                            Pill(text: String(format: "السرعة %.2g×", playback.speed), icon: "speedometer", color: SaylTheme.accent)
                        }
                        if item.kind == .video {
                            Button { playback.togglePictureInPicture() } label: {
                                Label(playback.lifetime.phase == .active ? "العودة إلى المشغّل" : "صورة داخل صورة",
                                      systemImage: playback.lifetime.phase == .active ? "pip.exit" : "pip.enter")
                                    .font(.headline)
                                    .frame(maxWidth: .infinity)
                                    .padding(.vertical, 14)
                            }
                            .buttonStyle(.borderedProminent)
                            .disabled(!playback.supportsPictureInPicture || playback.isLoading || playback.lifetime.isTransitioning
                                      || (!playback.isPictureInPicturePossible && playback.lifetime.phase != .active))
                            if !playback.supportsPictureInPicture {
                                Text("هذا الجهاز لا يدعم صورة داخل صورة.").font(.caption)
                            } else if !playback.isPictureInPicturePossible && !playback.lifetime.retainsSession {
                                Text("شغّل الفيديو وانتظر ظهور الصورة حتى يصبح زر PiP متاحًا.").font(.caption)
                            }
                        }
                        if let issue = playback.issue { InlineMessage(text: issue) }
                        Text(item.kind == .audio
                             ? "يستمر الصوت في الخلفية؛ زر إغلاق يوقف التشغيل."
                             : "اضغط صورة داخل صورة، أو غادر التطبيق أثناء تشغيل الفيديو إذا كان البدء التلقائي مفعّلًا في iOS.")
                            .font(.caption).foregroundStyle(SaylTheme.secondary)
                            .multilineTextAlignment(.center)
                    }.padding(20)
                }
                .background(SaylTheme.background)
                .navigationTitle(item.kind.title)
                .navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .cancellationAction) {
                        Button("إغلاق") { playback.close() }
                    }
                }
            }
        }
        // Preserve the source surface throughout PiP. The explicit Close button
        // remains available and correctly stops playback before detaching it.
        .interactiveDismissDisabled(playback.lifetime.retainsSession)
        .environment(\.layoutDirection, .rightToLeft)
    }
}

@MainActor
final class PlaybackVideoView: UIView {
    override class var layerClass: AnyClass { AVPlayerLayer.self }
    var playerLayer: AVPlayerLayer { layer as! AVPlayerLayer }
    var onAttachedToWindow: (() -> Void)?

    init() {
        super.init(frame: .zero)
        backgroundColor = .black
        playerLayer.videoGravity = .resizeAspect
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) is not used") }
    override func didMoveToWindow() {
        super.didMoveToWindow()
        if window != nil { onAttachedToWindow?() }
    }
}

private struct PlaybackSurface: UIViewRepresentable {
    let view: PlaybackVideoView
    func makeUIView(context: Context) -> PlaybackVideoView { view }
    func updateUIView(_ uiView: PlaybackVideoView, context: Context) { }
    // No dismantle teardown: PlaybackSession owns this layer while PiP is active.
}
