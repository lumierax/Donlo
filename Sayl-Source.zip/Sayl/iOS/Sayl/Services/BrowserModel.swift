import Foundation
import WebKit
import Combine

struct BrowserCandidate: Identifiable, Hashable {
    var id: String { url.absoluteString }
    let url: URL
    let title: String
    let mime: String
}

private final class WeakBrowserBridge: NSObject, WKScriptMessageHandler {
    weak var owner: BrowserModel?
    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        guard let body = message.body as? [String: String] else { return }
        Task { @MainActor [weak self] in self?.owner?.receive(body) }
    }
}

@MainActor
final class BrowserModel: NSObject, ObservableObject {
    @Published var address = ""
    @Published private(set) var currentUrl: URL?
    @Published private(set) var pageTitle = "المتصفح"
    @Published private(set) var progress = 0.0
    @Published private(set) var canGoBack = false
    @Published private(set) var canGoForward = false
    @Published private(set) var candidates: [BrowserCandidate] = []
    @Published var error: String?
    let webView: WKWebView
    private let bridge = WeakBrowserBridge()
    private var observations: [NSKeyValueObservation] = []

    override init() {
        let configuration = WKWebViewConfiguration()
        configuration.websiteDataStore = .nonPersistent()
        configuration.allowsInlineMediaPlayback = true
        configuration.mediaTypesRequiringUserActionForPlayback = .all
        configuration.defaultWebpagePreferences.allowsContentJavaScript = true
        if let path = Bundle.main.url(forResource: "media-discovery", withExtension: "js"),
           let script = try? String(contentsOf: path, encoding: .utf8) {
            configuration.userContentController.addUserScript(WKUserScript(source: script, injectionTime: .atDocumentEnd,
                                                                           forMainFrameOnly: false, in: .defaultClient))
        }
        webView = WKWebView(frame: .zero, configuration: configuration)
        super.init()
        bridge.owner = self
        configuration.userContentController.add(bridge, contentWorld: .defaultClient, name: "saylMedia")
        webView.navigationDelegate = self; webView.uiDelegate = self
        webView.allowsBackForwardNavigationGestures = true
        webView.isInspectable = false
        observations.append(webView.observe(\.estimatedProgress, options: [.new]) { [weak self] view, _ in
            let value = view.estimatedProgress
            Task { @MainActor in self?.progress = value }
        })
    }
    func open(_ url: URL) {
        guard url.scheme == "https" else { error = "المتصفح يقبل HTTPS فقط."; return }
        address = url.absoluteString; error = nil
        webView.load(URLRequest(url: url))
    }
    func openAddress() {
        do { open(try LinkRules.parse(address)) }
        catch { self.error = error.localizedDescription }
    }
    func scan() {
        webView.callAsyncJavaScript("window.__saylScan?.()", arguments: [:], in: nil, contentWorld: .defaultClient) { _ in }
    }
    fileprivate func receive(_ message: [String: String]) {
        guard let raw = message["url"], let url = try? LinkRules.parse(raw), candidates.count < 100,
              !candidates.contains(where: { $0.url == url }) else { return }
        candidates.append(BrowserCandidate(url: url, title: String((message["title"] ?? "وسائط الصفحة").prefix(240)),
                                           mime: message["mime"] ?? ""))
    }
    func localInspection(_ item: BrowserCandidate) -> MediaInspection? {
        if let direct = LinkRules.directInspection(for: item.url, title: item.title) { return direct }
        let mime = item.mime.lowercased().components(separatedBy: ";")[0]
        let types: [String: (MediaKind, String)] = ["video/mp4": (.video, "mp4"), "video/quicktime": (.video, "mov"),
                                                 "audio/mp4": (.audio, "m4a"), "audio/mpeg": (.audio, "mp3")]
        guard let (kind, ext) = types[mime] else { return nil }
        return MediaInspection(id: UUID().uuidString, title: item.title, webpageUrl: currentUrl ?? item.url,
                               source: item.url.host ?? "الصفحة", options: [MediaOption(id: "direct", label: "وسائط الصفحة",
                               kind: kind, ext: ext, directUrl: item.url)], expiresAt: Date().addingTimeInterval(900).timeIntervalSince1970)
    }
    func headers(for url: URL) async -> [String: String] {
        let cookies: [HTTPCookie] = await withCheckedContinuation { continuation in
            webView.configuration.websiteDataStore.httpCookieStore.getAllCookies { continuation.resume(returning: $0) }
        }
        let host = url.host?.lowercased() ?? ""
        let matching = cookies.filter { cookie in
            let domain = cookie.domain.lowercased().trimmingCharacters(in: CharacterSet(charactersIn: "."))
            let path = url.path.isEmpty ? "/" : url.path
            let pathMatches = path == cookie.path || (path.hasPrefix(cookie.path) && (cookie.path.hasSuffix("/") || path.dropFirst(cookie.path.count).first == "/"))
            return (host == domain || host.hasSuffix("." + domain)) && pathMatches
                && (!cookie.isSecure || url.scheme == "https") && (cookie.expiresDate.map { $0 > Date() } ?? true)
        }
        var result: [String: String] = [:]
        if !matching.isEmpty { result["Cookie"] = HTTPCookie.requestHeaderFields(with: matching)["Cookie"] }
        if let page = currentUrl {
            result["Referer"] = LinkRules.sameOrigin(page, url) ? page.absoluteString : "https://\(page.host ?? "")/"
        }
        if let userAgent = try? await webView.evaluateJavaScript("navigator.userAgent") as? String,
           !userAgent.contains("\r"), !userAgent.contains("\n") { result["User-Agent"] = userAgent }
        return result
    }
    func clearSession() async {
        webView.stopLoading()
        await webView.configuration.websiteDataStore.removeData(ofTypes: WKWebsiteDataStore.allWebsiteDataTypes(), modifiedSince: .distantPast)
        candidates = []; currentUrl = nil; address = ""; pageTitle = "المتصفح"
        webView.loadHTMLString("<html><body style='background:#101216'></body></html>", baseURL: nil)
    }
}

extension BrowserModel: WKNavigationDelegate, WKUIDelegate {
    func webView(_ webView: WKWebView, didCommit navigation: WKNavigation!) {
        candidates = []; currentUrl = webView.url
        if let url = currentUrl, url.scheme == "https" { address = url.absoluteString }
        canGoBack = webView.canGoBack; canGoForward = webView.canGoForward
    }
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        currentUrl = webView.url?.scheme == "https" ? webView.url : nil
        pageTitle = webView.title ?? "المتصفح"
        canGoBack = webView.canGoBack; canGoForward = webView.canGoForward
        scan()
    }
    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        if (error as NSError).code != NSURLErrorCancelled { self.error = "تعذّر فتح الصفحة. \(error.localizedDescription)" }
    }
    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction,
                 decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        let scheme = navigationAction.request.url?.scheme?.lowercased()
        decisionHandler(scheme == "https" || scheme == "about" ? .allow : .cancel)
    }
    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration,
                 for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        if navigationAction.targetFrame == nil, let url = navigationAction.request.url { open(url) }
        return nil
    }
    func webView(_ webView: WKWebView, requestMediaCapturePermissionFor origin: WKSecurityOrigin,
                 initiatedByFrame frame: WKFrameInfo, type: WKMediaCaptureType,
                 decisionHandler: @escaping (WKPermissionDecision) -> Void) { decisionHandler(.deny) }
}
