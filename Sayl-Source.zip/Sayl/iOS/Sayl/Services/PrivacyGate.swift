import Foundation
import LocalAuthentication
import Combine

@MainActor
final class PrivacyGate: ObservableObject {
    @Published private(set) var unlocked = false
    @Published private(set) var authenticating = false
    @Published private(set) var backgroundLocked = false
    @Published var error: String?
    private var context: LAContext?
    private var generation = UUID()

    func unlock() async {
        guard !authenticating else { return }
        let ticket = generation
        let local = LAContext()
        local.localizedCancelTitle = "ليس الآن"
        var issue: NSError?
        guard local.canEvaluatePolicy(.deviceOwnerAuthentication, error: &issue) else {
            error = "فعّل رمز قفل الجهاز أو Face ID من إعدادات الآيفون لفتح المكتبة الخاصة."
            return
        }
        authenticating = true; context = local; error = nil
        do {
            let accepted = try await local.evaluatePolicy(.deviceOwnerAuthentication, localizedReason: "افتح مكتبتك الخاصة في سَيْل")
            if ticket == generation {
                unlocked = accepted
                if accepted { backgroundLocked = false }
            }
        } catch {
            if ticket == generation {
                let code = (error as NSError).code
                if code != LAError.userCancel.rawValue && code != LAError.appCancel.rawValue && code != LAError.systemCancel.rawValue {
                    self.error = "لم يكتمل التحقق. استخدم Face ID أو رمز قفل جهازك."
                }
            }
        }
        if ticket == generation { authenticating = false; context = nil }
    }
    func lock(forBackground: Bool = false) {
        generation = UUID(); context?.invalidate(); context = nil
        backgroundLocked = forBackground
        unlocked = false; authenticating = false
    }
    func clearBackgroundLock() {
        backgroundLocked = false
    }
}
