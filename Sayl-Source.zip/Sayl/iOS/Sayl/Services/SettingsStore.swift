import Foundation
import Combine

@MainActor
final class SettingsStore: ObservableObject {
    @Published var serverAddress: String
    @Published var wifiOnly: Bool { didSet { UserDefaults.standard.set(wifiOnly, forKey: "wifiOnly") } }
    @Published var removeServerCopy: Bool { didSet { UserDefaults.standard.set(removeServerCopy, forKey: "removeServerCopy") } }
    @Published var searchTemplate: String { didSet { UserDefaults.standard.set(searchTemplate, forKey: "searchTemplate") } }
    init() {
        let defaults = UserDefaults.standard
        serverAddress = defaults.string(forKey: "serverAddress") ?? ""
        wifiOnly = defaults.object(forKey: "wifiOnly") as? Bool ?? true
        removeServerCopy = defaults.object(forKey: "removeServerCopy") as? Bool ?? true
        searchTemplate = defaults.string(forKey: "searchTemplate") ?? "https://www.youtube.com/results?search_query={query}"
    }
    var connection: ServerConnection? {
        guard !serverAddress.isEmpty, let base = try? validatedServer(serverAddress) else { return nil }
        return connection(for: base)
    }
    func connection(for base: URL) -> ServerConnection? {
        guard let token = Keychain.load("server@" + base.absoluteString), token.count >= 32 else { return nil }
        return ServerConnection(base: base, token: token)
    }
    func validatedServer(_ address: String) throws -> URL {
        #if DEBUG
        return try LinkRules.server(address, allowLoopbackHTTP: true)
        #else
        return try LinkRules.server(address)
        #endif
    }
    func save(address: String, token: String) throws {
        let url = try validatedServer(address)
        let secret = token.trimmingCharacters(in: .whitespacesAndNewlines)
        guard secret.count >= 32, !secret.contains("\n") else { throw SaylError.message("مفتاح الاتصال يجب أن يكون 32 محرفًا على الأقل.") }
        try Keychain.save(secret, key: "server@" + url.absoluteString)
        serverAddress = url.absoluteString
        UserDefaults.standard.set(serverAddress, forKey: "serverAddress")
    }
    func disconnect() {
        if let base = try? validatedServer(serverAddress) { Keychain.delete("server@" + base.absoluteString) }
        serverAddress = ""
        UserDefaults.standard.removeObject(forKey: "serverAddress")
    }
}
