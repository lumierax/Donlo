import Foundation
import Combine
import Network

enum SaylProxyProtocol: String, CaseIterable, Identifiable, Hashable, Sendable {
    case httpConnect
    case httpsConnect
    case socks5

    var id: String { rawValue }
    var title: String {
        switch self {
        case .httpConnect: return "HTTP CONNECT"
        case .httpsConnect: return "HTTPS CONNECT"
        case .socks5: return "SOCKS5"
        }
    }
}

enum SaylFreeProxyKind: String, CaseIterable, Identifiable, Codable, Hashable, Sendable {
    case http
    case socks5

    var id: String { rawValue }
    var title: String { self == .http ? "HTTP يدعم HTTPS" : "SOCKS5" }
    var proxyProtocol: SaylProxyProtocol { self == .http ? .httpConnect : .socks5 }
}

struct SaylFreeProxyEndpoint: Identifiable, Hashable, Codable, Sendable {
    let host: String
    let port: Int
    let kind: SaylFreeProxyKind

    var id: String { "\(kind.rawValue)|\(host)|\(port)" }
    var address: String { "\(host):\(port)" }
    var proxyProtocol: SaylProxyProtocol { kind.proxyProtocol }
}

@MainActor
final class SettingsStore: ObservableObject {
    @Published var serverAddress: String
    @Published var wifiOnly: Bool { didSet { UserDefaults.standard.set(wifiOnly, forKey: "wifiOnly") } }
    @Published var removeServerCopy: Bool { didSet { UserDefaults.standard.set(removeServerCopy, forKey: "removeServerCopy") } }
    @Published var searchTemplate: String { didSet { UserDefaults.standard.set(searchTemplate, forKey: "searchTemplate") } }
    @Published private(set) var proxyHost: String
    @Published private(set) var proxyPort: String
    @Published private(set) var proxyProtocol: SaylProxyProtocol
    @Published private(set) var proxyUsername: String
    @Published private(set) var proxyEnabled: Bool
    @Published private(set) var savedFreeProxies: [SaylFreeProxyEndpoint]
    @Published private(set) var proxyScanChecked = 0
    @Published private(set) var proxyScanTotal = 0
    @Published private(set) var proxyScanWorking = false
    private static let proxyPasswordKey = "proxy.profile.password"
    private static let savedFreeProxiesKey = "proxy.free.saved"

    init() {
        let defaults = UserDefaults.standard
        serverAddress = defaults.string(forKey: "serverAddress") ?? ""
        wifiOnly = defaults.object(forKey: "wifiOnly") as? Bool ?? true
        removeServerCopy = defaults.object(forKey: "removeServerCopy") as? Bool ?? true
        searchTemplate = defaults.string(forKey: "searchTemplate") ?? "https://www.youtube.com/results?search_query={query}"
        proxyHost = defaults.string(forKey: "proxy.host") ?? ""
        proxyPort = defaults.string(forKey: "proxy.port") ?? ""
        proxyProtocol = SaylProxyProtocol(rawValue: defaults.string(forKey: "proxy.protocol") ?? "") ?? .httpConnect
        proxyUsername = defaults.string(forKey: "proxy.username") ?? ""
        proxyEnabled = defaults.bool(forKey: "proxy.enabled")
        let saved = (try? JSONDecoder().decode(
            [SaylFreeProxyEndpoint].self,
            from: defaults.data(forKey: Self.savedFreeProxiesKey) ?? Data()
        )) ?? []
        savedFreeProxies = Array(saved.filter {
            Self.isPublicIPv4($0.host) && (1...65535).contains($0.port)
        }.prefix(200))
    }

    var proxyConfigurations: [ProxyConfiguration] {
        guard proxyEnabled, let configuration = try? makeProxyConfiguration(
            host: proxyHost, port: proxyPort, proxyType: proxyProtocol,
            username: proxyUsername, password: Keychain.load(Self.proxyPasswordKey) ?? ""
        ) else { return [] }
        return [configuration]
    }

    func saveProxy(host: String, port: String, proxyType proxyProtocol: SaylProxyProtocol,
                   username: String, password: String) throws {
        let profile = try validatedProxyProfile(host: host, port: port, username: username, password: password)
        let sameProfile = profile.host == proxyHost && String(profile.port) == proxyPort
            && proxyProtocol == self.proxyProtocol && profile.username == self.proxyUsername
        let oldPassword = sameProfile ? (Keychain.load(Self.proxyPasswordKey) ?? "") : ""
        let secret = password.isEmpty ? oldPassword : password
        if !profile.username.isEmpty {
            guard !secret.isEmpty else { throw SaylError.message("أدخل كلمة مرور البروكسي أو أفرغ اسم المستخدم.") }
            try Keychain.save(secret, key: Self.proxyPasswordKey)
        } else {
            Keychain.delete(Self.proxyPasswordKey)
        }
        proxyHost = profile.host
        proxyPort = String(profile.port)
        self.proxyProtocol = proxyProtocol
        proxyUsername = profile.username
        let defaults = UserDefaults.standard
        defaults.set(proxyHost, forKey: "proxy.host")
        defaults.set(proxyPort, forKey: "proxy.port")
        defaults.set(proxyProtocol.rawValue, forKey: "proxy.protocol")
        defaults.set(proxyUsername, forKey: "proxy.username")
    }

    func connectProxy(host: String, port: String, proxyType proxyProtocol: SaylProxyProtocol,
                      username: String, password: String) async throws {
        let profile = try validatedProxyProfile(host: host, port: port, username: username, password: password)
        let sameProfile = profile.host == proxyHost && String(profile.port) == proxyPort
            && proxyProtocol == self.proxyProtocol && profile.username == self.proxyUsername
        let oldPassword = sameProfile ? (Keychain.load(Self.proxyPasswordKey) ?? "") : ""
        let secret = password.isEmpty ? oldPassword : password
        guard profile.username.isEmpty || !secret.isEmpty else {
            throw SaylError.message("أدخل كلمة مرور البروكسي أو أفرغ اسم المستخدم.")
        }
        let proxy = try makeProxyConfiguration(
            host: profile.host, port: String(profile.port), proxyType: proxyProtocol,
            username: profile.username, password: secret
        )
        var configuration = URLSessionConfiguration.ephemeral
        configuration.proxyConfigurations = [proxy]
        configuration.timeoutIntervalForRequest = 12
        configuration.timeoutIntervalForResource = 20
        let session = URLSession(configuration: configuration)
        defer { session.invalidateAndCancel() }
        var request = URLRequest(url: URL(string: "https://example.com/")!)
        request.timeoutInterval = 12
        let (_, response) = try await session.data(for: request)
        guard let http = response as? HTTPURLResponse, (200...399).contains(http.statusCode) else {
            throw SaylError.message("وصلنا إلى البروكسي لكن اختبار HTTPS لم ينجح.")
        }
        try saveProxy(host: profile.host, port: String(profile.port), proxyType: proxyProtocol,
                      username: profile.username, password: secret)
        proxyEnabled = true
        UserDefaults.standard.set(true, forKey: "proxy.enabled")
    }

    func disconnectProxy() {
        proxyEnabled = false
        UserDefaults.standard.set(false, forKey: "proxy.enabled")
    }

    func searchFreeProxies(kind: SaylFreeProxyKind, country: String) async throws -> [SaylFreeProxyEndpoint] {
        let countryCode = country.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        guard countryCode.isEmpty || countryCode.range(of: "^[A-Z]{2}$", options: .regularExpression) != nil else {
            throw SaylError.message("اكتب رمز دولة من حرفين مثل SA، أو اتركه فارغًا للبحث في كل الدول.")
        }
        var components = URLComponents(string: "https://api.proxyscrape.com/v4/free-proxy-list/get")!
        var queryItems = [
            URLQueryItem(name: "request", value: "getproxies"),
            URLQueryItem(name: "protocol", value: kind.rawValue),
            URLQueryItem(name: "timeout", value: "10000"),
            URLQueryItem(name: "country", value: countryCode.isEmpty ? "all" : countryCode),
            URLQueryItem(name: "skip", value: "0"),
            URLQueryItem(name: "limit", value: "50")
        ]
        if kind == .http {
            queryItems.append(URLQueryItem(name: "ssl", value: "yes"))
            queryItems.append(URLQueryItem(name: "anonymity", value: "elite"))
        }
        components.queryItems = queryItems
        guard let url = components.url else { throw SaylError.message("تعذّر إنشاء طلب البحث.") }
        var configuration = URLSessionConfiguration.ephemeral
        configuration.proxyConfigurations = proxyConfigurations
        configuration.httpShouldSetCookies = false
        configuration.httpCookieStorage = nil
        configuration.timeoutIntervalForRequest = 20
        configuration.timeoutIntervalForResource = 25
        let session = URLSession(configuration: configuration)
        defer { session.invalidateAndCancel() }
        var request = URLRequest(url: url)
        request.setValue("text/plain", forHTTPHeaderField: "Accept")
        request.timeoutInterval = 20
        let (data, response) = try await session.data(for: request)
        guard data.count <= 1_000_000, let http = response as? HTTPURLResponse,
              (200...299).contains(http.statusCode) else {
            throw SaylError.message("تعذّر جلب القائمة المجانية من المصدر. حاول لاحقًا.")
        }
        guard let text = String(data: data, encoding: .utf8) else {
            throw SaylError.message("أعاد المصدر قائمة غير قابلة للقراءة.")
        }
        var seen = Set<String>()
        let results = text.split(whereSeparator: \.isNewline).compactMap { line -> SaylFreeProxyEndpoint? in
            let normalizedLine = String(line).trimmingCharacters(in: .whitespacesAndNewlines)
            let fields = normalizedLine.split(separator: ":", omittingEmptySubsequences: false)
            guard fields.count == 2,
                  let port = Int(fields[1]), (1...65535).contains(port) else { return nil }
            let host = String(fields[0])
            guard Self.isPublicIPv4(host) else { return nil }
            let endpoint = SaylFreeProxyEndpoint(host: host, port: port, kind: kind)
            guard seen.insert(endpoint.id).inserted else { return nil }
            return endpoint
        }
        guard !results.isEmpty else {
            throw SaylError.message("لم يُعثر على عناوين عامة صالحة بهذا الفلتر. جرّب دولة أخرى أو نوعًا مختلفًا.")
        }
        return Array(results.prefix(50))
    }

    /// يبدأ بالمحفوظات الناجحة ثم يجلب قائمة حديثة، ويفحص عدة عناوين بالتوازي.
    /// لا يوجد انتقال صامت للاتصال المباشر لأن allowFailover=false في إعداد البروكسي.
    func connectBestFreeProxy(kind: SaylFreeProxyKind, country: String) async throws -> (SaylFreeProxyEndpoint, Int) {
        proxyScanWorking = true
        proxyScanChecked = 0
        defer { proxyScanWorking = false }

        let fresh = try await searchFreeProxies(kind: kind, country: country)
        let cached = savedFreeProxies.filter { $0.kind == kind }
        var seen = Set<String>()
        var candidates: [SaylFreeProxyEndpoint] = []
        for endpoint in cached + fresh {
            if seen.insert(endpoint.id).inserted { candidates.append(endpoint) }
            if candidates.count >= 24 { break }
        }

        proxyScanTotal = candidates.count
        guard !candidates.isEmpty else { throw SaylError.message("لا توجد بروكسيات متاحة للفحص.") }

        var successes: [(SaylFreeProxyEndpoint, Int)] = []
        await withTaskGroup(of: (SaylFreeProxyEndpoint, Int)?.self) { group in
            for endpoint in candidates {
                group.addTask { [weak self] in
                    guard let self else { return nil }
                    do { return (endpoint, try await self.testFreeProxy(endpoint, timeout: 5)) }
                    catch { return nil }
                }
            }
            for await result in group {
                proxyScanChecked += 1
                if let result { successes.append(result) }
            }
        }

        guard let best = successes.min(by: { $0.1 < $1.1 }) else {
            throw SaylError.message("اكتمل الفحص ولم ينجح أي بروكسي. جرّب نوعًا أو دولة أخرى.")
        }
        try registerFreeProxy(best.0)
        try await connectProxy(host: best.0.host, port: String(best.0.port),
                               proxyType: best.0.proxyProtocol, username: "", password: "")
        return best
    }

    private func testFreeProxy(_ endpoint: SaylFreeProxyEndpoint, timeout: TimeInterval) async throws -> Int {
        let proxy = try makeProxyConfiguration(host: endpoint.host, port: String(endpoint.port),
                                               proxyType: endpoint.proxyProtocol, username: "", password: "")
        var configuration = URLSessionConfiguration.ephemeral
        configuration.proxyConfigurations = [proxy]
        configuration.httpShouldSetCookies = false
        configuration.httpCookieStorage = nil
        configuration.timeoutIntervalForRequest = timeout
        configuration.timeoutIntervalForResource = timeout + 2
        let session = URLSession(configuration: configuration)
        defer { session.invalidateAndCancel() }

        var request = URLRequest(url: URL(string: "https://example.com/")!)
        request.httpMethod = "HEAD"
        request.timeoutInterval = timeout
        let clock = ContinuousClock()
        let started = clock.now
        let (_, response) = try await session.data(for: request)
        let duration = started.duration(to: clock.now)
        guard let http = response as? HTTPURLResponse, (200...399).contains(http.statusCode) else {
            throw SaylError.message("فشل اختبار البروكسي.")
        }
        let components = duration.components
        let milliseconds = Int(components.seconds * 1000) + Int(components.attoseconds / 1_000_000_000_000_000)
        return max(1, milliseconds)
    }

    func registerFreeProxy(_ endpoint: SaylFreeProxyEndpoint) throws {
        guard Self.isPublicIPv4(endpoint.host), (1...65535).contains(endpoint.port) else {
            throw SaylError.message("عنوان القائمة غير صالح للحفظ.")
        }
        guard !savedFreeProxies.contains(where: { $0.id == endpoint.id }) else { return }
        savedFreeProxies.insert(endpoint, at: 0)
        savedFreeProxies = Array(savedFreeProxies.prefix(200))
        if let data = try? JSONEncoder().encode(savedFreeProxies) {
            UserDefaults.standard.set(data, forKey: Self.savedFreeProxiesKey)
        }
    }

    func removeFreeProxy(_ endpoint: SaylFreeProxyEndpoint) {
        savedFreeProxies.removeAll { $0.id == endpoint.id }
        if let data = try? JSONEncoder().encode(savedFreeProxies) {
            UserDefaults.standard.set(data, forKey: Self.savedFreeProxiesKey)
        }
    }

    func useFreeProxy(_ endpoint: SaylFreeProxyEndpoint) throws {
        guard Self.isPublicIPv4(endpoint.host), (1...65535).contains(endpoint.port) else {
            throw SaylError.message("عنوان القائمة غير صالح.")
        }
        try saveProxy(host: endpoint.host, port: String(endpoint.port), proxyType: endpoint.proxyProtocol,
                      username: "", password: "")
    }

    private func validatedProxyProfile(host: String, port: String, username: String,
                                       password: String) throws -> (host: String, port: Int, username: String) {
        let normalizedHost = host.trimmingCharacters(in: .whitespacesAndNewlines)
        let normalizedUsername = username.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !normalizedHost.isEmpty, normalizedHost.count <= 253,
              !normalizedHost.contains("://"), !normalizedHost.contains("/"),
              !normalizedHost.contains("@"),
              normalizedHost.rangeOfCharacter(from: .whitespacesAndNewlines) == nil,
              let portNumber = Int(port), (1...65535).contains(portNumber),
              !normalizedUsername.contains("\r"), !normalizedUsername.contains("\n"),
              !password.contains("\r"), !password.contains("\n") else {
            throw SaylError.message("أدخل عنوان بروكسي دون scheme أو مسار، ومنفذًا بين 1 و65535.")
        }
        return (normalizedHost, portNumber, normalizedUsername)
    }

    private static func isPublicIPv4(_ host: String) -> Bool {
        let parts = host.split(separator: ".", omittingEmptySubsequences: false)
        let octets = parts.compactMap { Int($0) }
        guard parts.count == 4, octets.count == 4,
              zip(parts, octets).allSatisfy({ String($0.0) == String($0.1) }),
              octets.allSatisfy({ (0...255).contains($0) }) else { return false }
        let a = octets[0], b = octets[1], c = octets[2]
        let specialUse = a == 0 || a == 10 || a == 127 || a >= 224
            || (a == 100 && (64...127).contains(b))
            || (a == 169 && b == 254)
            || (a == 172 && (16...31).contains(b))
            || (a == 192 && b == 168)
            || (a == 192 && b == 0 && (c == 0 || c == 2))
            || (a == 192 && b == 88 && c == 99)
            || (a == 198 && ((18...19).contains(b) || (b == 51 && c == 100)))
            || (a == 203 && b == 0 && c == 113)
        return !specialUse
    }

    private func makeProxyConfiguration(host: String, port: String, proxyType proxyProtocol: SaylProxyProtocol,
                                        username: String, password: String) throws -> ProxyConfiguration {
        let profile = try validatedProxyProfile(host: host, port: port, username: username, password: password)
        guard let networkPort = NWEndpoint.Port(rawValue: UInt16(profile.port)) else {
            throw SaylError.message("منفذ البروكسي غير صالح.")
        }
        let endpoint = NWEndpoint.hostPort(host: .name(profile.host, nil), port: networkPort)
        var configuration: ProxyConfiguration
        switch proxyProtocol {
        case .httpConnect:
            configuration = ProxyConfiguration(httpCONNECTProxy: endpoint)
        case .httpsConnect:
            configuration = ProxyConfiguration(httpCONNECTProxy: endpoint, tlsOptions: NWProtocolTLS.Options())
        case .socks5:
            configuration = ProxyConfiguration(socksv5Proxy: endpoint)
        }
        if !profile.username.isEmpty, !password.isEmpty {
            configuration.applyCredential(username: profile.username, password: password)
        }
        configuration.allowFailover = false
        return configuration
    }

    var connection: ServerConnection? {
        guard !serverAddress.isEmpty, let base = try? validatedServer(serverAddress) else { return nil }
        return connection(for: base)
    }
    func connection(for base: URL) -> ServerConnection? {
        guard let token = Keychain.load("server@" + base.absoluteString), token.count >= 32 else { return nil }
        return ServerConnection(base: base, token: token)
    }
    func validatedServer(_ address: String) throws -> URL {
        #if DEBUG
        return try LinkRules.server(address, allowLoopbackHTTP: true)
        #else
        return try LinkRules.server(address)
        #endif
    }
    func save(address: String, token: String) throws {
        let url = try validatedServer(address)
        let secret = token.trimmingCharacters(in: .whitespacesAndNewlines)
        guard secret.count >= 32, !secret.contains("\n") else { throw SaylError.message("مفتاح الاتصال يجب أن يكون 32 محرفًا على الأقل.") }
        try Keychain.save(secret, key: "server@" + url.absoluteString)
        serverAddress = url.absoluteString
        UserDefaults.standard.set(serverAddress, forKey: "serverAddress")
    }
    func disconnect() {
        if let base = try? validatedServer(serverAddress) { Keychain.delete("server@" + base.absoluteString) }
        serverAddress = ""
        UserDefaults.standard.removeObject(forKey: "serverAddress")
    }
}
