import Foundation

struct ServerConnection: Sendable {
    let base: URL
    let token: String
}

private final class OriginGuard: NSObject, URLSessionTaskDelegate, @unchecked Sendable {
    func urlSession(_ session: URLSession, task: URLSessionTask, willPerformHTTPRedirection response: HTTPURLResponse,
                    newRequest request: URLRequest, completionHandler: @escaping (URLRequest?) -> Void) {
        guard let original = task.originalRequest?.url, let target = request.url,
              LinkRules.sameOrigin(original, target) else { completionHandler(nil); return }
        completionHandler(request)
    }
}

struct APIClient: Sendable {
    let connection: ServerConnection
    private static let guardDelegate = OriginGuard()
    private static let session: URLSession = {
        let configuration = URLSessionConfiguration.ephemeral
        configuration.timeoutIntervalForRequest = 85
        configuration.timeoutIntervalForResource = 100
        configuration.httpShouldSetCookies = false
        return URLSession(configuration: configuration, delegate: guardDelegate, delegateQueue: nil)
    }()

    private func send<T: Decodable>(_ path: String, method: String = "GET", body: Data? = nil) async throws -> T {
        var request = URLRequest(url: connection.base.appendingPathComponent(path))
        request.httpMethod = method; request.httpBody = body
        request.setValue("Bearer " + connection.token, forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        if body != nil { request.setValue("application/json", forHTTPHeaderField: "Content-Type") }
        let (data, response) = try await Self.session.data(for: request)
        guard let http = response as? HTTPURLResponse, (200...299).contains(http.statusCode) else {
            let object = try? JSONSerialization.jsonObject(with: data) as? [String: Any]
            let message = object?["detail"] as? String
            throw SaylError.message(message ?? "تعذّر الاتصال بالخادم. تحقق من العنوان والمفتاح.")
        }
        let decoder = JSONDecoder()
        decoder.keyDecodingStrategy = .convertFromSnakeCase
        return try decoder.decode(T.self, from: data)
    }
    func inspect(_ url: URL) async throws -> MediaInspection {
        try await send("v1/inspect", method: "POST", body: JSONSerialization.data(withJSONObject: ["url": url.absoluteString]))
    }
    func create(inspection: String, option: String) async throws -> RemoteJob {
        try await send("v1/jobs", method: "POST", body: JSONSerialization.data(withJSONObject: ["inspection_id": inspection, "option_id": option]))
    }
    func job(_ id: String) async throws -> RemoteJob { try await send("v1/jobs/\(id)") }
    func cancel(_ id: String) async throws { let _: RemoteJob = try await send("v1/jobs/\(id)", method: "DELETE") }
    func health() async throws -> EngineHealth { try await send("v1/health") }
    func fileRequest(_ id: String) -> URLRequest {
        var request = URLRequest(url: connection.base.appendingPathComponent("v1/jobs/\(id)/file"))
        request.setValue("Bearer " + connection.token, forHTTPHeaderField: "Authorization")
        return request
    }
}

struct EngineHealth: Decodable {
    let status: String
    let engineInstalled: Bool
    let ffmpegInstalled: Bool
    let egressProxyConfigured: Bool
}
