import Foundation
import AVFoundation
import Combine

@MainActor
final class LibraryStore: ObservableObject {
    private struct Snapshot: Codable { var items: [LibraryItem]; var folders: [MediaFolder] }
    @Published private(set) var items: [LibraryItem] = []
    @Published private(set) var folders: [MediaFolder] = []
    @Published private(set) var ready = false
    @Published var error: String?

    init() { reload() }
    func reload() {
        do {
            try AppPaths.prepare()
            if let saved = try AppPaths.read(Snapshot.self, at: AppPaths.index) {
                items = saved.items; folders = saved.folders
            }
            ready = true; error = nil
        } catch {
            ready = false
            self.error = "تعذّرت قراءة فهرس المكتبة. لن تُستبدل بياناتك. افتح قفل الجهاز وحاول مجددًا."
        }
    }
    private func persist() throws {
        guard ready else { throw SaylError.message("المكتبة غير متاحة حاليًا؛ لن نكتب فوق فهرسها.") }
        try AppPaths.write(Snapshot(items: items, folders: folders), to: AppPaths.index, protected: true)
    }
    var totalBytes: Int64 { items.reduce(0) { $0 + $1.bytes } }
    func file(_ item: LibraryItem) -> URL { AppPaths.library.appendingPathComponent(item.filename) }
    func folderName(_ id: UUID?) -> String { folders.first { $0.id == id }?.name ?? "الوارد" }

    @discardableResult
    func createFolder(_ raw: String) throws -> UUID {
        let name = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !name.isEmpty, name.count <= 50 else { throw SaylError.message("اسم المجلد يجب أن يكون بين 1 و50 محرفًا.") }
        if let existing = folders.first(where: { $0.name == name }) { return existing.id }
        let folder = MediaFolder(name: name)
        folders.append(folder)
        do { try persist(); return folder.id }
        catch { folders.removeAll { $0.id == folder.id }; throw error }
    }
    func rename(_ id: UUID, title: String) throws {
        let trimmed = title.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty, trimmed.count <= 240, let index = items.firstIndex(where: { $0.id == id }) else { return }
        let old = items[index].title; items[index].title = trimmed
        do { try persist() } catch { items[index].title = old; throw error }
    }
    func move(_ id: UUID, folderId: UUID?) throws {
        guard let index = items.firstIndex(where: { $0.id == id }), folderId == nil || folders.contains(where: { $0.id == folderId }) else { return }
        let old = items[index].folderId; items[index].folderId = folderId
        do { try persist() } catch { items[index].folderId = old; throw error }
    }
    func favorite(_ id: UUID) throws {
        guard let index = items.firstIndex(where: { $0.id == id }) else { return }
        items[index].favorite.toggle()
        do { try persist() } catch { items[index].favorite.toggle(); throw error }
    }
    func remove(_ item: LibraryItem) throws {
        // Rename to trash first. An index-write failure can restore the original file.
        let original = file(item)
        let trash = AppPaths.staging.appendingPathComponent("trash-" + UUID().uuidString)
        let existed = FileManager.default.fileExists(atPath: original.path)
        if existed { try FileManager.default.moveItem(at: original, to: trash) }
        let saved = items
        items.removeAll { $0.id == item.id }
        do { try persist() }
        catch {
            items = saved
            if existed { try? FileManager.default.moveItem(at: trash, to: original) }
            throw error
        }
        if existed { try FileManager.default.removeItem(at: trash) }
    }
    func importFile(_ staged: URL, record: TransferRecord) async throws -> LibraryItem {
        guard ready else { throw SaylError.message("فهرس المكتبة غير متاح. افتح قفل الجهاز وحاول مجددًا.") }
        if let existing = items.first(where: { $0.id == record.id }) {
            try? FileManager.default.removeItem(at: staged)
            return existing
        }
        let asset = AVURLAsset(url: staged)
        let videoTracks = try await asset.loadTracks(withMediaType: .video)
        let audioTracks = try await asset.loadTracks(withMediaType: .audio)
        guard record.kind == .video ? !videoTracks.isEmpty : !audioTracks.isEmpty else {
            throw SaylError.message("الملف المستلم لا يحتوي الوسائط المطلوبة. ربما أرسل الموقع صفحة خطأ بدل الملف.")
        }
        if record.expectedAudio == true && audioTracks.isEmpty {
            throw SaylError.message("الملف لا يحتوي المسار الصوتي الذي عرضه المصدر. لم يُضف إلى المكتبة.")
        }
        guard try await asset.load(.isPlayable) else { throw SaylError.message("هذا الملف غير قابل للتشغيل على الجهاز.") }
        let rawDuration = try await asset.load(.duration).seconds
        let duration = rawDuration.isFinite && rawDuration > 0 ? rawDuration : nil
        let size = (try FileManager.default.attributesOfItem(atPath: staged.path)[.size] as? NSNumber)?.int64Value ?? 0
        guard size <= 2 * 1024 * 1024 * 1024 else { throw SaylError.message("الملف أكبر من الحد المحلي: ٢ غيغابايت.") }
        guard size > 0 else { throw SaylError.message("الملف المستلم فارغ.") }
        let filename = LinkRules.safeFilename(id: record.id, ext: record.ext)
        let destination = AppPaths.library.appendingPathComponent(filename)
        if FileManager.default.fileExists(atPath: destination.path) { try FileManager.default.removeItem(at: destination) }
        try FileManager.default.moveItem(at: staged, to: destination)
        do {
            try FileManager.default.setAttributes([.protectionKey: FileProtectionType.complete], ofItemAtPath: destination.path)
            let item = LibraryItem(id: record.id, title: record.title, filename: filename, sourceHost: record.sourceUrl.host ?? "رابط مباشر",
                                   kind: record.kind, bytes: size, duration: duration, folderId: record.folderId)
            items.insert(item, at: 0)
            do { try persist() }
            catch { items.removeAll { $0.id == record.id }; throw error }
            return item
        } catch {
            try? FileManager.default.moveItem(at: destination, to: staged)
            throw error
        }
    }
}
