import Foundation
import UIKit
import Combine

@MainActor
final class DownloadCenter: NSObject, ObservableObject {
    @Published private(set) var records: [TransferRecord] = []
    @Published var notice: String?
    private let library: LibraryStore
    private let settings: SettingsStore
    private var tasks: [UUID: URLSessionDownloadTask] = [:]
    private var samples: [UUID: (Date, Int64)] = [:]
    private var lastPersist = Date.distantPast
    private var restored = false
    private var canPersist = true
    private var polling: Task<Void, Never>?
    private var finalizing: Set<UUID> = []
    var backgroundCompletion: (() -> Void)?
    static let byteLimit: Int64 = 2 * 1024 * 1024 * 1024

    private lazy var session: URLSession = {
        let config = URLSessionConfiguration.background(withIdentifier: Self.sessionIdentifier)
        config.sessionSendsLaunchEvents = true
        config.isDiscretionary = false
        config.httpMaximumConnectionsPerHost = 2
        config.httpShouldSetCookies = false
        config.timeoutIntervalForRequest = 60
        config.timeoutIntervalForResource = 24 * 3600
        return URLSession(configuration: config, delegate: self, delegateQueue: nil)
    }()
    // Sensitive browser cookies use a foreground session: redirect vetoes are
    // not promised by Apple's background-session contract.
    private lazy var privateSession: URLSession = {
        let config = URLSessionConfiguration.ephemeral
        config.httpShouldSetCookies = false
        config.httpCookieStorage = nil
        config.httpMaximumConnectionsPerHost = 2
        config.timeoutIntervalForRequest = 60
        config.timeoutIntervalForResource = 24 * 3600
        return URLSession(configuration: config, delegate: self, delegateQueue: nil)
    }()
    nonisolated static var sessionIdentifier: String { (Bundle.main.bundleIdentifier ?? "app.sayl.ios") + ".transfers" }

    init(library: LibraryStore, settings: SettingsStore) {
        self.library = library; self.settings = settings
        super.init()
        do {
            try AppPaths.prepare()
            records = try AppPaths.read([TransferRecord].self, at: AppPaths.transfers) ?? []
        } catch {
            canPersist = false
            notice = "تعذّرت قراءة قائمة التنزيلات. لن يُستبدل سجلها. أعد فتح التطبيق بعد فتح قفل الجهاز."
        }
        reconnect()
    }
    var activeCount: Int { records.filter { $0.state.isActive }.count }
    private func index(_ id: UUID) -> Int? { records.firstIndex { $0.id == id } }
    private func persist() {
        guard canPersist else { return }
        do { try AppPaths.write(records, to: AppPaths.transfers); lastPersist = Date() }
        catch { notice = "تعذّر حفظ حالة التنزيلات على القرص. تحقق من المساحة المتاحة." }
    }
    private func reconnect() {
        session.getAllTasks { [weak self] all in
            DispatchQueue.main.async {
                guard let self else { return }
                for task in all {
                    guard let id = task.taskDescription.flatMap(UUID.init(uuidString:)),
                          let download = task as? URLSessionDownloadTask, let i = self.index(id),
                          ![TransferState.cancelled, .completed, .failed].contains(self.records[i].state) else { task.cancel(); continue }
                    if self.records[i].state == .paused { task.cancel(); continue }
                    self.tasks[id] = download
                    self.records[i].state = .receiving
                }
                for i in self.records.indices {
                    let record = self.records[i]
                    if record.state == .receiving && self.tasks[record.id] == nil {
                        self.records[i].state = FileManager.default.fileExists(atPath: AppPaths.resumeURL(record.id).path) ? .paused : .queued
                        self.records[i].received = 0
                    }
                    if record.state == .preparing && record.remoteJobId == nil {
                        self.records[i].state = .failed
                        self.records[i].error = "لم يكتمل إنشاء المهمة قبل إغلاق التطبيق. أعد فحص الرابط."
                    }
                }
                self.restored = true; self.persist(); self.pump(); self.resumeFinalization()
            }
        }
    }
    func enqueue(inspection: MediaInspection, option: MediaOption, folderId: UUID?, headers: [String: String]) async throws {
        guard canPersist, library.ready else { throw SaylError.message("التخزين المحلي غير متاح حاليًا.") }
        guard activeCount < 12 else { throw SaylError.message("لديك 12 مهمة نشطة. انتظر اكتمال بعضها.") }
        if let estimate = option.bytesEstimate, estimate > Self.byteLimit { throw SaylError.message("حد الملف في هذه النسخة 2 ج.ب.") }
        var record = TransferRecord(title: inspection.title, sourceUrl: inspection.webpageUrl,
                                    directUrl: option.directUrl, kind: option.kind, ext: option.ext, folderId: folderId)
        record.expectedAudio = option.hasAudio
        if option.directUrl != nil {
            record.requestHeaders = headers
            records.insert(record, at: 0); persist(); pump()
            return
        }
        guard let connection = settings.connection else { throw SaylError.message("اضبط المحرك الموسّع من الإعدادات أولًا.") }
        record.remoteBaseUrl = connection.base
        record.state = .preparing
        let id = record.id
        records.insert(record, at: 0); persist()
        do {
            let remote = try await APIClient(connection: connection).create(inspection: inspection.id, option: option.id)
            guard let i = index(id) else { try? await APIClient(connection: connection).cancel(remote.id); return }
            if records[i].state == .cancelled { try? await APIClient(connection: connection).cancel(remote.id); return }
            records[i].remoteJobId = remote.id; persist()
        } catch {
            if let i = index(id), records[i].state != .cancelled {
                records[i].state = .failed; records[i].error = error.localizedDescription; persist()
            }
            throw error
        }
    }
    func setForeground(_ foreground: Bool) {
        polling?.cancel(); polling = nil
        if foreground {
            resumeFinalization()
            polling = Task { [weak self] in
                while !Task.isCancelled {
                    guard let self else { return }
                    await self.pollRemote()
                    try? await Task.sleep(nanoseconds: 2_000_000_000)
                }
            }
        }
    }
    private func pollRemote() async {
        let pending = records.filter { $0.state == .preparing && $0.remoteJobId != nil }
        for record in pending {
            guard !Task.isCancelled, let jobId = record.remoteJobId, let base = record.remoteBaseUrl else { continue }
            guard let connection = settings.connection(for: base) else {
                fail(record.id, "مفتاح الخادم غير متاح. أعد ضبط الاتصال من الإعدادات."); continue
            }
            do {
                let remote = try await APIClient(connection: connection).job(jobId)
                guard let i = index(record.id), records[i].state == .preparing else { continue }
                records[i].error = nil
                records[i].remoteProgress = remote.progress
                switch remote.state {
                case "ready":
                    records[i].state = .queued; records[i].expected = remote.size; records[i].ext = remote.ext
                case "failed", "expired", "cancelled":
                    records[i].state = .failed; records[i].error = remote.error ?? "المهمة لم تعد متاحة على الخادم. أعد فحص الرابط."
                default: break
                }
                persist(); pump()
            } catch {
                guard let i = index(record.id), records[i].state == .preparing else { continue }
                records[i].error = "لا يمكن تحديث الحالة الآن. يستمر الخادم مستقلًا؛ ستُعاد المحاولة عند عودة الاتصال."
            }
        }
    }
    private func pump() {
        guard restored else { return }
        while tasks.count < 2, let record = records.first(where: { $0.state == .queued }) {
            do { try start(record) }
            catch { fail(record.id, error.localizedDescription) }
        }
    }
    private func start(_ record: TransferRecord) throws {
        var request: URLRequest
        if let job = record.remoteJobId, let base = record.remoteBaseUrl {
            guard let connection = settings.connection(for: base) else { throw SaylError.message("مفتاح الخادم غير موجود.") }
            request = APIClient(connection: connection).fileRequest(job)
        } else if let url = record.directUrl {
            request = URLRequest(url: url)
            record.requestHeaders.forEach { request.setValue($0.value, forHTTPHeaderField: $0.key) }
        } else { throw SaylError.message("رابط التنزيل غير متاح. أعد فحص المصدر.") }
        request.allowsCellularAccess = !settings.wifiOnly
        let usesPrivateSession = record.remoteJobId == nil && (record.requestHeaders["Cookie"] != nil || record.requestHeaders["Authorization"] != nil)
        let transport = usesPrivateSession ? privateSession : session
        let task: URLSessionDownloadTask
        if let resume = try? Data(contentsOf: AppPaths.resumeURL(record.id)), !resume.isEmpty {
            task = transport.downloadTask(withResumeData: resume)
            try? FileManager.default.removeItem(at: AppPaths.resumeURL(record.id))
        } else { task = transport.downloadTask(with: request) }
        task.taskDescription = record.id.uuidString
        tasks[record.id] = task
        if let i = index(record.id) { records[i].state = .receiving; records[i].error = nil }
        persist(); task.resume()
    }
    func pause(_ id: UUID) {
        guard let i = index(id), records[i].state == .receiving, let task = tasks[id] else { return }
        records[i].state = .paused; records[i].speed = nil; persist()
        let pausedTaskIdentifier = task.taskIdentifier
        task.cancel { [weak self] data in
            DispatchQueue.main.async {
                guard let self else { return }
                if let data, let i = self.index(id), self.records[i].state == .paused {
                    do {
                        try data.write(to: AppPaths.resumeURL(id), options: .atomic)
                        try FileManager.default.setAttributes([.protectionKey: FileProtectionType.completeUntilFirstUserAuthentication], ofItemAtPath: AppPaths.resumeURL(id).path)
                    } catch { self.notice = "لم يمكن حفظ نقطة الاستكمال؛ سيبدأ التنزيل من جديد عند المتابعة." }
                }
                if self.tasks[id]?.taskIdentifier == pausedTaskIdentifier { self.tasks.removeValue(forKey: id) }
                self.pump()
            }
        }
    }
    func resume(_ id: UUID) {
        guard let i = index(id), records[i].state == .paused, tasks[id] == nil else { return }
        // A server can refuse resume data; its error remains visible, with a full-retry action.
        records[i].state = .queued; records[i].error = nil; persist(); pump()
    }
    func restart(_ id: UUID) {
        guard let i = index(id), (records[i].state.canRetry || records[i].state == .paused), tasks[id] == nil else { return }
        if let name = records[i].stagingName {
            try? FileManager.default.removeItem(at: AppPaths.staging.appendingPathComponent(name))
            records[i].stagingName = nil
        }
        try? FileManager.default.removeItem(at: AppPaths.resumeURL(id))
        records[i].received = 0; records[i].error = nil
        records[i].state = records[i].remoteJobId != nil ? .preparing : .queued
        persist(); pump()
    }
    func cancel(_ id: UUID) {
        guard let i = index(id), records[i].state != .completed, records[i].state != .verifying else { return }
        let record = records[i]
        records[i].state = .cancelled; records[i].speed = nil
        tasks[id]?.cancel(); tasks.removeValue(forKey: id)
        try? FileManager.default.removeItem(at: AppPaths.resumeURL(id))
        if let name = record.stagingName { try? FileManager.default.removeItem(at: AppPaths.staging.appendingPathComponent(name)) }
        if let job = record.remoteJobId, let base = record.remoteBaseUrl, let connection = settings.connection(for: base) {
            Task { try? await APIClient(connection: connection).cancel(job) }
        }
        persist(); pump()
    }
    func clearFinished() {
        records.removeAll { [.completed, .cancelled].contains($0.state) }
        persist()
    }
    private func fail(_ id: UUID, _ message: String) {
        guard let i = index(id), records[i].state != .cancelled, records[i].state != .completed else { return }
        records[i].state = .failed; records[i].error = message; records[i].speed = nil
        persist()
    }
    private func progress(_ id: UUID, taskIdentifier: Int, received: Int64, total: Int64) {
        guard let i = index(id), TransferRules.acceptsNetworkEvent(state: records[i].state, currentTaskIdentifier: tasks[id]?.taskIdentifier, eventTaskIdentifier: taskIdentifier) else { return }
        if received > Self.byteLimit || total > Self.byteLimit {
            fail(id, "الملف تجاوز الحد المسموح: 2 ج.ب.")
            tasks[id]?.cancel(); tasks.removeValue(forKey: id); pump(); return
        }
        let now = Date()
        if let previous = samples[id], now.timeIntervalSince(previous.0) > 0.4 {
            records[i].speed = max(0, Double(received - previous.1) / now.timeIntervalSince(previous.0))
            samples[id] = (now, received)
        } else if samples[id] == nil { samples[id] = (now, received) }
        records[i].received = received
        records[i].expected = total > 0 ? total : nil
        if now.timeIntervalSince(lastPersist) > 1 { persist() }
    }
    private func acceptStaged(_ id: UUID, taskIdentifier: Int, name: String, status: Int, mime: String?) {
        let path = AppPaths.staging.appendingPathComponent(name)
        guard let i = index(id), TransferRules.acceptsNetworkEvent(state: records[i].state, currentTaskIdentifier: tasks[id]?.taskIdentifier, eventTaskIdentifier: taskIdentifier) else {
            try? FileManager.default.removeItem(at: path); pump(); return
        }
        tasks.removeValue(forKey: id); samples.removeValue(forKey: id)
        guard (200...299).contains(status), !(mime?.hasPrefix("text/") ?? false), mime != "application/json" else {
            try? FileManager.default.removeItem(at: path)
            fail(id, "لم يرسل المصدر ملف وسائط صالحًا (HTTP \(status)). أعد فحص الرابط."); pump(); return
        }
        records[i].stagingName = name; records[i].state = .verifying; records[i].speed = nil
        persist(); pump(); resumeFinalization()
    }
    func resumeFinalization() {
        guard UIApplication.shared.isProtectedDataAvailable else { return }
        if !library.ready { library.reload() }
        for record in records where record.state == .verifying && !finalizing.contains(record.id) {
            guard let name = record.stagingName else { fail(record.id, "لم يُعثر على الملف المؤقت. أعد التنزيل."); continue }
            finalizing.insert(record.id)
            Task { [weak self] in
                guard let self else { return }
                defer { self.finalizing.remove(record.id) }
                do {
                    _ = try await self.library.importFile(AppPaths.staging.appendingPathComponent(name), record: record)
                    guard let i = self.index(record.id) else { return }
                    self.records[i].state = .completed; self.records[i].stagingName = nil
                    self.records[i].requestHeaders = [:]
                    self.persist()
                    if self.settings.removeServerCopy, let job = record.remoteJobId, let base = record.remoteBaseUrl,
                       let connection = self.settings.connection(for: base) {
                        try? await APIClient(connection: connection).cancel(job)
                    }
                } catch {
                    if !UIApplication.shared.isProtectedDataAvailable { return }
                    self.fail(record.id, error.localizedDescription)
                }
            }
        }
    }
    private func finished(_ id: UUID, taskIdentifier: Int, error: NSError?) {
        guard let error, let i = index(id), TransferRules.acceptsNetworkEvent(state: records[i].state, currentTaskIdentifier: tasks[id]?.taskIdentifier, eventTaskIdentifier: taskIdentifier) else { return }
        if [.paused, .cancelled, .completed, .verifying, .failed].contains(records[i].state) { return }
        tasks.removeValue(forKey: id); samples.removeValue(forKey: id)
        if let resume = error.userInfo[NSURLSessionDownloadTaskResumeData] as? Data {
            try? resume.write(to: AppPaths.resumeURL(id), options: .atomic)
            records[i].state = .paused; records[i].error = "انقطع الاتصال. اضغط متابعة؛ وقد يطلب الخادم البدء من جديد."
            persist()
        } else { fail(id, "تعذّر نقل الملف. \(error.localizedDescription)") }
        pump()
    }
}

extension DownloadCenter: URLSessionDownloadDelegate {
    nonisolated func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask,
                                 didWriteData bytesWritten: Int64, totalBytesWritten: Int64, totalBytesExpectedToWrite: Int64) {
        guard let id = downloadTask.taskDescription.flatMap(UUID.init(uuidString:)) else { return }
        let taskIdentifier = downloadTask.taskIdentifier
        DispatchQueue.main.async { self.progress(id, taskIdentifier: taskIdentifier, received: totalBytesWritten, total: totalBytesExpectedToWrite) }
    }
    nonisolated func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didFinishDownloadingTo location: URL) {
        guard let id = downloadTask.taskDescription.flatMap(UUID.init(uuidString:)) else { return }
        let taskIdentifier = downloadTask.taskIdentifier
        let mimeExtensions = ["video/mp4": "mp4", "audio/mp4": "m4a", "video/quicktime": "mov", "audio/mpeg": "mp3", "audio/aac": "aac", "audio/wav": "wav"]
        let responseMime = downloadTask.response?.mimeType ?? ""
        let sourceExt = downloadTask.originalRequest?.url?.pathExtension.lowercased() ?? ""
        let ext = mimeExtensions[responseMime] ?? (LinkRules.directExtensions.contains(sourceExt) ? sourceExt : "media")
        let name = UUID().uuidString + "." + ext
        let destination = AppPaths.staging.appendingPathComponent(name)
        // URLSession deletes `location` on return: the move MUST happen synchronously here.
        do {
            try AppPaths.prepare()
            try FileManager.default.moveItem(at: location, to: destination)
            try FileManager.default.setAttributes([.protectionKey: FileProtectionType.completeUntilFirstUserAuthentication], ofItemAtPath: destination.path)
            let response = downloadTask.response as? HTTPURLResponse
            let status = response?.statusCode ?? 0; let mime = response?.mimeType
            DispatchQueue.main.async { self.acceptStaged(id, taskIdentifier: taskIdentifier, name: name, status: status, mime: mime) }
        } catch {
            DispatchQueue.main.async {
                guard self.tasks[id]?.taskIdentifier == taskIdentifier else { return }
                self.tasks.removeValue(forKey: id)
                self.fail(id, "تعذّر حفظ الملف المؤقت على الجهاز."); self.pump()
            }
        }
    }
    nonisolated func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        guard let id = task.taskDescription.flatMap(UUID.init(uuidString:)) else { return }
        let issue = error as NSError?
        let taskIdentifier = task.taskIdentifier
        DispatchQueue.main.async { self.finished(id, taskIdentifier: taskIdentifier, error: issue) }
    }
    nonisolated func urlSessionDidFinishEvents(forBackgroundURLSession session: URLSession) {
        DispatchQueue.main.async {
            let completion = self.backgroundCompletion; self.backgroundCompletion = nil; completion?()
        }
    }
    nonisolated func urlSession(_ session: URLSession, task: URLSessionTask, willPerformHTTPRedirection response: HTTPURLResponse,
                                 newRequest request: URLRequest, completionHandler: @escaping (URLRequest?) -> Void) {
        guard let original = task.originalRequest?.url, let target = request.url,
              target.scheme == "https" || LinkRules.sameOrigin(original, target) else { completionHandler(nil); return }
        var cleaned = request
        if !LinkRules.sameOrigin(original, target) {
            if task.originalRequest?.value(forHTTPHeaderField: "Authorization") != nil { completionHandler(nil); return }
            cleaned.setValue(nil, forHTTPHeaderField: "Cookie")
            cleaned.setValue(nil, forHTTPHeaderField: "Authorization")
            cleaned.setValue(original.scheme.map { "\($0)://\(original.host ?? "")/" }, forHTTPHeaderField: "Referer")
        }
        completionHandler(cleaned)
    }
}
