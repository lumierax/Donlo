import Foundation

// URLs only: safe to use from URLSession's non-main delegate queue.
enum AppPaths {
    static var root: URL { FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0].appendingPathComponent("Sayl", isDirectory: true) }
    static var library: URL { root.appendingPathComponent("Library", isDirectory: true) }
    static var staging: URL { root.appendingPathComponent("Staging", isDirectory: true) }
    static var resumes: URL { root.appendingPathComponent("Resume", isDirectory: true) }
    static var transfers: URL { root.appendingPathComponent("transfers.json") }
    static var index: URL { root.appendingPathComponent("library.json") }

    static func prepare() throws {
        for path in [root, library, staging, resumes] {
            try FileManager.default.createDirectory(at: path, withIntermediateDirectories: true)
            try FileManager.default.setAttributes([.protectionKey: FileProtectionType.completeUntilFirstUserAuthentication], ofItemAtPath: path.path)
        }
        var directory = root
        var resources = URLResourceValues()
        resources.isExcludedFromBackup = true
        try directory.setResourceValues(resources)
    }
    static func write<T: Encodable>(_ value: T, to url: URL, protected: Bool = false) throws {
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.sortedKeys]
        let data = try encoder.encode(value)
        try data.write(to: url, options: .atomic)
        try FileManager.default.setAttributes([.protectionKey: protected ? FileProtectionType.complete : FileProtectionType.completeUntilFirstUserAuthentication], ofItemAtPath: url.path)
    }
    static func read<T: Decodable>(_ type: T.Type, at url: URL) throws -> T? {
        guard FileManager.default.fileExists(atPath: url.path) else { return nil }
        return try JSONDecoder().decode(type, from: Data(contentsOf: url))
    }
    static func resumeURL(_ id: UUID) -> URL { resumes.appendingPathComponent(id.uuidString + ".resume") }
}
