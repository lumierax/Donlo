import AVKit
import Combine
import UIKit

/// Owned by AppModel, not by a sheet or tab. AVKit keeps a *weak* delegate;
/// retain the session, source layer and PiP controller throughout transitions.
@MainActor
final class PlaybackSession: NSObject, ObservableObject, AVPictureInPictureControllerDelegate {
    let player = AVPlayer()
    let videoView = PlaybackVideoView()
    let supportsPictureInPicture = AVPictureInPictureController.isPictureInPictureSupported()

    @Published private(set) var item: LibraryItem?
    @Published var isPresented = false
    @Published private(set) var lifetime = PlaybackLifetime()
    @Published private(set) var isPictureInPicturePossible = false
    @Published private(set) var isLoading = false
    @Published private(set) var isPlaying = false
    @Published private(set) var elapsed: Double = 0
    @Published private(set) var duration: Double = 0
    @Published private(set) var speed: Float = 1
    @Published private(set) var issue: String?

    private var pictureInPicture: AVPictureInPictureController?
    private var possibleObservation: NSKeyValueObservation?
    private var statusObservation: NSKeyValueObservation?
    private var playbackObservation: NSKeyValueObservation?
    private var timeObserver: Any?
    private var failureObserver: NSObjectProtocol?
    private var endObserver: NSObjectProtocol?
    private var loadTask: Task<Void, Never>?
    private var restoreTimeout: Task<Void, Never>?
    private var restoreCompletion: ((Bool) -> Void)?
    private var generation = UUID()
    private var closeRequested = false
    private var audioSessionActive = false

    override init() {
        super.init()
        videoView.playerLayer.player = player
        videoView.onAttachedToWindow = { [weak self] in
            // didMoveToWindow may run during a SwiftUI update.
            Task { @MainActor [weak self] in self?.completeRestorationIfVisible() }
        }
        if supportsPictureInPicture,
           let controller = AVPictureInPictureController(playerLayer: videoView.playerLayer) {
            pictureInPicture = controller
            controller.delegate = self
            possibleObservation = controller.observe(\.isPictureInPicturePossible, options: [.initial, .new]) { [weak self] _, _ in
                Task { @MainActor [weak self] in
                    guard let self else { return }
                    self.isPictureInPicturePossible = self.pictureInPicture?.isPictureInPicturePossible == true
                }
            }
        }
        playbackObservation = player.observe(\.timeControlStatus, options: [.initial, .new]) { [weak self] _, _ in
            Task { @MainActor [weak self] in
                guard let self else { return }
                self.isPlaying = self.player.timeControlStatus != .paused
            }
        }
        timeObserver = player.addPeriodicTimeObserver(forInterval: CMTime(seconds: 0.5, preferredTimescale: 600), queue: .main) { [weak self] _ in
            Task { @MainActor [weak self] in
                guard let self else { return }
                let seconds = self.player.currentTime().seconds
                if seconds.isFinite { self.elapsed = max(0, seconds) }
            }
        }
        failureObserver = NotificationCenter.default.addObserver(forName: .AVPlayerItemFailedToPlayToEndTime, object: nil, queue: .main) { [weak self] notification in
            guard let failed = notification.object as? AVPlayerItem else { return }
            Task { @MainActor [weak self] in
                guard let self, self.player.currentItem === failed else { return }
                self.issue = "توقف تشغيل الملف بسبب خطأ في الوسائط."
                self.player.pause()
            }
        }
        endObserver = NotificationCenter.default.addObserver(forName: .AVPlayerItemDidPlayToEndTime, object: nil, queue: .main) { [weak self] notification in
            guard let ended = notification.object as? AVPlayerItem else { return }
            Task { @MainActor [weak self] in
                guard let self, self.player.currentItem === ended else { return }
                self.savePosition()
                if self.lifetime.retainsSession { self.close() }
            }
        }
    }

    func open(_ selected: LibraryItem, url: URL, authorized: Bool) {
        guard authorized else { return }
        if item?.id == selected.id && !closeRequested {
            isPresented = true
            return
        }
        guard !lifetime.retainsSession && !closeRequested else {
            issue = "أغلق نافذة صورة داخل صورة قبل تشغيل ملف آخر."
            isPresented = true
            return
        }
        finishClosing()
        let ticket = UUID()
        generation = ticket
        item = selected
        speed = 1
        player.defaultRate = 1
        elapsed = 0
        duration = selected.duration.flatMap { $0.isFinite && $0 > 0 ? $0 : nil } ?? 0
        issue = nil
        isLoading = true
        isPresented = true
        pictureInPicture?.canStartPictureInPictureAutomaticallyFromInline = selected.kind == .video
        loadTask = Task { [weak self] in
            guard let self else { return }
            defer { if generation == ticket { isLoading = false } }
            do {
                let asset = AVURLAsset(url: url)
                guard try await asset.load(.isPlayable) else {
                    throw SaylError.message("تعذّر تشغيل هذا الملف على الجهاز.")
                }
                let measuredDuration = try await asset.load(.duration).seconds
                try Task.checkCancellation()
                guard generation == ticket else { return }
                if measuredDuration.isFinite && measuredDuration > 0 { duration = measuredDuration }
                let audio = AVAudioSession.sharedInstance()
                try audio.setCategory(.playback, mode: selected.kind == .audio ? .default : .moviePlayback)
                try audio.setActive(true)
                audioSessionActive = true
                let playerItem = AVPlayerItem(asset: asset)
                player.replaceCurrentItem(with: playerItem)
                statusObservation = playerItem.observe(\.status, options: [.initial, .new]) { [weak self] _, _ in
                    Task { @MainActor [weak self] in
                        guard let self, self.generation == ticket,
                              self.player.currentItem?.status == .failed else { return }
                        self.issue = self.player.currentItem?.error?.localizedDescription ?? "تعذّر تجهيز الفيديو للتشغيل."
                        self.player.pause()
                        self.deactivateAudio()
                    }
                }
                let saved = UserDefaults.standard.double(forKey: "position-" + selected.id.uuidString)
                if saved.isFinite && saved > 0 && (duration == 0 || saved < duration - 2) {
                    await player.seek(to: CMTime(seconds: saved, preferredTimescale: 600))
                }
                try Task.checkCancellation()
                guard generation == ticket && !closeRequested else { return }
                player.playImmediately(atRate: speed)
            } catch is CancellationError {
                // close() or a newer open() owns cleanup. Never stop its audio session here.
            } catch {
                guard generation == ticket else { return }
                issue = error.localizedDescription
                player.pause()
                deactivateAudio()
            }
        }
    }

    func togglePlayback() {
        guard item != nil && !isLoading && !closeRequested else { return }
        if player.timeControlStatus == .paused {
            do {
                try AVAudioSession.sharedInstance().setActive(true)
                audioSessionActive = true
                if duration > 0 && elapsed >= duration - 0.25 { seek(to: 0) }
                player.playImmediately(atRate: speed)
            } catch { issue = error.localizedDescription }
        } else { player.pause() }
    }

    func setSpeed(_ value: Float) {
        guard [Float(0.75), 1, 1.25, 1.5, 2].contains(value) else { return }
        speed = value
        player.defaultRate = value
        if player.rate != 0 { player.rate = value }
    }
    func seek(by offset: Double) { seek(to: player.currentTime().seconds + offset) }
    func seek(to seconds: Double) {
        guard item != nil && seconds.isFinite else { return }
        let target = max(0, duration > 0 ? min(seconds, duration) : seconds)
        player.seek(to: CMTime(seconds: target, preferredTimescale: 600))
        elapsed = target
    }

    /// Only this user action starts PiP explicitly. Automatic background entry is
    /// handled by AVKit via canStartPictureInPictureAutomaticallyFromInline.
    func togglePictureInPicture() {
        guard !closeRequested && !lifetime.isTransitioning else { return }
        if lifetime.phase == .active {
            lifetime.requestInlineReturn()
            isPresented = true
            pictureInPicture?.stopPictureInPicture()
            return
        }
        guard supportsPictureInPicture, let controller = pictureInPicture else {
            issue = "صورة داخل صورة غير مدعومة على هذا الجهاز."
            return
        }
        guard item?.kind == .video && !isLoading && controller.isPictureInPicturePossible,
              videoView.window != nil else {
            issue = "انتظر ظهور الفيديو وتشغيله ثم اضغط صورة داخل صورة مجددًا."
            return
        }
        issue = nil
        lifetime.willStart()
        controller.startPictureInPicture()
    }

    func presentationDidDismiss() {
        // A sheet disappearing during a PiP transition must not tear down AVKit.
        if !lifetime.retainsSession { close() }
    }
    func checkpoint() { savePosition() }

    func close() {
        loadTask?.cancel()
        generation = UUID()
        savePosition()
        player.pause()
        isPresented = false
        closeRequested = true
        pictureInPicture?.canStartPictureInPictureAutomaticallyFromInline = false
        completeRestoration(success: false)
        if lifetime.retainsSession || pictureInPicture?.isPictureInPictureActive == true {
            // If startup has not completed, didStart/failedToStart will finish closing.
            if pictureInPicture?.isPictureInPictureActive == true { pictureInPicture?.stopPictureInPicture() }
        } else { finishClosing() }
    }

    private func savePosition() {
        guard let item, player.currentItem != nil else { return }
        let seconds = player.currentTime().seconds
        if seconds.isFinite && seconds >= 0 {
            UserDefaults.standard.set(seconds, forKey: "position-" + item.id.uuidString)
        }
    }
    private func deactivateAudio() {
        guard audioSessionActive else { return }
        try? AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
        audioSessionActive = false
    }
    private func finishClosing() {
        loadTask?.cancel()
        loadTask = nil
        generation = UUID()
        savePosition()
        player.pause()
        statusObservation = nil
        player.replaceCurrentItem(with: nil)
        pictureInPicture?.canStartPictureInPictureAutomaticallyFromInline = false
        deactivateAudio()
        completeRestoration(success: false)
        lifetime = PlaybackLifetime()
        closeRequested = false
        isLoading = false
        isPlaying = false
        isPresented = false
        item = nil
        elapsed = 0
        duration = 0
    }

    private func completeRestorationIfVisible() {
        guard restoreCompletion != nil && isPresented && videoView.window != nil && !closeRequested else { return }
        completeRestoration(success: true)
    }
    private func completeRestoration(success: Bool) {
        guard let completion = restoreCompletion else { return }
        restoreCompletion = nil
        restoreTimeout?.cancel()
        restoreTimeout = nil
        if !success { lifetime.restorationFailed() }
        completion(success)
    }

    // MARK: AVPictureInPictureControllerDelegate
    func pictureInPictureControllerWillStartPictureInPicture(_ controller: AVPictureInPictureController) {
        lifetime.willStart()
    }
    func pictureInPictureControllerDidStartPictureInPicture(_ controller: AVPictureInPictureController) {
        lifetime.didStart()
        if closeRequested { controller.stopPictureInPicture() }
    }
    func pictureInPictureController(_ controller: AVPictureInPictureController, failedToStartPictureInPictureWithError error: Error) {
        lifetime.failedToStart()
        issue = "تعذّر بدء صورة داخل صورة: \(error.localizedDescription)"
        if closeRequested || !isPresented { finishClosing() }
    }
    func pictureInPictureControllerWillStopPictureInPicture(_ controller: AVPictureInPictureController) {
        lifetime.willStop()
    }
    func pictureInPictureControllerDidStopPictureInPicture(_ controller: AVPictureInPictureController) {
        let shouldClose = lifetime.didStop()
        if closeRequested || shouldClose { close() }
    }
    func pictureInPictureController(_ controller: AVPictureInPictureController,
                                    restoreUserInterfaceForPictureInPictureStopWithCompletionHandler completionHandler: @escaping (Bool) -> Void) {
        guard !closeRequested && item != nil else { completionHandler(false); return }
        completeRestoration(success: false)
        lifetime.requestInlineReturn()
        restoreCompletion = completionHandler
        isPresented = true
        completeRestorationIfVisible()
        if restoreCompletion != nil {
            // An unavailable presentation must not leave AVKit's completion pending forever.
            restoreTimeout = Task { [weak self] in
                do { try await Task.sleep(nanoseconds: 3_000_000_000) } catch { return }
                self?.completeRestoration(success: false)
            }
        }
    }
}
