/* Sayl's own bounded DOM observer. No eval, de-obfuscation, cookie collection,
   DRM handling, network interception, or automatic download. Runs in an isolated world. */
(() => {
  'use strict';
  if (window.__saylObserverInstalled) return;
  window.__saylObserverInstalled = true;
  const supported = /\.(mp4|mov|m4v|m4a|mp3|aac|wav|m3u8|mpd)(?:$|[?#])/i;
  const known = new Set();
  let timer;
  function emit(value, title, mime = '') {
    if (!value || typeof value !== 'string' || value.length > 8192 || known.size >= 100) return;
    try {
      const url = new URL(value, document.baseURI);
      if (url.protocol !== 'https:' || url.username || url.password) return;
      url.hash = '';
      if (known.has(url.href)) return;
      known.add(url.href);
      window.webkit?.messageHandlers?.saylMedia?.postMessage({
        url: url.href, title: String(title || document.title || 'وسائط الصفحة').slice(0, 240),
        mime: String(mime).slice(0, 100)
      });
    } catch (_) { /* A bad candidate must not stop the page observer. */ }
  }
  function jsonMedia(node, depth = 0) {
    if (!node || typeof node !== 'object' || depth > 8) return;
    if (Array.isArray(node)) { node.slice(0, 60).forEach(x => jsonMedia(x, depth + 1)); return; }
    const type = node['@type'];
    if (type === 'VideoObject' || type === 'AudioObject' ||
        (Array.isArray(type) && type.some(x => ['VideoObject', 'AudioObject'].includes(x)))) {
      emit(node.contentUrl, node.name, node.encodingFormat);
    }
    if (node['@graph']) jsonMedia(node['@graph'], depth + 1);
    if (node.mainEntity) jsonMedia(node.mainEntity, depth + 1);
    if (node.video) jsonMedia(node.video, depth + 1);
    if (node.audio) jsonMedia(node.audio, depth + 1);
  }
  function scan() {
    document.querySelectorAll('video, audio, video source, audio source').forEach(el => {
      const title = el.getAttribute('aria-label') || el.getAttribute('title') || document.title;
      emit(el.currentSrc || el.src || el.getAttribute('src'), title, el.getAttribute('type'));
    });
    document.querySelectorAll('meta[property="og:video"], meta[property="og:video:url"], meta[property="og:audio"]').forEach(el => emit(el.content));
    [...document.querySelectorAll('a[href]')].slice(0, 1200).forEach(el => {
      if (supported.test(el.href)) emit(el.href, el.textContent?.trim());
    });
    [...document.querySelectorAll('script[type="application/ld+json"]')].slice(0, 30).forEach(el => {
      if (el.textContent.length > 500000) return;
      try { jsonMedia(JSON.parse(el.textContent)); } catch (_) {}
    });
    performance.getEntriesByType('resource').slice(-500).forEach(entry => {
      if (supported.test(entry.name)) emit(entry.name);
    });
  }
  window.__saylScan = scan;
  new MutationObserver(() => {
    clearTimeout(timer); timer = setTimeout(scan, 450);
  }).observe(document.documentElement, {childList: true, subtree: true, attributes: true, attributeFilter: ['src']});
  document.addEventListener('play', scan, true);
  setInterval(scan, 5000);
  scan();
})();
