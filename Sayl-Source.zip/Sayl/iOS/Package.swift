// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "SaylCore",
    platforms: [.iOS(.v17), .macOS(.v13)],
    products: [.library(name: "SaylCore", targets: ["SaylCore"])],
    targets: [
        .target(name: "SaylCore", path: "Sayl/Core"),
        .testTarget(name: "SaylCoreTests", dependencies: ["SaylCore"], path: "Tests")
    ]
)
