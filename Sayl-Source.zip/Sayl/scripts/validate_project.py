#!/usr/bin/env python3
"""Structural checks only. xcodebuild remains the authoritative iOS build test."""
from pathlib import Path
import hashlib
import json
import plistlib
import re
import xml.etree.ElementTree as ET

root = Path(__file__).resolve().parents[1]
ios=root/'iOS'; app=ios/'Sayl'; project=ios/'Sayl.xcodeproj/project.pbxproj'
text=project.read_text()
ids=re.findall(r'^\s*([A-F0-9]{24}) = \{isa = ',text,re.M)
assert len(ids)==len(set(ids)), 'Duplicate project identifiers'
for ref in re.findall(r'\b[A-F0-9]{24}\b',text):
    assert ref in ids, f'Unknown project object {ref}'
for source in app.rglob('*.swift'):
    relative=source.relative_to(app).as_posix()
    key=hashlib.sha256(('sayl:file:'+relative).encode()).hexdigest()[:24].upper()
    assert key in ids, f'Missing source reference: {relative}'
for source in [app/'Info.plist',app/'Resources/PrivacyInfo.xcprivacy']:
    plistlib.loads(source.read_bytes())
for file in (ios/'Sayl.xcodeproj').rglob('*.xcscheme'):
    ET.parse(file)
for file in (ios/'Sayl.xcodeproj').rglob('*.xcworkspacedata'):
    ET.parse(file)
for file in (app/'Resources/Assets.xcassets').rglob('Contents.json'):
    data=json.loads(file.read_text())
    for image in data.get('images',[]):
        assert (file.parent/image['filename']).is_file()
assert (app/'Resources/media-discovery.js').is_file()
assert not list(root.glob('**/.env')), 'Do not distribute secrets'
print(f'Project structure: {len(ids)} unique objects, {len(list(app.rglob("*.swift")))} Swift files; plist, scheme and assets valid.')
