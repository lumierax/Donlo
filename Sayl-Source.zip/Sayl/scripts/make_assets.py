#!/usr/bin/env python3
"""Generate original app assets; requires Pillow, used only for development."""
from pathlib import Path
import json
import plistlib
from PIL import Image, ImageDraw

root=Path(__file__).resolve().parents[1]/'iOS/Sayl'
assets=root/'Resources/Assets.xcassets'
assets.mkdir(parents=True,exist_ok=True)
def contents(path, data):
    path.mkdir(parents=True,exist_ok=True)
    (path/'Contents.json').write_text(json.dumps(data,indent=2)+'\n')
contents(assets,{'info':{'author':'xcode','version':1}})
for name,color in [('AccentColor',(255,161,123)),('LaunchBackground',(16,18,22))]:
    contents(assets/(name+'.colorset'),{'colors':[{'idiom':'universal','color':{'color-space':'srgb','components':dict(zip(('red','green','blue'),[f'{c/255:.6f}' for c in color]))|{'alpha':'1.000'}}}], 'info':{'author':'xcode','version':1}})
# Apple supplies the rounded icon mask. The source stays opaque and fills the canvas.
size=1024
image=Image.new('RGB',(size,size))
draw=ImageDraw.Draw(image)
for y in range(size):
    t=y/(size-1)
    color=tuple(round(a*(1-t)+b*t) for a,b in zip((255,204,172),(248,143,109)))
    draw.line((0,y,size,y),fill=color)
draw.ellipse((-340,-360,900,880),outline=(255,215,189),width=3)
draw.ellipse((240,200,1480,1440),outline=(247,159,123),width=3)
mark=Image.new('RGBA',(size,size))
m=ImageDraw.Draw(mark)
ink=(33,26,23,255)
m.line([(512,258),(512,630)],fill=ink,width=70)
m.line([(374,502),(512,645),(650,502)],fill=ink,width=70)
for x,y in [(512,258),(374,502),(512,645),(650,502)]:
    m.ellipse((x-35,y-35,x+35,y+35),fill=ink)
m.rounded_rectangle((300,715,724,785),radius=35,fill=ink)
mark=mark.rotate(15,resample=Image.Resampling.BICUBIC)
image.paste(mark,(0,0),mark)
icon=assets/'AppIcon.appiconset'
contents(icon,{'images':[{'filename':'AppIcon.png','idiom':'universal','platform':'ios','size':'1024x1024'}],'info':{'author':'xcode','version':1}})
image.save(icon/'AppIcon.png',optimize=True)
info={
 'CFBundleDevelopmentRegion':'ar','CFBundleDisplayName':'سَيْل','CFBundleExecutable':'$(EXECUTABLE_NAME)',
 'CFBundleIdentifier':'$(PRODUCT_BUNDLE_IDENTIFIER)','CFBundleInfoDictionaryVersion':'6.0','CFBundleName':'$(PRODUCT_NAME)',
 'CFBundlePackageType':'APPL','CFBundleShortVersionString':'$(MARKETING_VERSION)','CFBundleVersion':'$(CURRENT_PROJECT_VERSION)',
 'LSRequiresIPhoneOS':True,'CFBundleLocalizations':['ar','en'],
 'NSFaceIDUsageDescription':'افتح مكتبتك الخاصة باستخدام Face ID أو رمز دخول الجهاز.',
 'NSLocalNetworkUsageDescription':'للاتصال بمحرك سَيْل الذي تستضيفه على شبكتك عند اختياره في الإعدادات.',
 'NSAppTransportSecurity':{'NSAllowsLocalNetworking':True,'NSExceptionDomains':{'localhost':{'NSExceptionAllowsInsecureHTTPLoads':True,'NSIncludesSubdomains':False}}},
 'UIApplicationSceneManifest':{'UIApplicationSupportsMultipleScenes':False},
 'UIApplicationSupportsIndirectInputEvents':True,
 'UIBackgroundModes':['audio'],  # Required by audio playback and Picture in Picture.

 'UILaunchScreen':{'UIColorName':'LaunchBackground'},
 'UISupportedInterfaceOrientations':['UIInterfaceOrientationPortrait','UIInterfaceOrientationLandscapeLeft','UIInterfaceOrientationLandscapeRight'],
 'UIFileSharingEnabled':False,'LSSupportsOpeningDocumentsInPlace':False,
 'CFBundleURLTypes':[{'CFBundleURLName':'app.sayl.download','CFBundleURLSchemes':['sayl']}],
}
(root/'Info.plist').write_bytes(plistlib.dumps(info,sort_keys=False))
privacy={
 'NSPrivacyTracking':False,'NSPrivacyTrackingDomains':[],
 'NSPrivacyCollectedDataTypes':[],
 'NSPrivacyAccessedAPITypes':[{'NSPrivacyAccessedAPIType':'NSPrivacyAccessedAPICategoryUserDefaults','NSPrivacyAccessedAPITypeReasons':['CA92.1']}],
}
(root/'Resources/PrivacyInfo.xcprivacy').write_bytes(plistlib.dumps(privacy,sort_keys=False))
print('Generated original icon, colors, Info.plist, and privacy manifest.')
