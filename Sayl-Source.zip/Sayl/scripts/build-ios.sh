#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
if ! command -v xcodebuild >/dev/null; then
  echo 'This script requires macOS + full Xcode with the iOS SDK. No binary was created.' >&2
  exit 1
fi
xcodebuild -project "$ROOT/iOS/Sayl.xcodeproj" -scheme Sayl \
  -configuration Debug -destination 'generic/platform=iOS Simulator' \
  -derivedDataPath "$ROOT/build/Simulator" CODE_SIGNING_ALLOWED=NO build
