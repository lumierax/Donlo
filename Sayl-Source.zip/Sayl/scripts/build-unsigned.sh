#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
if ! command -v xcodebuild >/dev/null; then
  echo 'This script requires macOS + full Xcode. No IPA was created.' >&2
  exit 1
fi
xcodebuild -project "$ROOT/iOS/Sayl.xcodeproj" -scheme Sayl -configuration Release \
  -destination 'generic/platform=iOS' -derivedDataPath "$ROOT/build/Device" \
  CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO build
APP="$ROOT/build/Device/Build/Products/Release-iphoneos/Sayl.app"
if [ ! -f "$APP/Sayl" ]; then
  echo 'Build did not produce an application executable. Refusing to package.' >&2
  exit 1
fi
mkdir -p "$ROOT/build/Package"
rm -rf "$ROOT/build/Package/Payload"
mkdir -p "$ROOT/build/Package/Payload"
ditto "$APP" "$ROOT/build/Package/Payload/Sayl.app"
(cd "$ROOT/build/Package" && /usr/bin/zip -q -r -y "$ROOT/build/Sayl-unsigned.ipa" Payload)
echo "Created: $ROOT/build/Sayl-unsigned.ipa"
echo 'UNSIGNED: not installable until signed with a valid provisioning profile. This is not an App Store archive.'
