#!/usr/bin/env python3
"""Regenerate the dependency-free Xcode project from Sayl's source tree."""
from __future__ import annotations
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1] / "iOS"
APP = ROOT / "Sayl"
PROJECT = ROOT / "Sayl.xcodeproj"
objects: list[str] = []

def uid(label: str) -> str:
    return hashlib.sha256(("sayl:" + label).encode()).hexdigest()[:24].upper()

def q(value: str) -> str:
    return json.dumps(value, ensure_ascii=False)

def put(label: str, isa: str, fields: str) -> str:
    key = uid(label)
    objects.append(f"\t\t{key} = {{isa = {isa}; {fields} }};")
    return key

def refs(values: list[str]) -> str:
    return "(" + ", ".join(values) + ("," if values else "") + ")"

def config(label: str, name: str, settings: dict[str, str | list[str]]) -> str:
    body = " ".join(f"{key} = {refs([q(x) for x in value]) if isinstance(value, list) else q(value)};" for key,value in settings.items())
    return put(label, "XCBuildConfiguration", f"buildSettings = {{{body}}}; name = {name};")

def config_list(label: str, configs: list[str]) -> str:
    return put(label, "XCConfigurationList", f"buildConfigurations = {refs(configs)}; defaultConfigurationIsVisible = 0; defaultConfigurationName = Release;")

sources = sorted(APP.rglob("*.swift"))
resources = [APP/"Resources/Assets.xcassets", APP/"Resources/media-discovery.js", APP/"Resources/PrivacyInfo.xcprivacy"]
all_files = sources + resources + [APP/"Info.plist"]
file_refs = {}
source_builds, resource_builds = [], []
for file in all_files:
    relative = file.relative_to(APP).as_posix()
    filetype = {".swift":"sourcecode.swift", ".xcassets":"folder.assetcatalog", ".js":"sourcecode.javascript", ".xcprivacy":"text.xml", ".plist":"text.plist.xml"}[file.suffix]
    ref = put("file:"+relative, "PBXFileReference", f"lastKnownFileType = {filetype}; path = {q(file.name)}; sourceTree = {q('<group>')};")
    file_refs[relative] = ref
    if file in sources or file in resources:
        build = put("build:"+relative, "PBXBuildFile", f"fileRef = {ref};")
        (source_builds if file in sources else resource_builds).append(build)

def directory_group(directory: Path) -> str:
    children = []
    for candidate in sorted(directory.iterdir(), key=lambda p:(p.is_file(),p.name)):
        relative = candidate.relative_to(APP).as_posix()
        if relative in file_refs:
            children.append(file_refs[relative])
        elif candidate.is_dir() and candidate.suffix != ".xcassets":
            children.append(directory_group(candidate))
    label = "group:" + (directory.relative_to(APP).as_posix() if directory != APP else "app")
    return put(label, "PBXGroup", f"children = {refs(children)}; path = {q(directory.name)}; sourceTree = {q('<group>')};")

appgroup=directory_group(APP)
product = put("product", "PBXFileReference", f"explicitFileType = wrapper.application; includeInIndex = 0; path = Sayl.app; sourceTree = BUILT_PRODUCTS_DIR;")
products = put("products", "PBXGroup", f"children = {refs([product])}; name = Products; sourceTree = {q('<group>')};")
rootgroup = put("rootgroup", "PBXGroup", f"children = {refs([appgroup,products])}; sourceTree = {q('<group>')};")
sourcephase = put("sources", "PBXSourcesBuildPhase", f"buildActionMask = 2147483647; files = {refs(source_builds)}; runOnlyForDeploymentPostprocessing = 0;")
resourcephase = put("resources", "PBXResourcesBuildPhase", f"buildActionMask = 2147483647; files = {refs(resource_builds)}; runOnlyForDeploymentPostprocessing = 0;")
frameworkphase = put("frameworks", "PBXFrameworksBuildPhase", "buildActionMask = 2147483647; files = (); runOnlyForDeploymentPostprocessing = 0;")
base_project = {
    "ALWAYS_SEARCH_USER_PATHS":"NO", "CLANG_ENABLE_MODULES":"YES", "CLANG_ENABLE_OBJC_ARC":"YES",
    "CLANG_WARN_DOCUMENTATION_COMMENTS":"YES", "GCC_C_LANGUAGE_STANDARD":"gnu17",
    "IPHONEOS_DEPLOYMENT_TARGET":"17.0", "SDKROOT":"iphoneos", "SWIFT_VERSION":"5.0",
    "ENABLE_STRICT_OBJC_MSGSEND":"YES", "GCC_NO_COMMON_BLOCKS":"YES",
}
project_configs = config_list("projectconfigs", [
    config("projectdebug", "Debug", {**base_project, "DEBUG_INFORMATION_FORMAT":"dwarf", "GCC_OPTIMIZATION_LEVEL":"0", "SWIFT_OPTIMIZATION_LEVEL":"-Onone", "ONLY_ACTIVE_ARCH":"YES", "ENABLE_TESTABILITY":"YES", "SWIFT_ACTIVE_COMPILATION_CONDITIONS":"DEBUG $(inherited)"}),
    config("projectrelease", "Release", {**base_project, "DEBUG_INFORMATION_FORMAT":"dwarf-with-dsym", "SWIFT_COMPILATION_MODE":"wholemodule", "SWIFT_OPTIMIZATION_LEVEL":"-O", "VALIDATE_PRODUCT":"YES"})])
base_target = {
    "ASSETCATALOG_COMPILER_APPICON_NAME":"AppIcon", "ASSETCATALOG_COMPILER_GLOBAL_ACCENT_COLOR_NAME":"AccentColor",
    "CODE_SIGN_STYLE":"Automatic", "CURRENT_PROJECT_VERSION":"1", "DEVELOPMENT_TEAM":"",
    "GENERATE_INFOPLIST_FILE":"NO", "INFOPLIST_FILE":"Sayl/Info.plist", "LD_RUNPATH_SEARCH_PATHS":["$(inherited)","@executable_path/Frameworks"],
    "MARKETING_VERSION":"1.0.0", "PRODUCT_BUNDLE_IDENTIFIER":"app.sayl.ios", "PRODUCT_NAME":"$(TARGET_NAME)",
    "SUPPORTED_PLATFORMS":"iphoneos iphonesimulator", "SUPPORTS_MACCATALYST":"NO", "SUPPORTS_MAC_DESIGNED_FOR_IPHONE_IPAD":"NO",
    "SWIFT_EMIT_LOC_STRINGS":"YES", "SWIFT_STRICT_CONCURRENCY":"targeted", "TARGETED_DEVICE_FAMILY":"1",
    "ENABLE_PREVIEWS":"YES", "ENABLE_USER_SCRIPT_SANDBOXING":"YES",
}
targetconfigs=config_list("targetconfigs",[config("targetdebug","Debug",base_target),config("targetrelease","Release",base_target)])
target = put("target", "PBXNativeTarget", f"buildConfigurationList = {targetconfigs}; buildPhases = {refs([sourcephase,frameworkphase,resourcephase])}; buildRules = (); dependencies = (); name = Sayl; productName = Sayl; productReference = {product}; productType = {q('com.apple.product-type.application')};")
project = put("project", "PBXProject", f"attributes = {{BuildIndependentTargetsInParallel = YES; LastUpgradeCheck = 1600; TargetAttributes = {{{target} = {{CreatedOnToolsVersion = 16.0; ProvisioningStyle = Automatic; SystemCapabilities = {{com.apple.BackgroundModes = {{enabled = 1;}};}};}};}};}}; buildConfigurationList = {project_configs}; compatibilityVersion = {q('Xcode 14.0')}; developmentRegion = ar; hasScannedForEncodings = 0; knownRegions = (ar, en, Base); mainGroup = {rootgroup}; productRefGroup = {products}; projectDirPath = {q('')}; projectRoot = {q('')}; targets = {refs([target])};")
PROJECT.mkdir(parents=True,exist_ok=True)
(PROJECT/"project.pbxproj").write_text("// !$*UTF8*$!\n{\n\tarchiveVersion = 1;\n\tclasses = {};\n\tobjectVersion = 56;\n\tobjects = {\n"+"\n".join(objects)+f"\n\t}};\n\trootObject = {project};\n}}\n")
scheme=PROJECT/"xcshareddata/xcschemes/Sayl.xcscheme"; scheme.parent.mkdir(parents=True,exist_ok=True)
buildable=f'<BuildableReference BuildableIdentifier="primary" BlueprintIdentifier="{target}" BuildableName="Sayl.app" BlueprintName="Sayl" ReferencedContainer="container:Sayl.xcodeproj"/>'
scheme.write_text(f'''<?xml version="1.0" encoding="UTF-8"?>
<Scheme LastUpgradeVersion="1600" version="1.3">
  <BuildAction parallelizeBuildables="YES" buildImplicitDependencies="YES"><BuildActionEntries><BuildActionEntry buildForTesting="YES" buildForRunning="YES" buildForProfiling="YES" buildForArchiving="YES" buildForAnalyzing="YES">{buildable}</BuildActionEntry></BuildActionEntries></BuildAction>
  <TestAction buildConfiguration="Debug" selectedDebuggerIdentifier="Xcode.DebuggerFoundation.Debugger.LLDB" selectedLauncherIdentifier="Xcode.IDEFoundation.Launcher.LLDB" shouldUseLaunchSchemeArgsEnv="YES"><Testables/></TestAction>
  <LaunchAction buildConfiguration="Debug" selectedDebuggerIdentifier="Xcode.DebuggerFoundation.Debugger.LLDB" selectedLauncherIdentifier="Xcode.IDEFoundation.Launcher.LLDB" launchStyle="0" useCustomWorkingDirectory="NO" ignoresPersistentStateOnLaunch="NO" debugDocumentVersioning="YES" debugServiceExtension="internal" allowLocationSimulation="YES"><BuildableProductRunnable runnableDebuggingMode="0">{buildable}</BuildableProductRunnable></LaunchAction>
  <ProfileAction buildConfiguration="Release" shouldUseLaunchSchemeArgsEnv="YES" savedToolIdentifier="" useCustomWorkingDirectory="NO" debugDocumentVersioning="YES"><BuildableProductRunnable runnableDebuggingMode="0">{buildable}</BuildableProductRunnable></ProfileAction>
  <AnalyzeAction buildConfiguration="Debug"/>
  <ArchiveAction buildConfiguration="Release" revealArchiveInOrganizer="YES"/>
</Scheme>
''')
workspace=PROJECT/"project.xcworkspace"; workspace.mkdir(exist_ok=True)
(workspace/"contents.xcworkspacedata").write_text('<?xml version="1.0" encoding="UTF-8"?><Workspace version="1.0"><FileRef location="self:"/></Workspace>\n')
print(f"Generated {PROJECT.name}: {len(sources)} Swift files, {len(resources)} resources, {len(objects)} objects")
