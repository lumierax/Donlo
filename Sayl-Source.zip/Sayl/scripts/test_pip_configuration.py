#!/usr/bin/env python3
"""Offline configuration regressions. This does not execute AVKit or simulate PiP."""
from pathlib import Path
import ast
import plistlib
import shutil
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]


class PiPConfigurationTests(unittest.TestCase):
    def test_shipped_plist_enables_background_audio(self):
        info = plistlib.loads((ROOT / 'iOS/Sayl/Info.plist').read_bytes())
        self.assertIn('audio', info.get('UIBackgroundModes', []))

    def test_asset_generator_preserves_background_audio(self):
        tree = ast.parse((ROOT / 'scripts/make_assets.py').read_text())
        assignment = next(node for node in tree.body if isinstance(node, ast.Assign)
                          and any(isinstance(target, ast.Name) and target.id == 'info' for target in node.targets))
        info = ast.literal_eval(assignment.value)
        self.assertIn('audio', info.get('UIBackgroundModes', []))

    def test_project_generator_keeps_background_capability_and_sources(self):
        # Execute the real generator in an isolated copy, not on the shipped tree.
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            shutil.copytree(ROOT / 'iOS/Sayl', root / 'iOS/Sayl')
            (root / 'scripts').mkdir()
            for name in ('generate_project.py', 'validate_project.py'):
                shutil.copy2(ROOT / 'scripts' / name, root / 'scripts' / name)
            for name in ('generate_project.py', 'validate_project.py'):
                result = subprocess.run([sys.executable, str(root / 'scripts' / name)],
                                        text=True, capture_output=True)
                self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
            project = (root / 'iOS/Sayl.xcodeproj/project.pbxproj').read_text()
            self.assertIn('com.apple.BackgroundModes = {enabled = 1;}', project)
            self.assertIn('PlaybackSession.swift', project)
            self.assertIn('PlaybackLifetime.swift', project)
            self.assertEqual(project, (ROOT / 'iOS/Sayl.xcodeproj/project.pbxproj').read_text())

    def test_browser_explicitly_allows_native_pip(self):
        source = (ROOT / 'iOS/Sayl/Services/BrowserModel.swift').read_text()
        self.assertIn('configuration.allowsPictureInPictureMediaPlayback = true', source)

    def test_foreground_transition_does_not_erase_lock_reason(self):
        app = (ROOT / 'iOS/Sayl/App/SaylApp.swift').read_text()
        self.assertNotIn('clearBackgroundLock()', app)
        self.assertIn('.environmentObject(model.playback)', app)


if __name__ == '__main__':
    unittest.main(verbosity=2)
