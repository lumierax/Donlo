#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
(cd "$ROOT/server" && python3 -m pytest -q)
(cd "$ROOT/iOS" && swift test)
while IFS= read -r -d '' file; do
  swiftc -frontend -parse "$file"
done < <(find "$ROOT/iOS/Sayl" -name '*.swift' -print0)
node --check "$ROOT/iOS/Sayl/Resources/media-discovery.js"
python3 "$ROOT/scripts/validate_project.py"
if command -v plutil >/dev/null; then
  plutil -lint -- "$ROOT/iOS/Sayl.xcodeproj/project.pbxproj" "$ROOT/iOS/Sayl/Info.plist"
fi
echo 'Core/server/structure checks passed. This does not compile UIKit or run iOS.'
