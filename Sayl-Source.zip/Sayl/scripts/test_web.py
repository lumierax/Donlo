#!/usr/bin/env python3
"""Offline DOM-observer and design-preview smoke tests in Chromium, not WKWebView."""
from __future__ import annotations
import argparse
from pathlib import Path
import shutil
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument('--screenshots', action='store_true')
args = parser.parse_args()
passed = []

def check(name: str, condition: bool) -> None:
    if not condition:
        raise AssertionError(name)
    passed.append(name)
    print('PASS', name)

with sync_playwright() as p:
    executable = shutil.which('chromium') or shutil.which('chromium-browser')
    browser = p.chromium.launch(executable_path=executable, args=['--no-sandbox'])
    context = browser.new_context(viewport={'width':1280,'height':960},device_scale_factor=1)
    context.route('https://**/*', lambda route: route.abort())
    page = context.new_page()
    errors = []
    page.on('pageerror', lambda error: errors.append(str(error)))
    page.set_content((ROOT/'preview/index.html').read_text())
    page.wait_for_timeout(200)
    check('Arabic RTL and no initial page overflow', page.locator('html').get_attribute('dir') == 'rtl' and page.evaluate('document.documentElement.scrollWidth <= innerWidth'))
    if args.screenshots:
        page.screenshot(path=str(ROOT/'preview/desktop.png'), full_page=True)
    page.locator('#sample').click()
    page.locator('#analyze').click()
    check('Quality sheet explicitly labels sample data', page.locator('#media-modal').is_visible() and 'لم يُحلّل' in page.locator('#media-modal').inner_text())
    page.locator('[data-quality="720"]').click()
    check('Only one selected sample quality', page.locator('.quality.selected').count() == 1 and '720p' in page.locator('.quality.selected').inner_text())
    if args.screenshots:
        page.locator('.phone').screenshot(path=str(ROOT/'preview/quality.png'))
    page.locator('#save-demo').click()
    check('Demonstration queue opens', page.locator('#download-data').is_visible() and page.locator('#download-badge').is_visible())
    page.locator('#pause-demo').click()
    check('Pause example changes UI state', 'متوقف' in page.locator('#demo-state').inner_text())
    page.locator('#cancel-demo').click()
    check('Cancel example returns to honest empty state', page.locator('#download-empty').is_visible())
    page.locator('[data-tab="library"]').click()
    check('Library initially locked', page.locator('#library-lock').is_visible())
    page.locator('#unlock-demo').click()
    page.locator('[data-filter="audio"]').click()
    check('Local library sample filtering', page.locator('[data-kind="audio"]').is_visible() and not page.locator('[data-kind="video"]').is_visible())
    page.locator('#lock-demo').click()
    check('Relock sample hides contents', not page.locator('#library-data').is_visible())
    page.locator('[data-tab="home"]').click()
    page.locator('#url').fill('')
    page.locator('#analyze').click()
    check('Empty link gives visible feedback', page.locator('#toast').is_visible())
    page.locator('#mode-search').click()
    page.locator('#url').fill('تجربة')
    page.locator('#analyze').click()
    check('Search sample routes to browser', page.locator('#page-browser').is_visible())
    page.locator('[data-tab="home"]').click()
    page.locator('.settings-open').first.click()
    page.keyboard.press('Escape')
    check('Modal Escape dismisses', not page.locator('#settings-modal').is_visible())
    page.set_viewport_size({'width':390,'height':900})
    check('390px viewport has no horizontal overflow', page.evaluate('document.documentElement.scrollWidth <= innerWidth'))
    page.evaluate("document.getElementById('toast').hidden=true")
    if args.screenshots:
        page.screenshot(path=str(ROOT/'preview/mobile.png'), full_page=True)
    check('Preview has no JavaScript runtime errors', not errors)

    # BrowserMedia discovery: run the actual original JavaScript against a local synthetic DOM.
    page = context.new_page()
    errors = []
    page.on('pageerror', lambda error: errors.append(str(error)))
    page.set_content('''<html><head><base href="https://public.example/"><title>اختبار الوسائط</title>
<meta property="og:video" content="https://public.example/og.mp4">
<script type="application/ld+json">{"@type":"VideoObject","contentUrl":"/structured.mp4","name":"مثال"}</script>
</head><body><video><source src="https://public.example/movie.mp4" type="video/mp4"></video>
<a href="/movie.mp4">duplicate</a><a href="/audio.mp3">audio</a><a href="/stream.m3u8">manifest</a>
<video src="blob:https://public.example/not-a-file"></video>
<a href="https://u:p@public.example/secret.mp4">credentials</a><a href="http://public.example/insecure.mp4">http</a>
</body></html>''')
    page.evaluate('window.messages=[];window.webkit={messageHandlers:{saylMedia:{postMessage:x=>window.messages.push(x)}}}')
    script=(ROOT/'iOS/Sayl/Resources/media-discovery.js').read_text()
    page.evaluate(script)
    messages=page.evaluate('window.messages')
    urls=[m['url'] for m in messages]
    check('Observer discovers media, OG and JSON-LD', {'https://public.example/movie.mp4','https://public.example/og.mp4','https://public.example/structured.mp4','https://public.example/audio.mp3'}.issubset(urls))
    check('Observer does not invent MP4 for manifest', 'https://public.example/stream.m3u8' in urls)
    check('Observer rejects insecure, blob, credential URLs', not any('blob:' in u or u.startswith('http:') or '@' in u for u in urls))
    check('Observer deduplicates media URLs', len(urls)==len(set(urls)))
    page.evaluate('''const a=document.createElement('a');a.href='/later.mp4';a.textContent='new';document.body.append(a);''')
    page.wait_for_timeout(700)
    check('Observer discovers dynamically added media', page.evaluate("messages.some(x=>x.url.endsWith('/later.mp4'))"))
    page.evaluate('''for(let i=0;i<140;i++){const a=document.createElement('a');a.href='/bounded-'+i+'.mp4';document.body.append(a)};window.__saylScan()''')
    check('Observer caps candidates at 100', page.evaluate('messages.length')==100)
    page.evaluate(script)
    check('Observer install guard avoids duplicate emissions', page.evaluate('messages.length')==100)
    check('Observer has no JavaScript runtime errors', not errors)
    browser.close()
print(f'{len(passed)} checks passed. Chromium only; no iOS runtime or website downloads tested.')
