# Site Media Scanner — iOS

تطبيق iOS أصلي بـ **SwiftUI** للبحث داخل موقع بكلمة أو عبارة، ثم فحص الصفحات المطابقة واستخراج روابط الوسائط التي يعرّضها الموقع للمتصفح/الجلسة.

## ما الذي يفعله؟

1. تدخل رابط الموقع.
2. تدخل كلمة البحث.
3. التطبيق يحاول اكتشاف نموذج البحث الداخلي إن وُجد.
4. يزحف داخل نفس الموقع عبر القوائم والـ pagination والروابط الداخلية.
5. يقرأ `sitemap.xml` إن كان متاحًا.
6. يعطي أولوية للروابط التي تحمل كلمة البحث أو تبدو كصفحات فيديو/قوائم.
7. في الصفحات المطابقة يبحث عن:
   - MP4 / WebM ومصادر الفيديو المباشرة
   - HLS (`m3u8`)
   - DASH (`mpd`)
   - الصوت
   - JSON / player configs
   - سلاسل JavaScript المتجزئة مثل `a + b + c` بدون `eval`
8. إذا لم تكفِ القراءة الساكنة، يمكنه استخدام `WKWebView` مخفيًا لفحص DOM وResource Timing للصفحة المطابقة فقط.

## بوابات العمر وCAPTCHA

التطبيق **لا يتجاوز** CAPTCHA أو anti-bot أو DRM أو paywalls أو تسجيل الدخول.

إذا اكتشف بوابة عمر/وصول أو تحققًا بشريًا، يظهر زر **Open site verification**. أكمل الخطوة بنفسك داخل `WKWebView`، ثم اضغط **Done**. التطبيق ينسخ الكوكيز المصرح بها إلى جلسة `URLSession` ويعيد البحث.

## المتطلبات

- Xcode 16 أو أحدث موصى به
- iOS 17+
- لا توجد مكتبات خارجية أو CocoaPods/SPM dependencies

## التشغيل

1. افتح `SiteMediaScanner.xcodeproj` في Xcode.
2. اختر Signing Team الخاص بك من **Signing & Capabilities**.
3. غيّر Bundle Identifier إذا لزم.
4. اختر Simulator أو iPhone واضغط Run.

## ملفات مهمة

- `Scanning/SiteCrawler.swift`: الزحف وترتيب الصفحات.
- `Scanning/MediaExtractor.swift`: اكتشاف MP4/HLS/DASH وJSON وإعادة تركيب JavaScript.
- `Scanning/HTMLInspector.swift`: استخراج الروابط، pagination، نموذج البحث، ومطابقة الكلمة.
- `Scanning/SitemapDiscovery.swift`: robots/sitemap.
- `Web/DynamicWebScanner.swift`: fallback ديناميكي مخفي عبر WKWebView.
- `Web/VerificationWebView.swift`: صفحة التحقق اليدوية عند الحاجة.
- `Session/CookieBridge.swift`: مشاركة الكوكيز بين WebKit وURLSession.

## ملاحظات مهمة

- الزحف محصور في نفس الـhost ولا يتبع روابط إلى مواقع أخرى.
- خيار `Respect robots.txt` مفعّل افتراضيًا.
- يمكن زيادة `Maximum pages` و`Maximum depth` من داخل التطبيق للمواقع الكبيرة.
- `WKWebView` fallback ليس اعتراضًا منخفض المستوى لكل network request؛ هو يجمع مصادر DOM وPerformance Resource Timing. يمكن تطويره لاحقًا لمواقع محددة عند الحاجة.
- الروابط الموقعة أو المؤقتة قد تنتهي صلاحيتها بحسب الموقع.
- استخدم المشروع فقط مع المحتوى والمواقع التي يحق لك الوصول إليها وتحليلها.

## GitHub

يمكن رفع ملف ZIP الخاص بالمشروع كملف واحد إلى GitHub أو إرفاقه في **Releases**. إذا أردت أن يعرض GitHub ملفات Swift ويشغّل GitHub Actions عليها، يجب أن تكون محتويات المشروع نفسها مفكوكة داخل المستودع.
