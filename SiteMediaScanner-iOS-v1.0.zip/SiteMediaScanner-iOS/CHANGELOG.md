# Changelog

## 1.1

- واجهة مبسطة ومناسبة لـ iPhone 12 / iOS 18.
- النتائج تعتمد على تطابق كلمة البحث مع عنوان الفيديو.
- عرض مدة الفيديو من metadata مع AVFoundation fallback.
- تنزيل أفضل مصدر فيديو مدعوم وحفظه مباشرة في تطبيق Photos.
- عرض اسم الفيديو أثناء التنزيل وحالة الحفظ.
- إضافة صلاحية `NSPhotoLibraryAddUsageDescription`.
- جعل الهدف iPhone فقط ورفع Deployment Target إلى iOS 18.0.

## 1.0

- أول إصدار للماسح الداخلي للمواقع.
## 1.1.1
- Fixed Swift compile error caused by awaiting on the right side of the nil-coalescing operator while resolving video duration.

