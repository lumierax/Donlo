# Changelog

## 1.0.0
- Native SwiftUI iOS project.
- Same-site keyword crawler.
- Search form, pagination, and sitemap discovery.
- robots.txt support.
- Direct/JSON/static-JavaScript media extraction.
- Optional hidden WKWebView dynamic fallback.
- Manual age/access/CAPTCHA session handoff without bypass logic.
- Result detail, copy, open, and share actions.
