# Changelog

## 1.1

- واجهة مبسطة ومناسبة لـ iPhone 12 / iOS 18.
- النتائج تعتمد على تطابق كلمة البحث مع عنوان الفيديو.
- عرض مدة الفيديو من metadata مع AVFoundation fallback.
- تنزيل أفضل مصدر فيديو مدعوم وحفظه مباشرة في تطبيق Photos.
- عرض اسم الفيديو أثناء التنزيل وحالة الحفظ.
- إضافة صلاحية `NSPhotoLibraryAddUsageDescription`.
- جعل الهدف iPhone فقط ورفع Deployment Target إلى iOS 18.0.

## 1.0

- أول إصدار للماسح الداخلي للمواقع.
## 1.1.1
- Fixed Swift compile error caused by awaiting on the right side of the nil-coalescing operator while resolving video duration.


## 1.1.2
- Verification web view now identifies as Safari on iOS 18 (fixes "unsupported browser" page and missing captcha).
- Same browser identity used for scanning and downloading so verification cookies stay valid.
- Page fits the iPhone screen (safe area respected, mobile viewport, popup support, reload and open-in-Safari buttons).

## 1.1.3
- Videos now appear in the list the moment they are found; duration fills in afterwards.
- Uses the site's own search box: search forms (any field name plus hidden fields), OpenSearch description, then common search URL layouts.
- Search result pages are followed first (video links and next pages), with a WKWebView render for JavaScript-driven results.
