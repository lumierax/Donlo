import AVFoundation
import Foundation

enum MediaMetadataProbe {
    private enum ProbeResult {
        case duration(Double?)
        case timeout
    }

    static func durationSeconds(from items: [MediaItem], timeoutSeconds: Double = 3.0) async -> Double? {
        guard let item = preferredProbeItem(from: items), let url = URL(string: item.url) else { return nil }

        return await withTaskGroup(of: ProbeResult.self) { group in
            group.addTask {
                let asset = AVURLAsset(url: url)
                do {
                    let duration = try await asset.load(.duration)
                    let seconds = CMTimeGetSeconds(duration)
                    if seconds.isFinite && seconds > 0 {
                        return .duration(seconds)
                    }
                } catch { }
                return .duration(nil)
            }

            group.addTask {
                let nanos = UInt64(max(timeoutSeconds, 0.5) * 1_000_000_000)
                try? await Task.sleep(nanoseconds: nanos)
                return .timeout
            }

            for await result in group {
                switch result {
                case .duration(let seconds):
                    group.cancelAll()
                    return seconds
                case .timeout:
                    group.cancelAll()
                    return nil
                }
            }
            return nil
        }
    }

    private static func preferredProbeItem(from items: [MediaItem]) -> MediaItem? {
        let candidates = items.filter { $0.kind == .video || $0.kind == .hls }
        return candidates.sorted { resolutionValue($0.resolution) > resolutionValue($1.resolution) }.first
    }

    private static func resolutionValue(_ value: String?) -> Int {
        guard let value else { return 0 }
        return Int(value.lowercased().replacingOccurrences(of: "p", with: "")) ?? 0
    }
}
