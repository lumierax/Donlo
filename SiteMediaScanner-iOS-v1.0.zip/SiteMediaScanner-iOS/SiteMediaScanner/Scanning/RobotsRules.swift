import Foundation

struct RobotsRules: Sendable {
    struct Rule: Sendable {
        let path: String
        let allow: Bool
    }

    let rules: [Rule]

    static let allowAll = RobotsRules(rules: [])

    func allows(_ url: URL) -> Bool {
        let target = url.path + (url.query.map { "?\($0)" } ?? "")
        let matching = rules.filter { !$0.path.isEmpty && target.hasPrefix($0.path) }
        guard let strongest = matching.max(by: { $0.path.count < $1.path.count }) else { return true }
        return strongest.allow
    }

    static func parse(_ text: String) -> RobotsRules {
        var currentAgents: [String] = []
        var relevant = false
        var rules: [Rule] = []

        for rawLine in text.components(separatedBy: .newlines) {
            let line = rawLine.split(separator: "#", maxSplits: 1).first.map(String.init)?
                .trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
            guard !line.isEmpty, let colon = line.firstIndex(of: ":") else { continue }
            let key = line[..<colon].trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
            let value = line[line.index(after: colon)...].trimmingCharacters(in: .whitespacesAndNewlines)

            if key == "user-agent" {
                if !currentAgents.isEmpty && relevant { currentAgents.removeAll() }
                currentAgents.append(value.lowercased())
                relevant = currentAgents.contains("*") || currentAgents.contains(where: { $0.contains("sitemediascanner") })
            } else if relevant && (key == "allow" || key == "disallow") {
                if key == "disallow" && value.isEmpty { continue }
                rules.append(Rule(path: value, allow: key == "allow"))
            }
        }
        return RobotsRules(rules: rules)
    }
}
