import Foundation

enum URLUtilities {
    private static let mediaExtensions: [String: MediaKind] = [
        "mp4": .video, "m4v": .video, "webm": .video, "mov": .video, "mkv": .video,
        "m3u8": .hls, "mpd": .dash,
        "mp3": .audio, "m4a": .audio, "aac": .audio, "ogg": .audio, "wav": .audio, "flac": .audio
    ]

    static func normalizedCandidate(_ raw: String, baseURL: URL?) -> URL? {
        var value = TextUtilities.decodeLooseString(raw)
            .trimmingCharacters(in: CharacterSet(charactersIn: "\"'` ,;\n\r\t"))
        guard !value.isEmpty else { return nil }

        // Reject broken absolute-looking fragments (for example `https/example.com/...`)
        // rather than accidentally resolving them as a relative path on the scanned site.
        if value.range(of: #"^https?/"#, options: [.regularExpression, .caseInsensitive]) != nil,
           value.range(of: #"^https?://"#, options: [.regularExpression, .caseInsensitive]) == nil {
            return nil
        }

        if value.hasPrefix("//") { value = "https:\(value)" }
        var url = URL(string: value)
        if url?.scheme == nil, let baseURL { url = URL(string: value, relativeTo: baseURL)?.absoluteURL }
        guard var components = url.flatMap({ URLComponents(url: $0, resolvingAgainstBaseURL: true) }),
              let scheme = components.scheme?.lowercased(), ["http", "https"].contains(scheme) else { return nil }
        components.fragment = nil
        return components.url
    }

    static func canonicalPageURL(_ url: URL) -> URL? {
        guard var components = URLComponents(url: url, resolvingAgainstBaseURL: false) else { return nil }
        components.fragment = nil
        if let items = components.queryItems {
            let filtered = items.filter { item in
                let key = item.name.lowercased()
                return !(key.hasPrefix("utm_") || key == "fbclid" || key == "gclid")
            }
            components.queryItems = filtered.isEmpty ? nil : filtered
        }
        return components.url
    }

    static func sameSite(_ candidate: URL, root: URL) -> Bool {
        func host(_ url: URL) -> String {
            let h = (url.host ?? "").lowercased()
            return h.hasPrefix("www.") ? String(h.dropFirst(4)) : h
        }
        return !host(candidate).isEmpty && host(candidate) == host(root)
    }

    static func classify(_ url: URL, contentType: String = "") -> (MediaKind, String?) {
        let ext = url.pathExtension.lowercased()
        var kind = mediaExtensions[ext] ?? .unknown
        let ct = contentType.lowercased()
        if ct.contains("application/vnd.apple.mpegurl") || ct.contains("application/x-mpegurl") { kind = .hls }
        else if ct.contains("application/dash+xml") { kind = .dash }
        else if ct.hasPrefix("video/") { kind = .video }
        else if ct.hasPrefix("audio/") { kind = .audio }
        return (kind, resolution(from: url.absoluteString))
    }

    static func resolution(from value: String) -> String? {
        if let captured = TextUtilities.firstCapture(#"(?:^|[^0-9])(2160|1440|1080|720|540|480|360|240|144)p(?:[^0-9]|$)"#, in: value) {
            return "\(captured)p"
        }
        let matches = TextUtilities.regexMatches(#"(?:^|[^0-9])(\d{3,4})x(\d{3,4})(?:[^0-9]|$)"#, in: value)
        if let first = matches.first, first.count > 2 { return "\(first[2])p" }
        return nil
    }

    static func isLikelyMedia(_ url: URL) -> Bool {
        if classify(url).0 != .unknown { return true }
        let text = url.absoluteString.lowercased()
        if text.range(of: #"[?&](?:format|type|mime|ext)=(?:mp4|m3u8|mpd|webm|m4a|mp3)(?:&|$)"#, options: .regularExpression) != nil { return true }
        return text.range(of: #"/(?:videoplayback|manifest)(?:[/?]|$)"#, options: .regularExpression) != nil
    }

    static func looksLikeDRM(_ url: URL) -> Bool {
        url.absoluteString.range(of: #"(?:widevine|playready|fairplay|drm|license|licence|clearkey)(?:[/?._-]|$)"#, options: [.regularExpression, .caseInsensitive]) != nil
    }
}
