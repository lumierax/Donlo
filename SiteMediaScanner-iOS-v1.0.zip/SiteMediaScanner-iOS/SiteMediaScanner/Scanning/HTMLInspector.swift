import Foundation

enum HTMLInspector {
    private static let skipExtension = #"\.(?:jpg|jpeg|png|gif|webp|svg|ico|css|js|mjs|map|woff2?|ttf|eot|pdf|zip|rar|7z|gz|tar)(?:$|[?#])"#
    private static let skipPath = #"/(?:logout|signout|login|signin|register|signup)(?:[/?#]|$)"#

    static func title(from html: String) -> String {
        guard let raw = TextUtilities.firstCapture(#"<title\b[^>]*>([\s\S]*?)</title>"#, in: html) else { return "" }
        return TextUtilities.stripTags(raw)
    }

    static func description(from html: String) -> String {
        let patterns = [
            #"<meta\b[^>]*name=[\"']description[\"'][^>]*content=[\"']([^\"']*)[\"'][^>]*>"#,
            #"<meta\b[^>]*content=[\"']([^\"']*)[\"'][^>]*name=[\"']description[\"'][^>]*>"#
        ]
        for pattern in patterns {
            if let value = TextUtilities.firstCapture(pattern, in: html) { return TextUtilities.decodeLooseString(value) }
        }
        return ""
    }

    static func keywordEvidence(in html: String, keyword: String) -> KeywordEvidence {
        let pageTitle = title(from: html)
        let meta = description(from: html)
        let visible = String(TextUtilities.stripTags(html).prefix(2_000_000))
        var evidence: [String] = []
        if TextUtilities.containsKeyword(pageTitle, keyword: keyword) { evidence.append("title") }
        if TextUtilities.containsKeyword(meta, keyword: keyword) { evidence.append("meta-description") }
        if TextUtilities.containsKeyword(visible, keyword: keyword) { evidence.append("page-text") }
        return KeywordEvidence(matched: !evidence.isEmpty, evidence: evidence, title: pageTitle)
    }

    static func links(in html: String, baseURL: URL) -> [PageLink] {
        let pattern = #"<a\b([^>]*)href\s*=\s*(?:\"([^\"]*)\"|'([^']*)'|([^\s>]+))([^>]*)>([\s\S]*?)</a>"#
        let matches = TextUtilities.regexMatches(pattern, in: html)
        var seen = Set<String>()
        var output: [PageLink] = []

        for m in matches where m.count >= 7 {
            let raw = !m[2].isEmpty ? m[2] : (!m[3].isEmpty ? m[3] : m[4])
            if raw.isEmpty || raw.range(of: #"^(?:mailto:|tel:|javascript:|data:|blob:)"#, options: [.regularExpression, .caseInsensitive]) != nil { continue }
            guard let url = URLUtilities.normalizedCandidate(raw, baseURL: baseURL),
                  ["http", "https"].contains(url.scheme?.lowercased() ?? "") else { continue }
            let absolute = url.absoluteString
            if absolute.range(of: skipExtension, options: [.regularExpression, .caseInsensitive]) != nil { continue }
            if url.path.range(of: skipPath, options: [.regularExpression, .caseInsensitive]) != nil { continue }
            guard seen.insert(absolute).inserted else { continue }

            let attrs = "\(m[1]) \(m[5])"
            let rel = TextUtilities.firstCapture(#"\brel\s*=\s*[\"']([^\"']+)[\"']"#, in: attrs) ?? ""
            let text = String(TextUtilities.stripTags(m[6]).prefix(500))
            output.append(PageLink(url: url, text: text, rel: rel))
        }
        return output
    }

    static func score(link: PageLink, keyword: String) -> (Int, [String]) {
        let decodedURL = link.url.absoluteString.removingPercentEncoding ?? link.url.absoluteString
        var score = 0
        var reasons: [String] = []
        if TextUtilities.containsKeyword(link.text, keyword: keyword) { score += 100; reasons.append("anchor-keyword") }
        if TextUtilities.containsKeyword(decodedURL, keyword: keyword) { score += 80; reasons.append("url-keyword") }
        if link.text.range(of: #"\bnext\b|التالي|›|»"#, options: [.regularExpression, .caseInsensitive]) != nil || link.rel.lowercased().contains("next") {
            score += 35; reasons.append("next")
        }
        if link.url.absoluteString.range(of: #"(?:[?&](?:page|p)=\d+|/page/\d+|/page-\d+)"#, options: [.regularExpression, .caseInsensitive]) != nil {
            score += 30; reasons.append("pagination")
        }
        if link.url.absoluteString.range(of: #"(?:/video(?:s)?/|/watch/|/view_video\.|/clip/|/movie/)"#, options: [.regularExpression, .caseInsensitive]) != nil {
            score += 25; reasons.append("video-like")
        }
        if link.url.absoluteString.range(of: #"(?:search|results|category|categories|tag|tags|latest|newest|popular|videos)"#, options: [.regularExpression, .caseInsensitive]) != nil {
            score += 10; reasons.append("listing-like")
        }
        return (score, reasons)
    }

    static func discoveredSearchURLs(in html: String, baseURL: URL, keyword: String) -> [URL] {
        let formPattern = #"<form\b([^>]*)>([\s\S]*?)</form>"#
        let forms = TextUtilities.regexMatches(formPattern, in: html)
        var found: [URL] = []
        var seen = Set<String>()

        for form in forms where form.count > 2 {
            let attrs = form[1]
            let body = form[2]
            let method = TextUtilities.firstCapture(#"\bmethod\s*=\s*[\"']?([^\s\"'>]+)"#, in: attrs)?.lowercased() ?? "get"
            guard method == "get" else { continue }
            let action = TextUtilities.firstCapture(#"\baction\s*=\s*(?:\"([^\"]*)\"|'([^']*)')"#, in: attrs)
                ?? baseURL.absoluteString

            let inputMatches = TextUtilities.regexMatches(#"<input\b[^>]*\bname\s*=\s*(?:\"([^\"]+)\"|'([^']+)')[^>]*>"#, in: body)
            let names = inputMatches.compactMap { m -> String? in
                guard m.count > 2 else { return nil }
                return !m[1].isEmpty ? m[1] : m[2]
            }
            guard let queryName = names.first(where: { name in
                ["q", "query", "search", "keyword", "keywords", "s", "term", "k"].contains(name.lowercased())
            }) else { continue }

            guard let actionURL = URLUtilities.normalizedCandidate(action, baseURL: baseURL),
                  var components = URLComponents(url: actionURL, resolvingAgainstBaseURL: true) else { continue }
            var items = components.queryItems ?? []
            items.removeAll { $0.name == queryName }
            items.append(URLQueryItem(name: queryName, value: keyword))
            components.queryItems = items
            if let url = components.url, seen.insert(url.absoluteString).inserted { found.append(url) }
        }
        return found
    }
}
