import Foundation

enum HTMLInspector {
    private static let skipExtension = #"\.(?:jpg|jpeg|png|gif|webp|svg|ico|css|js|mjs|map|woff2?|ttf|eot|pdf|zip|rar|7z|gz|tar)(?:$|[?#])"#
    private static let skipPath = #"/(?:logout|signout|login|signin|register|signup)(?:[/?#]|$)"#

    static func title(from html: String) -> String {
        let metaCandidates: [(String, String)] = [
            ("property", "og:title"),
            ("name", "twitter:title"),
            ("itemprop", "name")
        ]
        for (attribute, expected) in metaCandidates {
            if let value = metaContent(in: html, matchingAttribute: attribute, expectedValue: expected), !value.isEmpty {
                return value
            }
        }

        if let h1 = TextUtilities.firstCapture(#"<h1\b[^>]*>([\s\S]*?)</h1>"#, in: html) {
            let clean = TextUtilities.stripTags(h1)
            if !clean.isEmpty { return clean }
        }

        if let raw = TextUtilities.firstCapture(#"<title\b[^>]*>([\s\S]*?)</title>"#, in: html) {
            return TextUtilities.stripTags(raw)
        }
        return ""
    }

    static func description(from html: String) -> String {
        if let value = metaContent(in: html, matchingAttribute: "name", expectedValue: "description") {
            return value
        }
        if let value = metaContent(in: html, matchingAttribute: "property", expectedValue: "og:description") {
            return value
        }
        return ""
    }

    /// Results are intentionally matched against the video/page title, not arbitrary body text.
    static func keywordEvidence(in html: String, keyword: String) -> KeywordEvidence {
        let pageTitle = title(from: html)
        var evidence: [String] = []
        if TextUtilities.containsKeyword(pageTitle, keyword: keyword) {
            evidence.append("video-title")
        }
        return KeywordEvidence(matched: !evidence.isEmpty, evidence: evidence, title: pageTitle)
    }

    static func videoDurationSeconds(from html: String) -> Double? {
        // Common OpenGraph and schema.org metadata.
        for key in ["video:duration", "og:video:duration"] {
            if let raw = metaContent(in: html, matchingAttribute: "property", expectedValue: key),
               let value = parseDuration(raw) {
                return value
            }
        }
        if let raw = metaContent(in: html, matchingAttribute: "itemprop", expectedValue: "duration"),
           let value = parseDuration(raw) {
            return value
        }

        // <time itemprop="duration" datetime="PT4M32S">…</time>
        for tag in TextUtilities.regexMatches(#"<time\b[^>]*>"#, in: html).compactMap({ $0.first }) {
            if attributeValue("itemprop", in: tag)?.lowercased() == "duration",
               let raw = attributeValue("datetime", in: tag),
               let value = parseDuration(raw) {
                return value
            }
        }

        // JSON-LD / player configuration variants.
        let stringPatterns = [
            #"[\"']duration[\"']\s*:\s*[\"']([^\"']+)[\"']"#,
            #"[\"']videoDuration[\"']\s*:\s*[\"']([^\"']+)[\"']"#,
            #"[\"']length[\"']\s*:\s*[\"']([^\"']+)[\"']"#
        ]
        for pattern in stringPatterns {
            if let raw = TextUtilities.firstCapture(pattern, in: html), let value = parseDuration(raw) {
                return value
            }
        }

        let numericPatterns = [
            #"[\"']duration[\"']\s*:\s*([0-9]+(?:\.[0-9]+)?)"#,
            #"[\"']video_duration[\"']\s*:\s*([0-9]+(?:\.[0-9]+)?)"#,
            #"[\"']length_seconds[\"']\s*:\s*([0-9]+(?:\.[0-9]+)?)"#
        ]
        for pattern in numericPatterns {
            if let raw = TextUtilities.firstCapture(pattern, in: html), let value = parseDuration(raw) {
                return value
            }
        }

        return nil
    }

    static func links(in html: String, baseURL: URL) -> [PageLink] {
        let pattern = #"<a\b([^>]*)href\s*=\s*(?:\"([^\"]*)\"|'([^']*)'|([^\s>]+))([^>]*)>([\s\S]*?)</a>"#
        let matches = TextUtilities.regexMatches(pattern, in: html)
        var seen = Set<String>()
        var output: [PageLink] = []

        for m in matches where m.count >= 7 {
            let raw = !m[2].isEmpty ? m[2] : (!m[3].isEmpty ? m[3] : m[4])
            if raw.isEmpty || raw.range(of: #"^(?:mailto:|tel:|javascript:|data:|blob:)"#, options: [.regularExpression, .caseInsensitive]) != nil { continue }
            guard let url = URLUtilities.normalizedCandidate(raw, baseURL: baseURL),
                  ["http", "https"].contains(url.scheme?.lowercased() ?? "") else { continue }
            let absolute = url.absoluteString
            if absolute.range(of: skipExtension, options: [.regularExpression, .caseInsensitive]) != nil { continue }
            if url.path.range(of: skipPath, options: [.regularExpression, .caseInsensitive]) != nil { continue }
            guard seen.insert(absolute).inserted else { continue }

            let attrs = "\(m[1]) \(m[5])"
            let rel = TextUtilities.firstCapture(#"\brel\s*=\s*[\"']([^\"']+)[\"']"#, in: attrs) ?? ""
            let text = String(TextUtilities.stripTags(m[6]).prefix(500))
            output.append(PageLink(url: url, text: text, rel: rel))
        }
        return output
    }

    static func score(link: PageLink, keyword: String) -> (Int, [String]) {
        let decodedURL = link.url.absoluteString.removingPercentEncoding ?? link.url.absoluteString
        var score = 0
        var reasons: [String] = []
        if TextUtilities.containsKeyword(link.text, keyword: keyword) { score += 100; reasons.append("anchor-keyword") }
        if TextUtilities.containsKeyword(decodedURL, keyword: keyword) { score += 80; reasons.append("url-keyword") }
        if link.text.range(of: #"\bnext\b|التالي|›|»"#, options: [.regularExpression, .caseInsensitive]) != nil || link.rel.lowercased().contains("next") {
            score += 35; reasons.append("next")
        }
        if link.url.absoluteString.range(of: #"(?:[?&](?:page|p)=\d+|/page/\d+|/page-\d+)"#, options: [.regularExpression, .caseInsensitive]) != nil {
            score += 30; reasons.append("pagination")
        }
        if link.url.absoluteString.range(of: #"(?:/video(?:s)?/|/watch/|/view_video\.|/clip/|/movie/)"#, options: [.regularExpression, .caseInsensitive]) != nil {
            score += 25; reasons.append("video-like")
        }
        if link.url.absoluteString.range(of: #"(?:search|results|category|categories|tag|tags|latest|newest|popular|videos)"#, options: [.regularExpression, .caseInsensitive]) != nil {
            score += 10; reasons.append("listing-like")
        }
        return (score, reasons)
    }

    private static let searchNamePattern = #"^(?:q|s|k|kw|wd|key|find|text|term|terms|query|search|keyword|keywords|searchword|searchtext|search_query|searchquery|search-query|search_term|searchterm|search_keyword|q_search)$"#

    static func discoveredSearchURLs(in html: String, baseURL: URL, keyword: String) -> [URL] {
        let forms = TextUtilities.regexMatches(#"<form\b([^>]*)>([\s\S]*?)</form>"#, in: html)
        var found: [URL] = []
        var seen = Set<String>()

        for form in forms where form.count > 2 {
            let attrs = form[1]
            let body = form[2]
            let method = (attributeValue("method", in: "<form " + attrs + ">") ?? "get").lowercased()
            guard method == "get" else { continue }
            let action = attributeValue("action", in: "<form " + attrs + ">") ?? ""

            var queryName: String?
            var hidden: [URLQueryItem] = []
            for tagMatch in TextUtilities.regexMatches(#"<input\b[^>]*>"#, in: body) {
                guard let tag = tagMatch.first, let name = attributeValue("name", in: tag), !name.isEmpty else { continue }
                let type = (attributeValue("type", in: tag) ?? "text").lowercased()
                if type == "hidden" {
                    hidden.append(URLQueryItem(name: name, value: attributeValue("value", in: tag) ?? ""))
                } else if queryName == nil, ["text", "search", ""].contains(type) {
                    let lower = name.lowercased()
                    if lower.range(of: searchNamePattern, options: .regularExpression) != nil
                        || lower.contains("search") || lower.contains("query") || lower.contains("keyword") {
                        queryName = name
                    }
                }
            }
            guard let queryName else { continue }

            let actionURL = action.isEmpty ? baseURL : (URLUtilities.normalizedCandidate(action, baseURL: baseURL) ?? baseURL)
            guard var components = URLComponents(url: actionURL, resolvingAgainstBaseURL: true) else { continue }
            var items = components.queryItems ?? []
            for h in hidden where !items.contains(where: { $0.name == h.name }) { items.append(h) }
            items.removeAll { $0.name == queryName }
            items.append(URLQueryItem(name: queryName, value: keyword))
            components.queryItems = items
            if let url = components.url, seen.insert(url.absoluteString).inserted { found.append(url) }
        }
        return found
    }

    /// `<link rel="search" type="application/opensearchdescription+xml" href="...">`
    static func openSearchDescriptionURLs(in html: String, baseURL: URL) -> [URL] {
        var output: [URL] = []
        for tagMatch in TextUtilities.regexMatches(#"<link\b[^>]*>"#, in: html) {
            guard let tag = tagMatch.first,
                  (attributeValue("rel", in: tag) ?? "").lowercased() == "search",
                  let href = attributeValue("href", in: tag),
                  let url = URLUtilities.normalizedCandidate(href, baseURL: baseURL) else { continue }
            output.append(url)
        }
        return output
    }

    /// Turns an OpenSearch XML description into ready search URLs.
    static func searchURLs(fromOpenSearch xml: String, keyword: String) -> [URL] {
        let encoded = keyword.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? keyword
        var output: [URL] = []
        for m in TextUtilities.regexMatches(#"template\s*=\s*[\"']([^\"']+)[\"']"#, in: xml) where m.count > 1 {
            var t = TextUtilities.decodeLooseString(m[1])
            t = t.replacingOccurrences(of: "{searchTerms}", with: encoded)
            t = t.replacingOccurrences(of: "{searchTerms?}", with: encoded)
            t = t.replacingOccurrences(of: #"\{[^}]*\?\}"#, with: "", options: .regularExpression)
            if t.contains("{") { continue }
            if let url = URL(string: t) { output.append(url) }
        }
        return output
    }

    /// Common search URL layouts, used only when the page exposes no usable search form.
    static func commonSearchURLs(root: URL, keyword: String) -> [URL] {
        let q = keyword.trimmingCharacters(in: .whitespacesAndNewlines)
        let query = q.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? q
        let path = q.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? q
        let dash = q.lowercased().split(whereSeparator: { $0.isWhitespace }).joined(separator: "-")
        let dashEncoded = dash.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? dash
        guard var base = URLComponents(url: root, resolvingAgainstBaseURL: false) else { return [] }
        base.path = ""; base.query = nil; base.fragment = nil
        let origin = base.string ?? ""
        let templates = [
            "/?s=\(query)", "/search?q=\(query)", "/search/?q=\(query)", "/search?query=\(query)",
            "/search?search_query=\(query)", "/search/\(path)", "/search/\(dashEncoded)/", "/?q=\(query)",
            "/search.php?q=\(query)", "/videos?search=\(query)", "/search?keyword=\(query)"
        ]
        var seen = Set<String>()
        return templates.compactMap { URL(string: origin + $0) }.filter { seen.insert($0.absoluteString).inserted }
    }

    private static func metaContent(in html: String, matchingAttribute attribute: String, expectedValue: String) -> String? {
        for tag in TextUtilities.regexMatches(#"<meta\b[^>]*>"#, in: html).compactMap({ $0.first }) {
            guard attributeValue(attribute, in: tag)?.lowercased() == expectedValue.lowercased(),
                  let content = attributeValue("content", in: tag) else { continue }
            let clean = TextUtilities.decodeLooseString(content).trimmingCharacters(in: .whitespacesAndNewlines)
            if !clean.isEmpty { return clean }
        }
        return nil
    }

    private static func attributeValue(_ name: String, in tag: String) -> String? {
        let escaped = NSRegularExpression.escapedPattern(for: name)
        let quoted = #"\b"# + escaped + #"\s*=\s*(?:\"([^\"]*)\"|'([^']*)')"#
        if let match = TextUtilities.regexMatches(quoted, in: tag).first, match.count > 2 {
            return !match[1].isEmpty ? match[1] : match[2]
        }
        let bare = #"\b"# + escaped + #"\s*=\s*([^\s>]+)"#
        return TextUtilities.firstCapture(bare, in: tag)
    }

    private static func parseDuration(_ raw: String) -> Double? {
        let value = TextUtilities.decodeLooseString(raw).trimmingCharacters(in: .whitespacesAndNewlines)
        guard !value.isEmpty else { return nil }

        if let seconds = Double(value), seconds > 0 { return seconds }

        let upper = value.uppercased()
        if upper.hasPrefix("P") {
            let pattern = #"^P(?:(\d+(?:\.\d+)?)D)?(?:T(?:(\d+(?:\.\d+)?)H)?(?:(\d+(?:\.\d+)?)M)?(?:(\d+(?:\.\d+)?)S)?)?$"#
            if let m = TextUtilities.regexMatches(pattern, in: upper, options: []).first, m.count >= 5 {
                let days = Double(m[1]) ?? 0
                let hours = Double(m[2]) ?? 0
                let minutes = Double(m[3]) ?? 0
                let seconds = Double(m[4]) ?? 0
                let total = days * 86_400 + hours * 3_600 + minutes * 60 + seconds
                return total > 0 ? total : nil
            }
        }

        let parts = value.split(separator: ":").compactMap { Double($0) }
        if parts.count == 2 {
            let total = parts[0] * 60 + parts[1]
            return total > 0 ? total : nil
        }
        if parts.count == 3 {
            let total = parts[0] * 3600 + parts[1] * 60 + parts[2]
            return total > 0 ? total : nil
        }
        return nil
    }
}
