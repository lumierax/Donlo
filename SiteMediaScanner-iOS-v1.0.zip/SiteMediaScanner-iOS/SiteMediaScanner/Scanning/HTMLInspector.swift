import Foundation

enum HTMLInspector {
    private static let skipExtension = #"\.(?:jpg|jpeg|png|gif|webp|svg|ico|css|js|mjs|map|woff2?|ttf|eot|pdf|zip|rar|7z|gz|tar)(?:$|[?#])"#
    private static let skipPath = #"/(?:logout|signout|login|signin|register|signup)(?:[/?#]|$)"#
    private static let videoLikePattern = #"(?:/video(?:s)?/|/watch/|/view_video\.|/clip/|/movie/|/v/|[?&](?:viewkey|video|vid)=)"#

    static func title(from html: String) -> String {
        let metaCandidates: [(String, String)] = [
            ("property", "og:title"),
            ("name", "twitter:title"),
            ("itemprop", "name")
        ]
        for (attribute, expected) in metaCandidates {
            if let value = metaContent(in: html, matchingAttribute: attribute, expectedValue: expected), !value.isEmpty {
                return value
            }
        }

        if let h1 = TextUtilities.firstCapture(#"<h1\b[^>]*>([\s\S]*?)</h1>"#, in: html) {
            let clean = TextUtilities.stripTags(h1)
            if !clean.isEmpty { return clean }
        }

        if let raw = TextUtilities.firstCapture(#"<title\b[^>]*>([\s\S]*?)</title>"#, in: html) {
            return TextUtilities.stripTags(raw)
        }
        return ""
    }

    static func description(from html: String) -> String {
        if let value = metaContent(in: html, matchingAttribute: "name", expectedValue: "description") {
            return value
        }
        if let value = metaContent(in: html, matchingAttribute: "property", expectedValue: "og:description") {
            return value
        }
        return ""
    }

    static func looksLikeUnsupportedBrowserPage(_ html: String) -> Bool {
        let visible = TextUtilities.normalized(String(TextUtilities.stripTags(html).prefix(120_000)))
        let phrases = [
            "web browser that we don't support",
            "browser that we do not support",
            "browser is not supported",
            "unsupported browser",
            "upgrade to a recent version of chrome",
            "upgrade your browser",
            "your browser is out of date",
            "متصفح غير مدعوم",
            "المتصفح غير مدعوم",
            "حدّث المتصفح"
        ]
        return phrases.contains { visible.contains(TextUtilities.normalized($0)) }
    }

    /// Match only against the actual page/video title, never arbitrary page body text.
    static func keywordEvidence(in html: String, keyword: String) -> KeywordEvidence {
        let pageTitle = title(from: html)
        var evidence: [String] = []
        if TextUtilities.containsKeyword(pageTitle, keyword: keyword) {
            evidence.append("video-title")
        }
        return KeywordEvidence(matched: !evidence.isEmpty, evidence: evidence, title: pageTitle)
    }

    static func videoDurationSeconds(from html: String) -> Double? {
        for key in ["video:duration", "og:video:duration"] {
            if let raw = metaContent(in: html, matchingAttribute: "property", expectedValue: key),
               let value = parseDuration(raw) {
                return value
            }
        }
        if let raw = metaContent(in: html, matchingAttribute: "itemprop", expectedValue: "duration"),
           let value = parseDuration(raw) {
            return value
        }

        for tag in TextUtilities.regexMatches(#"<time\b[^>]*>"#, in: html).compactMap({ $0.first }) {
            if attributeValue("itemprop", in: tag)?.lowercased() == "duration",
               let raw = attributeValue("datetime", in: tag),
               let value = parseDuration(raw) {
                return value
            }
        }

        let stringPatterns = [
            #"[\"']duration[\"']\s*:\s*[\"']([^\"']+)[\"']"#,
            #"[\"']videoDuration[\"']\s*:\s*[\"']([^\"']+)[\"']"#,
            #"[\"']length[\"']\s*:\s*[\"']([^\"']+)[\"']"#
        ]
        for pattern in stringPatterns {
            if let raw = TextUtilities.firstCapture(pattern, in: html), let value = parseDuration(raw) {
                return value
            }
        }

        let numericPatterns = [
            #"[\"']duration[\"']\s*:\s*([0-9]+(?:\.[0-9]+)?)"#,
            #"[\"']video_duration[\"']\s*:\s*([0-9]+(?:\.[0-9]+)?)"#,
            #"[\"']length_seconds[\"']\s*:\s*([0-9]+(?:\.[0-9]+)?)"#
        ]
        for pattern in numericPatterns {
            if let raw = TextUtilities.firstCapture(pattern, in: html), let value = parseDuration(raw) {
                return value
            }
        }

        return nil
    }

    static func links(in html: String, baseURL: URL) -> [PageLink] {
        let pattern = #"<a\b([^>]*)href\s*=\s*(?:\"([^\"]*)\"|'([^']*)'|([^\s>]+))([^>]*)>([\s\S]*?)</a>"#
        let matches = TextUtilities.regexMatches(pattern, in: html)
        var output: [PageLink] = []
        var indexByURL: [String: Int] = [:]

        for m in matches where m.count >= 7 {
            let raw = !m[2].isEmpty ? m[2] : (!m[3].isEmpty ? m[3] : m[4])
            if raw.isEmpty || raw.range(of: #"^(?:mailto:|tel:|javascript:|data:|blob:)"#, options: [.regularExpression, .caseInsensitive]) != nil { continue }
            guard let url = URLUtilities.normalizedCandidate(raw, baseURL: baseURL),
                  ["http", "https"].contains(url.scheme?.lowercased() ?? "") else { continue }
            let absolute = url.absoluteString
            if absolute.range(of: skipExtension, options: [.regularExpression, .caseInsensitive]) != nil { continue }
            if url.path.range(of: skipPath, options: [.regularExpression, .caseInsensitive]) != nil { continue }

            let attrs = "\(m[1]) \(m[5])"
            let rel = TextUtilities.firstCapture(#"\brel\s*=\s*[\"']([^\"']+)[\"']"#, in: attrs) ?? ""
            let text = String(TextUtilities.stripTags(m[6]).prefix(500))
            let candidate = PageLink(url: url, text: text, rel: rel)

            if let existingIndex = indexByURL[absolute] {
                // Thumbnail links often occur before their textual title link. Keep the richer anchor text.
                if candidate.text.count > output[existingIndex].text.count {
                    output[existingIndex] = candidate
                }
            } else {
                indexByURL[absolute] = output.count
                output.append(candidate)
            }
        }
        return output
    }

    static func score(link: PageLink, keyword: String) -> (Int, [String]) {
        let decodedURL = link.url.absoluteString.removingPercentEncoding ?? link.url.absoluteString
        var score = 0
        var reasons: [String] = []
        if TextUtilities.containsKeyword(link.text, keyword: keyword) { score += 100; reasons.append("anchor-keyword") }
        if TextUtilities.containsKeyword(decodedURL, keyword: keyword) { score += 80; reasons.append("url-keyword") }
        if isPaginationLink(link) { score += 45; reasons.append("pagination") }
        if isLikelyVideoResultLink(link, keyword: keyword) { score += 35; reasons.append("video-result") }
        return (score, reasons)
    }

    static func isVideoLikeURL(_ url: URL) -> Bool {
        let decodedURL = url.absoluteString.removingPercentEncoding ?? url.absoluteString
        return decodedURL.range(of: videoLikePattern, options: [.regularExpression, .caseInsensitive]) != nil
    }

    static func isLikelyVideoResultLink(_ link: PageLink, keyword: String) -> Bool {
        let decodedURL = link.url.absoluteString.removingPercentEncoding ?? link.url.absoluteString
        if isVideoLikeURL(link.url) { return true }
        if TextUtilities.containsKeyword(link.text, keyword: keyword) { return true }
        if TextUtilities.containsKeyword(decodedURL, keyword: keyword) { return true }
        return false
    }

    static func isPaginationLink(_ link: PageLink) -> Bool {
        let lowerRel = link.rel.lowercased()
        if lowerRel.contains("next") { return true }

        let trimmed = link.text.trimmingCharacters(in: .whitespacesAndNewlines)
        if trimmed.range(of: #"^(?:next|more|التالي|التالية|›|»|→)$"#, options: [.regularExpression, .caseInsensitive]) != nil {
            return true
        }

        let absolute = link.url.absoluteString
        if absolute.range(of: #"(?:[?&](?:page|p|start|offset)=\d+|/page/\d+|/page-\d+)"#, options: [.regularExpression, .caseInsensitive]) != nil {
            return true
        }

        // Numeric links are pagination only when the URL still looks like a search/results page.
        if trimmed.range(of: #"^\d{1,4}$"#, options: .regularExpression) != nil,
           absolute.range(of: #"(?:search|results|query|keyword)"#, options: [.regularExpression, .caseInsensitive]) != nil {
            return true
        }
        return false
    }

    /// Finds the site's own search form. Supports both GET and classic POST forms.
    /// Requests are ranked so forms with role=search/type=search/search-like field names win.
    static func discoveredSearchRequests(in html: String, baseURL: URL, keyword: String) -> [SiteSearchRequest] {
        let formPattern = #"<form\b([^>]*)>([\s\S]*?)</form>"#
        let forms = TextUtilities.regexMatches(formPattern, in: html)
        var requests: [SiteSearchRequest] = []

        for form in forms where form.count > 2 {
            let attrs = form[1]
            let body = form[2]
            let formTag = "<form \(attrs)>"
            let methodRaw = (attributeValue("method", in: formTag) ?? "get").lowercased()
            guard let method = SearchHTTPMethod(rawValue: methodRaw.uppercased()) else { continue }

            let actionRaw = attributeValue("action", in: formTag) ?? baseURL.absoluteString
            guard let actionURL = URLUtilities.normalizedCandidate(actionRaw, baseURL: baseURL),
                  ["http", "https"].contains(actionURL.scheme?.lowercased() ?? "") else { continue }

            let inputTags = TextUtilities.regexMatches(#"<input\b[^>]*>"#, in: body).compactMap { $0.first }
            var hidden: [SearchField] = []
            var bestName: String?
            var bestInputScore = Int.min

            for tag in inputTags {
                guard let name = attributeValue("name", in: tag)?.trimmingCharacters(in: .whitespacesAndNewlines), !name.isEmpty else { continue }
                let type = (attributeValue("type", in: tag) ?? "text").lowercased()
                let value = attributeValue("value", in: tag) ?? ""

                if type == "hidden" {
                    hidden.append(SearchField(name: name, value: value))
                    continue
                }
                if ["submit", "button", "checkbox", "radio", "file", "password", "email"].contains(type) { continue }

                let placeholder = attributeValue("placeholder", in: tag) ?? ""
                let ariaLabel = attributeValue("aria-label", in: tag) ?? ""
                let lowerName = name.lowercased()
                var inputScore = 0

                if type == "search" { inputScore += 140 }
                if ["q", "query", "search", "keyword", "keywords", "s", "term", "k"].contains(lowerName) { inputScore += 120 }
                if lowerName.range(of: #"(?:search|query|keyword|term)"#, options: .regularExpression) != nil { inputScore += 95 }
                let hint = "\(placeholder) \(ariaLabel)"
                if hint.range(of: #"(?:search|find|بحث|ابحث)"#, options: [.regularExpression, .caseInsensitive]) != nil { inputScore += 90 }

                if inputScore > bestInputScore {
                    bestInputScore = inputScore
                    bestName = name
                }
            }

            guard let queryName = bestName, bestInputScore > 0 else { continue }

            var formScore = bestInputScore
            if (attributeValue("role", in: formTag) ?? "").lowercased() == "search" { formScore += 100 }
            if actionURL.absoluteString.range(of: #"(?:search|results|query)"#, options: [.regularExpression, .caseInsensitive]) != nil { formScore += 70 }
            if attrs.range(of: #"(?:search|بحث)"#, options: [.regularExpression, .caseInsensitive]) != nil { formScore += 40 }

            var fields = hidden.filter { $0.name != queryName }
            fields.append(SearchField(name: queryName, value: keyword))
            requests.append(SiteSearchRequest(actionURL: actionURL, method: method, fields: fields, score: formScore))
        }

        return requests.sorted { $0.score > $1.score }
    }

    private static func metaContent(in html: String, matchingAttribute attribute: String, expectedValue: String) -> String? {
        for tag in TextUtilities.regexMatches(#"<meta\b[^>]*>"#, in: html).compactMap({ $0.first }) {
            guard attributeValue(attribute, in: tag)?.lowercased() == expectedValue.lowercased(),
                  let content = attributeValue("content", in: tag) else { continue }
            let clean = TextUtilities.decodeLooseString(content).trimmingCharacters(in: .whitespacesAndNewlines)
            if !clean.isEmpty { return clean }
        }
        return nil
    }

    private static func attributeValue(_ name: String, in tag: String) -> String? {
        let escaped = NSRegularExpression.escapedPattern(for: name)
        let quoted = #"\b"# + escaped + #"\s*=\s*(?:\"([^\"]*)\"|'([^']*)')"#
        if let match = TextUtilities.regexMatches(quoted, in: tag).first, match.count > 2 {
            return !match[1].isEmpty ? match[1] : match[2]
        }
        let bare = #"\b"# + escaped + #"\s*=\s*([^\s>]+)"#
        return TextUtilities.firstCapture(bare, in: tag)
    }

    private static func parseDuration(_ raw: String) -> Double? {
        let value = TextUtilities.decodeLooseString(raw).trimmingCharacters(in: .whitespacesAndNewlines)
        guard !value.isEmpty else { return nil }

        if let seconds = Double(value), seconds > 0 { return seconds }

        let upper = value.uppercased()
        if upper.hasPrefix("P") {
            let pattern = #"^P(?:(\d+(?:\.\d+)?)D)?(?:T(?:(\d+(?:\.\d+)?)H)?(?:(\d+(?:\.\d+)?)M)?(?:(\d+(?:\.\d+)?)S)?)?$"#
            if let m = TextUtilities.regexMatches(pattern, in: upper, options: []).first, m.count >= 5 {
                let days = Double(m[1]) ?? 0
                let hours = Double(m[2]) ?? 0
                let minutes = Double(m[3]) ?? 0
                let seconds = Double(m[4]) ?? 0
                let total = days * 86_400 + hours * 3_600 + minutes * 60 + seconds
                return total > 0 ? total : nil
            }
        }

        let parts = value.split(separator: ":").compactMap { Double($0) }
        if parts.count == 2 {
            let total = parts[0] * 60 + parts[1]
            return total > 0 ? total : nil
        }
        if parts.count == 3 {
            let total = parts[0] * 3600 + parts[1] * 60 + parts[2]
            return total > 0 ? total : nil
        }
        return nil
    }
}
