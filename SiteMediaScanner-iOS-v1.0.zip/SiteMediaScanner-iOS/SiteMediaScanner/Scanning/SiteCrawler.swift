import Foundation

final class SiteCrawler {
    private struct QueueItem {
        let url: URL
        let depth: Int
        let priority: Int
        let sequence: Int
        let via: String
    }

    private let http = HTTPClient()

    func search(
        siteURL: URL,
        keyword: String,
        options: ScanOptions,
        progress: @escaping @Sendable (ScanProgress) -> Void,
        onResult: @escaping @Sendable (PageMediaResult) -> Void = { _ in }
    ) async throws -> SiteScanResult {
        guard !keyword.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            throw NSError(domain: "SiteMediaScanner", code: 1, userInfo: [NSLocalizedDescriptionKey: "Search keyword is required."])
        }

        var root = siteURL
        if root.scheme?.lowercased() == "http" {
            var components = URLComponents(url: root, resolvingAgainstBaseURL: false)
            components?.scheme = "https"
            if let https = components?.url { root = https }
        }
        guard ["http", "https"].contains(root.scheme?.lowercased() ?? "") else {
            throw NSError(domain: "SiteMediaScanner", code: 2, userInfo: [NSLocalizedDescriptionKey: "Only HTTP/HTTPS sites are supported."])
        }

        let maxPages = max(1, options.maxPages)
        let maxDepth = max(0, options.maxDepth)
        let maxResults = max(1, options.maxResults)
        var sequence = 0
        var queue: [QueueItem] = []
        var queued = Set<String>()
        var visited = Set<String>()
        var results: [PageMediaResult] = []
        var errors: [ScanErrorItem] = []
        var dynamicUsed = 0
        var emitted = Set<String>()
        var dynamicSearchUsed = 0

        func enqueue(_ url: URL, depth: Int, priority: Int, via: String) {
            guard depth <= maxDepth,
                  let canonical = URLUtilities.canonicalPageURL(url),
                  URLUtilities.sameSite(canonical, root: root) else { return }
            let key = canonical.absoluteString
            guard !queued.contains(key), !visited.contains(key) else { return }
            queued.insert(key)
            queue.append(QueueItem(url: canonical, depth: depth, priority: priority, sequence: sequence, via: via))
            sequence += 1
        }

        let robots = options.respectRobots ? await SitemapDiscovery.robotsRules(rootURL: root, http: http) : .allowAll
        enqueue(root, depth: 0, priority: 1000, via: "root")

        if options.useSitemap {
            let sitemapURLs = await SitemapDiscovery.discover(rootURL: root, http: http, maxURLs: max(maxPages * 8, 500))
            for url in sitemapURLs where robots.allows(url) {
                let fake = PageLink(url: url, text: url.path.removingPercentEncoding ?? url.path, rel: "")
                let score = HTMLInspector.score(link: fake, keyword: keyword)
                enqueue(url, depth: 1, priority: 5 + score.0, via: "sitemap")
            }
        }

        while !queue.isEmpty && visited.count < maxPages && results.count < maxResults {
            try Task.checkCancellation()
            queue.sort {
                if $0.priority != $1.priority { return $0.priority > $1.priority }
                return $0.sequence < $1.sequence
            }
            let item = queue.removeFirst()
            queued.remove(item.url.absoluteString)
            guard !visited.contains(item.url.absoluteString), robots.allows(item.url) else { continue }
            visited.insert(item.url.absoluteString)

            progress(ScanProgress(scannedPages: visited.count, queuedPages: queue.count, foundResults: results.count, currentURL: item.url.absoluteString))

            let response: HTTPTextResponse
            do {
                response = try await http.fetchText(item.url)
            } catch {
                if item.via != "site-search-guess" {
                    errors.append(ScanErrorItem(url: item.url.absoluteString, message: error.localizedDescription))
                }
                continue
            }

            let finalURL = URLUtilities.canonicalPageURL(response.finalURL) ?? response.finalURL
            if let gate = AccessGateDetector.detect(html: response.body, url: finalURL) {
                if item.via == "root" || visited.count <= 1 {
                    return SiteScanResult(siteURL: root.absoluteString, keyword: keyword, scannedPages: visited.count, queuedRemaining: queue.count, results: [], errors: errors, blocked: gate)
                }
                errors.append(ScanErrorItem(url: finalURL.absoluteString, message: "Blocked by \(gate.type.rawValue): \(gate.evidence.joined(separator: ", "))"))
                continue
            }

            // Use the site's own search box first: form, OpenSearch description, then common URL layouts.
            if item.via == "root" {
                var searchURLs = HTMLInspector.discoveredSearchURLs(in: response.body, baseURL: finalURL, keyword: keyword)
                for descURL in HTMLInspector.openSearchDescriptionURLs(in: response.body, baseURL: finalURL).prefix(2) {
                    if let xml = try? await http.fetchText(descURL) {
                        searchURLs += HTMLInspector.searchURLs(fromOpenSearch: xml.body, keyword: keyword)
                    }
                }
                if searchURLs.isEmpty {
                    for url in HTMLInspector.commonSearchURLs(root: root, keyword: keyword) {
                        enqueue(url, depth: 0, priority: 700, via: "site-search-guess")
                    }
                } else {
                    for url in searchURLs { enqueue(url, depth: 0, priority: 900, via: "site-search") }
                }
            }

            // Pages produced by the site's own search: follow their video links and pagination first.
            let isSearchPage = item.via.hasPrefix("site-search")
            if isSearchPage {
                var links = HTMLInspector.links(in: response.body, baseURL: finalURL)
                // JS-rendered search results: render once in WKWebView when the plain HTML has almost no links.
                if links.count < 15 && options.dynamicFallback && dynamicSearchUsed < 3 {
                    dynamicSearchUsed += 1
                    if let rendered = try? await DynamicWebScanner().renderedHTML(url: finalURL) {
                        links = HTMLInspector.links(in: rendered, baseURL: finalURL)
                    }
                }
                for link in links {
                    guard URLUtilities.sameSite(link.url, root: root), robots.allows(link.url) else { continue }
                    let scored = HTMLInspector.score(link: link, keyword: keyword)
                    let isPaging = scored.1.contains("next") || scored.1.contains("pagination")
                    enqueue(link.url, depth: item.depth + 1,
                            priority: scored.0 + (isPaging ? 400 : 300),
                            via: isPaging ? "site-search-page" : "search-result")
                }
            }

            let evidence = HTMLInspector.keywordEvidence(in: response.body, keyword: keyword)
            if evidence.matched {
                var media = MediaExtractor.extract(from: response.body, baseURL: finalURL)
                if media.isEmpty && options.dynamicFallback && dynamicUsed < options.maxDynamicPages {
                    do {
                        dynamicUsed += 1
                        let dynamic = try await DynamicWebScanner().scan(url: finalURL)
                        media = MediaExtractor.deduplicated(media + dynamic)
                        await CookieBridge.importWebKitCookiesIntoURLSession()
                    } catch {
                        errors.append(ScanErrorItem(url: finalURL.absoluteString, message: "Dynamic fallback: \(error.localizedDescription)"))
                    }
                }
                if !media.isEmpty, emitted.insert(finalURL.absoluteString).inserted {
                    let pageDuration = HTMLInspector.videoDurationSeconds(from: response.body)
                    let title = evidence.title.isEmpty ? finalURL.lastPathComponent : evidence.title
                    var entry = PageMediaResult(
                        pageURL: finalURL.absoluteString,
                        title: title,
                        durationSeconds: pageDuration,
                        matchEvidence: evidence.evidence,
                        media: media
                    )
                    // Show it in the app immediately; the duration is filled in afterwards if it needs probing.
                    results.append(entry)
                    onResult(entry)
                    progress(ScanProgress(scannedPages: visited.count, queuedPages: queue.count, foundResults: results.count, currentURL: item.url.absoluteString))
                    if pageDuration == nil {
                        let probed = await MediaMetadataProbe.durationSeconds(from: media)
                        if let probed {
                            entry = PageMediaResult(pageURL: entry.pageURL, title: entry.title, durationSeconds: probed, matchEvidence: entry.matchEvidence, media: entry.media)
                            results[results.count - 1] = entry
                            onResult(entry)
                        }
                    }
                }
            }

            if item.depth < maxDepth && !isSearchPage {
                for link in HTMLInspector.links(in: response.body, baseURL: finalURL) {
                    guard URLUtilities.sameSite(link.url, root: root), robots.allows(link.url) else { continue }
                    let scored = HTMLInspector.score(link: link, keyword: keyword)
                    enqueue(link.url, depth: item.depth + 1, priority: scored.0, via: scored.1.joined(separator: ","))
                }
            }

            if options.requestDelayMilliseconds > 0 {
                try await Task.sleep(nanoseconds: options.requestDelayMilliseconds * 1_000_000)
            }
        }

        var seenPages = Set<String>()
        let unique = results.filter { seenPages.insert($0.pageURL).inserted }
        progress(ScanProgress(scannedPages: visited.count, queuedPages: queue.count, foundResults: unique.count, currentURL: ""))
        return SiteScanResult(
            siteURL: root.absoluteString,
            keyword: keyword,
            scannedPages: visited.count,
            queuedRemaining: queue.count,
            results: Array(unique.prefix(maxResults)),
            errors: Array(errors.prefix(50)),
            blocked: nil
        )
    }
}
