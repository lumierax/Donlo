import Foundation

final class SiteCrawler {
    private enum QueueRole: Sendable {
        case searchListing
        case videoCandidate
    }

    private struct QueueItem: Sendable {
        let url: URL
        let depth: Int
        let priority: Int
        let sequence: Int
        let role: QueueRole
    }

    private let http = HTTPClient()

    func search(
        siteURL: URL,
        keyword: String,
        options: ScanOptions,
        progress: @escaping @Sendable (ScanProgress) async -> Void,
        resultFound: @escaping @Sendable (PageMediaResult) async -> Void
    ) async throws -> SiteScanResult {
        let cleanKeyword = keyword.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !cleanKeyword.isEmpty else {
            throw NSError(domain: "SiteMediaScanner", code: 1, userInfo: [NSLocalizedDescriptionKey: "Search keyword is required."])
        }

        var root = siteURL
        if root.scheme?.lowercased() == "http" {
            var components = URLComponents(url: root, resolvingAgainstBaseURL: false)
            components?.scheme = "https"
            if let https = components?.url { root = https }
        }
        guard ["http", "https"].contains(root.scheme?.lowercased() ?? "") else {
            throw NSError(domain: "SiteMediaScanner", code: 2, userInfo: [NSLocalizedDescriptionKey: "Only HTTP/HTTPS sites are supported."])
        }

        let maxPages = max(2, options.maxPages)
        let maxDepth = max(1, options.maxDepth)
        let maxResults = max(1, options.maxResults)
        let robots = options.respectRobots ? await SitemapDiscovery.robotsRules(rootURL: root, http: http) : .allowAll

        var sequence = 0
        var queue: [QueueItem] = []
        var queued = Set<String>()
        var visited = Set<String>()
        var results: [PageMediaResult] = []
        var errors: [ScanErrorItem] = []
        var dynamicUsed = 0
        var scannedPages = 0
        var searchModeNote = ""

        func emitProgress(currentURL: String) async {
            await progress(ScanProgress(
                scannedPages: scannedPages,
                queuedPages: queue.count,
                foundResults: results.count,
                currentURL: currentURL
            ))
        }

        func enqueue(_ url: URL, depth: Int, priority: Int, role: QueueRole) {
            guard depth <= maxDepth,
                  let canonical = URLUtilities.canonicalPageURL(url),
                  URLUtilities.sameSite(canonical, root: root),
                  robots.allows(canonical) else { return }
            let key = canonical.absoluteString
            guard !queued.contains(key), !visited.contains(key) else { return }
            queued.insert(key)
            queue.append(QueueItem(url: canonical, depth: depth, priority: priority, sequence: sequence, role: role))
            sequence += 1
        }

        func upsert(_ result: PageMediaResult) async {
            if let index = results.firstIndex(where: { $0.id == result.id }) {
                results[index] = result
            } else if results.count < maxResults {
                results.append(result)
            } else {
                return
            }

            // The caller awaits this update, so the row is visible immediately and is
            // already preserved if the user presses Stop on the next page.
            await resultFound(result)
            await emitProgress(currentURL: result.pageURL)
        }

        func gateIfBlocking(html: String, url: URL) -> AccessGate? {
            guard let gate = AccessGateDetector.detect(html: html, url: url) else { return nil }
            if gate.type == .humanVerification && options.ignoreHumanVerificationGate {
                errors.append(ScanErrorItem(url: url.absoluteString, message: "Ignored suspected human-verification warning by user choice."))
                return nil
            }
            return gate
        }

        // 1) Open only the landing page. If URLSession receives an unsupported-browser
        // interstitial, re-render the same page with WKWebView/Safari identity.
        try Task.checkCancellation()
        await emitProgress(currentURL: root.absoluteString)

        var rootResponse = try await http.fetchText(root)
        scannedPages += 1

        if HTMLInspector.looksLikeUnsupportedBrowserPage(rootResponse.body),
           options.dynamicFallback,
           dynamicUsed < options.maxDynamicPages {
            do {
                dynamicUsed += 1
                rootResponse = try await DynamicWebScanner().renderPage(url: rootResponse.finalURL)
                await CookieBridge.importWebKitCookiesIntoURLSession()
            } catch {
                errors.append(ScanErrorItem(url: root.absoluteString, message: "Safari render fallback: \(error.localizedDescription)"))
            }
        }

        if let canonical = URLUtilities.canonicalPageURL(rootResponse.finalURL) {
            visited.insert(canonical.absoluteString)
        }
        await emitProgress(currentURL: rootResponse.finalURL.absoluteString)

        if let gate = gateIfBlocking(html: rootResponse.body, url: rootResponse.finalURL) {
            return SiteScanResult(
                siteURL: root.absoluteString,
                keyword: cleanKeyword,
                scannedPages: scannedPages,
                queuedRemaining: 0,
                results: results,
                errors: errors,
                blocked: gate,
                note: nil
            )
        }

        // 2) Prefer the site's REAL rendered search box. This is important for modern
        // sites whose search UI is generated by JavaScript and has no useful <form> in source.
        var initialSearchResponse: HTTPTextResponse?

        if options.dynamicFallback, dynamicUsed < options.maxDynamicPages {
            do {
                dynamicUsed += 1
                if let renderedSearch = try await DynamicWebScanner().searchSite(
                    url: rootResponse.finalURL,
                    keyword: cleanKeyword
                ) {
                    initialSearchResponse = renderedSearch
                    scannedPages += 1
                    searchModeNote = "تم استخدام مربع البحث الظاهر في الموقع."
                    await CookieBridge.importWebKitCookiesIntoURLSession()
                }
            } catch {
                errors.append(ScanErrorItem(url: rootResponse.finalURL.absoluteString, message: "Rendered site search: \(error.localizedDescription)"))
            }
        }

        // If the rendered search field could not be used, submit a classic HTML search
        // form directly. We still do not crawl categories or unrelated areas of the site.
        if initialSearchResponse == nil {
            let searchRequests = HTMLInspector.discoveredSearchRequests(
                in: rootResponse.body,
                baseURL: rootResponse.finalURL,
                keyword: cleanKeyword
            ).filter { URLUtilities.sameSite($0.actionURL, root: root) }

            var lastSearchError: Error?
            for request in searchRequests.prefix(4) {
                try Task.checkCancellation()
                do {
                    var response = try await http.submitSearch(request)
                    scannedPages += 1

                    if HTMLInspector.looksLikeUnsupportedBrowserPage(response.body),
                       options.dynamicFallback,
                       dynamicUsed < options.maxDynamicPages {
                        do {
                            dynamicUsed += 1
                            response = try await DynamicWebScanner().renderPage(url: response.finalURL)
                            await CookieBridge.importWebKitCookiesIntoURLSession()
                        } catch {
                            errors.append(ScanErrorItem(url: response.finalURL.absoluteString, message: "Search results Safari fallback: \(error.localizedDescription)"))
                        }
                    }

                    initialSearchResponse = response
                    searchModeNote = "تم إرسال الكلمة عبر نموذج البحث الخاص بالموقع."
                    break
                } catch {
                    lastSearchError = error
                    errors.append(ScanErrorItem(url: request.actionURL.absoluteString, message: "Site search: \(error.localizedDescription)"))
                }
            }

            if initialSearchResponse == nil, let lastSearchError, !HTMLInspector.discoveredSearchRequests(
                in: rootResponse.body,
                baseURL: rootResponse.finalURL,
                keyword: cleanKeyword
            ).isEmpty {
                throw lastSearchError
            }
        }

        guard let searchResponse = initialSearchResponse else {
            await emitProgress(currentURL: "")
            return SiteScanResult(
                siteURL: root.absoluteString,
                keyword: cleanKeyword,
                scannedPages: scannedPages,
                queuedRemaining: 0,
                results: results,
                errors: errors,
                blocked: nil,
                note: "لم أجد خانة بحث قابلة للاستخدام في الموقع. لم أقم بالزحف العشوائي في الأقسام."
            )
        }

        if let canonical = URLUtilities.canonicalPageURL(searchResponse.finalURL) {
            // For SPA search the URL can remain the root. It is safe to mark it visited;
            // the rendered search HTML is processed below before the queue begins.
            visited.insert(canonical.absoluteString)
        }

        if let gate = gateIfBlocking(html: searchResponse.body, url: searchResponse.finalURL) {
            return SiteScanResult(
                siteURL: root.absoluteString,
                keyword: cleanKeyword,
                scannedPages: scannedPages,
                queuedRemaining: 0,
                results: results,
                errors: errors,
                blocked: gate,
                note: nil
            )
        }

        func discoverLinksFromSearchListing(html: String, baseURL: URL, depth: Int) {
            for link in HTMLInspector.links(in: html, baseURL: baseURL) {
                guard URLUtilities.sameSite(link.url, root: root), robots.allows(link.url) else { continue }

                if HTMLInspector.isPaginationLink(link) {
                    let scored = HTMLInspector.score(link: link, keyword: cleanKeyword)
                    enqueue(link.url, depth: depth + 1, priority: 900 + scored.0, role: .searchListing)
                } else if HTMLInspector.isLikelyVideoResultLink(link, keyword: cleanKeyword) {
                    let scored = HTMLInspector.score(link: link, keyword: cleanKeyword)
                    enqueue(link.url, depth: depth + 1, priority: 600 + scored.0, role: .videoCandidate)
                }
            }
        }

        // Some searches redirect directly to a matching video page.
        let initialEvidence = HTMLInspector.keywordEvidence(in: searchResponse.body, keyword: cleanKeyword)
        let initialMedia = initialEvidence.matched ? MediaExtractor.extract(from: searchResponse.body, baseURL: searchResponse.finalURL) : []
        if initialEvidence.matched, !initialMedia.isEmpty, HTMLInspector.isVideoLikeURL(searchResponse.finalURL) {
            let initialResult = PageMediaResult(
                pageURL: searchResponse.finalURL.absoluteString,
                title: initialEvidence.title.isEmpty ? searchResponse.finalURL.lastPathComponent : initialEvidence.title,
                durationSeconds: HTMLInspector.videoDurationSeconds(from: searchResponse.body),
                matchEvidence: initialEvidence.evidence,
                media: initialMedia
            )
            await upsert(initialResult)
        } else {
            discoverLinksFromSearchListing(html: searchResponse.body, baseURL: searchResponse.finalURL, depth: 0)
        }
        await emitProgress(currentURL: searchResponse.finalURL.absoluteString)

        // 3) Follow only video candidates and pagination discovered inside search results.
        while !queue.isEmpty && scannedPages < maxPages && results.count < maxResults {
            try Task.checkCancellation()
            queue.sort {
                if $0.priority != $1.priority { return $0.priority > $1.priority }
                return $0.sequence < $1.sequence
            }

            let item = queue.removeFirst()
            queued.remove(item.url.absoluteString)
            guard !visited.contains(item.url.absoluteString), robots.allows(item.url) else { continue }
            visited.insert(item.url.absoluteString)
            await emitProgress(currentURL: item.url.absoluteString)

            var response: HTTPTextResponse
            do {
                response = try await http.fetchText(item.url)
                scannedPages += 1
            } catch {
                errors.append(ScanErrorItem(url: item.url.absoluteString, message: error.localizedDescription))
                continue
            }

            if HTMLInspector.looksLikeUnsupportedBrowserPage(response.body),
               options.dynamicFallback,
               dynamicUsed < options.maxDynamicPages {
                do {
                    dynamicUsed += 1
                    response = try await DynamicWebScanner().renderPage(url: response.finalURL)
                    await CookieBridge.importWebKitCookiesIntoURLSession()
                } catch {
                    errors.append(ScanErrorItem(url: item.url.absoluteString, message: "Safari render fallback: \(error.localizedDescription)"))
                }
            }

            let finalURL = URLUtilities.canonicalPageURL(response.finalURL) ?? response.finalURL
            if let gate = gateIfBlocking(html: response.body, url: finalURL) {
                errors.append(ScanErrorItem(url: finalURL.absoluteString, message: "Blocked by \(gate.type.rawValue): \(gate.evidence.joined(separator: ", "))"))
                continue
            }

            switch item.role {
            case .searchListing:
                discoverLinksFromSearchListing(html: response.body, baseURL: finalURL, depth: item.depth)

            case .videoCandidate:
                let evidence = HTMLInspector.keywordEvidence(in: response.body, keyword: cleanKeyword)
                guard evidence.matched else { break }

                var media = MediaExtractor.extract(from: response.body, baseURL: finalURL)
                if media.isEmpty && options.dynamicFallback && dynamicUsed < options.maxDynamicPages {
                    do {
                        dynamicUsed += 1
                        let dynamic = try await DynamicWebScanner().scan(url: finalURL)
                        media = MediaExtractor.deduplicated(media + dynamic)
                        await CookieBridge.importWebKitCookiesIntoURLSession()
                    } catch {
                        errors.append(ScanErrorItem(url: finalURL.absoluteString, message: "Dynamic media fallback: \(error.localizedDescription)"))
                    }
                }

                guard !media.isEmpty else { break }
                let title = evidence.title.isEmpty ? finalURL.lastPathComponent : evidence.title
                let pageDuration = HTMLInspector.videoDurationSeconds(from: response.body)

                // Publish before duration probing. Download is available immediately.
                var result = PageMediaResult(
                    pageURL: finalURL.absoluteString,
                    title: title,
                    durationSeconds: pageDuration,
                    matchEvidence: evidence.evidence,
                    media: media
                )
                await upsert(result)

                // Duration enrichment updates the same visible row later.
                if pageDuration == nil {
                    let probedDuration = await MediaMetadataProbe.durationSeconds(from: media)
                    if let probedDuration, probedDuration > 0 {
                        result = PageMediaResult(
                            pageURL: result.pageURL,
                            title: result.title,
                            durationSeconds: probedDuration,
                            matchEvidence: result.matchEvidence,
                            media: result.media
                        )
                        await upsert(result)
                    }
                }
            }

            await emitProgress(currentURL: finalURL.absoluteString)
            if options.requestDelayMilliseconds > 0 {
                try await Task.sleep(nanoseconds: options.requestDelayMilliseconds * 1_000_000)
            }
        }

        await emitProgress(currentURL: "")
        return SiteScanResult(
            siteURL: root.absoluteString,
            keyword: cleanKeyword,
            scannedPages: scannedPages,
            queuedRemaining: queue.count,
            results: Array(results.prefix(maxResults)),
            errors: Array(errors.prefix(50)),
            blocked: nil,
            note: searchModeNote.isEmpty ? "تم استخدام نتائج بحث الموقع فقط." : searchModeNote
        )
    }
}
