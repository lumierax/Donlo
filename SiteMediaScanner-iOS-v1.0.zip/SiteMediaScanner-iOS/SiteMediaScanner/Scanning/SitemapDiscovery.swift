import Foundation

enum SitemapDiscovery {
    static func discover(rootURL: URL, http: HTTPClient, maxURLs: Int) async -> [URL] {
        guard let origin = originURL(rootURL) else { return [] }
        var seeds = Set<URL>()
        if let sitemap = URL(string: "/sitemap.xml", relativeTo: origin)?.absoluteURL { seeds.insert(sitemap) }

        if let robotsURL = URL(string: "/robots.txt", relativeTo: origin)?.absoluteURL,
           let response = try? await http.fetchText(robotsURL, timeout: 10) {
            let matches = TextUtilities.regexMatches(#"^\s*Sitemap:\s*(\S+)\s*$"#, in: response.body, options: [.caseInsensitive, .anchorsMatchLines])
            for match in matches where match.count > 1 {
                if let url = URL(string: match[1]) { seeds.insert(url) }
            }
        }

        var queue = Array(seeds)
        var visited = Set<String>()
        var pages: [URL] = []
        var pageSeen = Set<String>()

        while !queue.isEmpty && pages.count < maxURLs && visited.count < 20 {
            let sitemapURL = queue.removeFirst()
            guard URLUtilities.sameSite(sitemapURL, root: rootURL), visited.insert(sitemapURL.absoluteString).inserted else { continue }
            guard let response = try? await http.fetchText(sitemapURL, timeout: 10) else { continue }
            let isIndex = response.body.range(of: #"<sitemapindex\b"#, options: [.regularExpression, .caseInsensitive]) != nil
            let locations = TextUtilities.regexMatches(#"<loc\b[^>]*>([\s\S]*?)</loc>"#, in: response.body)
            for match in locations where match.count > 1 {
                let raw = TextUtilities.decodeLooseString(match[1]).trimmingCharacters(in: .whitespacesAndNewlines)
                guard let url = URL(string: raw), URLUtilities.sameSite(url, root: rootURL) else { continue }
                if isIndex || url.absoluteString.range(of: #"sitemap.*\.xml(?:$|\?)"#, options: [.regularExpression, .caseInsensitive]) != nil {
                    if !visited.contains(url.absoluteString) { queue.append(url) }
                } else if let canonical = URLUtilities.canonicalPageURL(url), pageSeen.insert(canonical.absoluteString).inserted {
                    pages.append(canonical)
                    if pages.count >= maxURLs { break }
                }
            }
        }
        return pages
    }

    static func robotsRules(rootURL: URL, http: HTTPClient) async -> RobotsRules {
        guard let origin = originURL(rootURL),
              let robotsURL = URL(string: "/robots.txt", relativeTo: origin)?.absoluteURL,
              let response = try? await http.fetchText(robotsURL, timeout: 10) else { return .allowAll }
        return RobotsRules.parse(response.body)
    }

    private static func originURL(_ url: URL) -> URL? {
        guard let scheme = url.scheme, let host = url.host else { return nil }
        var components = URLComponents()
        components.scheme = scheme
        components.host = host
        components.port = url.port
        components.path = "/"
        return components.url
    }
}
