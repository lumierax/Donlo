import Foundation

enum TextUtilities {
    static func decodeLooseString(_ input: String) -> String {
        var value = input.trimmingCharacters(in: .whitespacesAndNewlines)
        let entities: [(String, String)] = [
            ("&amp;", "&"), ("&#38;", "&"), ("&quot;", "\""), ("&#34;", "\""),
            ("&#39;", "'"), ("&apos;", "'"), ("&lt;", "<"), ("&gt;", ">")
        ]
        for (entity, replacement) in entities {
            value = value.replacingOccurrences(of: entity, with: replacement)
        }

        let replacements: [(String, String)] = [
            ("\\u002F", "/"), ("\\u002f", "/"), ("\\u003A", ":"), ("\\u003a", ":"),
            ("\\u0026", "&"), ("\\u003D", "="), ("\\u003d", "="),
            ("\\x2F", "/"), ("\\x2f", "/"), ("\\x3A", ":"), ("\\x3a", ":"),
            ("\\/", "/"), ("\\&", "&")
        ]
        for (needle, replacement) in replacements {
            value = value.replacingOccurrences(of: needle, with: replacement)
        }

        if value.range(of: #"^https?%3A%2F%2F"#, options: [.regularExpression, .caseInsensitive]) != nil,
           let decoded = value.removingPercentEncoding {
            value = decoded
        }
        return value
    }

    static func stripTags(_ html: String) -> String {
        var value = html
        let patterns = [
            #"<script\b[^>]*>[\s\S]*?</script>"#,
            #"<style\b[^>]*>[\s\S]*?</style>"#,
            #"<noscript\b[^>]*>[\s\S]*?</noscript>"#,
            #"<!--[\s\S]*?-->"#,
            #"<[^>]+>"#
        ]
        for pattern in patterns {
            value = value.replacingOccurrences(of: pattern, with: " ", options: [.regularExpression, .caseInsensitive])
        }
        value = decodeLooseString(value)
        return value.replacingOccurrences(of: #"\s+"#, with: " ", options: .regularExpression)
            .trimmingCharacters(in: .whitespacesAndNewlines)
    }

    static func normalized(_ value: String) -> String {
        value.precomposedStringWithCompatibilityMapping
            .lowercased()
            .replacingOccurrences(of: #"\s+"#, with: " ", options: .regularExpression)
            .trimmingCharacters(in: .whitespacesAndNewlines)
    }

    static func containsKeyword(_ value: String, keyword: String) -> Bool {
        let needle = normalized(keyword)
        return !needle.isEmpty && normalized(value).contains(needle)
    }

    static func regexMatches(_ pattern: String, in text: String, options: NSRegularExpression.Options = [.caseInsensitive]) -> [[String]] {
        guard let regex = try? NSRegularExpression(pattern: pattern, options: options) else { return [] }
        let ns = text as NSString
        let range = NSRange(location: 0, length: ns.length)
        return regex.matches(in: text, range: range).map { match in
            (0..<match.numberOfRanges).map { index in
                let r = match.range(at: index)
                return r.location == NSNotFound ? "" : ns.substring(with: r)
            }
        }
    }

    static func firstCapture(_ pattern: String, in text: String) -> String? {
        regexMatches(pattern, in: text).first.flatMap { $0.count > 1 ? $0[1] : nil }
    }
}
