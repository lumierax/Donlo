import Foundation

enum AccessGateDetector {
    private static let humanMarkers = [
        "captcha", "recaptcha", "hcaptcha", "turnstile", "verify you are human", "confirm you are human",
        "are you human", "checking your browser", "security check", "bot verification",
        "تحقق من أنك إنسان", "التحقق من أنك انسان", "لست روبوت", "أنا لست روبوت"
    ]

    private static let ageMarkers = [
        "age verification", "verify your age", "confirm your age", "are you 18", "18 years or older",
        "enter if you are 18", "age gate", "تأكيد العمر", "تحقق من عمرك", "هل عمرك 18", "عمرك 18",
        "فوق 18", "للبالغين فقط"
    ]

    static func detect(html: String, url: URL) -> AccessGate? {
        let text = TextUtilities.normalized(String(TextUtilities.stripTags(html).prefix(300_000)))
        let source = TextUtilities.normalized(String(html.prefix(500_000)))
        let haystack = "\(text) \(source) \(TextUtilities.normalized(url.absoluteString))"

        let human = humanMarkers.filter { haystack.contains(TextUtilities.normalized($0)) }
        if !human.isEmpty { return AccessGate(type: .humanVerification, evidence: Array(human.prefix(4))) }

        let age = ageMarkers.filter { haystack.contains(TextUtilities.normalized($0)) }
        let ageUI = html.range(of: #"<(?:form|button|input)\b"#, options: [.regularExpression, .caseInsensitive]) != nil &&
            text.range(of: #"(?:18\+|i\s+am\s+18|enter|continue|yes|confirm|age|العمر|دخول|متابعة)"#, options: [.regularExpression, .caseInsensitive]) != nil
        let ageURL = url.absoluteString.range(of: #"(?:^|[/_-])(?:age|adult|verify)(?:[/_-]|$|\?)"#, options: [.regularExpression, .caseInsensitive]) != nil
        if !age.isEmpty && (ageUI || ageURL) { return AccessGate(type: .ageGate, evidence: Array(age.prefix(4))) }
        return nil
    }
}
