import Foundation

enum AccessGateDetector {
    // These phrases are inspected ONLY in visible page text. Script/style contents are
    // removed first so an advertisement or analytics bundle containing words such as
    // "captcha" or "challenge" does not stop the scan.
    private static let explicitHumanPhrases = [
        "verify you are human", "confirm you are human", "are you human",
        "checking your browser", "bot verification", "complete the security check",
        "prove you are human", "human verification",
        "تحقق من أنك إنسان", "التحقق من أنك انسان", "أثبت أنك إنسان",
        "لست روبوت", "أنا لست روبوت"
    ]

    // Strong DOM/provider signatures. These are intentionally specific; generic words
    // like "captcha", "challenge", "verify" and "security check" in source code are
    // NOT enough on their own.
    private static let widgetPatterns = [
        #"class\s*=\s*[\"'][^\"']*\bg-recaptcha\b[^\"']*[\"']"#,
        #"class\s*=\s*[\"'][^\"']*\bh-captcha\b[^\"']*[\"']"#,
        #"class\s*=\s*[\"'][^\"']*\bcf-turnstile\b[^\"']*[\"']"#,
        #"id\s*=\s*[\"'][^\"']*(?:recaptcha|hcaptcha|turnstile)[^\"']*[\"']"#,
        #"data-(?:sitekey|site-key)\s*=\s*[\"'][^\"']+[\"'][^>]*(?:recaptcha|hcaptcha|turnstile)"#
    ]

    private static let challengeEnginePatterns = [
        #"/cdn-cgi/challenge-platform/"#,
        #"\bcf-chl-(?:widget|opt|out|rc|ctx|ray)\b"#,
        #"challenges\.cloudflare\.com/turnstile"#
    ]

    private static let providerScriptPatterns = [
        #"google\.com/recaptcha/(?:api|enterprise)\.js"#,
        #"gstatic\.com/recaptcha/"#,
        #"hcaptcha\.com/(?:1/)?api\.js"#,
        #"challenges\.cloudflare\.com/turnstile/v\d+/api\.js"#
    ]

    private static let ageMarkers = [
        "age verification", "verify your age", "confirm your age", "are you 18", "18 years or older",
        "enter if you are 18", "age gate", "تأكيد العمر", "تحقق من عمرك", "هل عمرك 18", "عمرك 18",
        "فوق 18", "للبالغين فقط"
    ]

    static func detect(html: String, url: URL) -> AccessGate? {
        let visibleRaw = String(TextUtilities.stripTags(html).prefix(300_000))
        let visibleText = TextUtilities.normalized(visibleRaw)
        let title = TextUtilities.normalized(extractTitle(from: html))

        // Keep element attributes (where CAPTCHA widgets live) but throw away script/style
        // bodies, which are a common source of false positives from ads.
        let structuralSource = TextUtilities.normalized(
            String(sourceWithoutEmbeddedCode(html).prefix(600_000))
        )

        if let human = detectHumanVerification(
            visibleText: visibleText,
            title: title,
            structuralSource: structuralSource,
            url: url
        ) {
            return human
        }

        let age = ageMarkers.filter { visibleText.contains(TextUtilities.normalized($0)) }
        let ageUI = structuralSource.range(
            of: #"<(?:form|button|input)\b"#,
            options: [.regularExpression, .caseInsensitive]
        ) != nil && visibleText.range(
            of: #"(?:18\+|i\s+am\s+18|enter|continue|yes|confirm|age|العمر|دخول|متابعة)"#,
            options: [.regularExpression, .caseInsensitive]
        ) != nil
        let ageURL = url.absoluteString.range(
            of: #"(?:^|[/_-])(?:age|adult|verify)(?:[/_-]|$|\?)"#,
            options: [.regularExpression, .caseInsensitive]
        ) != nil

        if !age.isEmpty && (ageUI || ageURL) {
            return AccessGate(type: .ageGate, evidence: Array(age.prefix(4)))
        }
        return nil
    }

    private static func detectHumanVerification(
        visibleText: String,
        title: String,
        structuralSource: String,
        url: URL
    ) -> AccessGate? {
        let phrases = explicitHumanPhrases.filter {
            visibleText.contains(TextUtilities.normalized($0))
        }

        let titlePhrases = explicitHumanPhrases.filter {
            !title.isEmpty && title.contains(TextUtilities.normalized($0))
        }

        let widgets = matchingPatterns(widgetPatterns, in: structuralSource)
        let engines = matchingPatterns(challengeEnginePatterns, in: structuralSource)
        let providerScripts = matchingPatterns(providerScriptPatterns, in: structuralSource)

        let challengeURL = url.absoluteString.range(
            of: #"/cdn-cgi/challenge-platform/|challenges\.cloudflare\.com/turnstile"#,
            options: [.regularExpression, .caseInsensitive]
        ) != nil

        // A real widget/container or Cloudflare challenge engine is strong enough by itself.
        if !widgets.isEmpty || !engines.isEmpty || challengeURL {
            var evidence: [String] = []
            evidence.append(contentsOf: widgets.prefix(2).map { "widget:\($0)" })
            evidence.append(contentsOf: engines.prefix(2).map { "challenge:\($0)" })
            if challengeURL { evidence.append("challenge-url") }
            evidence.append(contentsOf: phrases.prefix(2))
            return AccessGate(type: .humanVerification, evidence: Array(evidence.prefix(4)))
        }

        // A provider script alone can be included by advertising code. Require matching
        // visible challenge text before treating it as a gate.
        if !providerScripts.isEmpty && !phrases.isEmpty {
            return AccessGate(
                type: .humanVerification,
                evidence: Array((["provider-script"] + Array(phrases.prefix(3))).prefix(4))
            )
        }

        // Explicit wording in the page title is strong evidence because ads normally do
        // not control the document title.
        if !titlePhrases.isEmpty && !phrases.isEmpty {
            return AccessGate(type: .humanVerification, evidence: Array(titlePhrases.prefix(4)))
        }

        // Challenge interstitials are usually tiny pages. On a normal, content-heavy page,
        // one phrase inside an advertisement must not stop the crawler.
        if phrases.count >= 2 || (!phrases.isEmpty && visibleText.count < 4_000) {
            return AccessGate(type: .humanVerification, evidence: Array(phrases.prefix(4)))
        }

        return nil
    }

    private static func matchingPatterns(_ patterns: [String], in text: String) -> [String] {
        patterns.compactMap { pattern in
            text.range(of: pattern, options: [.regularExpression, .caseInsensitive]) == nil ? nil : pattern
        }
    }

    private static func sourceWithoutEmbeddedCode(_ html: String) -> String {
        var value = html
        let replacements: [(String, String)] = [
            (#"<script\b([^>]*)>[\s\S]*?</script>"#, "<script$1></script>"),
            (#"<style\b[^>]*>[\s\S]*?</style>"#, " "),
            (#"<noscript\b[^>]*>[\s\S]*?</noscript>"#, " "),
            (#"<!--[\s\S]*?-->"#, " ")
        ]
        for (pattern, replacement) in replacements {
            value = value.replacingOccurrences(
                of: pattern,
                with: replacement,
                options: [.regularExpression, .caseInsensitive]
            )
        }
        return value
    }

    private static func extractTitle(from html: String) -> String {
        TextUtilities.firstCapture(#"<title\b[^>]*>([\s\S]*?)</title>"#, in: html)
            .map(TextUtilities.stripTags) ?? ""
    }
}
