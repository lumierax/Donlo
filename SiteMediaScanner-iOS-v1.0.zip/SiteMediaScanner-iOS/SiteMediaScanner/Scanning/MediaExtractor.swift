import Foundation

enum MediaExtractor {
    static func extract(from source: String, baseURL: URL) -> [MediaItem] {
        var items: [MediaItem] = []
        items.append(contentsOf: extractDirect(from: source, baseURL: baseURL))
        items.append(contentsOf: extractJSON(from: source, baseURL: baseURL))
        items.append(contentsOf: extractStaticJavaScript(from: source, baseURL: baseURL))
        return deduplicated(items)
    }

    static func makeItem(raw: String, baseURL: URL, discoveredBy: String, evidence: String?) -> MediaItem? {
        guard let url = URLUtilities.normalizedCandidate(raw, baseURL: baseURL),
              URLUtilities.isLikelyMedia(url), !URLUtilities.looksLikeDRM(url) else { return nil }
        let (kind, resolution) = URLUtilities.classify(url)
        return MediaItem(url: url.absoluteString, kind: kind, resolution: resolution, discoveredBy: discoveredBy, evidence: evidence)
    }

    private static func extractDirect(from source: String, baseURL: URL) -> [MediaItem] {
        var output: [MediaItem] = []
        let absolute = #"https?(?::|\\u003[aA]|\\x3[aA])(?:\\?/){2}[^\s\"'<>`\\]+"#
        for match in TextUtilities.regexMatches(absolute, in: source) {
            if let value = match.first, let item = makeItem(raw: value, baseURL: baseURL, discoveredBy: "direct", evidence: "absolute-url") {
                output.append(item)
            }
        }

        let attributes = #"(?:src|href|file|url|content|data-src|data-file)\s*=\s*[\"']([^\"']+)[\"']"#
        for match in TextUtilities.regexMatches(attributes, in: source) where match.count > 1 {
            if let item = makeItem(raw: match[1], baseURL: baseURL, discoveredBy: "direct", evidence: "html-attribute") {
                output.append(item)
            }
        }
        return output
    }

    private static func extractJSON(from source: String, baseURL: URL) -> [MediaItem] {
        var output: [MediaItem] = []
        let scriptPattern = #"<script[^>]+type=[\"']application/(?:ld\+)?json[\"'][^>]*>([\s\S]*?)</script>"#
        for match in TextUtilities.regexMatches(scriptPattern, in: source) where match.count > 1 {
            if let data = match[1].data(using: .utf8), let json = try? JSONSerialization.jsonObject(with: data) {
                walkJSON(json, path: "$", baseURL: baseURL, output: &output, depth: 0)
            }
        }

        // Player configs are often JavaScript objects rather than strict JSON. Capture useful key/string pairs too.
        let pairPattern = #"[\"']?(url|src|file|source|videoUrl|video_url|downloadUrl|download_url|manifest|hls|dash)[\"']?\s*:\s*[\"']([^\"']+)[\"']"#
        for match in TextUtilities.regexMatches(pairPattern, in: source) where match.count > 2 {
            if let item = makeItem(raw: match[2], baseURL: baseURL, discoveredBy: "player-config", evidence: match[1]) {
                output.append(item)
            }
        }
        return output
    }

    private static func walkJSON(_ value: Any, path: String, baseURL: URL, output: inout [MediaItem], depth: Int) {
        guard depth <= 12 else { return }
        if let array = value as? [Any] {
            for (index, child) in array.enumerated() {
                walkJSON(child, path: "\(path)[\(index)]", baseURL: baseURL, output: &output, depth: depth + 1)
            }
            return
        }
        guard let dictionary = value as? [String: Any] else { return }
        let useful = Set(["url", "src", "file", "source", "videourl", "video_url", "downloadurl", "download_url", "manifest", "hls", "dash"])
        for (key, child) in dictionary {
            let childPath = "\(path).\(key)"
            if let string = child as? String, useful.contains(key.lowercased()),
               let item = makeItem(raw: string, baseURL: baseURL, discoveredBy: "json", evidence: childPath) {
                output.append(item)
            }
            walkJSON(child, path: childPath, baseURL: baseURL, output: &output, depth: depth + 1)
        }
    }

    private enum JSPart {
        case literal(String)
        case name(String)
    }

    private static func extractStaticJavaScript(from source: String, baseURL: URL) -> [MediaItem] {
        let assignmentPattern = #"\b(?:var|let|const)\s+([A-Za-z_$][\w$]*)\s*=\s*([^;\n]{1,12000})(?=;|\n)"#
        let assignments = TextUtilities.regexMatches(assignmentPattern, in: source)
        var table: [String: [JSPart]] = [:]
        for match in assignments where match.count > 2 {
            if let parts = parseConcatenation(match[2]) { table[match[1]] = parts }
        }

        var cache: [String: String] = [:]
        var resolving = Set<String>()

        func resolve(_ name: String) -> String? {
            if let cached = cache[name] { return cached }
            guard !resolving.contains(name), let parts = table[name] else { return nil }
            resolving.insert(name)
            defer { resolving.remove(name) }
            var value = ""
            for part in parts {
                switch part {
                case .literal(let literal): value += literal
                case .name(let child):
                    guard let resolved = resolve(child) else { return nil }
                    value += resolved
                }
                if value.count > 50_000 { return nil }
            }
            cache[name] = value
            return value
        }

        var output: [MediaItem] = []
        for name in table.keys {
            guard let value = resolve(name), !value.isEmpty else { continue }
            let absolute = value.range(of: #"^https?://"#, options: [.regularExpression, .caseInsensitive]) != nil || value.hasPrefix("//")
            let meaningfulName = name.range(of: #"(?:url|src|file|source|video|audio|manifest|media|quality|stream)"#, options: [.regularExpression, .caseInsensitive]) != nil
            guard absolute || (meaningfulName && value.count > 5 && value.range(of: #"^\.[a-z0-9]{2,5}$"#, options: [.regularExpression, .caseInsensitive]) == nil) else { continue }
            if let item = makeItem(raw: value, baseURL: baseURL, discoveredBy: "static-js", evidence: name) {
                output.append(item)
            }
        }
        return output
    }

    private static func parseConcatenation(_ expression: String) -> [JSPart]? {
        let clean = expression.replacingOccurrences(of: #"/\*[\s\S]*?\*/"#, with: "", options: .regularExpression)
        var parts: [String] = []
        var current = ""
        var quote: Character?
        var escaped = false

        for char in clean {
            if let activeQuote = quote {
                current.append(char)
                if escaped { escaped = false }
                else if char == "\\" { escaped = true }
                else if char == activeQuote { quote = nil }
                continue
            }
            if char == "\"" || char == "'" || char == "`" {
                quote = char; current.append(char); continue
            }
            if char == "+" {
                parts.append(current.trimmingCharacters(in: .whitespacesAndNewlines)); current = ""; continue
            }
            current.append(char)
        }
        if quote != nil { return nil }
        parts.append(current.trimmingCharacters(in: .whitespacesAndNewlines))
        guard !parts.isEmpty, parts.allSatisfy({ !$0.isEmpty }) else { return nil }

        var output: [JSPart] = []
        for token in parts {
            if let literal = decodeJSLiteral(token) { output.append(.literal(literal)); continue }
            if token.range(of: #"^[A-Za-z_$][\w$]*$"#, options: .regularExpression) != nil { output.append(.name(token)); continue }
            return nil
        }
        return output
    }

    private static func decodeJSLiteral(_ token: String) -> String? {
        guard token.count >= 2, let first = token.first, token.last == first, ["\"", "'", "`"].contains(String(first)) else { return nil }
        var body = String(token.dropFirst().dropLast())
        if first == "`" && body.contains("${") { return nil }
        body = body.replacingOccurrences(of: #"\n"#, with: "\n")
            .replacingOccurrences(of: #"\r"#, with: "\r")
            .replacingOccurrences(of: #"\t"#, with: "\t")
            .replacingOccurrences(of: #"\\([\\\"'`])"#, with: "$1", options: .regularExpression)
        return TextUtilities.decodeLooseString(body)
    }

    static func deduplicated(_ items: [MediaItem]) -> [MediaItem] {
        var seen = Set<String>()
        return items.filter { seen.insert($0.url).inserted }
    }
}
