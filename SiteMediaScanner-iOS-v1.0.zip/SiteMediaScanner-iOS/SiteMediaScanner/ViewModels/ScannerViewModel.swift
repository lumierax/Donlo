import Foundation
import SwiftUI

@MainActor
final class ScannerViewModel: ObservableObject {
    @Published var siteText = ""
    @Published var keyword = ""
    @Published var maxPages = 150
    @Published var maxDepth = 5
    @Published var maxResults = 50
    @Published var useSitemap = true
    @Published var respectRobots = true
    @Published var dynamicFallback = true

    @Published private(set) var isScanning = false
    @Published private(set) var progress = ScanProgress(scannedPages: 0, queuedPages: 0, foundResults: 0, currentURL: "")
    @Published private(set) var results: [PageMediaResult] = []
    @Published private(set) var errors: [ScanErrorItem] = []
    @Published private(set) var blockedGate: AccessGate?
    @Published var message: String?
    @Published var showVerification = false

    private var scanTask: Task<Void, Never>?

    var siteURL: URL? {
        var raw = siteText.trimmingCharacters(in: .whitespacesAndNewlines)
        if raw.isEmpty { return nil }
        if !raw.lowercased().hasPrefix("http://") && !raw.lowercased().hasPrefix("https://") { raw = "https://\(raw)" }
        guard let url = URL(string: raw) else { return nil }
        if url.scheme?.lowercased() == "http" {
            var components = URLComponents(url: url, resolvingAgainstBaseURL: false)
            components?.scheme = "https"
            return components?.url
        }
        return url
    }

    func start() {
        guard let url = siteURL else { message = "Enter a valid website URL."; return }
        guard !keyword.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { message = "Enter a search word or phrase."; return }

        scanTask?.cancel()
        isScanning = true
        message = nil
        blockedGate = nil
        results = []
        errors = []
        progress = ScanProgress(scannedPages: 0, queuedPages: 0, foundResults: 0, currentURL: url.absoluteString)

        let options = ScanOptions(
            maxPages: maxPages,
            maxDepth: maxDepth,
            maxResults: maxResults,
            maxDynamicPages: 8,
            useSitemap: useSitemap,
            respectRobots: respectRobots,
            dynamicFallback: dynamicFallback,
            requestDelayMilliseconds: 120
        )

        scanTask = Task { [weak self] in
            guard let self else { return }
            await CookieBridge.importWebKitCookiesIntoURLSession()
            do {
                let result = try await SiteCrawler().search(siteURL: url, keyword: self.keyword, options: options) { progress in
                    Task { @MainActor [weak self] in self?.progress = progress }
                }
                guard !Task.isCancelled else { return }
                self.results = result.results
                self.errors = result.errors
                self.blockedGate = result.blocked
                if let blocked = result.blocked {
                    self.message = blocked.type == .humanVerification
                        ? "The site requires human verification. Complete it manually, then retry."
                        : "The site has an age/access gate. Complete it manually, then retry."
                } else if result.results.isEmpty {
                    self.message = "Scan finished. No matching media was found within the current limits."
                } else {
                    self.message = "Finished: \(result.results.count) matching page(s), \(result.scannedPages) page(s) scanned."
                }
            } catch is CancellationError {
                self.message = "Scan stopped."
            } catch {
                self.message = error.localizedDescription
            }
            self.isScanning = false
        }
    }

    func stop() {
        scanTask?.cancel()
        scanTask = nil
        isScanning = false
        message = "Scan stopped."
    }

    func openVerification() {
        guard siteURL != nil else { return }
        showVerification = true
    }

    func verificationCompleted() {
        Task {
            await CookieBridge.importWebKitCookiesIntoURLSession()
            blockedGate = nil
            start()
        }
    }

    func clearSession() {
        Task {
            await CookieBridge.clearAll()
            blockedGate = nil
            message = "Browser and scanner cookies cleared."
        }
    }
}
