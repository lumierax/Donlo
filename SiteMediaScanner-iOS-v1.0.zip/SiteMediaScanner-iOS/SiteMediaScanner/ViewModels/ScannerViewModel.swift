import Foundation
import SwiftUI

@MainActor
final class ScannerViewModel: ObservableObject {
    @Published var siteText = ""
    @Published var keyword = ""
    @Published var maxPages = 500
    @Published var maxDepth = 8
    @Published var maxResults = 250
    @Published var useSitemap = true
    @Published var respectRobots = true
    @Published var dynamicFallback = true

    @Published private(set) var isScanning = false
    @Published private(set) var progress = ScanProgress(scannedPages: 0, queuedPages: 0, foundResults: 0, currentURL: "")
    @Published private(set) var results: [PageMediaResult] = []
    @Published private(set) var errors: [ScanErrorItem] = []
    @Published private(set) var blockedGate: AccessGate?
    @Published var message: String?
    @Published var showVerification = false

    @Published private(set) var downloadingResultID: String?
    @Published private(set) var downloadingTitle: String?
    @Published private(set) var savedResultIDs: Set<String> = []
    @Published var downloadMessage: String?

    private var scanTask: Task<Void, Never>?
    private var downloadTask: Task<Void, Never>?

    var siteURL: URL? {
        var raw = siteText.trimmingCharacters(in: .whitespacesAndNewlines)
        if raw.isEmpty { return nil }
        if !raw.lowercased().hasPrefix("http://") && !raw.lowercased().hasPrefix("https://") { raw = "https://\(raw)" }
        guard let url = URL(string: raw) else { return nil }
        if url.scheme?.lowercased() == "http" {
            var components = URLComponents(url: url, resolvingAgainstBaseURL: false)
            components?.scheme = "https"
            return components?.url
        }
        return url
    }

    func start() {
        guard let url = siteURL else { message = "أدخل رابط موقع صالح."; return }
        guard !keyword.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { message = "أدخل كلمة البحث."; return }

        scanTask?.cancel()
        isScanning = true
        message = nil
        blockedGate = nil
        results = []
        errors = []
        progress = ScanProgress(scannedPages: 0, queuedPages: 0, foundResults: 0, currentURL: url.absoluteString)

        let options = ScanOptions(
            maxPages: maxPages,
            maxDepth: maxDepth,
            maxResults: maxResults,
            maxDynamicPages: 8,
            useSitemap: useSitemap,
            respectRobots: respectRobots,
            dynamicFallback: dynamicFallback,
            requestDelayMilliseconds: 120
        )

        scanTask = Task { [weak self] in
            guard let self else { return }
            await CookieBridge.importWebKitCookiesIntoURLSession()
            do {
                let result = try await SiteCrawler().search(siteURL: url, keyword: self.keyword, options: options, progress: { progress in
                    Task { @MainActor [weak self] in self?.progress = progress }
                }, onResult: { found in
                    Task { @MainActor [weak self] in self?.upsert(found) }
                })
                guard !Task.isCancelled else { return }
                self.errors = result.errors
                self.blockedGate = result.blocked
                if let blocked = result.blocked {
                    self.message = blocked.type == .humanVerification
                        ? "الموقع يطلب تحققًا بشريًا. أكمله يدويًا ثم أعد البحث."
                        : "الموقع يحتوي بوابة عمر/وصول. أكملها يدويًا ثم أعد البحث."
                } else if self.results.isEmpty {
                    self.message = "انتهى البحث ولم أجد فيديوهات تحمل الكلمة في عنوانها ضمن حدود المسح الحالية."
                } else {
                    self.message = "تم العثور على \(self.results.count) فيديو مطابق بعد فحص \(result.scannedPages) صفحة."
                }
            } catch is CancellationError {
                self.message = "تم إيقاف البحث."
            } catch {
                self.message = error.localizedDescription
            }
            self.isScanning = false
        }
    }

    /// Adds a result the moment it is found, or updates it (for example when its duration arrives).
    private func upsert(_ found: PageMediaResult) {
        if let index = results.firstIndex(where: { $0.id == found.id }) {
            let old = results[index]
            results[index] = PageMediaResult(
                pageURL: found.pageURL, title: found.title,
                durationSeconds: found.durationSeconds ?? old.durationSeconds,
                matchEvidence: found.matchEvidence, media: found.media
            )
        } else {
            results.append(found)
        }
    }

    func stop() {
        scanTask?.cancel()
        scanTask = nil
        isScanning = false
        message = "تم إيقاف البحث."
    }

    func download(_ result: PageMediaResult) {
        guard downloadingResultID == nil else { return }
        downloadMessage = nil
        downloadingResultID = result.id
        downloadingTitle = result.title

        downloadTask = Task { [weak self] in
            guard let self else { return }
            await CookieBridge.importWebKitCookiesIntoURLSession()
            do {
                let media = try await VideoLibrarySaver.saveBestVideo(from: result)
                guard !Task.isCancelled else { return }
                self.savedResultIDs.insert(result.id)
                let quality = media.resolution.map { " (\($0))" } ?? ""
                self.downloadMessage = "تم حفظ «\(result.title)»\(quality) في تطبيق الصور."
            } catch {
                self.downloadMessage = error.localizedDescription
            }
            self.downloadingResultID = nil
            self.downloadingTitle = nil
        }
    }

    func openVerification() {
        guard siteURL != nil else { return }
        showVerification = true
    }

    func verificationCompleted() {
        Task {
            await CookieBridge.importWebKitCookiesIntoURLSession()
            blockedGate = nil
            start()
        }
    }

    func clearSession() {
        Task {
            await CookieBridge.clearAll()
            blockedGate = nil
            message = "تم مسح جلسة المتصفح والكوكيز."
        }
    }
}
