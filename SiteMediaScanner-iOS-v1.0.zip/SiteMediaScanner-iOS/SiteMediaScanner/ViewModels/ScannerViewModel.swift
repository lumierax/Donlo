import Foundation
import SwiftUI

@MainActor
final class ScannerViewModel: ObservableObject {
    @Published var siteText = ""
    @Published var keyword = ""
    @Published var maxPages = 500
    @Published var maxDepth = 8
    @Published var maxResults = 250
    @Published var useSitemap = false
    @Published var respectRobots = true
    @Published var dynamicFallback = true

    @Published private(set) var isScanning = false
    @Published private(set) var progress = ScanProgress(scannedPages: 0, queuedPages: 0, foundResults: 0, currentURL: "")
    @Published private(set) var results: [PageMediaResult] = []
    @Published private(set) var errors: [ScanErrorItem] = []
    @Published private(set) var blockedGate: AccessGate?
    @Published var message: String?
    @Published var showVerification = false

    @Published private(set) var downloadingResultID: String?
    @Published private(set) var downloadingTitle: String?
    @Published private(set) var savedResultIDs: Set<String> = []
    @Published var downloadMessage: String?

    private var scanTask: Task<Void, Never>?
    private var downloadTask: Task<Void, Never>?
    private var ignoreHumanVerificationForNextScan = false

    var siteURL: URL? {
        var raw = siteText.trimmingCharacters(in: .whitespacesAndNewlines)
        if raw.isEmpty { return nil }
        if !raw.lowercased().hasPrefix("http://") && !raw.lowercased().hasPrefix("https://") { raw = "https://\(raw)" }
        guard let url = URL(string: raw) else { return nil }
        if url.scheme?.lowercased() == "http" {
            var components = URLComponents(url: url, resolvingAgainstBaseURL: false)
            components?.scheme = "https"
            return components?.url
        }
        return url
    }

    func start() {
        guard let url = siteURL else { message = "أدخل رابط موقع صالح."; return }
        guard !keyword.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { message = "أدخل كلمة البحث."; return }

        scanTask?.cancel()
        isScanning = true
        message = "جاري استخدام خانة البحث الخاصة بالموقع…"
        blockedGate = nil
        results = []
        errors = []
        progress = ScanProgress(scannedPages: 0, queuedPages: 0, foundResults: 0, currentURL: url.absoluteString)

        let options = ScanOptions(
            maxPages: maxPages,
            maxDepth: maxDepth,
            maxResults: maxResults,
            maxDynamicPages: 12,
            useSitemap: useSitemap,
            respectRobots: respectRobots,
            dynamicFallback: dynamicFallback,
            ignoreHumanVerificationGate: ignoreHumanVerificationForNextScan,
            requestDelayMilliseconds: 100
        )
        ignoreHumanVerificationForNextScan = false

        let searchKeyword = keyword
        scanTask = Task { [weak self] in
            guard let self else { return }
            await CookieBridge.importWebKitCookiesIntoURLSession()
            do {
                let result = try await SiteCrawler().search(
                    siteURL: url,
                    keyword: searchKeyword,
                    options: options,
                    progress: { progress in
                        await MainActor.run { [weak self] in
                            self?.progress = progress
                        }
                    },
                    resultFound: { found in
                        // Await the MainActor update. This guarantees that a result is
                        // visible before the crawler reports the next progress update.
                        await MainActor.run { [weak self] in
                            self?.upsertResult(found)
                        }
                    }
                )
                try Task.checkCancellation()
                for found in result.results { self.upsertResult(found) }
                self.errors = result.errors
                self.blockedGate = result.blocked
                if let blocked = result.blocked {
                    self.message = blocked.type == .humanVerification
                        ? "الموقع يطلب تحققًا بشريًا. أكمله يدويًا ثم أعد البحث."
                        : "الموقع يحتوي بوابة عمر/وصول. أكملها يدويًا ثم أعد البحث."
                } else if self.results.isEmpty {
                    self.message = result.note ?? "انتهى البحث ولم أجد فيديوهات تحمل الكلمة في عنوانها ضمن نتائج بحث الموقع."
                } else {
                    let suffix = result.note.map { " — \($0)" } ?? ""
                    self.message = "تم العثور على \(self.results.count) فيديو مطابق بعد فحص \(result.scannedPages) صفحة\(suffix)"
                }
            } catch is CancellationError {
                self.message = self.results.isEmpty
                    ? "تم إيقاف البحث."
                    : "تم إيقاف البحث. بقيت \(self.results.count) نتيجة متاحة ويمكن تحميلها الآن."
            } catch {
                self.message = error.localizedDescription
            }
            self.isScanning = false
            self.progress = ScanProgress(
                scannedPages: self.progress.scannedPages,
                queuedPages: self.progress.queuedPages,
                foundResults: self.results.count,
                currentURL: ""
            )
        }
    }

    func stop() {
        scanTask?.cancel()
        scanTask = nil
        isScanning = false
        progress = ScanProgress(
            scannedPages: progress.scannedPages,
            queuedPages: progress.queuedPages,
            foundResults: results.count,
            currentURL: ""
        )
        message = results.isEmpty
            ? "تم إيقاف البحث."
            : "تم إيقاف البحث. بقيت \(results.count) نتيجة متاحة ويمكن تحميلها الآن."
    }

    private func upsertResult(_ result: PageMediaResult) {
        if let index = results.firstIndex(where: { $0.id == result.id }) {
            results[index] = result
        } else {
            results.append(result)
        }
        progress = ScanProgress(
            scannedPages: progress.scannedPages,
            queuedPages: progress.queuedPages,
            foundResults: results.count,
            currentURL: progress.currentURL
        )
    }

    func download(_ result: PageMediaResult) {
        guard downloadingResultID == nil else { return }
        downloadMessage = nil
        downloadingResultID = result.id
        downloadingTitle = result.title

        downloadTask = Task { [weak self] in
            guard let self else { return }
            await CookieBridge.importWebKitCookiesIntoURLSession()
            do {
                let media = try await VideoLibrarySaver.saveBestVideo(from: result)
                try Task.checkCancellation()
                self.savedResultIDs.insert(result.id)
                let quality = media.resolution.map { " (\($0))" } ?? ""
                self.downloadMessage = "تم حفظ «\(result.title)»\(quality) في تطبيق الصور."
            } catch is CancellationError {
                self.downloadMessage = "تم إلغاء تحميل «\(result.title)»."
            } catch {
                self.downloadMessage = error.localizedDescription
            }
            self.downloadingResultID = nil
            self.downloadingTitle = nil
        }
    }

    func openVerification() {
        guard siteURL != nil else { return }
        showVerification = true
    }

    func continueAfterFalsePositive() {
        guard blockedGate?.type == .humanVerification else { return }
        blockedGate = nil
        message = "سيتم تجاهل إنذار التحقق في هذه المحاولة ومتابعة البحث."
        ignoreHumanVerificationForNextScan = true
        start()
    }

    func verificationCompleted() {
        Task {
            await CookieBridge.importWebKitCookiesIntoURLSession()
            blockedGate = nil
            start()
        }
    }

    func clearSession() {
        Task {
            await CookieBridge.clearAll()
            blockedGate = nil
            message = "تم مسح جلسة المتصفح والكوكيز."
        }
    }
}
