import Foundation

struct HTTPTextResponse: Sendable {
    let body: String
    let finalURL: URL
    let statusCode: Int
    let contentType: String
}

enum HTTPClientError: LocalizedError {
    case invalidResponse
    case badStatus(Int)
    case unsupportedContentType(String)

    var errorDescription: String? {
        switch self {
        case .invalidResponse: return "Invalid HTTP response."
        case .badStatus(let status): return "HTTP status \(status)."
        case .unsupportedContentType(let type): return "Unsupported content type: \(type)"
        }
    }
}

actor HTTPClient {
    private let session: URLSession
    private let userAgent = "SiteMediaScanner-iOS/1.0"
    private let maxBodyBytes = 8_000_000

    init() {
        let configuration = URLSessionConfiguration.default
        configuration.httpCookieStorage = HTTPCookieStorage.shared
        configuration.httpShouldSetCookies = true
        configuration.httpCookieAcceptPolicy = .always
        configuration.requestCachePolicy = .reloadIgnoringLocalCacheData
        configuration.timeoutIntervalForRequest = 20
        configuration.timeoutIntervalForResource = 30
        self.session = URLSession(configuration: configuration)
    }

    func fetchText(_ url: URL, timeout: TimeInterval = 20) async throws -> HTTPTextResponse {
        var request = URLRequest(url: url, timeoutInterval: timeout)
        request.httpMethod = "GET"
        request.setValue(userAgent, forHTTPHeaderField: "User-Agent")
        request.setValue("text/html,application/xhtml+xml,application/xml,text/xml,text/plain;q=0.9,*/*;q=0.2", forHTTPHeaderField: "Accept")
        request.setValue("gzip, deflate, br", forHTTPHeaderField: "Accept-Encoding")

        let (data, response) = try await session.data(for: request)
        guard let http = response as? HTTPURLResponse else { throw HTTPClientError.invalidResponse }
        guard (200...399).contains(http.statusCode) else { throw HTTPClientError.badStatus(http.statusCode) }

        let contentType = http.value(forHTTPHeaderField: "Content-Type") ?? ""
        let lower = contentType.lowercased()
        if !lower.isEmpty,
           !lower.contains("text/") && !lower.contains("html") && !lower.contains("xml") && !lower.contains("json") && !lower.contains("javascript") {
            throw HTTPClientError.unsupportedContentType(contentType)
        }

        let limited = data.prefix(maxBodyBytes)
        let body = String(data: limited, encoding: .utf8)
            ?? String(data: limited, encoding: .isoLatin1)
            ?? ""
        return HTTPTextResponse(body: body, finalURL: http.url ?? url, statusCode: http.statusCode, contentType: contentType)
    }
}
