import Foundation

enum BrowserIdentity {
    // Safari-compatible identity for iPhone on iOS 18. Using an app-specific
    // User-Agent makes some sites return an "unsupported browser" page.
    static let safariIOS18 = "Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Mobile/15E148 Safari/604.1"

    static func applyNavigationHeaders(to request: inout URLRequest) {
        request.setValue(safariIOS18, forHTTPHeaderField: "User-Agent")
        request.setValue("text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8", forHTTPHeaderField: "Accept")
        request.setValue("gzip, deflate, br", forHTTPHeaderField: "Accept-Encoding")
        request.setValue("en-US,en;q=0.9,ar;q=0.8", forHTTPHeaderField: "Accept-Language")
        request.setValue("1", forHTTPHeaderField: "Upgrade-Insecure-Requests")
    }
}

struct HTTPTextResponse: Sendable {
    let body: String
    let finalURL: URL
    let statusCode: Int
    let contentType: String
}

enum HTTPClientError: LocalizedError {
    case invalidResponse
    case badStatus(Int)
    case unsupportedContentType(String)

    var errorDescription: String? {
        switch self {
        case .invalidResponse: return "Invalid HTTP response."
        case .badStatus(let status): return "HTTP status \(status)."
        case .unsupportedContentType(let type): return "Unsupported content type: \(type)"
        }
    }
}

actor HTTPClient {
    private let session: URLSession
    private let maxBodyBytes = 8_000_000

    init() {
        let configuration = URLSessionConfiguration.default
        configuration.httpCookieStorage = HTTPCookieStorage.shared
        configuration.httpShouldSetCookies = true
        configuration.httpCookieAcceptPolicy = .always
        configuration.requestCachePolicy = .reloadIgnoringLocalCacheData
        configuration.timeoutIntervalForRequest = 20
        configuration.timeoutIntervalForResource = 30
        self.session = URLSession(configuration: configuration)
    }

    func fetchText(_ url: URL, timeout: TimeInterval = 20) async throws -> HTTPTextResponse {
        var request = URLRequest(url: url, timeoutInterval: timeout)
        request.httpMethod = "GET"
        configureHeaders(&request)
        return try await perform(request)
    }

    func submitSearch(_ search: SiteSearchRequest, timeout: TimeInterval = 20) async throws -> HTTPTextResponse {
        var requestURL = search.actionURL

        if search.method == .get {
            guard var components = URLComponents(url: search.actionURL, resolvingAgainstBaseURL: true) else {
                throw HTTPClientError.invalidResponse
            }
            var items = components.queryItems ?? []
            let names = Set(search.fields.map { $0.name })
            items.removeAll { names.contains($0.name) }
            items.append(contentsOf: search.fields.map { URLQueryItem(name: $0.name, value: $0.value) })
            components.queryItems = items
            if let url = components.url { requestURL = url }
        }

        var request = URLRequest(url: requestURL, timeoutInterval: timeout)
        request.httpMethod = search.method.rawValue
        configureHeaders(&request)

        if search.method == .post {
            var components = URLComponents()
            components.queryItems = search.fields.map { URLQueryItem(name: $0.name, value: $0.value) }
            request.httpBody = components.percentEncodedQuery?.data(using: .utf8)
            request.setValue("application/x-www-form-urlencoded; charset=utf-8", forHTTPHeaderField: "Content-Type")
        }

        return try await perform(request)
    }

    private func configureHeaders(_ request: inout URLRequest) {
        BrowserIdentity.applyNavigationHeaders(to: &request)
    }

    private func perform(_ request: URLRequest) async throws -> HTTPTextResponse {
        let (data, response) = try await session.data(for: request)
        guard let http = response as? HTTPURLResponse else { throw HTTPClientError.invalidResponse }
        guard (200...399).contains(http.statusCode) else { throw HTTPClientError.badStatus(http.statusCode) }

        let contentType = http.value(forHTTPHeaderField: "Content-Type") ?? ""
        let lower = contentType.lowercased()
        if !lower.isEmpty,
           !lower.contains("text/") && !lower.contains("html") && !lower.contains("xml") && !lower.contains("json") && !lower.contains("javascript") {
            throw HTTPClientError.unsupportedContentType(contentType)
        }

        let limited = data.prefix(maxBodyBytes)
        let body = String(data: limited, encoding: .utf8)
            ?? String(data: limited, encoding: .isoLatin1)
            ?? ""
        return HTTPTextResponse(body: body, finalURL: http.url ?? request.url!, statusCode: http.statusCode, contentType: contentType)
    }
}
