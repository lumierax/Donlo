import SwiftUI

@main
struct SiteMediaScannerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
