import SwiftUI
import UIKit

struct ResultDetailView: View {
    let result: PageMediaResult
    let onDownload: () -> Void
    @State private var copiedURL: String?

    var body: some View {
        List {
            Section("الفيديو") {
                Text(result.title)
                    .font(.headline)
                LabeledContent("المدة", value: result.formattedDuration)
                if let url = URL(string: result.pageURL) {
                    Link("فتح صفحة الفيديو", destination: url)
                }
                Button(action: onDownload) {
                    Label("تحميل أفضل جودة إلى الصور", systemImage: "square.and.arrow.down")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)
                .controlSize(.large)
            }

            Section("الجودات والمصادر") {
                ForEach(result.media) { item in
                    VStack(alignment: .leading, spacing: 7) {
                        HStack {
                            Text(item.resolution ?? item.kind.rawValue.uppercased())
                                .font(.headline)
                            Spacer()
                            Text(item.kind.rawValue.uppercased())
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                        Text(item.url)
                            .font(.caption2)
                            .textSelection(.enabled)
                            .lineLimit(3)
                        HStack {
                            Button(copiedURL == item.url ? "تم النسخ" : "نسخ الرابط") {
                                UIPasteboard.general.string = item.url
                                copiedURL = item.url
                            }
                            .buttonStyle(.bordered)

                            if let url = URL(string: item.url) {
                                Link("فتح", destination: url)
                                    .buttonStyle(.bordered)
                            }
                        }
                    }
                    .padding(.vertical, 4)
                }
            }
        }
        .navigationTitle("تفاصيل الفيديو")
        .navigationBarTitleDisplayMode(.inline)
    }
}
