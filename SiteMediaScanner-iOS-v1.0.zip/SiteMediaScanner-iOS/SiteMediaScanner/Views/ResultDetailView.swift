import SwiftUI
import UIKit

struct ResultDetailView: View {
    let result: PageMediaResult
    @State private var copiedURL: String?

    var body: some View {
        List {
            Section("Page") {
                Text(result.title)
                if let url = URL(string: result.pageURL) {
                    Link(result.pageURL, destination: url)
                        .font(.caption)
                }
                Text("Matched: \(result.matchEvidence.joined(separator: ", "))")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            Section("Media") {
                ForEach(result.media) { item in
                    VStack(alignment: .leading, spacing: 7) {
                        HStack {
                            Text(item.resolution ?? item.kind.rawValue.uppercased())
                                .font(.headline)
                            Spacer()
                            Text(item.kind.rawValue.uppercased())
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                        Text(item.url)
                            .font(.caption2)
                            .textSelection(.enabled)
                        HStack {
                            Button(copiedURL == item.url ? "Copied" : "Copy") {
                                UIPasteboard.general.string = item.url
                                copiedURL = item.url
                            }
                            .buttonStyle(.bordered)

                            if let url = URL(string: item.url) {
                                Link("Open", destination: url)
                                    .buttonStyle(.bordered)
                                ShareLink(item: url) {
                                    Text("Share")
                                }
                                .buttonStyle(.bordered)
                            }
                        }
                        Text("Found by: \(item.discoveredBy)\(item.evidence.map { " • \($0)" } ?? "")")
                            .font(.caption2)
                            .foregroundStyle(.tertiary)
                    }
                    .padding(.vertical, 4)
                }
            }
        }
        .navigationTitle("Media")
        .navigationBarTitleDisplayMode(.inline)
    }
}
