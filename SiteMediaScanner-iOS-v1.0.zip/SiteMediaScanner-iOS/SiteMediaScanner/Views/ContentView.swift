import SwiftUI

struct ContentView: View {
    @StateObject private var model = ScannerViewModel()

    var body: some View {
        NavigationStack {
            Form {
                Section("Search inside a site") {
                    TextField("https://example.com", text: $model.siteText)
                        .keyboardType(.URL)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                    TextField("Search word or phrase", text: $model.keyword)
                        .textInputAutocapitalization(.never)

                    if model.isScanning {
                        Button("Stop scan", role: .destructive) { model.stop() }
                    } else {
                        Button("Scan site") { model.start() }
                            .disabled(model.siteText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || model.keyword.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                    }
                }

                Section("Scan limits") {
                    Stepper("Maximum pages: \(model.maxPages)", value: $model.maxPages, in: 10...3000, step: 10)
                    Stepper("Maximum depth: \(model.maxDepth)", value: $model.maxDepth, in: 1...20)
                    Stepper("Maximum results: \(model.maxResults)", value: $model.maxResults, in: 1...500)
                    Toggle("Use sitemap.xml", isOn: $model.useSitemap)
                    Toggle("Respect robots.txt", isOn: $model.respectRobots)
                    Toggle("Dynamic WKWebView fallback", isOn: $model.dynamicFallback)
                }

                if model.isScanning || model.progress.scannedPages > 0 {
                    Section("Progress") {
                        if model.isScanning { ProgressView() }
                        LabeledContent("Scanned", value: "\(model.progress.scannedPages)")
                        LabeledContent("Queued", value: "\(model.progress.queuedPages)")
                        LabeledContent("Found", value: "\(model.progress.foundResults)")
                        if !model.progress.currentURL.isEmpty {
                            Text(model.progress.currentURL)
                                .font(.caption)
                                .foregroundStyle(.secondary)
                                .textSelection(.enabled)
                                .lineLimit(3)
                        }
                    }
                }

                if let gate = model.blockedGate {
                    Section("Site access required") {
                        Text(gate.type == .humanVerification
                             ? "Human verification was detected. The app does not bypass CAPTCHA or anti-bot checks."
                             : "An age/access gate was detected. Open the site, complete it yourself, and the scanner can reuse that authorized session.")
                        Button("Open site verification") { model.openVerification() }
                        Button("Clear saved session", role: .destructive) { model.clearSession() }
                    }
                }

                if let message = model.message {
                    Section {
                        Text(message).foregroundStyle(.secondary)
                    }
                }

                if !model.results.isEmpty {
                    Section("Results (\(model.results.count))") {
                        ForEach(model.results) { result in
                            NavigationLink {
                                ResultDetailView(result: result)
                            } label: {
                                VStack(alignment: .leading, spacing: 5) {
                                    Text(result.title.isEmpty ? "Untitled page" : result.title)
                                        .font(.headline)
                                        .lineLimit(2)
                                    Text("\(result.media.count) media URL(s)")
                                        .font(.subheadline)
                                        .foregroundStyle(.secondary)
                                    Text(result.pageURL)
                                        .font(.caption2)
                                        .foregroundStyle(.tertiary)
                                        .lineLimit(1)
                                }
                            }
                        }
                    }
                }

                if !model.errors.isEmpty {
                    Section("Skipped / errors") {
                        DisclosureGroup("Show \(model.errors.count) item(s)") {
                            ForEach(model.errors.prefix(25)) { item in
                                VStack(alignment: .leading, spacing: 3) {
                                    Text(item.message).font(.caption)
                                    Text(item.url).font(.caption2).foregroundStyle(.secondary).lineLimit(2)
                                }
                            }
                        }
                    }
                }

                Section {
                    Text("The scanner only discovers URLs exposed to the browser/session. It does not bypass DRM, paywalls, login controls, CAPTCHA, or anti-bot protections.")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
            .navigationTitle("Site Media Scanner")
            .sheet(isPresented: $model.showVerification) {
                if let url = model.siteURL {
                    VerificationSheet(url: url, onDone: model.verificationCompleted)
                }
            }
        }
    }
}
