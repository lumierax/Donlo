import SwiftUI

struct ContentView: View {
    @StateObject private var model = ScannerViewModel()
    @State private var showAdvanced = false

    var body: some View {
        NavigationStack {
            List {
                searchSection
                progressSection
                accessSection
                statusSection
                resultsSection
                advancedSection
                errorsSection
                footerSection
            }
            .listStyle(.insetGrouped)
            .navigationTitle("ماسح الفيديو")
            .navigationBarTitleDisplayMode(.large)
            .sheet(isPresented: $model.showVerification) {
                if let url = model.siteURL {
                    VerificationSheet(url: url, onDone: model.verificationCompleted)
                }
            }
        }
    }

    private var searchSection: some View {
        Section {
            VStack(alignment: .leading, spacing: 14) {
                Text("اكتب الموقع وكلمة البحث")
                    .font(.headline)

                TextField("example.com", text: $model.siteText)
                    .keyboardType(.URL)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    .textFieldStyle(.roundedBorder)

                TextField("كلمة موجودة في عنوان الفيديو", text: $model.keyword)
                    .textInputAutocapitalization(.never)
                    .textFieldStyle(.roundedBorder)

                if model.isScanning {
                    Button(role: .destructive) { model.stop() } label: {
                        Label("إيقاف البحث", systemImage: "stop.fill")
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.borderedProminent)
                    .controlSize(.large)
                } else {
                    Button { model.start() } label: {
                        Label("ابحث عن الفيديوهات", systemImage: "magnifyingglass")
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.borderedProminent)
                    .controlSize(.large)
                    .disabled(model.siteText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || model.keyword.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                }
            }
            .padding(.vertical, 4)
        }
    }

    @ViewBuilder
    private var progressSection: some View {
        if model.isScanning || model.progress.scannedPages > 0 {
            Section("تقدم البحث") {
                if model.isScanning {
                    ProgressView("جاري البحث داخل الموقع…")
                }
                HStack {
                    stat("تم الفحص", value: model.progress.scannedPages)
                    Spacer()
                    stat("بالانتظار", value: model.progress.queuedPages)
                    Spacer()
                    stat("الفيديوهات", value: model.progress.foundResults)
                }
                if !model.progress.currentURL.isEmpty && model.isScanning {
                    Text(model.progress.currentURL)
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                        .lineLimit(2)
                }
            }
        }
    }

    @ViewBuilder
    private var accessSection: some View {
        if let gate = model.blockedGate {
            Section("يحتاج الموقع إلى موافقة") {
                Text(gate.type == .humanVerification
                     ? "ظهر تحقق بشري. افتح الصفحة وأكمل التحقق بنفسك، ثم سيستخدم التطبيق الجلسة المصرح بها."
                     : "ظهرت بوابة عمر أو وصول. افتحها ووافق بنفسك ثم أكمل البحث.")
                Button("فتح صفحة التحقق") { model.openVerification() }
                Button("مسح الجلسة المحفوظة", role: .destructive) { model.clearSession() }
            }
        }
    }

    @ViewBuilder
    private var statusSection: some View {
        if let message = model.message {
            Section {
                Text(message).foregroundStyle(.secondary)
            }
        }
        if let downloadMessage = model.downloadMessage {
            Section {
                Label(downloadMessage, systemImage: model.savedResultIDs.isEmpty ? "info.circle" : "checkmark.circle.fill")
                    .foregroundStyle(model.savedResultIDs.isEmpty ? Color.secondary : Color.green)
            }
        }
        if let title = model.downloadingTitle {
            Section {
                HStack(spacing: 12) {
                    ProgressView()
                    VStack(alignment: .leading, spacing: 3) {
                        Text("جاري التحميل إلى الصور")
                            .font(.headline)
                        Text(title)
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                            .lineLimit(2)
                    }
                }
            }
        }
    }

    @ViewBuilder
    private var resultsSection: some View {
        if !model.results.isEmpty {
            Section("النتائج (\(model.results.count))") {
                ForEach(model.results) { result in
                    VStack(alignment: .leading, spacing: 10) {
                        NavigationLink {
                            ResultDetailView(result: result, onDownload: { model.download(result) })
                        } label: {
                            VStack(alignment: .leading, spacing: 7) {
                                Text(result.title)
                                    .font(.headline)
                                    .foregroundStyle(.primary)
                                    .lineLimit(3)

                                HStack(spacing: 14) {
                                    Label(result.formattedDuration, systemImage: "clock")
                                    Label("\(result.media.count) مصدر", systemImage: "film")
                                }
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                            }
                        }

                        Button {
                            model.download(result)
                        } label: {
                            if model.savedResultIDs.contains(result.id) {
                                Label("تم الحفظ في الصور", systemImage: "checkmark.circle.fill")
                                    .frame(maxWidth: .infinity)
                            } else if model.downloadingResultID == result.id {
                                HStack {
                                    ProgressView()
                                    Text("جاري تحميل هذا الفيديو…")
                                }
                                .frame(maxWidth: .infinity)
                            } else {
                                Label("تحميل إلى تطبيق الصور", systemImage: "square.and.arrow.down")
                                    .frame(maxWidth: .infinity)
                            }
                        }
                        .buttonStyle(.borderedProminent)
                        .controlSize(.large)
                        .disabled(model.downloadingResultID != nil || model.savedResultIDs.contains(result.id))
                    }
                    .padding(.vertical, 6)
                }
            }
        }
    }

    private var advancedSection: some View {
        Section {
            DisclosureGroup("إعدادات البحث المتقدمة", isExpanded: $showAdvanced) {
                Stepper("أقصى عدد صفحات: \(model.maxPages)", value: $model.maxPages, in: 20...5000, step: 20)
                Stepper("عمق التصفح: \(model.maxDepth)", value: $model.maxDepth, in: 1...20)
                Stepper("أقصى عدد نتائج: \(model.maxResults)", value: $model.maxResults, in: 1...1000)
                Toggle("استخدام sitemap.xml", isOn: $model.useSitemap)
                Toggle("احترام robots.txt", isOn: $model.respectRobots)
                Toggle("استخدام WKWebView عند الحاجة", isOn: $model.dynamicFallback)
            }
        }
    }

    @ViewBuilder
    private var errorsSection: some View {
        if !model.errors.isEmpty {
            Section("صفحات تم تجاوزها") {
                DisclosureGroup("عرض \(model.errors.count) عنصر") {
                    ForEach(model.errors.prefix(25)) { item in
                        VStack(alignment: .leading, spacing: 3) {
                            Text(item.message).font(.caption)
                            Text(item.url).font(.caption2).foregroundStyle(.secondary).lineLimit(2)
                        }
                    }
                }
            }
        }
    }

    private var footerSection: some View {
        Section {
            Text("يعرض التطبيق الصفحات التي تحتوي كلمة البحث في عنوان الفيديو، ويستخرج المدة عندما تكون متاحة في بيانات الصفحة أو ملف الوسائط. الحفظ إلى الصور يعمل للمصادر القابلة للتنزيل وغير المحمية بـ DRM.")
                .font(.caption)
                .foregroundStyle(.secondary)
        }
    }

    private func stat(_ title: String, value: Int) -> some View {
        VStack(spacing: 3) {
            Text("\(value)").font(.headline).monospacedDigit()
            Text(title).font(.caption).foregroundStyle(.secondary)
        }
    }
}
