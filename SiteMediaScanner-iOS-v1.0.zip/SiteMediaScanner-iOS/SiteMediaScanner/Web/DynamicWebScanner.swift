import Foundation
import WebKit

@MainActor
final class DynamicWebScanner {
    enum DynamicError: LocalizedError {
        case loadTimedOut
        case invalidJavaScriptResult

        var errorDescription: String? {
            switch self {
            case .loadTimedOut: return "Dynamic page load timed out."
            case .invalidJavaScriptResult: return "Could not inspect dynamic page resources."
            }
        }
    }

    /// Loads the page in WKWebView (JavaScript on) and returns the rendered HTML. Used for JS-driven search results.
    func renderedHTML(url: URL, timeoutSeconds: Double = 12, settleSeconds: Double = 2.0) async throws -> String {
        let webView = WKWebView(frame: CGRect(x: 0, y: 0, width: 390, height: 844), configuration: BrowserProfile.makeConfiguration())
        webView.customUserAgent = BrowserProfile.userAgent
        webView.load(URLRequest(url: url, timeoutInterval: timeoutSeconds))
        let deadline = Date().addingTimeInterval(timeoutSeconds)
        while webView.isLoading && Date() < deadline {
            try Task.checkCancellation()
            try await Task.sleep(nanoseconds: 200_000_000)
        }
        if webView.isLoading { webView.stopLoading(); throw DynamicError.loadTimedOut }
        try await Task.sleep(nanoseconds: UInt64(settleSeconds * 1_000_000_000))
        let value: Any? = try await withCheckedThrowingContinuation { continuation in
            webView.evaluateJavaScript("document.documentElement.outerHTML") { result, error in
                if let error { continuation.resume(throwing: error) } else { continuation.resume(returning: result) }
            }
        }
        guard let html = value as? String else { throw DynamicError.invalidJavaScriptResult }
        return html
    }

    func scan(url: URL, timeoutSeconds: Double = 12) async throws -> [MediaItem] {
        let configuration = WKWebViewConfiguration()
        configuration.websiteDataStore = .default()
        configuration.defaultWebpagePreferences.allowsContentJavaScript = true

        let webView = WKWebView(frame: .zero, configuration: configuration)
        webView.customUserAgent = BrowserProfile.userAgent
        webView.load(URLRequest(url: url, timeoutInterval: timeoutSeconds))

        let deadline = Date().addingTimeInterval(timeoutSeconds)
        while webView.isLoading && Date() < deadline {
            try Task.checkCancellation()
            try await Task.sleep(nanoseconds: 200_000_000)
        }
        if webView.isLoading {
            webView.stopLoading()
            throw DynamicError.loadTimedOut
        }

        try await Task.sleep(nanoseconds: 700_000_000)
        let script = #"""
        (() => {
          const out = new Set();
          const add = (v) => { if (typeof v === 'string' && v.length > 3) out.add(v); };
          document.querySelectorAll('video,audio,source').forEach(el => {
            add(el.currentSrc); add(el.src); add(el.getAttribute('src'));
          });
          document.querySelectorAll('[data-src],[data-file],[data-url]').forEach(el => {
            add(el.getAttribute('data-src')); add(el.getAttribute('data-file')); add(el.getAttribute('data-url'));
          });
          try { performance.getEntriesByType('resource').forEach(e => add(e.name)); } catch (_) {}
          return Array.from(out).slice(0, 1500);
        })();
        """#

        let value: Any? = try await withCheckedThrowingContinuation { continuation in
            webView.evaluateJavaScript(script) { result, error in
                if let error { continuation.resume(throwing: error) }
                else { continuation.resume(returning: result) }
            }
        }
        guard let urls = value as? [String] else { throw DynamicError.invalidJavaScriptResult }

        var items: [MediaItem] = []
        for raw in urls {
            if let item = MediaExtractor.makeItem(raw: raw, baseURL: url, discoveredBy: "wkwebview", evidence: "dom-or-resource") {
                items.append(item)
            }
        }
        return MediaExtractor.deduplicated(items)
    }
}
