import Foundation
import WebKit

@MainActor
final class DynamicWebScanner {
    enum DynamicError: LocalizedError {
        case loadTimedOut
        case invalidJavaScriptResult

        var errorDescription: String? {
            switch self {
            case .loadTimedOut: return "Dynamic page load timed out."
            case .invalidJavaScriptResult: return "Could not inspect the dynamic page."
            }
        }
    }

    /// Renders a page with the system WebKit engine and returns the final DOM HTML.
    /// This is used when a site serves a simplified/unsupported-browser page to URLSession.
    func renderPage(url: URL, timeoutSeconds: Double = 14) async throws -> HTTPTextResponse {
        let webView = makeWebView()
        try await load(webView: webView, url: url, timeoutSeconds: timeoutSeconds)
        try await settle(milliseconds: 650)
        return try await snapshot(webView: webView, fallbackURL: url)
    }

    /// Uses the site's actual rendered search field. This supports ordinary HTML forms
    /// and many JavaScript/SPA search boxes that cannot be submitted with URLSession alone.
    func searchSite(url: URL, keyword: String, timeoutSeconds: Double = 16) async throws -> HTTPTextResponse? {
        let webView = makeWebView()
        try await load(webView: webView, url: url, timeoutSeconds: timeoutSeconds)

        let literal = try javaScriptStringLiteral(keyword)
        let searchScript = #"""
        (() => {
          const keyword = \#(literal);
          const visible = (el) => {
            if (!el) return false;
            const s = window.getComputedStyle(el);
            const r = el.getBoundingClientRect();
            return s.display !== 'none' && s.visibility !== 'hidden' && r.width > 3 && r.height > 3;
          };
          const score = (el) => {
            const type = (el.getAttribute('type') || '').toLowerCase();
            const name = (el.getAttribute('name') || '').toLowerCase();
            const id = (el.id || '').toLowerCase();
            const role = (el.getAttribute('role') || '').toLowerCase();
            const ph = (el.getAttribute('placeholder') || '').toLowerCase();
            const aria = (el.getAttribute('aria-label') || '').toLowerCase();
            const blob = `${name} ${id} ${role} ${ph} ${aria}`;
            let n = 0;
            if (type === 'search') n += 220;
            if (role === 'searchbox') n += 180;
            if (/^(q|s|query|search|keyword|keywords|term|k)$/.test(name)) n += 170;
            if (/(search|query|keyword|find|بحث|ابحث)/i.test(blob)) n += 130;
            if (el.closest('form[role="search"]')) n += 120;
            if (el.closest('header,nav')) n += 20;
            return n;
          };

          const inputs = Array.from(document.querySelectorAll(
            'input[type="search"], input:not([type]), input[type="text"], textarea, [contenteditable="true"]'
          )).filter(visible).sort((a,b) => score(b) - score(a));

          const input = inputs.find(el => score(el) > 0);
          if (!input) {
            const trigger = Array.from(document.querySelectorAll(
              'button,a,[role="button"]'
            )).filter(visible).find(el => {
              const blob = `${el.getAttribute('aria-label') || ''} ${el.getAttribute('title') || ''} ${el.id || ''} ${el.className || ''} ${el.textContent || ''}`;
              return /(search|find|بحث|ابحث)/i.test(blob);
            });
            if (trigger && typeof trigger.click === 'function') {
              trigger.click();
              return { found: false, submitted: false, opened: true };
            }
            return { found: false, submitted: false, opened: false };
          }

          input.focus();
          if (input.isContentEditable) {
            input.textContent = keyword;
          } else {
            const proto = input.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
            const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
            if (setter) setter.call(input, keyword); else input.value = keyword;
          }
          input.dispatchEvent(new Event('input', { bubbles: true }));
          input.dispatchEvent(new Event('change', { bubbles: true }));

          const form = input.form || input.closest('form');
          if (form) {
            const submitter = form.querySelector('button[type="submit"],input[type="submit"],button:not([type])');
            try {
              if (typeof form.requestSubmit === 'function') {
                submitter ? form.requestSubmit(submitter) : form.requestSubmit();
                return { found: true, submitted: true };
              }
            } catch (_) {}
            if (submitter && typeof submitter.click === 'function') {
              submitter.click();
              return { found: true, submitted: true };
            }
            try {
              form.submit();
              return { found: true, submitted: true };
            } catch (_) {}
          }

          const container = input.closest('[role="search"],header,nav,div') || input.parentElement;
          const button = container?.querySelector?.(
            'button[type="submit"],button[aria-label*="search" i],button[title*="search" i],[role="button"][aria-label*="search" i]'
          );
          if (button && visible(button)) {
            button.click();
            return { found: true, submitted: true };
          }

          // Last resort for JS search components that listen to Enter on the field.
          for (const type of ['keydown','keypress','keyup']) {
            input.dispatchEvent(new KeyboardEvent(type, {
              key: 'Enter', code: 'Enter', keyCode: 13, which: 13,
              bubbles: true, cancelable: true
            }));
          }
          return { found: true, submitted: true };
        })();
        """#

        var outcome = try await evaluate(searchScript, in: webView)
        var dict = outcome as? [String: Any]
        if dict?["found"] as? Bool != true, dict?["opened"] as? Bool == true {
            try await settle(milliseconds: 450)
            outcome = try await evaluate(searchScript, in: webView)
            dict = outcome as? [String: Any]
        }
        guard dict?["found"] as? Bool == true else {
            return nil
        }

        let startURL = webView.url?.absoluteString ?? url.absoluteString
        let deadline = Date().addingTimeInterval(timeoutSeconds)
        var sawNavigation = false
        var quietTicks = 0

        while Date() < deadline {
            try Task.checkCancellation()
            let currentURL = webView.url?.absoluteString ?? startURL
            if currentURL != startURL || webView.isLoading { sawNavigation = true }

            if sawNavigation {
                if webView.isLoading {
                    quietTicks = 0
                } else {
                    quietTicks += 1
                    if quietTicks >= 3 { break }
                }
            } else {
                // SPA search often changes the DOM without changing location/isLoading.
                quietTicks += 1
                if quietTicks >= 8 { break }
            }
            try await Task.sleep(nanoseconds: 250_000_000)
        }

        try await settle(milliseconds: 500)
        return try await snapshot(webView: webView, fallbackURL: url)
    }

    func scan(url: URL, timeoutSeconds: Double = 12) async throws -> [MediaItem] {
        let webView = makeWebView()
        try await load(webView: webView, url: url, timeoutSeconds: timeoutSeconds)
        try await settle(milliseconds: 700)

        let script = #"""
        (() => {
          const out = new Set();
          const add = (v) => { if (typeof v === 'string' && v.length > 3) out.add(v); };
          document.querySelectorAll('video,audio,source').forEach(el => {
            add(el.currentSrc); add(el.src); add(el.getAttribute('src'));
          });
          document.querySelectorAll('[data-src],[data-file],[data-url]').forEach(el => {
            add(el.getAttribute('data-src')); add(el.getAttribute('data-file')); add(el.getAttribute('data-url'));
          });
          try { performance.getEntriesByType('resource').forEach(e => add(e.name)); } catch (_) {}
          return Array.from(out).slice(0, 1500);
        })();
        """#

        let value = try await evaluate(script, in: webView)
        guard let urls = value as? [String] else { throw DynamicError.invalidJavaScriptResult }

        let baseURL = webView.url ?? url
        var items: [MediaItem] = []
        for raw in urls {
            if let item = MediaExtractor.makeItem(raw: raw, baseURL: baseURL, discoveredBy: "wkwebview", evidence: "dom-or-resource") {
                items.append(item)
            }
        }
        return MediaExtractor.deduplicated(items)
    }

    private func makeWebView() -> WKWebView {
        let configuration = WKWebViewConfiguration()
        configuration.websiteDataStore = .default()
        configuration.defaultWebpagePreferences.allowsContentJavaScript = true
        let webView = WKWebView(frame: CGRect(x: 0, y: 0, width: 390, height: 844), configuration: configuration)
        webView.customUserAgent = BrowserIdentity.safariIOS18
        return webView
    }

    private func load(webView: WKWebView, url: URL, timeoutSeconds: Double) async throws {
        var request = URLRequest(url: url, timeoutInterval: timeoutSeconds)
        BrowserIdentity.applyNavigationHeaders(to: &request)
        webView.load(request)

        let deadline = Date().addingTimeInterval(timeoutSeconds)
        var beganLoading = false
        while Date() < deadline {
            try Task.checkCancellation()
            if webView.isLoading { beganLoading = true }
            if beganLoading && !webView.isLoading { return }
            if !beganLoading, webView.url != nil, !webView.isLoading { return }
            try await Task.sleep(nanoseconds: 150_000_000)
        }
        webView.stopLoading()
        throw DynamicError.loadTimedOut
    }

    private func snapshot(webView: WKWebView, fallbackURL: URL) async throws -> HTTPTextResponse {
        let htmlValue = try await evaluate("document.documentElement ? document.documentElement.outerHTML : ''", in: webView)
        guard let html = htmlValue as? String else { throw DynamicError.invalidJavaScriptResult }
        return HTTPTextResponse(
            body: html,
            finalURL: webView.url ?? fallbackURL,
            statusCode: 200,
            contentType: "text/html; rendered=wkwebview"
        )
    }

    private func evaluate(_ script: String, in webView: WKWebView) async throws -> Any? {
        try await withCheckedThrowingContinuation { continuation in
            webView.evaluateJavaScript(script) { result, error in
                if let error { continuation.resume(throwing: error) }
                else { continuation.resume(returning: result) }
            }
        }
    }

    private func settle(milliseconds: UInt64) async throws {
        try Task.checkCancellation()
        try await Task.sleep(nanoseconds: milliseconds * 1_000_000)
    }

    private func javaScriptStringLiteral(_ value: String) throws -> String {
        let data = try JSONSerialization.data(withJSONObject: value, options: [.fragmentsAllowed])
        guard let literal = String(data: data, encoding: .utf8) else {
            throw DynamicError.invalidJavaScriptResult
        }
        return literal
    }
}
