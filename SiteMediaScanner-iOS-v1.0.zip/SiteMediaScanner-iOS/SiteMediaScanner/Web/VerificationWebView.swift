import SwiftUI
import WebKit

/// One shared "Safari on iPhone" identity. Cloudflare/hCaptcha/reCAPTCHA clearance cookies are
/// bound to the User-Agent, so the verification web view, the scanner and the downloader must all use the same one.
enum BrowserProfile {
    static let userAgent = "Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Mobile/15E148 Safari/604.1"

    @MainActor
    static func makeConfiguration() -> WKWebViewConfiguration {
        let configuration = WKWebViewConfiguration()
        configuration.websiteDataStore = .default()
        configuration.allowsInlineMediaPlayback = true
        configuration.defaultWebpagePreferences.allowsContentJavaScript = true
        configuration.defaultWebpagePreferences.preferredContentMode = .mobile
        configuration.preferences.javaScriptCanOpenWindowsAutomatically = true
        return configuration
    }
}

struct VerificationWebView: UIViewRepresentable {
    let url: URL
    @Binding var reloadToken: Int

    func makeCoordinator() -> Coordinator { Coordinator() }

    func makeUIView(context: Context) -> WKWebView {
        let configuration = BrowserProfile.makeConfiguration()

        // Add a mobile viewport only when the page has none, so wide pages fit the iPhone 12 screen.
        let viewportScript = WKUserScript(source: """
        (function () {
          if (!document.querySelector('meta[name=viewport]')) {
            var m = document.createElement('meta');
            m.name = 'viewport';
            m.content = 'width=device-width, initial-scale=1, viewport-fit=cover';
            (document.head || document.documentElement).appendChild(m);
          }
        })();
        """, injectionTime: .atDocumentStart, forMainFrameOnly: true)
        configuration.userContentController.addUserScript(viewportScript)

        let webView = WKWebView(frame: .zero, configuration: configuration)
        webView.customUserAgent = BrowserProfile.userAgent
        webView.uiDelegate = context.coordinator
        webView.navigationDelegate = context.coordinator
        webView.allowsBackForwardNavigationGestures = true
        webView.scrollView.contentInsetAdjustmentBehavior = .always
        webView.scrollView.keyboardDismissMode = .interactive
        context.coordinator.lastReloadToken = reloadToken
        webView.load(URLRequest(url: url))
        return webView
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {
        if context.coordinator.lastReloadToken != reloadToken {
            context.coordinator.lastReloadToken = reloadToken
            uiView.load(URLRequest(url: url))
        }
    }

    final class Coordinator: NSObject, WKUIDelegate, WKNavigationDelegate {
        var lastReloadToken = 0

        // Captcha widgets often open a popup; load it in the same view instead of dropping it.
        func webView(_ webView: WKWebView,
                     createWebViewWith configuration: WKWebViewConfiguration,
                     for navigationAction: WKNavigationAction,
                     windowFeatures: WKWindowFeatures) -> WKWebView? {
            if navigationAction.targetFrame == nil || navigationAction.targetFrame?.isMainFrame == false {
                webView.load(navigationAction.request)
            }
            return nil
        }
    }
}

struct VerificationSheet: View {
    let url: URL
    let onDone: () -> Void
    @Environment(\.dismiss) private var dismiss
    @Environment(\.openURL) private var openURL
    @State private var reloadToken = 0

    var body: some View {
        NavigationStack {
            // No ignoresSafeArea: the page stays inside the visible iPhone screen.
            VerificationWebView(url: url, reloadToken: $reloadToken)
                .navigationTitle("Site verification")
                .navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .cancellationAction) {
                        Button { reloadToken += 1 } label: { Image(systemName: "arrow.clockwise") }
                    }
                    ToolbarItem(placement: .primaryAction) {
                        Button { openURL(url) } label: { Image(systemName: "safari") }
                    }
                    ToolbarItem(placement: .confirmationAction) {
                        Button("Done") {
                            onDone()
                            dismiss()
                        }
                    }
                }
        }
    }
}
