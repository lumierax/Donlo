import SwiftUI
import WebKit

struct VerificationWebView: UIViewRepresentable {
    let url: URL

    func makeUIView(context: Context) -> WKWebView {
        let configuration = WKWebViewConfiguration()
        configuration.websiteDataStore = .default()
        let webView = WKWebView(frame: .zero, configuration: configuration)
        webView.customUserAgent = BrowserIdentity.safariIOS18
        var request = URLRequest(url: url)
        BrowserIdentity.applyNavigationHeaders(to: &request)
        webView.load(request)
        return webView
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {}
}

struct VerificationSheet: View {
    let url: URL
    let onDone: () -> Void
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            VerificationWebView(url: url)
                .ignoresSafeArea(edges: .bottom)
                .navigationTitle("Site verification")
                .navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .confirmationAction) {
                        Button("Done") {
                            onDone()
                            dismiss()
                        }
                    }
                }
        }
    }
}
