import AVFoundation
import Foundation
import Photos

enum VideoLibrarySaverError: LocalizedError {
    case noSupportedMedia
    case invalidURL
    case badHTTPStatus(Int)
    case photosPermissionDenied
    case exportUnavailable
    case exportFailed(String)
    case photoSaveFailed

    var errorDescription: String? {
        switch self {
        case .noSupportedMedia:
            return "لم أجد صيغة فيديو قابلة للحفظ في تطبيق الصور."
        case .invalidURL:
            return "رابط الفيديو غير صالح."
        case .badHTTPStatus(let status):
            return "فشل تنزيل الفيديو. رمز الخادم: \(status)."
        case .photosPermissionDenied:
            return "يحتاج التطبيق إذن إضافة الفيديوهات إلى تطبيق الصور."
        case .exportUnavailable:
            return "تعذر تجهيز بث الفيديو للحفظ في تطبيق الصور."
        case .exportFailed(let message):
            return "فشل تجهيز الفيديو: \(message)"
        case .photoSaveFailed:
            return "تعذر حفظ الفيديو في تطبيق الصور."
        }
    }
}

enum VideoLibrarySaver {
    static func saveBestVideo(from result: PageMediaResult) async throws -> MediaItem {
        guard let media = preferredMedia(from: result.media), let mediaURL = URL(string: media.url) else {
            throw VideoLibrarySaverError.noSupportedMedia
        }

        let localURL: URL
        if media.kind == .hls || mediaURL.pathExtension.lowercased() == "m3u8" {
            localURL = try await exportStream(url: mediaURL, title: result.title)
        } else if media.kind == .video {
            localURL = try await downloadDirect(url: mediaURL, pageURL: result.pageURL, title: result.title)
        } else {
            throw VideoLibrarySaverError.noSupportedMedia
        }

        defer { try? FileManager.default.removeItem(at: localURL) }
        try await saveToPhotoLibrary(fileURL: localURL, title: result.title)
        return media
    }

    static func preferredMedia(from items: [MediaItem]) -> MediaItem? {
        let supportedDirect = items.filter { item in
            guard item.kind == .video, let url = URL(string: item.url) else { return false }
            let ext = url.pathExtension.lowercased()
            return ext.isEmpty || ["mp4", "m4v", "mov"].contains(ext)
        }
        if let best = supportedDirect.sorted(by: mediaSort).first { return best }

        let hls = items.filter { $0.kind == .hls || URL(string: $0.url)?.pathExtension.lowercased() == "m3u8" }
        return hls.sorted(by: mediaSort).first
    }

    private static func mediaSort(_ lhs: MediaItem, _ rhs: MediaItem) -> Bool {
        resolutionValue(lhs.resolution) > resolutionValue(rhs.resolution)
    }

    private static func resolutionValue(_ value: String?) -> Int {
        guard let value else { return 0 }
        return Int(value.lowercased().replacingOccurrences(of: "p", with: "")) ?? 0
    }

    private static func downloadDirect(url: URL, pageURL: String, title: String) async throws -> URL {
        let configuration = URLSessionConfiguration.default
        configuration.httpCookieStorage = HTTPCookieStorage.shared
        configuration.httpShouldSetCookies = true
        configuration.timeoutIntervalForRequest = 30
        configuration.timeoutIntervalForResource = 60 * 60
        let session = URLSession(configuration: configuration)

        var request = URLRequest(url: url)
        request.setValue(BrowserIdentity.safariIOS18, forHTTPHeaderField: "User-Agent")
        request.setValue(pageURL, forHTTPHeaderField: "Referer")
        request.setValue("video/*,*/*;q=0.8", forHTTPHeaderField: "Accept")
        request.setValue("en-US,en;q=0.9,ar;q=0.8", forHTTPHeaderField: "Accept-Language")

        let (temporaryURL, response) = try await session.download(for: request)
        if let http = response as? HTTPURLResponse, !(200...299).contains(http.statusCode) {
            throw VideoLibrarySaverError.badHTTPStatus(http.statusCode)
        }

        let suggested = response.suggestedFilename.flatMap { URL(fileURLWithPath: $0).pathExtension }
        let sourceExtension = url.pathExtension
        let ext = sanitizeExtension(!sourceExtension.isEmpty ? sourceExtension : (suggested ?? "mp4"))
        let destination = makeTemporaryVideoURL(title: title, ext: ext)
        try? FileManager.default.removeItem(at: destination)
        try FileManager.default.moveItem(at: temporaryURL, to: destination)
        return destination
    }

    private static func exportStream(url: URL, title: String) async throws -> URL {
        let asset = AVURLAsset(url: url)
        guard let session = AVAssetExportSession(asset: asset, presetName: AVAssetExportPresetHighestQuality) else {
            throw VideoLibrarySaverError.exportUnavailable
        }

        let fileType: AVFileType
        let ext: String
        if session.supportedFileTypes.contains(.mp4) {
            fileType = .mp4
            ext = "mp4"
        } else if session.supportedFileTypes.contains(.mov) {
            fileType = .mov
            ext = "mov"
        } else {
            throw VideoLibrarySaverError.exportUnavailable
        }

        let destination = makeTemporaryVideoURL(title: title, ext: ext)
        try? FileManager.default.removeItem(at: destination)
        session.outputURL = destination
        session.outputFileType = fileType
        session.shouldOptimizeForNetworkUse = true

        await withCheckedContinuation { continuation in
            session.exportAsynchronously { continuation.resume() }
        }

        switch session.status {
        case .completed:
            return destination
        case .failed, .cancelled:
            throw VideoLibrarySaverError.exportFailed(session.error?.localizedDescription ?? "Unknown export error")
        default:
            throw VideoLibrarySaverError.exportFailed("Unexpected export state")
        }
    }

    private static func saveToPhotoLibrary(fileURL: URL, title: String) async throws {
        let status: PHAuthorizationStatus = await withCheckedContinuation { continuation in
            PHPhotoLibrary.requestAuthorization(for: .addOnly) { status in
                continuation.resume(returning: status)
            }
        }
        guard status == .authorized || status == .limited else {
            throw VideoLibrarySaverError.photosPermissionDenied
        }

        try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Void, Error>) in
            PHPhotoLibrary.shared().performChanges({
                let request = PHAssetCreationRequest.forAsset()
                let options = PHAssetResourceCreationOptions()
                options.originalFilename = "\(safeFilename(title)).\(fileURL.pathExtension.isEmpty ? "mp4" : fileURL.pathExtension)"
                request.addResource(with: .video, fileURL: fileURL, options: options)
            }) { success, error in
                if success {
                    continuation.resume()
                } else {
                    continuation.resume(throwing: error ?? VideoLibrarySaverError.photoSaveFailed)
                }
            }
        }
    }

    private static func makeTemporaryVideoURL(title: String, ext: String) -> URL {
        let base = safeFilename(title)
        let unique = UUID().uuidString.prefix(8)
        return FileManager.default.temporaryDirectory.appendingPathComponent("\(base)-\(unique).\(ext)")
    }

    private static func safeFilename(_ title: String) -> String {
        let clean = title
            .replacingOccurrences(of: #"[\\/:*?\"<>|\n\r\t]+"#, with: " ", options: .regularExpression)
            .replacingOccurrences(of: #"\s+"#, with: " ", options: .regularExpression)
            .trimmingCharacters(in: .whitespacesAndNewlines)
        return String((clean.isEmpty ? "video" : clean).prefix(90))
    }

    private static func sanitizeExtension(_ value: String) -> String {
        let clean = value.lowercased().filter { $0.isLetter || $0.isNumber }
        return clean.isEmpty ? "mp4" : clean
    }
}
