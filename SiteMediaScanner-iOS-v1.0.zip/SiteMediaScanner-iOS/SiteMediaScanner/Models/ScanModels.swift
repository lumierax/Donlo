import Foundation

enum MediaKind: String, Codable, CaseIterable, Sendable {
    case video
    case hls
    case dash
    case audio
    case unknown
}

struct MediaItem: Identifiable, Hashable, Codable, Sendable {
    let url: String
    let kind: MediaKind
    let resolution: String?
    let discoveredBy: String
    let evidence: String?

    var id: String { url }
}

struct PageMediaResult: Identifiable, Hashable, Sendable {
    let pageURL: String
    let title: String
    let durationSeconds: Double?
    let matchEvidence: [String]
    let media: [MediaItem]

    var id: String { pageURL }

    var formattedDuration: String {
        guard let durationSeconds, durationSeconds.isFinite, durationSeconds > 0 else {
            return "غير متوفرة"
        }
        let total = Int(durationSeconds.rounded())
        let hours = total / 3600
        let minutes = (total % 3600) / 60
        let seconds = total % 60
        if hours > 0 {
            return String(format: "%d:%02d:%02d", hours, minutes, seconds)
        }
        return String(format: "%d:%02d", minutes, seconds)
    }
}

enum AccessGateType: String, Sendable {
    case ageGate = "age-gate"
    case humanVerification = "human-verification"
}

struct AccessGate: Sendable {
    let type: AccessGateType
    let evidence: [String]
}

struct ScanErrorItem: Identifiable, Hashable, Sendable {
    let url: String
    let message: String
    var id: String { "\(url)|\(message)" }
}

struct SiteScanResult: Sendable {
    let siteURL: String
    let keyword: String
    let scannedPages: Int
    let queuedRemaining: Int
    let results: [PageMediaResult]
    let errors: [ScanErrorItem]
    let blocked: AccessGate?
    let note: String?
}

enum SearchHTTPMethod: String, Sendable {
    case get = "GET"
    case post = "POST"
}

struct SearchField: Sendable {
    let name: String
    let value: String
}

struct SiteSearchRequest: Sendable {
    let actionURL: URL
    let method: SearchHTTPMethod
    let fields: [SearchField]
    let score: Int
}

struct ScanProgress: Sendable {
    let scannedPages: Int
    let queuedPages: Int
    let foundResults: Int
    let currentURL: String
}

struct ScanOptions: Sendable {
    var maxPages: Int = 500
    var maxDepth: Int = 8
    var maxResults: Int = 250
    var maxDynamicPages: Int = 8
    var useSitemap: Bool = true
    var respectRobots: Bool = true
    var dynamicFallback: Bool = true
    var ignoreHumanVerificationGate: Bool = false
    var requestDelayMilliseconds: UInt64 = 120

    static let `default` = ScanOptions()
}

struct PageLink: Hashable, Sendable {
    let url: URL
    let text: String
    let rel: String
}

struct KeywordEvidence: Sendable {
    let matched: Bool
    let evidence: [String]
    let title: String
}
