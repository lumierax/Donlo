import Foundation

enum MediaKind: String, Codable, CaseIterable, Sendable {
    case video
    case hls
    case dash
    case audio
    case unknown
}

struct MediaItem: Identifiable, Hashable, Codable, Sendable {
    let url: String
    let kind: MediaKind
    let resolution: String?
    let discoveredBy: String
    let evidence: String?

    var id: String { url }
}

struct PageMediaResult: Identifiable, Hashable, Sendable {
    let pageURL: String
    let title: String
    let matchEvidence: [String]
    let media: [MediaItem]

    var id: String { pageURL }
}

enum AccessGateType: String, Sendable {
    case ageGate = "age-gate"
    case humanVerification = "human-verification"
}

struct AccessGate: Sendable {
    let type: AccessGateType
    let evidence: [String]
}

struct ScanErrorItem: Identifiable, Hashable, Sendable {
    let url: String
    let message: String
    var id: String { "\(url)|\(message)" }
}

struct SiteScanResult: Sendable {
    let siteURL: String
    let keyword: String
    let scannedPages: Int
    let queuedRemaining: Int
    let results: [PageMediaResult]
    let errors: [ScanErrorItem]
    let blocked: AccessGate?
}

struct ScanProgress: Sendable {
    let scannedPages: Int
    let queuedPages: Int
    let foundResults: Int
    let currentURL: String
}

struct ScanOptions: Sendable {
    var maxPages: Int = 150
    var maxDepth: Int = 5
    var maxResults: Int = 50
    var maxDynamicPages: Int = 8
    var useSitemap: Bool = true
    var respectRobots: Bool = true
    var dynamicFallback: Bool = true
    var requestDelayMilliseconds: UInt64 = 120

    static let `default` = ScanOptions()
}

struct PageLink: Hashable, Sendable {
    let url: URL
    let text: String
    let rel: String
}

struct KeywordEvidence: Sendable {
    let matched: Bool
    let evidence: [String]
    let title: String
}
