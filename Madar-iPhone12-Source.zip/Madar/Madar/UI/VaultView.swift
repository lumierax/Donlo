import SwiftUI
import AVKit

struct VaultView: View {
    @EnvironmentObject private var app: AppModel
    @EnvironmentObject private var vault: VaultStore
    @State private var query = ""
    @State private var selectedFolder: UUID?
    @State private var newFolder = ""
    @State private var addingFolder = false
    @State private var deleting: VaultEntry?
    @State private var renaming: VaultEntry?
    @State private var name = ""
    private var entries: [VaultEntry] {
        vault.index.entries.filter { item in
            (selectedFolder == nil || item.folderID == selectedFolder) &&
                (query.isEmpty || item.title.localizedCaseInsensitiveContains(query))
        }
    }
    var body: some View {
        NavigationStack {
            Group {
                if vault.isUnlocked {
                    ScrollView {
                        VStack(alignment: .leading, spacing: 22) {
                            summary
                            folderStrip
                            if entries.isEmpty {
                                ContentUnavailableView("لا توجد ملفات هنا بعد", systemImage: "folder", description: Text("اختر فيديو من النتائج واحفظه داخل التطبيق."))
                                    .padding(.vertical, 22)
                            } else {
                                LazyVStack(spacing: 12) { ForEach(entries) { item in entryRow(item) } }
                            }
                            Surface {
                                VStack(alignment: .leading, spacing: 12) {
                                    Toggle(isOn: Binding(get: { vault.biometricEnabled }, set: { enabled in
                                        Task { do { try await vault.setBiometric(enabled) } catch { app.alert = error.localizedDescription } }
                                    })) { Label("فتح باستخدام Face ID", systemImage: "faceid").font(.subheadline) }.disabled(vault.isUpdatingBiometrics)
                                    Text("الخروج يقفل المساحة ويوقف أي تنزيل جارٍ. ملفاتك ليست في الصور أو تطبيق الملفات.")
                                        .font(.caption).foregroundStyle(Palette.muted)
                                }
                            }
                        }.padding(20)
                    }.searchable(text: $query, prompt: "البحث في ملفاتك")
                } else {
                    ContentUnavailableView("المساحة مقفلة", systemImage: "lock", description: Text("ارجع إلى الشاشة الرئيسية وافتحها مجددًا."))
                }
            }
            .background(MadarBackground())
            .navigationTitle("المساحة الخاصة").navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) { Button { app.lockVault() } label: { Label("قفل", systemImage: "lock.fill") } }
                ToolbarItem(placement: .topBarLeading) { Button { addingFolder = true } label: { Image(systemName: "folder.badge.plus") }.accessibilityLabel("مجلد جديد") }
            }
            .alert("مجلد جديد", isPresented: $addingFolder) {
                TextField("اسم المجلد", text: $newFolder)
                Button("إنشاء") { do { selectedFolder = try vault.addFolder(newFolder); newFolder = "" } catch { app.alert = error.localizedDescription } }
                Button("إلغاء", role: .cancel) {}
            }
            .confirmationDialog("حذف الفيديو نهائيًا؟", isPresented: Binding(get: { deleting != nil }, set: { if !$0 { deleting = nil } }), titleVisibility: .visible) {
                Button("حذف الفيديو", role: .destructive) {
                    guard let item = deleting else { return }
                    do { try vault.remove(item.id); deleting = nil } catch { app.alert = error.localizedDescription }
                }
                Button("إلغاء", role: .cancel) { deleting = nil }
            } message: { Text("هذا الحذف لا يمكن التراجع عنه.") }
            .sheet(item: $renaming) { item in
                NavigationStack {
                    Form {
                        TextField("الاسم", text: $name)
                        Button("حفظ") { do { try vault.rename(item.id, title: name); renaming = nil } catch { app.alert = error.localizedDescription } }
                    }.navigationTitle("تغيير الاسم").navigationBarTitleDisplayMode(.inline)
                        .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("إلغاء") { renaming = nil } } }
                }.presentationDetents([.medium])
            }
            .fullScreenCover(item: $app.playback) { session in
                PrivatePlayerView(session: session).environment(\.layoutDirection, .rightToLeft)
            }
        }.privacySensitive()
    }
    private var summary: some View {
        Surface {
            HStack(spacing: 15) {
                Image(systemName: "checkmark.shield").font(.system(size: 32, weight: .light)).foregroundStyle(Palette.mint)
                VStack(alignment: .leading, spacing: 5) {
                    Text("\(vault.index.entries.count) فيديو محفوظ").font(.title3.bold())
                    Text(ByteCountFormatter.string(fromByteCount: vault.index.entries.reduce(0) { $0 + $1.bytes }, countStyle: .file) + " · أحجام الفيديو قبل التشفير")
                        .font(.caption).foregroundStyle(Palette.muted)
                }
                Spacer(minLength: 0)
            }
        }
    }
    private var folderStrip: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 9) {
                folderButton("الكل", id: nil)
                ForEach(vault.index.folders) { folder in
                    folderButton(folder.name, id: folder.id)
                        .contextMenu {
                            Button("حذف المجلد ونقل ملفاته إلى الجذر", role: .destructive) {
                                do { try vault.removeFolder(folder.id); if selectedFolder == folder.id { selectedFolder = nil } }
                                catch { app.alert = error.localizedDescription }
                            }
                        }
                }
            }
        }
    }
    private func folderButton(_ title: String, id: UUID?) -> some View {
        Button { selectedFolder = id } label: {
            Text(title).font(.subheadline.weight(.semibold)).padding(.horizontal, 16).padding(.vertical, 11)
                .foregroundStyle(selectedFolder == id ? Palette.background : Palette.muted)
                .background(selectedFolder == id ? Palette.mint : Palette.panel, in: Capsule())
        }.buttonStyle(.plain)
    }
    private func entryRow(_ item: VaultEntry) -> some View {
        Button { app.play(item) } label: {
            HStack(spacing: 13) {
                Image(systemName: "play.fill").font(.title3).foregroundStyle(Palette.accent)
                    .frame(width: 55, height: 64).background(Palette.accent.opacity(0.11), in: RoundedRectangle(cornerRadius: 15))
                VStack(alignment: .leading, spacing: 7) {
                    Text(item.title).font(.subheadline.weight(.semibold)).foregroundStyle(.white).lineLimit(2).multilineTextAlignment(.leading)
                    Text(item.quality + " · " + ByteCountFormatter.string(fromByteCount: item.bytes, countStyle: .file))
                        .font(.caption).foregroundStyle(Palette.muted)
                    Text(item.createdAt.formatted(date: .abbreviated, time: .omitted)).font(.caption2).foregroundStyle(Palette.muted.opacity(0.7))
                }
                Spacer(minLength: 0)
                Image(systemName: "ellipsis").foregroundStyle(Palette.muted)
            }.padding(13).background(Palette.panel, in: RoundedRectangle(cornerRadius: 21))
                .overlay(RoundedRectangle(cornerRadius: 21).stroke(Palette.line, lineWidth: 1))
        }.buttonStyle(.plain)
        .contextMenu {
            Button("تشغيل", systemImage: "play") { app.play(item) }
            Button("تغيير الاسم", systemImage: "pencil") { name = item.title; renaming = item }
            Menu("نقل إلى مجلد", systemImage: "folder") {
                Button("بدون مجلد") { move(item, folder: nil) }
                ForEach(vault.index.folders) { folder in Button(folder.name) { move(item, folder: folder.id) } }
            }
            Button("حذف", systemImage: "trash", role: .destructive) { deleting = item }
        }
    }
    private func move(_ item: VaultEntry, folder: UUID?) { do { try vault.move(item.id, folder: folder) } catch { app.alert = error.localizedDescription } }
}

struct PrivatePlayerView: View {
    @EnvironmentObject private var app: AppModel
    @ObservedObject var session: PlaybackSession
    var body: some View {
        VStack(spacing: 0) {
            HStack {
                Button { session.stop(); app.playback = nil } label: { Image(systemName: "xmark.circle.fill").font(.title2) }.accessibilityLabel("إغلاق المشغّل")
                Text(session.title).font(.subheadline.weight(.semibold)).lineLimit(1)
                Spacer()
                Image(systemName: "lock.fill").font(.caption).foregroundStyle(Palette.muted)
            }.padding(16)
            if let error = session.error {
                ContentUnavailableView("تعذر التشغيل", systemImage: "play.slash", description: Text(error))
            } else { NativePlayer(player: session.player) }
        }.background(.black).foregroundStyle(.white)
            .onAppear { session.player.play() }
            .onDisappear { session.stop() }
    }
}
struct NativePlayer: UIViewControllerRepresentable {
    let player: AVPlayer
    func makeUIViewController(context: Context) -> AVPlayerViewController {
        let controller = AVPlayerViewController()
        controller.player = player
        controller.allowsPictureInPicturePlayback = false
        controller.canStartPictureInPictureAutomaticallyFromInline = false
        controller.updatesNowPlayingInfoCenter = false
        controller.showsPlaybackControls = true
        return controller
    }
    func updateUIViewController(_ controller: AVPlayerViewController, context: Context) { controller.player = player }
}
