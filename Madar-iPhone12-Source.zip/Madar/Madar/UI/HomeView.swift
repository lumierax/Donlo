import SwiftUI

struct HomeView: View {
    @EnvironmentObject private var app: AppModel
    @EnvironmentObject private var transfers: TransferCenter
    @FocusState private var focus: Field?
    private enum Field { case site, query }
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 23) {
                    if app.results.isEmpty { hero }
                    searchPanel
                    statusPanel
                    if let issue = app.interaction { recoveryPanel(issue) }
                    if !app.results.isEmpty { resultSection }
                    else if !app.isSearching { emptyHints }
                }.padding(.horizontal, 20).padding(.top, 16).padding(.bottom, 28)
            }
            .scrollDismissesKeyboard(.interactively)
            .background(Palette.background.opacity(0.01))
            .safeAreaInset(edge: .top, spacing: 0) { header }
            .toolbar(.hidden, for: .navigationBar)
            .toolbar {
                ToolbarItemGroup(placement: .keyboard) {
                    Spacer(); Button("تم") { focus = nil }
                }
            }
            .background(MadarBackground())
        }.background(.clear)
    }
    private var header: some View {
        HStack(spacing: 10) {
            HStack(spacing: 10) {
                OrbitMark()
                VStack(alignment: .leading, spacing: 0) {
                    Text("مدار").font(.system(size: 24, weight: .bold, design: .rounded))
                    Text("MADAR").font(.system(size: 9, weight: .medium, design: .monospaced)).tracking(3).foregroundStyle(Palette.muted)
                }
            }
            .contentShape(Rectangle())
            .onLongPressGesture(minimumDuration: 1.8) { focus = nil; app.requestUnlock(.vault) }
            .accessibilityElement(children: .combine)
            .accessibilityAction(named: Text("الإجراء الخاص")) { app.requestUnlock(.vault) }
            Spacer()
            Button { focus = nil; app.requestUnlock(.transfers) } label: {
                RoundIcon(name: "arrow.down.to.line")
                    .overlay(alignment: .topTrailing) {
                        if transfers.activeCount > 0 {
                            Text("\(transfers.activeCount)").font(.caption2.bold()).foregroundStyle(Palette.background)
                                .padding(4).background(Palette.mint, in: Circle()).offset(x: 2, y: -2)
                        }
                    }
            }.accessibilityLabel("التنزيلات")
            Button { focus = nil; app.sheet = .settings } label: { RoundIcon(name: "slider.horizontal.3") }.accessibilityLabel("الإعدادات")
        }.foregroundStyle(.white).padding(.horizontal, 20).padding(.top, 6).padding(.bottom, 13)
            .background(Palette.background.opacity(0.97))
    }
    private var hero: some View {
        VStack(alignment: .leading, spacing: 11) {
            CapsuleLabel(title: "مساحة أبسط لاكتشاف الفيديو", symbol: "sparkle", color: Palette.mint)
            Text("ابحث. اختر.\nاحتفظ بما يهمّك.")
                .font(.system(size: 31, weight: .bold, design: .rounded)).lineSpacing(3)
            Text("الموقع الذي تختاره، والنتائج أمامك.\nمن دون ازدحام المتصفح.")
                .font(.subheadline).foregroundStyle(Palette.muted).lineSpacing(4)
        }.frame(maxWidth: .infinity, alignment: .leading).padding(.bottom, 2)
    }
    private var searchPanel: some View {
        Surface {
            VStack(alignment: .leading, spacing: 14) {
                Picker("طريقة البحث", selection: $app.inputMode) {
                    ForEach(AppModel.InputMode.allCases, id: \.self) { Text($0.rawValue).tag($0) }
                }.pickerStyle(.segmented)
                VStack(alignment: .leading, spacing: 7) {
                    Text(app.inputMode == .search ? "الموقع" : "رابط صفحة الفيديو أو الملف").font(.caption.weight(.medium)).foregroundStyle(Palette.muted)
                    HStack(spacing: 8) {
                        TextField("https://example.com", text: $app.site)
                            .keyboardType(.URL).textContentType(.URL).textInputAutocapitalization(.never)
                            .autocorrectionDisabled().focused($focus, equals: .site).submitLabel(.next)
                            .onSubmit { if app.inputMode == .search { focus = .query } else { submit() } }
                            .environment(\.layoutDirection, .leftToRight)
                        Image(systemName: "globe").foregroundStyle(Palette.muted)
                    }.madarField()
                }
                if app.inputMode == .search {
                    VStack(alignment: .leading, spacing: 7) {
                        Text("ماذا تبحث عنه؟").font(.caption.weight(.medium)).foregroundStyle(Palette.muted)
                        HStack {
                            TextField("اكتب كلمة أو اسم فيديو", text: $app.keyword)
                                .keyboardType(.default).focused($focus, equals: .query).submitLabel(.search).onSubmit(submit)
                            Image(systemName: "magnifyingglass").foregroundStyle(Palette.muted)
                        }.madarField()
                    }
                }
                if app.isSearching {
                    Button { app.stop() } label: { Label("إيقاف البحث", systemImage: "stop.fill") }.buttonStyle(PrimaryStyle())
                } else {
                    Button(action: submit) { Label(app.inputMode == .search ? "ابدأ البحث" : "افحص الفيديو", systemImage: "sparkle.magnifyingglass") }
                        .buttonStyle(PrimaryStyle()).disabled(app.site.trimmingCharacters(in: .whitespaces).isEmpty)
                }
            }
        }
    }
    private func submit() { focus = nil; app.beginSearch() }
    private var statusPanel: some View {
        HStack(alignment: .top, spacing: 9) {
            if app.isSearching { ProgressView().controlSize(.small).tint(Palette.mint) }
            else { Circle().fill(Palette.mint).frame(width: 6, height: 6).padding(.top, 6) }
            Text(app.status).font(.footnote).foregroundStyle(Palette.muted).fixedSize(horizontal: false, vertical: true)
            Spacer(minLength: 0)
        }.animation(.easeInOut(duration: 0.2), value: app.isSearching)
    }
    private func recoveryPanel(_ issue: BrowserIssue) -> some View {
        Surface(padding: 16) {
            VStack(alignment: .leading, spacing: 12) {
                Label("خطوة تحتاج تدخلك", systemImage: "hand.raised").font(.subheadline.bold()).foregroundStyle(Palette.accent)
                Text(issue.message).font(.footnote).foregroundStyle(Palette.muted)
                Button { focus = nil; app.showRecoveryBrowser() } label: { Label("فتح نافذة الموقع", systemImage: "rectangle.on.rectangle") }.buttonStyle(SoftStyle())
            }.frame(maxWidth: .infinity, alignment: .leading)
        }
    }
    private var resultSection: some View {
        VStack(alignment: .leading, spacing: 15) {
            HStack {
                Text("النتائج").font(.title3.bold())
                CapsuleLabel(title: "\(app.results.count)", color: Palette.mint)
                Spacer()
                Button { app.settings.grid.toggle(); app.saveSettings() } label: {
                    Image(systemName: app.settings.grid ? "list.bullet" : "square.grid.2x2").frame(width: 36, height: 36)
                }.accessibilityLabel("تغيير طريقة عرض النتائج")
                Button { app.clearResults() } label: { Image(systemName: "xmark").frame(width: 36, height: 36) }.accessibilityLabel("مسح النتائج")
            }
            Text("الأسماء والصور أولًا. افحص الجودات عند فتح الفيديو.").font(.caption).foregroundStyle(Palette.muted)
            if app.settings.grid {
                LazyVGrid(columns: [GridItem(.adaptive(minimum: 145), spacing: 12)], spacing: 14) {
                    ForEach(app.results) { result in ResultCard(result: result, grid: true) }
                }
            } else {
                LazyVStack(spacing: 12) { ForEach(app.results) { result in ResultCard(result: result, grid: false) } }
            }
            if app.nextPage != nil && !app.isSearching {
                Button { app.loadMore() } label: { Label("عرض نتائج إضافية", systemImage: "plus") }.buttonStyle(PrimaryStyle())
            }
        }
    }
    private var emptyHints: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack(alignment: .top, spacing: 13) {
                Image(systemName: "rectangle.stack").foregroundStyle(Palette.accent).frame(width: 22)
                VStack(alignment: .leading, spacing: 4) {
                    Text("نتائج قبل الانتظار").font(.subheadline.weight(.semibold))
                    Text("تبقى البطاقات ظاهرة حتى لو تعذر فحص أحد الروابط.").font(.footnote).foregroundStyle(Palette.muted)
                }
            }
            HStack(alignment: .top, spacing: 13) {
                Image(systemName: "iphone").foregroundStyle(Palette.mint).frame(width: 22)
                VStack(alignment: .leading, spacing: 4) {
                    Text("الحفظ داخل التطبيق").font(.subheadline.weight(.semibold))
                    Text("لا ألبومات صور، ولا حفظ تلقائي في الاستديو.").font(.footnote).foregroundStyle(Palette.muted)
                }
            }
        }.padding(.horizontal, 5).padding(.top, 2)
    }
}

struct ResultCard: View {
    @EnvironmentObject private var app: AppModel
    let result: VideoResult
    let grid: Bool
    var body: some View {
        Button { app.sheet = .details(result.id) } label: {
            Group {
                if grid {
                    VStack(alignment: .leading, spacing: 10) {
                        ThumbnailView(result: result).aspectRatio(16/10, contentMode: .fit).clipShape(RoundedRectangle(cornerRadius: 15))
                        details.padding(.horizontal, 4).padding(.bottom, 4)
                    }.padding(8)
                } else {
                    HStack(spacing: 12) {
                        ThumbnailView(result: result).frame(width: 112, height: 78).clipShape(RoundedRectangle(cornerRadius: 13))
                        details
                        Image(systemName: "chevron.forward").font(.caption.bold()).foregroundStyle(Palette.muted)
                    }.padding(11)
                }
            }.frame(maxWidth: .infinity, alignment: .leading)
                .background(Palette.panel, in: RoundedRectangle(cornerRadius: 21))
                .overlay(RoundedRectangle(cornerRadius: 21).stroke(Palette.line, lineWidth: 1))
        }.buttonStyle(.plain).privacySensitive()
    }
    private var details: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(result.title).font(.subheadline.weight(.semibold)).foregroundStyle(.white).lineLimit(2).multilineTextAlignment(.leading)
            HStack(spacing: 5) {
                if result.state == .resolving { ProgressView().controlSize(.mini) }
                Text(result.sources.isEmpty ? result.state.title : "\(result.sources.count) جودات متاحة")
                    .font(.caption2).foregroundStyle(result.state == .ready ? Palette.mint : Palette.muted)
            }
        }.frame(maxWidth: .infinity, alignment: .leading)
    }
}
