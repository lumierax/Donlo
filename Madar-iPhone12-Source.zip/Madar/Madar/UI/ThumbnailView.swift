import SwiftUI
import UIKit

@MainActor
final class ThumbnailCache {
    static let shared = ThumbnailCache()
    private let cache = NSCache<NSString, UIImage>()
    private init() { cache.totalCostLimit = 24 * 1024 * 1024; cache.countLimit = 80 }
    func get(_ key: String) -> UIImage? { cache.object(forKey: key as NSString) }
    func put(_ image: UIImage, key: String) { cache.setObject(image, forKey: key as NSString, cost: Int(image.size.width * image.size.height) * 4) }
    func clear() { cache.removeAllObjects() }
}
struct ThumbnailView: View {
    @EnvironmentObject private var app: AppModel
    let result: VideoResult
    @State private var image: UIImage?
    var body: some View {
        GeometryReader { proxy in
            ZStack {
                LinearGradient(colors: [Palette.accent.opacity(0.22), Palette.mint.opacity(0.09)], startPoint: .topLeading, endPoint: .bottomTrailing)
                if let image {
                    Image(uiImage: image).resizable().scaledToFill().frame(width: proxy.size.width, height: proxy.size.height).clipped()
                } else { Image(systemName: "play.rectangle").font(.system(size: 29, weight: .light)).foregroundStyle(Palette.accent.opacity(0.7)) }
                if let duration = result.duration, !duration.isEmpty {
                    VStack { Spacer(); HStack { Spacer(); Text(duration).font(.caption2.monospacedDigit().weight(.semibold)).padding(.horizontal, 6).padding(.vertical, 3).background(.black.opacity(0.7), in: RoundedRectangle(cornerRadius: 5)) }.padding(8) }
                }
            }
        }.clipped().privacySensitive()
        .task(id: result.thumbnailURL) {
            guard let url = result.thumbnailURL else { return }
            if let cached = ThumbnailCache.shared.get(url.absoluteString) { image = cached; return }
            do {
                let data = try await app.network.image(url, referer: result.pageURL, userAgent: app.browser.userAgent)
                try Task.checkCancellation()
                if let decoded = UIImage(data: data) {
                    let small = await decoded.byPreparingThumbnail(ofSize: CGSize(width: 640, height: 400)) ?? decoded
                    ThumbnailCache.shared.put(small, key: url.absoluteString); image = small
                }
            } catch { /* A missing thumbnail must never remove an otherwise useful video. */ }
        }
    }
}
