import SwiftUI

struct TransfersView: View {
    @EnvironmentObject private var app: AppModel
    @EnvironmentObject private var transfers: TransferCenter
    @EnvironmentObject private var vault: VaultStore
    var body: some View {
        NavigationStack {
            Group {
                if !vault.isUnlocked {
                    VStack(spacing: 20) {
                        ContentUnavailableView("التنزيلات مقفلة", systemImage: "lock", description: Text("افتح المساحة الخاصة لعرض الأسماء وإعادة المحاولة."))
                        Button("فتح") { app.requestUnlock(.transfers) }.buttonStyle(PrimaryStyle()).padding(24)
                    }
                } else if transfers.items.isEmpty {
                    ContentUnavailableView("قائمة هادئة", systemImage: "arrow.down.circle", description: Text("تنزيلاتك الجديدة ستظهر هنا، مع التقدم وسبب أي توقف."))
                } else {
                    ScrollView {
                        VStack(alignment: .leading, spacing: 16) {
                            Text("أبقِ التطبيق مفتوحًا حتى اكتمال التنزيل والتشفير. الانتقال للخلفية أو القفل يوقف التنزيل، وإعادة المحاولة تبدأ من الصفر.")
                                .font(.footnote).foregroundStyle(Palette.muted).lineSpacing(4)
                            ForEach(transfers.items) { item in row(item) }
                        }.padding(20)
                    }
                }
            }.background(MadarBackground())
                .navigationTitle("التنزيلات").navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .topBarTrailing) { Button("إغلاق") { app.sheet = nil } }
                    ToolbarItem(placement: .topBarLeading) { Button("تنظيف القائمة") { transfers.clearFinished() }.font(.caption).disabled(!vault.isUnlocked) }
                }
        }.privacySensitive()
    }
    private func row(_ item: TransferItem) -> some View {
        Surface {
            VStack(alignment: .leading, spacing: 13) {
                HStack(alignment: .top, spacing: 11) {
                    Image(systemName: item.state == .completed ? "checkmark.circle.fill" : item.active ? "arrow.down.circle" : "exclamationmark.circle")
                        .font(.title2).foregroundStyle(item.state == .completed ? Palette.mint : Palette.accent)
                    Text(item.choice.result.title).font(.subheadline.weight(.semibold)).lineLimit(2)
                    Spacer(minLength: 0)
                }
                if item.active {
                    if let progress = item.progress { ProgressView(value: progress).tint(Palette.mint) }
                    else { HStack { ProgressView(); Text("الخادم لم يرسل الحجم الإجمالي").font(.caption).foregroundStyle(Palette.muted) } }
                }
                HStack(alignment: .top) {
                    Text(item.note).font(.caption).foregroundStyle(Palette.muted).fixedSize(horizontal: false, vertical: true)
                    Spacer(minLength: 8)
                    if item.active, let progress = item.progress { Text("\(Int(progress * 100))٪").font(.caption.monospacedDigit()).foregroundStyle(Palette.mint) }
                }
                if item.active {
                    Button("إلغاء التنزيل", role: .destructive) { transfers.cancel(item.id) }.font(.footnote)
                } else if item.state != .completed {
                    Button { do { try transfers.retry(item.id) } catch { app.alert = error.localizedDescription } } label: { Label("إعادة المحاولة", systemImage: "arrow.clockwise") }.buttonStyle(SoftStyle())
                    Button { app.recheckDownload(item.choice) } label: {
                        Label("إعادة فحص صفحة الفيديو", systemImage: "magnifyingglass")
                    }.buttonStyle(SoftStyle())
                }
            }
        }
    }
}
