import SwiftUI

struct SettingsView: View {
    @EnvironmentObject private var app: AppModel
    @State private var editing: SiteProfile?
    @State private var clearing = false
    var body: some View {
        NavigationStack {
            Form {
                Section {
                    HStack(spacing: 13) {
                        OrbitMark(size: 49)
                        VStack(alignment: .leading, spacing: 3) {
                            Text("مدار").font(.title2.bold())
                            Text("1.0.0 · مشروع iPhone جديد").font(.caption).foregroundStyle(Palette.muted)
                        }
                    }.padding(.vertical, 7)
                }
                Section("البحث") {
                    Stepper("الصفحات في كل بحث: \(app.settings.pageLimit)", value: $app.settings.pageLimit, in: 1...5)
                        .onChange(of: app.settings.pageLimit) { _, _ in app.saveSettings() }
                    Toggle("عرض النتائج كشبكة", isOn: $app.settings.grid).onChange(of: app.settings.grid) { _, _ in app.saveSettings() }
                    Text("تُتابع صفحات نتائج البحث فقط، وليس جميع أقسام الموقع. لا يعني الدعم العام أن كل مشغّل أو موقع قابل للاستخراج.")
                        .font(.footnote).foregroundStyle(Palette.muted)
                }
                Section {
                    ForEach(app.settings.profiles) { profile in
                        Button { editing = profile } label: {
                            HStack {
                                VStack(alignment: .leading, spacing: 4) {
                                    Text(profile.host).foregroundStyle(.white)
                                    Text(profile.searchTemplate == nil ? "تعريف خانة البحث" : "رابط بحث محفوظ").font(.caption).foregroundStyle(Palette.muted)
                                }
                                Spacer(); Image(systemName: "chevron.forward").font(.caption)
                            }
                        }
                    }.onDelete { offsets in app.settings.profiles.remove(atOffsets: offsets); app.saveSettings() }
                    Button("إضافة تعريف موقع", systemImage: "plus") {
                        let host = (try? URLTools.website(app.site)).map { app.normalizedHost($0) } ?? ""
                        editing = app.profile(host) ?? SiteProfile(host: host)
                    }
                } header: { Text("تعريفات المواقع") } footer: {
                    Text("التعريف يحفظ النطاق وطريقة البحث فقط. لا تضع كلمات مرور أو رموز جلسات داخل القالب. يمكنك حذف التعريف بالسحب.")
                }
                Section("المتصفح") {
                    LabeledContent("المحرك الداخلي", value: "WebKit")
                    Text("المتصفح يعمل خلف الواجهة ولا يظهر إلا للتدخل اليدوي. لا توجد موافقة تلقائية على العمر أو حل آلي للتحقق البشري.")
                        .font(.footnote).foregroundStyle(Palette.muted)
                    Text("Brave ليس محركًا مدمجًا في هذا المشروع. يفتح زر المتصفح الخارجي Brave عند اختياره افتراضيًا في iOS، لكن جلساته لا تتزامن مع مدار.")
                        .font(.footnote).foregroundStyle(Palette.muted)
                    Button("مسح جلسة المواقع والنتائج", role: .destructive) { clearing = true }
                }
                Section("الحفظ والخصوصية") {
                    Label("الحفظ محلي؛ لا صلاحية للصور", systemImage: "iphone")
                    Label("لا حساب ولا خادم تابع للتطبيق", systemImage: "person.crop.circle.badge.checkmark")
                    Text("مواقع الويب وخوادم الفيديو تتلقى اتصالاتك كأي تصفح. التطبيق ليس VPN، ولا يخفي عنوان IP عن المواقع.")
                        .font(.footnote).foregroundStyle(Palette.muted)
                    Text("التنزيل في المقدمة فقط. لا تسجيل بث مباشر، ولا فك DRM، ولا تجاوز حماية وصول. نزّل فقط ما يُسمح لك بتنزيله.")
                        .font(.footnote).foregroundStyle(Palette.muted)
                }
                Section("عن هذا الإصدار") {
                    Text("واجهة SwiftUI أصلية، تستهدف iPhone وiOS 18.5 أو أحدث. بعض المواقع ومصادر HLS تحتاج اختبارًا أو تعريفًا خاصًا.")
                        .font(.footnote).foregroundStyle(Palette.muted)
                    Text("أُعيد تنفيذ أساليب الاستخراج من الملفين المرفقين، مع إبقاء إشعارات MIT في مجلد Licenses. لم تُضمّن بيانات الاختبار أو الصور من الملف الثاني.")
                        .font(.caption).foregroundStyle(Palette.muted)
                }
            }.scrollContentBackground(.hidden).background(MadarBackground())
                .navigationTitle("الإعدادات").navigationBarTitleDisplayMode(.inline)
                .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("تم") { app.sheet = nil } } }
                .sheet(item: $editing) { profile in
                    SiteProfileEditor(profile: profile) { saved in app.saveProfile(saved); editing = nil }
                        .environment(\.layoutDirection, .rightToLeft)
                }
                .confirmationDialog("مسح الجلسة والنتائج؟", isPresented: $clearing, titleVisibility: .visible) {
                    Button("مسح", role: .destructive) {
                        app.clearResults()
                        Task { await app.browser.clearSession(); app.network.replaceCookies([]) }
                    }
                    Button("إلغاء", role: .cancel) {}
                } message: { Text("سيزيل كوكيز هذه الجلسة. لن يحذف الملفات المحفوظة أو تعريفات المواقع.") }
        }
    }
}
struct SiteProfileEditor: View {
    @Environment(\.dismiss) private var dismiss
    private let onSave: (SiteProfile) -> Void
    @State private var host: String
    @State private var template: String
    @State private var searchSelector: String
    @State private var resultSelector: String
    @State private var error: String?
    init(profile: SiteProfile, onSave: @escaping (SiteProfile) -> Void) {
        self.onSave = onSave
        _host = State(initialValue: profile.host)
        _template = State(initialValue: profile.searchTemplate ?? "")
        _searchSelector = State(initialValue: profile.searchSelector ?? "")
        _resultSelector = State(initialValue: profile.resultSelector ?? "")
    }
    var body: some View {
        NavigationStack {
            Form {
                Section("نطاق الموقع") {
                    TextField("example.com", text: $host).keyboardType(.URL)
                }
                Section {
                    TextField("https://example.com/search?q={query}", text: $template, axis: .vertical).lineLimit(3...6)
                } header: { Text("رابط البحث — اختياري") } footer: {
                    Text("نفّذ بحثًا يدويًا في الموقع، ثم استبدل كلمة البحث في الرابط بـ {query}. لا نفترض مسارات غير موجودة.")
                }
                Section {
                    TextField("input[type='search']", text: $searchSelector, axis: .vertical)
                } header: { Text("محدد خانة البحث — اختياري") } footer: {
                    Text("يمكن للتطبيق حفظه عندما تختار الخانة من نافذة التدخل اليدوي. مفيد للبحث الذي يعتمد JavaScript أو POST.")
                }
                Section {
                    TextField("article.video-card a", text: $resultSelector, axis: .vertical)
                } header: { Text("محدد بطاقات النتائج — متقدم") } footer: {
                    Text("اتركه فارغًا للاكتشاف العام. استخدم محدد CSS لبطاقات الفيديو أو روابطها عندما يكون تصميم الموقع خاصًا.")
                }
                if let error { Section { Text(error).foregroundStyle(.orange) } }
                Section { Button("حفظ التعريف", action: save) }
            }
            .textInputAutocapitalization(.never).autocorrectionDisabled()
            .environment(\.layoutDirection, .leftToRight)
            .navigationTitle("تعريف الموقع").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("إلغاء") { dismiss() } } }
        }
    }
    private func save() {
        do {
            let base = try URLTools.website(host)
            let cleanTemplate = template.trimmingCharacters(in: .whitespacesAndNewlines)
            if !cleanTemplate.isEmpty { _ = try SearchTemplate.url(template: cleanTemplate, keyword: "test", base: base) }
            guard searchSelector.count < 1000, resultSelector.count < 1000 else { throw MadarError.message("المحدد أطول من المسموح.") }
            let domain = (base.host ?? "").lowercased().replacingOccurrences(of: #"^www\."#, with: "", options: .regularExpression)
            onSave(SiteProfile(host: domain, searchTemplate: cleanTemplate.isEmpty ? nil : cleanTemplate,
                searchSelector: searchSelector.isEmpty ? nil : searchSelector, resultSelector: resultSelector.isEmpty ? nil : resultSelector))
        } catch { self.error = error.localizedDescription }
    }
}
