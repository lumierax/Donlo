import SwiftUI

// Native system type and flexible dimensions: no fixed iPhone screen coordinates.
enum Palette {
    static let background = Color(red: 0.035, green: 0.045, blue: 0.075)
    static let panel = Color(red: 0.073, green: 0.087, blue: 0.135)
    static let inset = Color(red: 0.045, green: 0.057, blue: 0.094)
    static let accent = Color(red: 0.65, green: 0.57, blue: 1.0)
    static let mint = Color(red: 0.39, green: 0.90, blue: 0.78)
    static let muted = Color(red: 0.65, green: 0.70, blue: 0.80)
    static let line = Color.white.opacity(0.09)
    static let gradient = LinearGradient(colors: [Color(red: 0.48, green: 0.36, blue: 0.96), Color(red: 0.35, green: 0.44, blue: 0.88)], startPoint: .topLeading, endPoint: .bottomTrailing)
}
struct MadarBackground: View {
    var body: some View {
        ZStack(alignment: .topLeading) {
            Palette.background
            RadialGradient(colors: [Palette.accent.opacity(0.14), .clear], center: .topLeading, startRadius: 0, endRadius: 430)
        }.ignoresSafeArea()
    }
}
struct OrbitMark: View {
    var size: CGFloat = 35
    var body: some View {
        ZStack {
            Circle().fill(Palette.accent.opacity(0.14))
            Ellipse().stroke(Palette.accent, lineWidth: 1.6).frame(width: size * 0.72, height: size * 0.39).rotationEffect(.degrees(-35))
            Circle().fill(Palette.mint).frame(width: size * 0.19, height: size * 0.19)
            Circle().fill(.white).frame(width: size * 0.10, height: size * 0.10).offset(x: size * 0.29, y: -size * 0.18)
        }.frame(width: size, height: size)
    }
}
struct Surface<Content: View>: View {
    var padding: CGFloat = 18
    @ViewBuilder var content: Content
    var body: some View {
        content.padding(padding).background(Palette.panel, in: RoundedRectangle(cornerRadius: 24, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 24, style: .continuous).stroke(Palette.line, lineWidth: 1))
    }
}
struct CapsuleLabel: View {
    let title: String
    var symbol: String? = nil
    var color: Color = Palette.muted
    var body: some View {
        HStack(spacing: 5) {
            if let symbol { Image(systemName: symbol) }
            Text(title)
        }.font(.caption.weight(.medium)).foregroundStyle(color)
            .padding(.horizontal, 10).padding(.vertical, 6)
            .background(color.opacity(0.10), in: Capsule())
    }
}
struct PrimaryStyle: ButtonStyle {
    @Environment(\.isEnabled) private var enabled
    func makeBody(configuration: Configuration) -> some View {
        configuration.label.font(.headline).foregroundStyle(.white)
            .frame(maxWidth: .infinity).frame(minHeight: 52)
            .background(Palette.gradient, in: RoundedRectangle(cornerRadius: 17, style: .continuous))
            .opacity(enabled ? (configuration.isPressed ? 0.78 : 1) : 0.4)
            .scaleEffect(configuration.isPressed ? 0.985 : 1)
            .animation(.easeOut(duration: 0.15), value: configuration.isPressed)
    }
}
struct SoftStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label.font(.subheadline.weight(.semibold)).foregroundStyle(Palette.accent)
            .padding(.horizontal, 15).frame(minHeight: 44)
            .background(Palette.accent.opacity(configuration.isPressed ? 0.2 : 0.1), in: RoundedRectangle(cornerRadius: 14))
    }
}
struct RoundIcon: View {
    let name: String
    var body: some View {
        Image(systemName: name).font(.system(size: 18, weight: .medium))
            .frame(width: 44, height: 44).background(.white.opacity(0.045), in: Circle())
            .overlay(Circle().stroke(Palette.line, lineWidth: 1))
    }
}
struct SectionHeading: View {
    let title: String
    var subtitle: String? = nil
    var body: some View {
        VStack(alignment: .leading, spacing: 5) {
            Text(title).font(.title3.bold()).foregroundStyle(.white)
            if let subtitle { Text(subtitle).font(.footnote).foregroundStyle(Palette.muted) }
        }.frame(maxWidth: .infinity, alignment: .leading)
    }
}
extension View {
    func madarField() -> some View {
        self.font(.system(size: 17)).padding(.horizontal, 14).frame(minHeight: 52)
            .background(Palette.inset, in: RoundedRectangle(cornerRadius: 14))
            .overlay(RoundedRectangle(cornerRadius: 14).stroke(Palette.line, lineWidth: 1))
    }
}
