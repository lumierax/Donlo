import SwiftUI
import UIKit

struct RootView: View {
    @ObservedObject var app: AppModel
    @Environment(\.scenePhase) private var scenePhase
    var body: some View {
        ZStack {
            if app.sheet?.id != "browser" {
                BrowserHost(engine: app.browser).allowsHitTesting(false).accessibilityHidden(true)
            }
            MadarBackground()
            HomeView()
        }
        .sheet(item: $app.sheet) { route in
            SheetRouter(app: app, route: route)
                .presentationDragIndicator(.visible)
                .presentationCornerRadius(28)
                .presentationBackground(Palette.background)
                .environment(\.layoutDirection, .rightToLeft)
        }
        .onChange(of: app.sheet?.id) { old, new in app.sheetChanged(from: old, to: new) }
        .onChange(of: scenePhase) { _, new in if new == .background { app.enteredBackground() } }
        .onReceive(NotificationCenter.default.publisher(for: UIApplication.willResignActiveNotification)) { _ in
            app.playback?.player.pause(); PrivacyCurtain.shared.show()
        }
        .onReceive(NotificationCenter.default.publisher(for: UIApplication.didBecomeActiveNotification)) { _ in PrivacyCurtain.shared.hide() }
        .onReceive(NotificationCenter.default.publisher(for: UIApplication.protectedDataWillBecomeUnavailableNotification)) { _ in app.enteredBackground() }
        .alert("تنبيه", isPresented: Binding(get: { app.sheet == nil && app.alert != nil }, set: { if !$0 { app.alert = nil } })) {
            Button("حسنًا", role: .cancel) { app.alert = nil }
        } message: { Text(app.alert ?? "") }
        .task { app.start() }
    }
}
struct SheetRouter: View {
    @ObservedObject var app: AppModel
    let route: AppSheet
    var body: some View {
        Group {
            switch route {
            case .welcome: WelcomeView()
            case .settings: SettingsView()
            case .transfers: TransfersView()
            case .unlock: UnlockView()
            case .vault: VaultView()
            case .browser: RecoveryBrowserView()
            case .details(let id): VideoDetailView(resultID: id)
            }
        }
        .id(route.id)
        .tint(Palette.accent)
        .alert("تنبيه", isPresented: Binding(get: { app.alert != nil }, set: { if !$0 { app.alert = nil } })) {
            Button("حسنًا", role: .cancel) { app.alert = nil }
        } message: { Text(app.alert ?? "") }
    }
}
