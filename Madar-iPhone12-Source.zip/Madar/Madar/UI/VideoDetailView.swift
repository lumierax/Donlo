import SwiftUI

struct VideoDetailView: View {
    @EnvironmentObject private var app: AppModel
    @EnvironmentObject private var vault: VaultStore
    let resultID: String
    @State private var selectedID: String?
    @State private var folder: UUID?
    @State private var folderName = ""
    private var result: VideoResult? { app.result(resultID) }
    private var selected: MediaSource? { result?.sources.first(where: { $0.id == selectedID }) ?? result?.sources.first }
    var body: some View {
        NavigationStack {
            Group {
                if let result {
                    ScrollView {
                        VStack(alignment: .leading, spacing: 22) {
                            ThumbnailView(result: result).aspectRatio(16/9, contentMode: .fit).clipShape(RoundedRectangle(cornerRadius: 24))
                            VStack(alignment: .leading, spacing: 9) {
                                Text(result.title).font(.title2.bold()).textSelection(.enabled)
                                Text(result.pageURL.host ?? "").font(.caption.monospaced()).foregroundStyle(Palette.muted)
                                    .environment(\.layoutDirection, .leftToRight)
                            }
                            qualitySection(result)
                            if !result.sources.isEmpty { destinationSection }
                            if let note = result.note { Text(note).font(.footnote).foregroundStyle(Palette.muted).lineSpacing(4) }
                            if result.state == .needsInteraction {
                                Button { app.showRecoveryBrowser() } label: { Label("فتح الموقع للخطوة المطلوبة", systemImage: "hand.tap") }.buttonStyle(PrimaryStyle())
                            }
                            if result.state == .failed || result.state == .unavailable || result.state == .needsInteraction {
                                Button { app.resolve(resultID) } label: { Label("إعادة فحص المصادر", systemImage: "arrow.clockwise") }.buttonStyle(SoftStyle())
                            }
                            if result.state != .resolving {
                                Button { app.resolve(resultID, deep: true) } label: {
                                    Label("فحص موسّع للمشغّل والمصادر المتأخرة", systemImage: "magnifyingglass")
                                }.buttonStyle(SoftStyle())
                                Button { app.openPlayer(resultID) } label: {
                                    Label("فتح المشغّل لالتقاط المصدر بعد التشغيل", systemImage: "play.rectangle")
                                }.buttonStyle(SoftStyle())
                            }
                            Text("التنزيل يعيد محاولة أخطاء الشبكة تلقائيًا حتى 4 محاولات، ويطلب رابطًا جديدًا عند انتهاء صلاحيته. بعض المشغّلات تحتاج ضغطة تشغيل منك.")
                                .font(.caption).foregroundStyle(Palette.muted)
                        }.padding(20)
                    }.scrollDismissesKeyboard(.interactively)
                    .safeAreaInset(edge: .bottom) {
                        if let selected {
                            VStack(spacing: 9) {
                                Button {
                                    app.download(DownloadChoice(result: result, source: selected, folder: folder))
                                } label: { Label("حفظ داخل التطبيق · \(selected.quality)", systemImage: "arrow.down.to.line") }.buttonStyle(PrimaryStyle())
                                Text("لن يُحفظ في تطبيق الصور").font(.caption2).foregroundStyle(Palette.muted)
                            }.padding(.horizontal, 20).padding(.top, 12).padding(.bottom, 8).background(.ultraThinMaterial)
                        }
                    }
                } else { ContentUnavailableView("النتيجة غير متاحة", systemImage: "video.slash", description: Text("أعد البحث عن الفيديو.")) }
            }
            .background(MadarBackground())
            .navigationTitle("اختر الجودة").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("إغلاق") { app.sheet = nil } } }
            .task { if result?.state == .pending { app.resolve(resultID) } }
        }
    }
    @ViewBuilder
    private func qualitySection(_ result: VideoResult) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            SectionHeading(title: "الجودة والصيغة", subtitle: "تظهر الخيارات التي يكشفها المصدر فقط")
            if result.state == .resolving {
                Surface { HStack(spacing: 12) { ProgressView().tint(Palette.accent); Text("نفحص المصادر المتاحة…").font(.subheadline); Spacer() } }
                Button("إيقاف الفحص") { app.stop() }.font(.footnote)
            } else if result.sources.isEmpty {
                Surface { Label(result.state.title, systemImage: "video.badge.waveform").font(.subheadline).foregroundStyle(Palette.muted).frame(maxWidth: .infinity, alignment: .leading) }
                if result.state == .pending { Button("افحص الجودات") { app.resolve(resultID) }.buttonStyle(PrimaryStyle()) }
            } else {
                VStack(spacing: 9) {
                    ForEach(result.sources) { source in
                        Button { selectedID = source.id } label: {
                            HStack(spacing: 12) {
                                Image(systemName: selected?.id == source.id ? "checkmark.circle.fill" : "circle")
                                    .font(.title3).foregroundStyle(selected?.id == source.id ? Palette.mint : Palette.muted)
                                VStack(alignment: .leading, spacing: 4) {
                                    Text(source.quality).font(.headline).foregroundStyle(.white)
                                    Text(source.kind == .hls ? "بث HLS · يحتاج تجهيزًا" : "ملف فيديو مباشر").font(.caption).foregroundStyle(Palette.muted)
                                }
                                Spacer()
                                Text(source.kind == .hls ? "HLS" : (source.url.pathExtension.isEmpty ? "VIDEO" : source.url.pathExtension.uppercased()))
                                    .font(.caption2.monospaced().bold()).foregroundStyle(Palette.accent)
                            }.padding(15)
                                .background(selected?.id == source.id ? Palette.accent.opacity(0.12) : Palette.panel, in: RoundedRectangle(cornerRadius: 17))
                                .overlay(RoundedRectangle(cornerRadius: 17).stroke(selected?.id == source.id ? Palette.accent.opacity(0.5) : Palette.line, lineWidth: 1))
                        }.buttonStyle(.plain)
                    }
                }
                Button("تحديث الروابط والجودات") { app.resolve(resultID) }.font(.footnote)
            }
        }
    }
    private var destinationSection: some View {
        Surface {
            VStack(alignment: .leading, spacing: 13) {
                Label("مكان الحفظ", systemImage: "folder").font(.headline)
                if vault.isUnlocked {
                    Picker("المجلد الداخلي", selection: $folder) {
                        Text("بدون مجلد").tag(nil as UUID?)
                        ForEach(vault.index.folders) { Text($0.name).tag(Optional($0.id)) }
                    }.pickerStyle(.menu)
                    DisclosureGroup("مجلد جديد") {
                        HStack {
                            TextField("اسم المجلد", text: $folderName).textInputAutocapitalization(.sentences)
                            Button { createFolder() } label: { Image(systemName: "plus.circle.fill").font(.title2) }
                                .disabled(folderName.trimmingCharacters(in: .whitespaces).isEmpty)
                        }.madarField().padding(.top, 8)
                    }.font(.subheadline)
                } else {
                    Text("سيُطلب رمزك قبل الحفظ. افتح المساحة الخاصة لاختيار مجلد موجود.").font(.footnote).foregroundStyle(Palette.muted)
                    Button("فتح لاختيار المجلد") { app.requestUnlock(.details(resultID)) }.buttonStyle(SoftStyle())
                }
            }
        }
    }
    private func createFolder() {
        do { folder = try vault.addFolder(folderName); folderName = "" }
        catch { app.alert = error.localizedDescription }
    }
}
