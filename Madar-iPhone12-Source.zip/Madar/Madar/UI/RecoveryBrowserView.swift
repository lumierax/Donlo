import SwiftUI
import WebKit
import UIKit

struct BrowserHost: UIViewRepresentable {
    let engine: BrowserEngine
    func makeUIView(context: Context) -> UIView {
        let view = UIView(); view.backgroundColor = .black
        attach(to: view); return view
    }
    func updateUIView(_ view: UIView, context: Context) { attach(to: view) }
    private func attach(to view: UIView) {
        guard engine.webView.superview !== view else { return }
        engine.webView.removeFromSuperview(); engine.webView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(engine.webView)
        NSLayoutConstraint.activate([
            engine.webView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            engine.webView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            engine.webView.topAnchor.constraint(equalTo: view.topAnchor),
            engine.webView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
    }
}
struct RecoveryBrowserView: View {
    @EnvironmentObject private var app: AppModel
    @EnvironmentObject private var browser: BrowserEngine
    @State private var address = ""
    @State private var confirmExternal = false
    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                VStack(alignment: .leading, spacing: 10) {
                    Text(app.interaction?.message ?? "أكمل الخطوة المطلوبة، ثم اضغط متابعة.")
                        .font(.footnote).foregroundStyle(Palette.muted).lineLimit(4)
                    HStack(spacing: 10) {
                        Image(systemName: "lock.shield").foregroundStyle(Palette.mint)
                        TextField("https://example.com", text: $address)
                            .keyboardType(.URL).textInputAutocapitalization(.never).autocorrectionDisabled()
                            .submitLabel(.go).onSubmit(navigate).environment(\.layoutDirection, .leftToRight)
                        Button(action: navigate) { Image(systemName: "arrow.clockwise") }.accessibilityLabel("فتح الرابط أو تحديث الصفحة")
                    }.font(.footnote).padding(11).background(Palette.inset, in: RoundedRectangle(cornerRadius: 12))
                    if let fieldNotice = browser.fieldNotice { Text(fieldNotice).font(.caption).foregroundStyle(Palette.mint) }
                    if browser.isRecordingSearch || browser.isPreparingSearchRecording {
                        HStack {
                            Label(browser.isRecordingSearch ? "تعليم البحث · \(browser.recordedSearchSteps.count) خطوات" : "تجهيز التعليم", systemImage: "record.circle")
                                .font(.caption.weight(.semibold))
                            Spacer()
                            Button("إلغاء التعليم") { browser.cancelSearchTeaching() }.font(.caption)
                        }
                    }
                }.padding(15).background(Palette.background)
                if browser.progress < 1 { ProgressView(value: browser.progress).tint(Palette.accent) }
                BrowserHost(engine: browser)
                HStack(spacing: 10) {
                    Button { browser.webView.goBack() } label: { Image(systemName: "chevron.backward").frame(width: 38, height: 44) }.accessibilityLabel("الصفحة السابقة")
                    Button { browser.webView.goForward() } label: { Image(systemName: "chevron.forward").frame(width: 38, height: 44) }.accessibilityLabel("الصفحة التالية")
                    Spacer(minLength: 0)
                    if app.interaction?.kind == .search {
                        Menu {
                            Button("تعليم خطوات البحث", systemImage: "hand.tap") { Task { await app.teachSearch() } }
                            Button("تحديد الخانة فقط", systemImage: "scope") { Task { await browser.chooseSearchField() } }
                            Button("اختبار المسار من البداية", systemImage: "arrow.clockwise") { app.retrySearchFromStart() }
                            Button("قراءة النتائج الحالية", systemImage: "list.bullet.rectangle") { app.useCurrentSearchResults() }
                        } label: { Label("إعداد البحث", systemImage: "slider.horizontal.3") }
                            .font(.footnote.weight(.semibold))
                            .disabled(browser.isRecordingSearch || browser.isPreparingSearchRecording)
                    }
                    Menu {
                        Button("فتح في المتصفح الافتراضي", systemImage: "arrow.up.forward.app") { confirmExternal = true }
                        Button("تحديث الصفحة", systemImage: "arrow.clockwise") { browser.webView.reload() }
                    } label: { Image(systemName: "ellipsis.circle").font(.title3).frame(width: 44, height: 44) }.accessibilityLabel("خيارات المتصفح")
                }.padding(.horizontal, 12).padding(.vertical, 5).background(Palette.background)
            }
            .navigationTitle("نافذة تدخل يدوي").navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) { Button("إلغاء") { browser.cancelSearchTeaching(); browser.visible = false; app.sheet = nil } }
                ToolbarItem(placement: .topBarTrailing) { Button("متابعة") { app.continueFromBrowser() }.fontWeight(.bold)
                    .disabled(browser.isRecordingSearch || browser.isPreparingSearchRecording) }
            }
            .onAppear { browser.visible = true; address = browser.webView.url?.absoluteString ?? browser.address }
            .onDisappear { browser.cancelSearchTeaching(); browser.visible = false }
            .onChange(of: browser.address) { _, value in address = value }
            .confirmationDialog("فتح المتصفح الخارجي؟", isPresented: $confirmExternal, titleVisibility: .visible) {
                Button("فتح الرابط خارجيًا") {
                    guard let url = browser.webView.url, url.scheme == "https" else { return }
                    UIApplication.shared.open(url, options: [:]) { success in
                        if !success { Task { @MainActor in app.alert = "تعذر فتح المتصفح الخارجي." } }
                    }
                }
                Button("إلغاء", role: .cancel) {}
            } message: {
                Text("سيفتح Brave إذا جعلته المتصفح الافتراضي. جلسة Brave منفصلة ولا تُنقل كوكيز التحقق إلى مدار؛ أكمل التحقق هنا عند الإمكان. الانتقال للخلفية يوقف أي تنزيل جارٍ.")
            }
        }
    }
    private func navigate() {
        Task { do { try await browser.load(URLTools.website(address)) } catch { app.alert = error.localizedDescription } }
    }
}
