import SwiftUI

struct WelcomeView: View {
    @EnvironmentObject private var app: AppModel
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 26) {
                OrbitMark(size: 74).padding(.top, 22)
                Text("أهلًا بك في مدار").font(.largeTitle.bold())
                Text("بحث واضح، وتنزيل داخلي، ومساحة لا تظهر في واجهة البحث.").font(.title3).foregroundStyle(Palette.muted)
                Surface {
                    VStack(alignment: .leading, spacing: 16) {
                        Label("طريقتك للدخول", systemImage: "hand.point.up.left").font(.headline)
                        Text("اضغط اسم «مدار» أعلى الشاشة ضغطًا مطوّلًا لمدة ثانيتين تقريبًا، ثم أدخل رمزك.").font(.body).lineSpacing(4)
                        Text("الإشارة المخفية ليست الحماية: ملفاتك وفهرسها مشفّران، والرمز هو مفتاح الوصول.").font(.footnote).foregroundStyle(Palette.muted)
                    }
                }
                Text("احفظ رمزك جيدًا. لا يوجد رمز افتراضي أو باب خلفي لاستعادته. حذف التطبيق يحذف ملفاته المحلية؛ لا تُنسخ المساحة الخاصة احتياطيًا إلى iCloud.")
                    .font(.footnote).foregroundStyle(Palette.muted).lineSpacing(4)
                Button { app.welcomeDone(setup: true) } label: { Text("إنشاء رمز خاص") }.buttonStyle(PrimaryStyle())
                Button("إعداد الرمز لاحقًا") { app.welcomeDone(setup: false) }.frame(maxWidth: .infinity)
            }.padding(24)
        }.background(MadarBackground())
    }
}
struct UnlockView: View {
    @EnvironmentObject private var app: AppModel
    @EnvironmentObject private var vault: VaultStore
    @State private var passphrase = ""
    @State private var confirmation = ""
    @State private var enableFaceID = false
    @State private var busy = false
    @State private var error: String?
    @State private var task: Task<Void, Never>?
    @FocusState private var focused: Bool
    private var creating: Bool { !vault.isConfigured }
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 22) {
                    ZStack {
                        RoundedRectangle(cornerRadius: 25).fill(Palette.accent.opacity(0.12)).frame(width: 82, height: 82)
                        Image(systemName: "lock.shield").font(.system(size: 37, weight: .light)).foregroundStyle(Palette.accent)
                    }.padding(.top, 24)
                    VStack(alignment: .leading, spacing: 9) {
                        Text(creating ? "هذه المساحة لك وحدك" : "مرحبًا بعودتك").font(.largeTitle.bold())
                        Text(creating ? "اختر رمزًا من 8 أحرف على الأقل. عبارة مرور طويلة أفضل من أرقام قصيرة." : "أدخل رمز المساحة الخاصة للمتابعة.")
                            .font(.subheadline).foregroundStyle(Palette.muted).lineSpacing(4)
                    }
                    VStack(spacing: 12) {
                        SecureField(creating ? "الرمز الجديد" : "رمزك الخاص", text: $passphrase)
                            .textContentType(creating ? .newPassword : .password)
                            .textInputAutocapitalization(.never).autocorrectionDisabled().focused($focused)
                            .submitLabel(creating ? .next : .go).onSubmit { if !creating { submit() } }.madarField()
                        if creating {
                            SecureField("أعد كتابة الرمز", text: $confirmation).textContentType(.newPassword)
                                .textInputAutocapitalization(.never).autocorrectionDisabled().submitLabel(.go).onSubmit(submit).madarField()
                            Toggle("تفعيل Face ID لهذا الجهاز", isOn: $enableFaceID).font(.subheadline).padding(.vertical, 7)
                        }
                    }
                    if let error { Label(error, systemImage: "exclamationmark.circle").font(.footnote).foregroundStyle(.orange) }
                    Button(action: submit) {
                        HStack { if busy { ProgressView().tint(.white) }; Text(creating ? "إنشاء المساحة الخاصة" : "فتح المساحة") }
                    }.buttonStyle(PrimaryStyle()).disabled(busy || passphrase.isEmpty)
                    if !creating && vault.biometricEnabled {
                        Button { biometric() } label: { Label("فتح باستخدام Face ID", systemImage: "faceid").frame(maxWidth: .infinity) }.buttonStyle(SoftStyle()).disabled(busy)
                    }
                    if creating {
                        Text("لن يُرسل رمزك أو مفتاحك إلى أي خادم. لا يمكن استعادة الملفات عند فقدان الرمز ووسيلة الدخول الحيوية.")
                            .font(.footnote).foregroundStyle(Palette.muted).lineSpacing(4)
                    }
                    Text("يُقفل المحتوى عند انتقال التطبيق إلى الخلفية. لا تحمي هذه الميزة من جهاز مخترق أو تصوير الشاشة أثناء فتحها.")
                        .font(.caption).foregroundStyle(Palette.muted).lineSpacing(3)
                }.padding(24)
            }.scrollDismissesKeyboard(.interactively).background(MadarBackground())
                .navigationTitle(creating ? "إعداد الحماية" : "فتح خاص").navigationBarTitleDisplayMode(.inline)
                .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("إلغاء") { task?.cancel(); app.cancelUnlock() }.disabled(busy) } }
                .interactiveDismissDisabled(busy)
                .onDisappear { task?.cancel(); passphrase = ""; confirmation = "" }
        }
    }
    private func submit() {
        guard !busy else { return }
        if creating && passphrase != confirmation { error = "الرمزان غير متطابقين."; return }
        busy = true; error = nil; focused = false
        let secret = passphrase, setup = creating
        task = Task {
            do {
                if setup {
                    try await vault.configure(passphrase: secret)
                    if enableFaceID {
                        do { try await vault.setBiometric(true) }
                        catch { app.alert = "أُنشئ الرمز، لكن Face ID لم يتفعّل: " + error.localizedDescription }
                    }
                } else { try await vault.unlock(passphrase: secret) }
                try Task.checkCancellation(); passphrase = ""; confirmation = ""; busy = false; app.unlockFinished()
            } catch { self.error = error.localizedDescription; busy = false }
        }
    }
    private func biometric() {
        busy = true; error = nil; focused = false
        task = Task {
            do { try await vault.unlockBiometric(); try Task.checkCancellation(); busy = false; app.unlockFinished() }
            catch { self.error = error.localizedDescription; busy = false }
        }
    }
}
