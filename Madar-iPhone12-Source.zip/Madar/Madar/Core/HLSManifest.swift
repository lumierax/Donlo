import Foundation

public struct HLSManifest: Sendable {
    public var variants: [MediaSource]
    public var encrypted: Bool
    public var isLive: Bool
    public var hasExternalAudio: Bool
    public static func parse(_ text: String, base: URL) throws -> HLSManifest {
        guard text.trimmingCharacters(in: .whitespacesAndNewlines).hasPrefix("#EXTM3U") else {
            throw MadarError.message("الرد ليس قائمة HLS صالحة؛ قد يكون صفحة تحقق بدل الفيديو.")
        }
        let lines = text.components(separatedBy: .newlines).map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
        var variants: [MediaSource] = []; var pending: String?
        var encrypted = false; var externalAudio = false
        for line in lines {
            if line.hasPrefix("#EXT-X-KEY:") || line.hasPrefix("#EXT-X-SESSION-KEY:") {
                if !line.contains("METHOD=NONE") { encrypted = true }
            }
            if line.hasPrefix("#EXT-X-MEDIA:"), line.contains("TYPE=AUDIO"), line.contains("URI=") { externalAudio = true }
            if line.hasPrefix("#EXT-X-STREAM-INF:") { pending = line; continue }
            if !line.isEmpty, !line.hasPrefix("#"), let attrs = pending {
                if let url = URLTools.candidate(line, base: base) {
                    let height = URLTools.matches(#"RESOLUTION=\d+x(\d+)"#, attrs).first.flatMap { Int($0[1]) }
                    variants.append(MediaSource(url: url, kind: .hls, height: height, evidence: "HLS master"))
                }
                pending = nil
            }
        }
        return HLSManifest(variants: URLTools.unique(variants), encrypted: encrypted,
                           isLive: variants.isEmpty && !lines.contains("#EXT-X-ENDLIST"), hasExternalAudio: externalAudio)
    }
}
