import Foundation

public enum SearchTemplate {
    public static func url(template: String, keyword: String, base: URL) throws -> URL {
        guard template.contains("{query}") else { throw MadarError.message("ضع {query} مكان كلمة البحث في الرابط.") }
        let allowed = CharacterSet.alphanumerics.union(CharacterSet(charactersIn: "-._~"))
        guard let encoded = keyword.addingPercentEncoding(withAllowedCharacters: allowed),
              let url = URLTools.candidate(template.replacingOccurrences(of: "{query}", with: encoded), base: base),
              URLTools.sameSite(url, base) else {
            throw MadarError.message("يجب أن يكون رابط البحث HTTPS ومن الموقع نفسه.")
        }
        return url
    }
    /// Learn only an exact, user-observed query item. Never invent a site's search route.
    public static func learned(from url: URL, keyword: String) -> String? {
        guard !keyword.isEmpty, var c = URLComponents(url: url, resolvingAgainstBaseURL: true),
              let items = c.queryItems,
              !items.contains(where: { $0.name.range(of: "token|session|csrf|auth|password|^sid$", options: [.regularExpression, .caseInsensitive]) != nil }),
              items.contains(where: { $0.value == keyword }) else { return nil }
        c.queryItems = items.map { item in
            item.value == keyword ? URLQueryItem(name: item.name, value: "MADAR_QUERY_PLACEHOLDER") : item
        }
        return c.url?.absoluteString.replacingOccurrences(of: "MADAR_QUERY_PLACEHOLDER", with: "{query}")
    }
}
