import Foundation

public enum SearchTemplate {
    public static func url(template: String, keyword: String, base: URL) throws -> URL {
        guard template.contains("{query}") else { throw MadarError.message("ضع {query} مكان كلمة البحث في الرابط.") }
        let allowed = CharacterSet.alphanumerics.union(CharacterSet(charactersIn: "-._~"))
        guard let encoded = keyword.addingPercentEncoding(withAllowedCharacters: allowed),
              let url = URLTools.candidate(template.replacingOccurrences(of: "{query}", with: encoded), base: base),
              URLTools.sameSite(url, base) else {
            throw MadarError.message("يجب أن يكون رابط البحث HTTPS ومن الموقع نفسه.")
        }
        return url
    }
    /// Learn only an exact, user-observed query item. Never invent a site's search route.
    public static func learned(from url: URL, keyword: String) -> String? {
        guard !keyword.isEmpty, var c = URLComponents(url: url, resolvingAgainstBaseURL: true),
              let items = c.queryItems,
              !items.contains(where: { $0.name.range(of: "token|session|csrf|auth|password|^sid$", options: [.regularExpression, .caseInsensitive]) != nil }),
              items.contains(where: { $0.value == keyword }) else { return nil }
        c.queryItems = items.map { item in
            item.value == keyword ? URLQueryItem(name: item.name, value: "MADAR_QUERY_PLACEHOLDER") : item
        }
        return c.url?.absoluteString.replacingOccurrences(of: "MADAR_QUERY_PLACEHOLDER", with: "{query}")
    }
}

/// Shared validation for the settings editor and WebKit replay. A workflow is not arbitrary JavaScript.
public enum SearchWorkflow {
    public static let maximumSteps = 8
    public static func startURL(stored: String?, base: URL) throws -> URL {
        let value = stored?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        guard let url = URLTools.candidate(value.isEmpty ? base.absoluteString : value, base: base),
              URLTools.sameSite(url, base) else {
            throw MadarError.message("يجب أن تكون صفحة بدء خطوات البحث HTTPS ومن الموقع نفسه.")
        }
        let sensitive = "token|session|csrf|auth|password|secret|^sid$"
        if URLComponents(url: url, resolvingAgainstBaseURL: false)?.queryItems?.contains(where: {
            $0.name.range(of: sensitive, options: [.regularExpression, .caseInsensitive]) != nil
        }) == true {
            throw MadarError.message("صفحة البدء تحتوي معلمة جلسة أو رمزًا حساسًا. استخدم رابطًا عامًا للموقع.")
        }
        return url
    }
    public static func validate(steps: [SearchStep], field: String?) throws {
        guard steps.count <= maximumSteps else { throw MadarError.message("الحد الأقصى ثماني خطوات لفتح البحث.") }
        for step in steps {
            guard !step.selector.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty,
                  step.selector.count < 1000, step.label.count <= 100 else {
                throw MadarError.message("إحدى خطوات البحث فارغة أو أطول من المسموح.")
            }
        }
        if !steps.isEmpty {
            guard let field, !field.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty, field.count < 1000 else {
                throw MadarError.message("حدد خانة البحث النهائية مع خطوات الفتح.")
            }
        }
    }
    public static func timeout(_ saved: Double?) -> Double {
        guard let saved, saved.isFinite else { return 5 }
        return min(12, max(2, saved))
    }
}
