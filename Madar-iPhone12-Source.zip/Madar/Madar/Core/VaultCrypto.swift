#if canImport(CryptoKit) && canImport(CommonCrypto) && canImport(Security)
import Foundation
import CryptoKit
import CommonCrypto
import Security

public enum VaultCrypto {
    public static let rounds: UInt32 = 600_000
    public static func random(_ count: Int) throws -> Data {
        var data = Data(count: count)
        let status = data.withUnsafeMutableBytes { SecRandomCopyBytes(kSecRandomDefault, count, $0.baseAddress!) }
        guard status == errSecSuccess else { throw MadarError.message("تعذر إنشاء مفتاح آمن.") }
        return data
    }
    public static func derive(passphrase: String, salt: Data, rounds: UInt32 = rounds) throws -> SymmetricKey {
        guard !passphrase.isEmpty, salt.count >= 16, (100_000...2_000_000).contains(rounds) else { throw MadarError.message("بيانات المفتاح غير صالحة.") }
        let password = Array(passphrase.utf8)
        let outputLength = 32
        var output = [UInt8](repeating: 0, count: outputLength)
        let result = password.withUnsafeBytes { p in
            salt.withUnsafeBytes { s in
                CCKeyDerivationPBKDF(CCPBKDFAlgorithm(kCCPBKDF2), p.baseAddress!.assumingMemoryBound(to: Int8.self), password.count,
                    s.baseAddress!.assumingMemoryBound(to: UInt8.self), salt.count,
                    CCPseudoRandomAlgorithm(kCCPRFHmacAlgSHA256), rounds, &output, outputLength)
            }
        }
        guard result == kCCSuccess else { throw MadarError.message("تعذر اشتقاق مفتاح الحماية.") }
        return SymmetricKey(data: output)
    }
    public static func seal(_ data: Data, key: SymmetricKey, context: String) throws -> Data {
        guard let combined = try AES.GCM.seal(data, using: key, authenticating: Data(context.utf8)).combined else {
            throw MadarError.message("تعذر تشفير البيانات.")
        }
        return combined
    }
    public static func open(_ data: Data, key: SymmetricKey, context: String) throws -> Data {
        try AES.GCM.open(AES.GCM.SealedBox(combined: data), using: key, authenticating: Data(context.utf8))
    }
}

/// Fixed-size independently authenticated chunks allow AVPlayer random access
/// without writing a decrypted video to disk. Header and position are authenticated.
public enum ChunkCipher {
    public static let chunkSize = 1_048_576
    public static let headerSize = 36
    public static let overhead = 28 // AES.GCM combined: 12-byte nonce + 16-byte tag.
    public struct Header {
        public let raw: Data
        public let size: UInt64
        public let chunk: Int
        public let salt: Data
    }
    private static func le<T: FixedWidthInteger>(_ value: T) -> Data {
        var x = value.littleEndian; return withUnsafeBytes(of: &x) { Data($0) }
    }
    private static func number(_ data: Data) -> UInt64 {
        data.enumerated().reduce(UInt64(0)) { $0 | (UInt64($1.element) << UInt64($1.offset * 8)) }
    }
    public static func readHeader(_ file: FileHandle) throws -> Header {
        try file.seek(toOffset: 0)
        guard let raw = try file.read(upToCount: headerSize), raw.count == headerSize,
              raw.prefix(8) == Data("MDVLT001".utf8) else { throw MadarError.message("الملف المشفّر غير صالح.") }
        let chunk = Int(number(raw.subdata(in: 24..<28))), size = number(raw.subdata(in: 28..<36))
        guard chunk == chunkSize, size > 0, size < 512 * 1_024 * 1_024 * 1_024 else { throw MadarError.message("حجم ملف غير صالح.") }
        let actual = try file.seekToEnd()
        let count = (size + UInt64(chunk) - 1) / UInt64(chunk)
        guard actual == UInt64(headerSize) + size + count * UInt64(overhead) else { throw MadarError.message("الملف غير مكتمل أو تعرّض للتعديل.") }
        return Header(raw: raw, size: size, chunk: chunk, salt: raw.subdata(in: 8..<24))
    }
    private static func fileKey(_ key: SymmetricKey, salt: Data) -> SymmetricKey {
        HKDF<SHA256>.deriveKey(inputKeyMaterial: key, salt: salt, info: Data("Madar.file.v1".utf8), outputByteCount: 32)
    }
    public static func encrypt(input: URL, output: URL, key: SymmetricKey, progress: @Sendable (Double) -> Void = { _ in }) throws -> UInt64 {
        let source = try FileHandle(forReadingFrom: input); defer { try? source.close() }
        let size = try source.seekToEnd(); try source.seek(toOffset: 0)
        guard size > 0, size < 512 * 1_024 * 1_024 * 1_024 else { throw MadarError.message("الفيديو فارغ أو حجمه غير مدعوم.") }
        let salt = try VaultCrypto.random(16)
        let header = Data("MDVLT001".utf8) + salt + le(UInt32(chunkSize)) + le(size)
        let derived = fileKey(key, salt: salt)
        guard FileManager.default.createFile(atPath: output.path, contents: nil, attributes: nil) else { throw MadarError.message("تعذر إنشاء الملف؛ راجع المساحة المتاحة.") }
        let target = try FileHandle(forWritingTo: output); defer { try? target.close() }
        var succeeded = false
        defer { if !succeeded { try? FileManager.default.removeItem(at: output) } }
        try target.write(contentsOf: header)
        var read: UInt64 = 0; var index: UInt64 = 0
        while read < size {
            try Task.checkCancellation()
            guard let data = try source.read(upToCount: min(chunkSize, Int(size - read))), !data.isEmpty else {
                throw MadarError.message("تعذر إكمال قراءة الملف المؤقت.")
            }
            guard let sealed = try AES.GCM.seal(data, using: derived, authenticating: header + le(index)).combined else {
                throw MadarError.message("تعذر تشفير جزء من الملف.")
            }
            try target.write(contentsOf: sealed)
            read += UInt64(data.count); index += 1; progress(Double(read) / Double(size))
        }
        try target.synchronize(); succeeded = true
        return size
    }
    public static func read(file: FileHandle, header: Header, key: SymmetricKey, offset: UInt64, count: Int) throws -> Data {
        guard offset <= header.size, count >= 0 else { throw MadarError.message("نطاق قراءة غير صالح.") }
        let length = min(UInt64(count), header.size - offset)
        guard length <= 16 * 1_024 * 1_024 else { throw MadarError.message("طلب قراءة أكبر من الحد المسموح.") }
        if length == 0 { return Data() }
        let first = offset / UInt64(header.chunk), last = (offset + length - 1) / UInt64(header.chunk)
        let derived = fileKey(key, salt: header.salt)
        var result = Data(); result.reserveCapacity(Int(length))
        for index in first...last {
            let chunkStart = index * UInt64(header.chunk)
            let plainLength = min(UInt64(header.chunk), header.size - chunkStart)
            try file.seek(toOffset: UInt64(headerSize) + index * UInt64(header.chunk + overhead))
            guard let record = try file.read(upToCount: Int(plainLength) + overhead), record.count == Int(plainLength) + overhead else {
                throw MadarError.message("جزء من الملف مفقود.")
            }
            let plain = try AES.GCM.open(AES.GCM.SealedBox(combined: record), using: derived, authenticating: header.raw + le(index))
            let begin = Int(max(offset, chunkStart) - chunkStart)
            let end = Int(min(offset + length, chunkStart + plainLength) - chunkStart)
            result.append(plain.subdata(in: begin..<end))
        }
        return result
    }
}
#endif
