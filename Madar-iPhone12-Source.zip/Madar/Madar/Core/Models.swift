import Foundation

public enum MediaKind: String, Codable, Sendable { case file, hls, dash }

public struct MediaSource: Identifiable, Codable, Hashable, Sendable {
    public var url: URL
    public var kind: MediaKind
    public var height: Int?
    public var label: String?
    public var evidence: String
    /// Page/frame that actually supplied this source; never a raw Cookie header.
    public var requestReferer: URL?
    public var id: String { url.absoluteString }
    public var quality: String { height.map { "\($0)p" } ?? label ?? (kind == .hls ? "HLS · تلقائي" : "الجودة الأصلية") }
    public init(url: URL, kind: MediaKind = .file, height: Int? = nil, label: String? = nil, evidence: String = "page", requestReferer: URL? = nil) {
        self.url = url; self.kind = kind; self.height = height; self.label = label; self.evidence = evidence; self.requestReferer = requestReferer
    }
}

public enum ResolutionState: String, Codable, Sendable {
    case pending, resolving, ready, needsInteraction, unavailable, failed
    public var title: String {
        switch self {
        case .pending: return "افحص الجودات"
        case .resolving: return "جارٍ فحص الجودات"
        case .ready: return "جاهز للتنزيل"
        case .needsInteraction: return "يحتاج خطوة منك"
        case .unavailable: return "لا يوجد مصدر مدعوم"
        case .failed: return "تعذر الفحص"
        }
    }
}

public struct VideoResult: Identifiable, Codable, Sendable {
    public var pageURL: URL
    public var title: String
    public var thumbnailURL: URL?
    public var duration: String?
    public var sources: [MediaSource] = []
    public var state: ResolutionState = .pending
    public var note: String?
    public var id: String { pageURL.absoluteString }
    public init(pageURL: URL, title: String, thumbnailURL: URL? = nil, duration: String? = nil) {
        self.pageURL = pageURL; self.title = URLTools.videoTitle(title, page: pageURL); self.thumbnailURL = thumbnailURL; self.duration = duration
    }
}

public struct SiteProfile: Identifiable, Codable, Sendable, Equatable {
    public var host: String
    public var searchTemplate: String?
    public var searchSelector: String?
    public var resultSelector: String?
    public var id: String { host }
    public init(host: String, searchTemplate: String? = nil, searchSelector: String? = nil, resultSelector: String? = nil) {
        self.host = host; self.searchTemplate = searchTemplate; self.searchSelector = searchSelector; self.resultSelector = resultSelector
    }
}

public struct VaultFolder: Identifiable, Codable, Hashable, Sendable {
    public var id: UUID
    public var name: String
    public init(id: UUID = UUID(), name: String) { self.id = id; self.name = name }
}
public struct VaultEntry: Identifiable, Codable, Sendable {
    public var id: UUID
    public var title: String
    public var fileExtension: String
    public var bytes: Int64
    public var createdAt: Date
    public var folderID: UUID?
    public var quality: String
    public var fileName: String { id.uuidString + ".mdv" }
    public init(id: UUID, title: String, fileExtension: String, bytes: Int64, folderID: UUID?, quality: String) {
        self.id = id; self.title = title; self.fileExtension = fileExtension; self.bytes = bytes
        self.folderID = folderID; self.quality = quality; self.createdAt = Date()
    }
}
public struct VaultIndex: Codable, Sendable {
    public var entries: [VaultEntry] = []
    public var folders: [VaultFolder] = []
    public init() {}
}

public enum MadarError: LocalizedError, Equatable {
    case invalidURL, insecureURL, unsupported, locked, badResponse(Int), message(String)
    public var errorDescription: String? {
        switch self {
        case .invalidURL: return "الرابط غير صالح. استخدم رابط موقع كاملًا."
        case .insecureURL: return "هذا الإصدار يقبل HTTPS فقط لحماية اتصالك."
        case .unsupported: return "لم يُعثر على ملف فيديو أو بث HLS قابل للتنزيل."
        case .locked: return "افتح المساحة الخاصة أولًا."
        case .badResponse(let code): return "رفض الخادم الطلب (\(code)). قد يحتاج تحققًا أو رابطًا جديدًا."
        case .message(let message): return message
        }
    }
}

/// A server refusal is not the same as a temporary network failure.
public struct HTTPFailure: LocalizedError, Sendable {
    public let status: Int
    public let retryAfter: TimeInterval?
    public init(status: Int, retryAfter: TimeInterval? = nil) { self.status = status; self.retryAfter = retryAfter }
    public var errorDescription: String? {
        if status == 429 { return "طلب الخادم تخفيف الطلبات (429). أعد المحاولة لاحقًا إذا طال الانتظار." }
        return "رفض الخادم الطلب (\(status)). قد تحتاج الصفحة تحققًا أو رابطًا جديدًا."
    }
}

public enum DownloadContentError: LocalizedError {
    case notVideo, empty, partial, unreadable
    public var errorDescription: String? {
        switch self {
        case .notVideo: return "الخادم أرسل صفحة أو رسالة بدل الفيديو. افتح صفحة الفيديو وأعد فحص المصدر."
        case .empty: return "أعاد الخادم ملفًا فارغًا؛ لم يُحفظ كفيديو."
        case .partial: return "الرد يحتوي جزءًا من الملف فقط؛ لم يُحفظ كفيديو مكتمل."
        case .unreadable: return "الملف لا يحتوي فيديو قابلًا للقراءة على هذا الجهاز. اختر مصدرًا آخر من صفحة الفيديو."
        }
    }
}
