import Foundation

/// New implementation of the two supplied projects' extraction strategies.
/// This parses data and literal concatenations only. It never evals page JavaScript.
public enum MediaExtractor {
    public static func extract(_ html: String, base: URL) -> [MediaSource] {
        let source = URLTools.decoded(String(html.prefix(6_000_000)))
        var output: [MediaSource] = []
        func add(_ raw: String, _ evidence: String, _ height: Int? = nil, _ kind: MediaKind? = nil) {
            guard let url = URLTools.candidate(raw, base: base), let type = (kind == .file ? (URLTools.mediaKind(url) ?? .file) : (kind ?? URLTools.mediaKind(url))) else { return }
            output.append(MediaSource(url: url, kind: type, height: height ?? URLTools.height(raw), evidence: evidence, requestReferer: base))
        }
        // A media element's src or an explicit media MIME type can be extensionless.
        func attributes(_ tag: String) -> [String: String] {
            var values: [String: String] = [:]
            for row in URLTools.matches(#"([\w:-]+)\s*=\s*["']([^"']*)["']"#, tag) { values[row[1].lowercased()] = row[2] }
            return values
        }
        for row in URLTools.matches(#"<(video|source)\b[^>]*>"#, html, options: .caseInsensitive) {
            let attrs = attributes(row[0])
            let declared = attrs["type"]
            let kind = URLTools.mediaKind(mimeType: declared)
            if let raw = attrs["src"] ?? attrs["data-src"] ?? attrs["data-file"] {
                // A <video> source is already strong evidence; its container does not need to be on a whitelist.
                let tag = row[1].lowercased()
                let candidate = URLTools.candidate(raw, base: base)
                let explicitVideo = tag == "video" || declared?.lowercased().hasPrefix("video/") == true ||
                    (tag == "source" && candidate?.pathExtension.isEmpty == false)
                add(raw, "media element", nil, kind ?? (explicitVideo ? .file : nil))
            }
        }
        // Untyped <source> is usable as video only inside a video element (not audio).
        for block in URLTools.matches(#"<video\b[^>]*>[\s\S]*?</video>"#, html, options: .caseInsensitive) {
            for row in URLTools.matches(#"<source\b[^>]*>"#, block[0], options: .caseInsensitive) {
                let attrs = attributes(row[0])
                if let raw = attrs["src"] ?? attrs["data-src"] {
                    // Being inside <video> is enough evidence even for an unknown/new MIME or extension.
                    add(raw, "video source element", nil, URLTools.mediaKind(mimeType: attrs["type"]) ?? .file)
                }
            }
        }
        var meta: [String: String] = [:]
        for row in URLTools.matches(#"<meta\b[^>]*>"#, html, options: .caseInsensitive) {
            let attrs = attributes(row[0])
            if let key = attrs["property"] ?? attrs["name"], let content = attrs["content"] { meta[key.lowercased()] = content }
        }
        for key in ["og:video", "og:video:url", "og:video:secure_url", "twitter:player:stream"] {
            if let raw = meta[key] { add(raw, "video metadata", nil, URLTools.mediaKind(mimeType: meta["og:video:type"] ?? meta["twitter:player:stream:content_type"])) }
        }
        for m in URLTools.matches(#"https?://[^\s\"'<>`\\]+"#, source) { add(m[0], "direct URL") }
        for m in URLTools.matches(#"(?:src|file|href|data-src|data-file)\s*=\s*[\"']([^\"']+)[\"']"#, source, options: .caseInsensitive) {
            add(m[1], "HTML attribute")
        }
        for m in URLTools.matches(#"[\"']?(?:url|src|file|videoUrl|video_url|contentUrl|hls|manifest)[\"']?\s*:\s*[\"']([^\"']+)[\"']"#, source) {
            add(m[1], "player field")
        }
        func walk(_ object: Any, depth: Int = 0) {
            guard depth < 16 else { return }
            if let a = object as? [Any] { for x in a { walk(x, depth: depth + 1) }; return }
            guard let d = object as? [String: Any] else { return }
            let quality = (d["quality"] as? String).flatMap(Int.init) ?? (d["quality"] as? Int) ?? (d["height"] as? Int)
            let format = (d["format"] as? String ?? d["type"] as? String ?? "").lowercased()
            let kind = URLTools.mediaKind(mimeType: format)
            for (key, value) in d {
                if let raw = value as? String, ["url", "src", "file", "videourl", "video_url", "contenturl", "downloadurl"].contains(key.lowercased()) {
                    let videoObject = (d["@type"] as? String == "VideoObject") || (d["@type"] as? [String] ?? []).contains("VideoObject")
                    let explicitVideo = videoObject && ["contenturl", "downloadurl"].contains(key.lowercased())
                    let videoKey = ["videourl", "video_url", "contenturl", "downloadurl"].contains(key.lowercased())
                    add(raw, "JSON metadata", quality, kind ?? ((explicitVideo || videoKey || !format.isEmpty) ? .file : nil))
                }
                walk(value, depth: depth + 1)
            }
        }
        for m in URLTools.matches(#"<script[^>]*type\s*=\s*[\"']application/(?:ld\+)?json[\"'][^>]*>([\s\S]*?)</script>"#, html, options: .caseInsensitive) {
            if let data = m[1].data(using: .utf8), let object = try? JSONSerialization.jsonObject(with: data) { walk(object) }
        }
        // mediaDefinitions is often a strict JSON array inside a JS player configuration.
        for m in URLTools.matches(#"[\"']?mediaDefinitions[\"']?\s*:\s*(\[[\s\S]*?\])"#, html) {
            if let data = m[1].data(using: .utf8), let object = try? JSONSerialization.jsonObject(with: data) { walk(object) }
        }
        for value in resolveLiteralAssignments(source) { add(value, "static JS concatenation", nil, .file) }
        // Compatibility with the second supplied archive's comment-marked, split URL format.
        var combined: String?
        for m in URLTools.matches(#"\*/\s*[A-Za-z_$][\w$]*\s*=\s*([^;\n]+)"#, source) {
            guard let value = literalExpression(m[1], names: [:]) else { continue }
            if value.hasPrefix("https://") {
                if let old = combined { add(old, "legacy split URL", nil, .file) }
                combined = value
            } else if combined != nil { combined! += value }
        }
        if let combined { add(combined, "legacy split URL", nil, .file) }
        return URLTools.unique(output)
    }

    static func resolveLiteralAssignments(_ source: String) -> [String] {
        let assignments = URLTools.matches(#"(?:\b(?:var|let|const)\s+|(?<=;)\s*)([A-Za-z_$][\w$]*)\s*=\s*([^;\n]{1,16000})"#, source)
        var names: [String: String] = [:]
        for _ in 0..<min(assignments.count + 1, 24) {
            var changed = false
            for m in assignments where names[m[1]] == nil {
                if let value = literalExpression(m[2], names: names), value.utf8.count <= 32_768 {
                    names[m[1]] = value; changed = true
                }
            }
            if !changed { break }
        }
        return Array(names.values)
    }
    static func literalExpression(_ expression: String, names: [String: String]) -> String? {
        var parts: [String] = []; var token = ""; var quote: Character?; var escaped = false
        for ch in expression.trimmingCharacters(in: .whitespacesAndNewlines) {
            if let q = quote {
                token.append(ch)
                if escaped { escaped = false }
                else if ch == "\\" { escaped = true }
                else if ch == q { quote = nil }
            } else if ch == "\"" || ch == "'" { quote = ch; token.append(ch) }
            else if ch == "+" { parts.append(token); token = "" }
            else { token.append(ch) }
        }
        guard quote == nil else { return nil }
        parts.append(token)
        var result = ""
        for part in parts {
            let p = part.trimmingCharacters(in: .whitespacesAndNewlines)
            if p.count >= 2, let first = p.first, (first == "\"" || first == "'"), p.last == first {
                // A token must contain exactly one quoted literal, not an expression or function call.
                let pattern = first == "\"" ? #"^\"(?:[^\"\\]|\\.)*\"$"# : #"^'(?:[^'\\]|\\.)*'$"#
                guard !URLTools.matches(pattern, p).isEmpty else { return nil }
                result += URLTools.decoded(String(p.dropFirst().dropLast()))
                    .replacingOccurrences(of: "\\\"", with: "\"").replacingOccurrences(of: "\\'", with: "'")
            } else if let value = names[p] { result += value }
            else { return nil }
            if result.utf8.count > 32_768 { return nil }
        }
        return result
    }
}
