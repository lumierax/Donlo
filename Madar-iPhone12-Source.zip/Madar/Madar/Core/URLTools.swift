import Foundation

public enum URLTools {
    public static func website(_ raw: String) throws -> URL {
        var text = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        if !text.contains("://") { text = "https://" + text }
        guard let url = URL(string: text), let host = url.host, !host.isEmpty,
              url.user == nil, url.password == nil else { throw MadarError.invalidURL }
        guard url.scheme?.lowercased() == "https" else { throw MadarError.insecureURL }
        return url
    }
    public static func decoded(_ raw: String) -> String {
        var text = raw.replacingOccurrences(of: "&amp;", with: "&")
            .replacingOccurrences(of: "&#38;", with: "&")
            .replacingOccurrences(of: "&quot;", with: "\"")
            .replacingOccurrences(of: "&#39;", with: "'")
            .replacingOccurrences(of: "\\/", with: "/")
        for pair in [("\\u0026", "&"), ("\\u003a", ":"), ("\\u002f", "/"), ("\\x3a", ":"), ("\\x2f", "/"), ("\\x26", "&")] {
            text = text.replacingOccurrences(of: pair.0, with: pair.1, options: .caseInsensitive)
        }
        return text
    }
    public static func candidate(_ raw: String, base: URL) -> URL? {
        let text = decoded(raw).trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty, text.count <= 16_384,
              let url = URL(string: text, relativeTo: base)?.absoluteURL,
              url.scheme?.lowercased() == "https", url.host != nil,
              url.user == nil, url.password == nil else { return nil }
        return url
    }
    public static func mediaKind(_ url: URL) -> MediaKind? {
        switch url.pathExtension.lowercased() {
        case "mp4", "m4v", "mov", "webm": return .file
        case "m3u8": return .hls
        case "mpd": return .dash
        default: return nil
        }
    }
    public static func height(_ text: String) -> Int? {
        if let m = matches(#"(?:^|[^0-9])(2160|1440|1080|720|576|540|480|360|240|144)[pP](?:[^0-9]|$)"#, text).first,
           m.count > 1 { return Int(m[1]) }
        if let m = matches(#"\b\d{2,5}[xX](\d{2,5})\b"#, text).first, m.count > 1 { return Int(m[1]) }
        return nil
    }
    public static func matches(_ pattern: String, _ text: String, options: NSRegularExpression.Options = []) -> [[String]] {
        guard let regex = try? NSRegularExpression(pattern: pattern, options: options) else { return [] }
        let ns = text as NSString
        return regex.matches(in: text, range: NSRange(location: 0, length: ns.length)).map { match in
            (0..<match.numberOfRanges).map { i in
                let r = match.range(at: i); return r.location == NSNotFound ? "" : ns.substring(with: r)
            }
        }
    }
    public static func sameSite(_ a: URL, _ b: URL) -> Bool {
        func host(_ u: URL) -> String { (u.host ?? "").lowercased().replacingOccurrences(of: #"^www\."#, with: "", options: .regularExpression) }
        return !host(a).isEmpty && host(a) == host(b)
    }
    public static func unique(_ sources: [MediaSource]) -> [MediaSource] {
        var out: [MediaSource] = []; var positions: [String: Int] = [:]
        for source in sources {
            if let i = positions[source.id] {
                if out[i].height == nil { out[i].height = source.height }
                if out[i].label == nil { out[i].label = source.label }
            } else { positions[source.id] = out.count; out.append(source) }
        }
        return out.sorted { ($0.height ?? 0) > ($1.height ?? 0) }
    }
}
