import Foundation

public enum URLTools {
    public static func website(_ raw: String) throws -> URL {
        var text = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        if !text.contains("://") { text = "https://" + text }
        guard let url = URL(string: text), let host = url.host, !host.isEmpty,
              url.user == nil, url.password == nil else { throw MadarError.invalidURL }
        guard url.scheme?.lowercased() == "https" else { throw MadarError.insecureURL }
        return url
    }
    public static func decoded(_ raw: String) -> String {
        var text = raw.replacingOccurrences(of: "&amp;", with: "&")
            .replacingOccurrences(of: "&#38;", with: "&")
            .replacingOccurrences(of: "&quot;", with: "\"")
            .replacingOccurrences(of: "&#39;", with: "'")
            .replacingOccurrences(of: "\\/", with: "/")
        for pair in [("\\u0026", "&"), ("\\u003a", ":"), ("\\u002f", "/"), ("\\x3a", ":"), ("\\x2f", "/"), ("\\x26", "&")] {
            text = text.replacingOccurrences(of: pair.0, with: pair.1, options: .caseInsensitive)
        }
        return text
    }
    public static func candidate(_ raw: String, base: URL) -> URL? {
        let text = decoded(raw).trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty, text.count <= 16_384,
              let url = URL(string: text, relativeTo: base)?.absoluteURL,
              url.scheme?.lowercased() == "https", url.host != nil,
              url.user == nil, url.password == nil else { return nil }
        return url
    }
    public static func mediaKind(_ url: URL, mimeType: String? = nil) -> MediaKind? {
        if let type = mediaKind(mimeType: mimeType) { return type }
        switch url.pathExtension.lowercased() {
        case "m3u8": return .hls
        case "mpd": return .dash
        default: return nil // Container/file type is discovered from video context or server MIME, not a fixed extension whitelist.
        }
    }
    public static func mediaKind(mimeType: String?) -> MediaKind? {
        let mime = (mimeType ?? "").lowercased().split(separator: ";").first.map(String.init)?.trimmingCharacters(in: .whitespaces) ?? ""
        if ["application/vnd.apple.mpegurl", "application/x-mpegurl", "audio/mpegurl", "audio/x-mpegurl", "hls"].contains(mime) { return .hls }
        if mime == "application/dash+xml" || mime == "dash" { return .dash }
        // Do not whitelist containers/codecs. If the server says it is video, accept it as a file.
        if mime.hasPrefix("video/") { return .file }
        // Some player metadata supplies a format token instead of a MIME type. Any non-empty
        // token explicitly attached to a video source is handled by MediaExtractor as a file.
        return nil
    }
    public static func videoTitle(_ title: String?, page: URL) -> String {
        let clean = (title ?? "").split(whereSeparator: { $0.isWhitespace }).joined(separator: " ")
        if !clean.isEmpty { return String(clean.prefix(300)) }
        let component = page.lastPathComponent.removingPercentEncoding ?? page.lastPathComponent
        let suffix = String((component.isEmpty ? (page.host ?? "") : component).prefix(80))
        return suffix.isEmpty ? "فيديو بدون عنوان" : "فيديو بدون عنوان · " + suffix
    }
    public static func sameOrigin(_ a: URL, _ b: URL) -> Bool {
        a.scheme?.lowercased() == b.scheme?.lowercased() && a.host?.lowercased() == b.host?.lowercased() && (a.port ?? 443) == (b.port ?? 443)
    }
    public static func height(_ text: String) -> Int? {
        if let m = matches(#"(?:^|[^0-9])(2160|1440|1080|720|576|540|480|360|240|144)[pP](?:[^0-9]|$)"#, text).first,
           m.count > 1 { return Int(m[1]) }
        if let m = matches(#"\b\d{2,5}[xX](\d{2,5})\b"#, text).first, m.count > 1 { return Int(m[1]) }
        return nil
    }
    public static func matches(_ pattern: String, _ text: String, options: NSRegularExpression.Options = []) -> [[String]] {
        guard let regex = try? NSRegularExpression(pattern: pattern, options: options) else { return [] }
        let ns = text as NSString
        return regex.matches(in: text, range: NSRange(location: 0, length: ns.length)).map { match in
            (0..<match.numberOfRanges).map { i in
                let r = match.range(at: i); return r.location == NSNotFound ? "" : ns.substring(with: r)
            }
        }
    }
    public static func sameSite(_ a: URL, _ b: URL) -> Bool {
        func host(_ u: URL) -> String { (u.host ?? "").lowercased().replacingOccurrences(of: #"^www\."#, with: "", options: .regularExpression) }
        return !host(a).isEmpty && host(a) == host(b)
    }
    public static func unique(_ sources: [MediaSource]) -> [MediaSource] {
        var out: [MediaSource] = []; var positions: [String: Int] = [:]
        for source in sources {
            if let i = positions[source.id] {
                if out[i].height == nil { out[i].height = source.height }
                if out[i].label == nil { out[i].label = source.label }
                if out[i].requestReferer == nil { out[i].requestReferer = source.requestReferer }
                // An observed playlist MIME type is stronger evidence than a guessed file kind.
                if out[i].kind == .file && source.kind != .file { out[i].kind = source.kind }
                if source.evidence.hasPrefix("WebKit") {
                    out[i].requestReferer = source.requestReferer ?? out[i].requestReferer
                    out[i].evidence = source.evidence
                }
            } else { positions[source.id] = out.count; out.append(source) }
        }
        return out.sorted { ($0.height ?? 0) > ($1.height ?? 0) }
    }
}

/// Shared, testable bounds. No unbounded loops or blind retries of denied URLs.
public enum DownloadPolicy {
    public static let maximumAttempts = 4
    public static let maximumServerWait: TimeInterval = 60
    public static func retryDelay(status: Int?, networkCode: Int? = nil, failedAttempt: Int, retryAfter: TimeInterval? = nil) -> TimeInterval? {
        guard failedAttempt > 0, failedAttempt < maximumAttempts else { return nil }
        if let status {
            guard [408, 425, 429, 500, 502, 503, 504].contains(status) else { return nil }
        } else {
            let transient: [URLError.Code] = [.timedOut, .networkConnectionLost, .cannotConnectToHost, .cannotFindHost, .dnsLookupFailed, .notConnectedToInternet, .resourceUnavailable]
            guard let networkCode, transient.map(\.rawValue).contains(networkCode) else { return nil }
        }
        let delay = max(pow(2, Double(failedAttempt - 1)), retryAfter ?? 0)
        return delay <= maximumServerWait ? delay : nil
    }
    public static func retryAfter(_ raw: String?, now: Date = Date()) -> TimeInterval? {
        guard let value = raw?.trimmingCharacters(in: .whitespacesAndNewlines), !value.isEmpty else { return nil }
        if let seconds = Double(value), seconds.isFinite, seconds >= 0 { return seconds }
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX"); formatter.timeZone = TimeZone(secondsFromGMT: 0)
        formatter.dateFormat = "EEE, dd MMM yyyy HH:mm:ss zzz"
        return formatter.date(from: value).map { max(0, $0.timeIntervalSince(now)) }
    }
    public static func shouldRefresh(status: Int) -> Bool { [401, 403, 404, 410].contains(status) }
    private static func identity(_ url: URL) -> String {
        guard var c = URLComponents(url: url, resolvingAgainstBaseURL: false) else { return url.absoluteString }
        // Strip only known authorization/expiry fields. Content IDs and quality parameters stay.
        let temporary: Set<String> = ["token", "access_token", "expires", "expiry", "exp", "signature", "sig", "policy", "key-pair-id", "hdnts", "hdnea", "auth", "authorization"]
        c.queryItems = c.queryItems?.filter { !temporary.contains($0.name.lowercased()) && !$0.name.lowercased().hasPrefix("x-amz-") }
            .sorted { $0.name == $1.name ? ($0.value ?? "") < ($1.value ?? "") : $0.name < $1.name }
        if c.queryItems?.isEmpty == true { c.queryItems = nil }
        c.fragment = nil
        return c.string ?? url.absoluteString
    }
    public static func refreshedSource(for selected: MediaSource, in candidates: [MediaSource]) -> MediaSource? {
        // Never switch to another video, host, path or a different requested quality automatically.
        let matching = candidates.filter { $0.kind == selected.kind && ($0.height == selected.height || $0.height == nil || selected.height == nil) && identity($0.url) == identity(selected.url) }
        let renewed = URLTools.unique(matching.filter { $0.id != selected.id })
        guard renewed.count <= 1 else { return nil } // Ambiguous tokens must not select another clip.
        return renewed.first ?? matching.first
    }
    public static func completeByteRange(_ header: String?, bytes: Int64) -> Bool {
        guard let header, let parts = URLTools.matches(#"^bytes (\d+)-(\d+)/(\d+)$"#, header, options: .caseInsensitive).first,
              let start = Int64(parts[1]), let end = Int64(parts[2]), let total = Int64(parts[3]) else { return false }
        return start == 0 && total > 0 && end == total - 1 && bytes == total
    }
}
