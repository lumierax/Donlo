/* Madar DOM adapter. Runs inside WebKit, not in the Swift process.
   Never presses consent, age, CAPTCHA, purchase or login controls. */
(() => {
  "use strict";
  if (window.__madar) return;
  const clean = v => String(v || "").replace(/\s+/g, " ").trim();
  const visible = el => {
    if (!el) return false;
    const r = el.getBoundingClientRect(), s = getComputedStyle(el);
    return r.width > 2 && r.height > 2 && s.display !== "none" && s.visibility !== "hidden";
  };
  const absolute = raw => {
    if (typeof raw !== "string" || !raw.trim()) return null;
    try { const u = new URL(raw, document.baseURI); return u.protocol === "https:" ? u.href : null; }
    catch (_) { return null; }
  };
  const sameSite = raw => {
    try { return new URL(raw).hostname.replace(/^www\./, "") === location.hostname.replace(/^www\./, ""); }
    catch (_) { return false; }
  };
  function gate() {
    const title = clean(document.title).toLowerCase();
    const text = clean(document.body?.innerText).slice(0, 18000).toLowerCase();
    const frames = [...document.querySelectorAll('iframe[src*="recaptcha"],iframe[src*="hcaptcha"],iframe[src*="challenges.cloudflare.com"]')];
    const humanText = /verify (?:that )?you are human|checking your browser|performing security verification|أثبت أنك|التحقق من أنك إنسان|تحقق من أنك إنسان/.test(text);
    if (frames.some(visible) || (humanText && (text.length < 4000 || /just a moment|security check|verification/.test(title))))
      return { kind: "human", message: "الموقع يطلب تحققًا بشريًا. أكمله بنفسك داخل نافذة الموقع." };
    const dialogs = [...document.querySelectorAll('[role="dialog"],dialog,[id*="age-gate"],[class*="age-gate"],[id*="ageVerification"]')].filter(visible);
    const gateText = dialogs.map(x => clean(x.innerText)).join(" ") || (text.length < 3000 ? text : "");
    if (/verify your age|confirm your age|age verification|are you (?:18|21)|تأكيد العمر|التحقق من العمر|أكبر من 18/i.test(gateText))
      return { kind: "age", message: "الموقع يطلب إثبات العمر أو موافقتك. لن ينفذ التطبيق هذه الخطوة نيابةً عنك." };
    if (/access denied|request blocked|تم حظر الوصول/i.test(title) && text.length < 5000)
      return { kind: "access", message: "الموقع منع الطلب. يمكنك معاينة الصفحة لمعرفة السبب." };
    return null;
  }
  function results(selector = "") {
    const out = [], seen = new Set();
    let nodes;
    try { nodes = [...document.querySelectorAll(selector || 'a[href]')]; }
    catch (_) { throw new Error("محدد النتائج المحفوظ غير صالح."); }
    function add(url, title, thumb, duration) {
      url = absolute(url);
      title = clean(title);
      if (!url || !sameSite(url) || seen.has(url) || title.length < 2) return;
      seen.add(url); out.push({ url, title: title.slice(0, 300), thumbnail: absolute(thumb || "") || null, duration: clean(duration) || null });
    }
    for (const node of nodes) {
      if (out.length >= 160) break;
      const a = node.matches('a[href]') ? node : node.querySelector('a[href]');
      if (!a) continue;
      if (!selector && (/(?:^|\s)(?:next|prev)(?:\s|$)/i.test(a.rel) || a.closest('nav,.pagination,[role="navigation"]'))) continue;
      const parent = a.parentElement && !['BODY', 'HTML', 'NAV', 'MAIN'].includes(a.parentElement.tagName) ? a.parentElement : a;
      const card = a.closest('article,li,[data-video-id],[data-video],[class*="video-card"],[class*="videoBox"],[class*="video-item"],[class*="thumb-block"]') || parent;
      const img = a.querySelector('img') || card?.querySelector('img');
      const href = a.getAttribute('href') || '';
      const videoHint = /(?:\/(?:watch|view_video|clip|movie)(?:[/?._-])|\/videos?\/[^/?]+|\/v\/|\.(?:mp4|m4v|mov)(?:[?#]|$))/i.test(href) || card?.hasAttribute('data-video-id');
      const duration = card?.querySelector('[class*="duration"],time,[class*="videoDuration"]')?.textContent;
      if (!selector && !videoHint && !(img && duration)) continue;
      const title = a.getAttribute('title') || a.getAttribute('aria-label') ||
        card?.querySelector('h2,h3,h4,[class*="title"]')?.textContent || img?.getAttribute('alt') || a.textContent;
      const thumb = img?.getAttribute('data-src') || img?.getAttribute('data-original') || img?.currentSrc || img?.src;
      add(href, title, thumb, duration);
    }
    // Schema.org is useful on sites without conventional cards.
    let visited = 0;
    function walk(x, depth = 0) {
      if (!x || depth > 10 || visited++ > 4000) return;
      if (Array.isArray(x)) { for (const item of x) walk(item, depth + 1); return; }
      if (typeof x !== 'object') return;
      if (x['@type'] === 'VideoObject') add(x.url || x.mainEntityOfPage || location.href, x.name, Array.isArray(x.thumbnailUrl) ? x.thumbnailUrl[0] : x.thumbnailUrl, x.duration);
      for (const value of Object.values(x)) walk(value, depth + 1);
    }
    for (const s of document.querySelectorAll('script[type="application/ld+json"]')) {
      try { walk(JSON.parse(s.textContent)); } catch (_) {}
    }
    const next = [...document.querySelectorAll('a[rel="next"],a[aria-label],a.next,.pagination a')].find(a => {
      return a.rel === 'next' || /^(next|التالي|التالية|›|»|next page)$/i.test(clean(a.getAttribute('aria-label') || a.textContent));
    });
    const nextURL = next ? absolute(next.href) : null;
    return { items: out, next: nextURL && sameSite(nextURL) ? nextURL : null, url: location.href, title: document.title, gate: gate() };
  }
  function search(keyword, selector = "") {
    const block = gate();
    if (block) return { submitted: false, gate: block };
    const score = el => {
      const type = (el.type || '').toLowerCase();
      if (['password', 'email', 'tel', 'hidden'].includes(type)) return -1000;
      const words = `${el.name} ${el.id} ${el.placeholder} ${el.getAttribute('aria-label')}`;
      return (type === 'search' ? 200 : 0) + (/^(q|s|query|search|keyword|term)$/i.test(el.name) ? 150 : 0) +
        (/(search|query|keyword|بحث|ابحث)/i.test(words) ? 100 : 0) + (el.closest('form[role="search"]') ? 100 : 0);
    };
    let input = null;
    if (selector) { try { input = document.querySelector(selector); } catch (_) {} }
    if (input && !['INPUT', 'TEXTAREA'].includes(input.tagName)) input = null;
    if (!input) input = [...document.querySelectorAll('input[type="search"],input[type="text"],input:not([type])')]
      .filter(visible).sort((a,b) => score(b) - score(a)).find(el => score(el) > 0);
    if (!input) {
      const trigger = [...document.querySelectorAll('button,[role="button"]')].filter(visible).find(el =>
        /^(search|open search|بحث|ابحث|فتح البحث)$/i.test(clean(el.getAttribute('aria-label') || el.getAttribute('title') || el.textContent)));
      if (trigger) { trigger.click(); return { opened: true, submitted: false }; }
      return { submitted: false, missing: true };
    }
    // Do not focus hidden web content: that could summon a second, unwanted keyboard.
    const proto = input.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
    setter ? setter.call(input, keyword) : input.value = keyword;
    input.dispatchEvent(new Event('input', { bubbles: true }));
    input.dispatchEvent(new Event('change', { bubbles: true }));
    const form = input.form;
    if (form) {
      const button = form.querySelector('button[type="submit"],input[type="submit"]');
      if (form.requestSubmit) { button ? form.requestSubmit(button) : form.requestSubmit(); }
      else if (button) button.click();
      else form.submit();
      return { submitted: true };
    }
    const button = input.closest('[role="search"],header,nav,div')?.querySelector('button[type="submit"],button[aria-label*="search" i]');
    if (button) button.click();
    else for (const type of ['keydown','keypress','keyup']) input.dispatchEvent(new KeyboardEvent(type, { key: 'Enter', code: 'Enter', bubbles: true, cancelable: true }));
    return { submitted: true };
  }
  function media() {
    const urls = new Set();
    function add(raw) { const u = absolute(raw); if (u && /\.(?:mp4|m4v|mov|webm|m3u8|mpd)(?:\?|$)/i.test(u)) urls.add(u); }
    for (const el of document.querySelectorAll('video,source,audio')) { add(el.currentSrc); add(el.src); }
    try { for (const e of performance.getEntriesByType('resource')) add(e.name); } catch (_) {}
    return [...urls].slice(0, 400);
  }
  function pickField() {
    function picked(event) {
      const input = event.target.closest('input,textarea');
      if (!input || ['password','email','hidden'].includes(input.type)) return;
      event.preventDefault(); event.stopImmediatePropagation();
      document.removeEventListener('click', picked, true);
      let selector;
      if (input.id) selector = '#' + CSS.escape(input.id);
      else {
        let el = input; const path = [];
        while (el && el.nodeType === 1 && path.length < 8) {
          const tag = el.tagName.toLowerCase();
          const peers = [...(el.parentElement?.children || [])].filter(x => x.tagName === el.tagName);
          path.unshift(`${tag}:nth-of-type(${peers.indexOf(el) + 1})`); el = el.parentElement;
        }
        selector = path.join(' > ');
      }
      window.webkit?.messageHandlers?.mdField?.postMessage({ selector, url: location.href });
    }
    document.addEventListener('click', picked, { capture: true });
    return true;
  }
  window.__madar = { gate, results, search, media, pickField };
  // Source discovery in accessible child frames; the Swift side still validates all messages.
  if (window !== window.top) {
    const report = () => { const urls = media(); if (urls.length) window.webkit?.messageHandlers?.mdMedia?.postMessage(urls); };
    setTimeout(report, 1200); setTimeout(report, 3500);
  }
})();
