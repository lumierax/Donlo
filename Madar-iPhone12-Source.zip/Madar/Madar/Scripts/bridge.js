/* Madar DOM adapter. Runs inside WebKit, not in the Swift process.
   Never presses consent, age, CAPTCHA, purchase or login controls. */
(() => {
  "use strict";
  if (window.__madar) return;
  const clean = v => String(v || "").replace(/\s+/g, " ").trim();
  const visible = el => {
    if (!el) return false;
    const r = el.getBoundingClientRect(), s = getComputedStyle(el);
    return r.width > 2 && r.height > 2 && s.display !== "none" && s.visibility !== "hidden";
  };
  const absolute = raw => {
    if (typeof raw !== "string" || !raw.trim()) return null;
    try { const u = new URL(raw, document.baseURI); return u.protocol === "https:" && !u.username && !u.password ? u.href : null; }
    catch (_) { return null; }
  };
  const sameSite = raw => {
    try { return new URL(raw).hostname.replace(/^www\./, "") === location.hostname.replace(/^www\./, ""); }
    catch (_) { return false; }
  };
  function gate() {
    const title = clean(document.title).toLowerCase();
    const text = clean(document.body?.innerText).slice(0, 18000).toLowerCase();
    const frames = [...document.querySelectorAll('iframe[src*="recaptcha"],iframe[src*="hcaptcha"],iframe[src*="challenges.cloudflare.com"]')];
    const humanText = /verify (?:that )?you are human|checking your browser|performing security verification|أثبت أنك|التحقق من أنك إنسان|تحقق من أنك إنسان/.test(text);
    if (frames.some(visible) || (humanText && (text.length < 4000 || /just a moment|security check|verification/.test(title))))
      return { kind: "human", message: "الموقع يطلب تحققًا بشريًا. أكمله بنفسك داخل نافذة الموقع." };
    const dialogs = [...document.querySelectorAll('[role="dialog"],dialog,[id*="age-gate"],[class*="age-gate"],[id*="ageVerification"]')].filter(visible);
    const gateText = dialogs.map(x => clean(x.innerText)).join(" ") || (text.length < 3000 ? text : "");
    if (/verify your age|confirm your age|age verification|are you (?:18|21)|تأكيد العمر|التحقق من العمر|أكبر من 18/i.test(gateText))
      return { kind: "age", message: "الموقع يطلب إثبات العمر أو موافقتك. لن ينفذ التطبيق هذه الخطوة نيابةً عنك." };
    if (/access denied|request blocked|تم حظر الوصول/i.test(title) && text.length < 5000)
      return { kind: "access", message: "الموقع منع الطلب. يمكنك معاينة الصفحة لمعرفة السبب." };
    return null;
  }
  function fallbackTitle(url) {
    try {
      const u = new URL(url), raw = u.pathname.split('/').filter(Boolean).pop() || u.hostname;
      let suffix = raw; try { suffix = decodeURIComponent(raw); } catch (_) {}
      return `فيديو بدون عنوان · ${clean(suffix).slice(0, 80)}`;
    } catch (_) { return 'فيديو بدون عنوان'; }
  }
  function results(selector = "") {
    const out = [], seen = new Map();
    let nodes;
    try { nodes = [...document.querySelectorAll(selector || 'a[href]')]; }
    catch (_) { throw new Error("محدد النتائج المحفوظ غير صالح."); }
    function add(url, title, thumb, duration) {
      url = absolute(url); title = clean(title);
      if (!url || !sameSite(url)) return;
      if (seen.has(url)) {
        const old = seen.get(url);
        if (old.untitled && title) { old.title = title.slice(0, 300); old.untitled = false; }
        if (!old.thumbnail) old.thumbnail = absolute(thumb || '');
        if (!old.duration) old.duration = clean(duration) || null;
        return;
      }
      if (out.length >= 400) return;
      const item = { url, title: title ? title.slice(0, 300) : fallbackTitle(url), untitled: !title,
        thumbnail: absolute(thumb || '') || null, duration: clean(duration) || null };
      seen.set(url, item); out.push(item);
    }
    for (const node of nodes) {
      const a = node.matches('a[href]') ? node : node.querySelector('a[href]');
      if (!a) continue;
      if (!selector && (/(?:^|\s)(?:next|prev)(?:\s|$)/i.test(a.rel) || a.closest('nav,.pagination,[role="navigation"]'))) continue;
      const parent = a.parentElement && !['BODY', 'HTML', 'NAV', 'MAIN'].includes(a.parentElement.tagName) ? a.parentElement : a;
      let card = a.closest('article,li,[data-video-id],[data-video],[class*="video-card"],[class*="videoBox"],[class*="video-item"],[class*="thumb-block"]') || parent;
      const href = a.getAttribute('href') || '';
      // A shared grid is not a card. Do not borrow another video's heading or poster.
      const mediaLinks = [...(card?.querySelectorAll('a[href]') || [])].filter(link =>
        /\/(?:watch|view_video|clip|movie|videos?|v)(?:[/?._-])/i.test(link.getAttribute('href') || '') || link.querySelector('img'));
      if (new Set(mediaLinks.map(link => absolute(link.getAttribute('href')))).size > 1) card = a;
      const img = a.querySelector('img') || card?.querySelector('img');
      const videoHint = /(?:\/(?:watch|view_video|clip|movie)(?:[/?._-])|\/videos?\/[^/?]+|\/v\/|\.(?:mp4|m4v|mov|webm|m3u8)(?:[?#]|$))/i.test(href) || card?.hasAttribute('data-video-id');
      const duration = card?.querySelector('[class*="duration"],time,[class*="videoDuration"]')?.textContent;
      if (!selector && !videoHint && !(img && duration)) continue;
      const title = clean(a.getAttribute('title')) || clean(a.getAttribute('aria-label')) ||
        clean(a.querySelector('h2,h3,h4,[class*="title"]')?.textContent) ||
        clean(card?.querySelector('h2,h3,h4,[class*="title"]')?.textContent) || clean(img?.getAttribute('alt')) || clean(a.textContent);
      const thumb = img?.getAttribute('data-src') || img?.getAttribute('data-original') || img?.currentSrc || img?.src;
      add(href, title, thumb, duration);
    }
    let visited = 0;
    function walk(x, depth = 0) {
      if (!x || depth > 10 || visited++ > 4000) return;
      if (Array.isArray(x)) { for (const item of x) walk(item, depth + 1); return; }
      if (typeof x !== 'object') return;
      if ([x['@type']].flat().includes('VideoObject')) {
        const main = typeof x.mainEntityOfPage === 'string' ? x.mainEntityOfPage : x.mainEntityOfPage?.['@id'];
        add(x.url || main || location.href, x.name || x.headline,
          Array.isArray(x.thumbnailUrl) ? x.thumbnailUrl[0] : x.thumbnailUrl, x.duration);
      }
      for (const value of Object.values(x)) walk(value, depth + 1);
    }
    for (const el of document.querySelectorAll('script[type="application/ld+json"]')) {
      try { walk(JSON.parse(el.textContent)); } catch (_) {}
    }
    const next = [...document.querySelectorAll('a[rel="next"],a[aria-label],a.next,.pagination a')].find(a =>
      a.rel === 'next' || /^(next|التالي|التالية|›|»|next page)$/i.test(clean(a.getAttribute('aria-label') || a.textContent)));
    const nextURL = next ? absolute(next.href) : null;
    return { items: out, next: nextURL && sameSite(nextURL) ? nextURL : null, url: location.href, title: document.title, gate: gate() };
  }
  function search(keyword, selector = "") {
    const block = gate();
    if (block) return { submitted: false, gate: block };
    const score = el => {
      const type = (el.type || '').toLowerCase();
      if (['password', 'email', 'tel', 'hidden'].includes(type)) return -1000;
      const words = `${el.name} ${el.id} ${el.placeholder} ${el.getAttribute('aria-label')}`;
      return (type === 'search' ? 200 : 0) + (/^(q|s|query|search|keyword|term)$/i.test(el.name) ? 150 : 0) +
        (/(search|query|keyword|بحث|ابحث)/i.test(words) ? 100 : 0) + (el.closest('form[role="search"]') ? 100 : 0);
    };
    let input = null;
    if (selector) { try { input = document.querySelector(selector); } catch (_) {} }
    if (input && !['INPUT', 'TEXTAREA'].includes(input.tagName)) input = null;
    if (!input) input = [...document.querySelectorAll('input[type="search"],input[type="text"],input:not([type])')]
      .filter(visible).sort((a,b) => score(b) - score(a)).find(el => score(el) > 0);
    if (!input) {
      const trigger = [...document.querySelectorAll('button,[role="button"]')].filter(visible).find(el =>
        /^(search|open search|بحث|ابحث|فتح البحث)$/i.test(clean(el.getAttribute('aria-label') || el.getAttribute('title') || el.textContent)));
      if (trigger) { trigger.click(); return { opened: true, submitted: false }; }
      return { submitted: false, missing: true };
    }
    // Do not focus hidden web content: that could summon a second, unwanted keyboard.
    const proto = input.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
    setter ? setter.call(input, keyword) : input.value = keyword;
    input.dispatchEvent(new Event('input', { bubbles: true }));
    input.dispatchEvent(new Event('change', { bubbles: true }));
    const form = input.form;
    if (form) {
      const button = form.querySelector('button[type="submit"],input[type="submit"]');
      if (form.requestSubmit) { button ? form.requestSubmit(button) : form.requestSubmit(); }
      else if (button) button.click();
      else form.submit();
      return { submitted: true };
    }
    const button = input.closest('[role="search"],header,nav,div')?.querySelector('button[type="submit"],button[aria-label*="search" i]');
    if (button) button.click();
    else for (const type of ['keydown','keypress','keyup']) input.dispatchEvent(new KeyboardEvent(type, { key: 'Enter', code: 'Enter', bubbles: true, cancelable: true }));
    return { submitted: true };
  }
  // Installed at document start, before a player's initial fetch/XHR when WebKit permits it.
  // Observe only URL + Content-Type, not response bodies, credential fields or DRM keys.
  // Signed URLs can contain authorization data; records stay in this ephemeral session.
  const mediaRecords = new Map(), pendingReports = new Map(), primed = new WeakSet();
  let reportTimer = null, scanTimer = null;
  function kindFor(url, mime = '') {
    const type = clean(mime).split(';')[0].trim().toLowerCase();
    if (['application/vnd.apple.mpegurl','application/x-mpegurl','audio/mpegurl','audio/x-mpegurl','hls'].includes(type)) return 'hls';
    if (type === 'application/dash+xml') return 'dash';
    if (['video/mp4','video/x-m4v','video/quicktime','video/webm'].includes(type)) return 'file';
    if (type && /^(?:text\/|audio\/|image\/)|(?:json|xml|mp2t)/.test(type)) return null;
    let path; try { path = new URL(url).pathname; } catch (_) { return null; }
    if (/\.m3u8$/i.test(path)) return 'hls';
    if (/\.mpd$/i.test(path)) return 'dash';
    if (/\.(?:mp4|m4v|mov|webm)$/i.test(path)) return 'file';
    return null;
  }
  function addMedia(raw, mime = '', evidence = 'DOM', assumeVideo = false) {
    const url = absolute(raw);
    if (!url) return;
    const kind = kindFor(url, mime) || (!mime && assumeVideo ? 'file' : null);
    if (!kind) return;
    const previous = mediaRecords.get(url);
    if (!previous && mediaRecords.size >= 600) return;
    if (previous && (previous.kind === kind || kind === 'file')) return;
    const record = { url, kind, referer: location.href, evidence: `WebKit ${evidence}` };
    mediaRecords.set(url, record); pendingReports.set(url, record);
    if (!reportTimer) reportTimer = setTimeout(reportMedia, 100);
  }
  function reportMedia() {
    reportTimer = null;
    if (!pendingReports.size) return;
    const batch = [...pendingReports.values()].slice(0, 100);
    batch.forEach(record => pendingReports.delete(record.url));
    try { window.webkit?.messageHandlers?.mdMedia?.postMessage(batch); } catch (_) {}
    if (pendingReports.size && !reportTimer) reportTimer = setTimeout(reportMedia, 100);
  }
  function scanMedia() {
    const roots = [document];
    // Bounded traversal also covers players using open shadow roots.
    for (let i = 0; i < roots.length && i < 24; i++) {
      const root = roots[i];
      for (const el of [...root.querySelectorAll('video,source')].slice(0, 500)) {
        if (el.tagName === 'SOURCE' && el.closest('audio')) continue;
        const video = el.tagName === 'VIDEO' || !!el.closest('video');
        const type = el.getAttribute('type') || '';
        for (const raw of [el.currentSrc, el.src, el.getAttribute('data-src'), el.getAttribute('data-file')])
          addMedia(raw, type, 'media element', video);
      }
      for (const el of [...root.querySelectorAll('[data-src],[data-file],a[download]')].slice(0, 500))
        addMedia(el.getAttribute('data-file') || el.getAttribute('data-src') || el.getAttribute('href'), '', 'lazy attribute');
      for (const el of [...root.querySelectorAll('*')].slice(0, 2000)) {
        if (el.shadowRoot && roots.length < 24) roots.push(el.shadowRoot);
      }
    }
    try { for (const entry of performance.getEntriesByType('resource')) addMedia(entry.name, '', 'resource'); } catch (_) {}
    return roots;
  }
  function scheduleScan() {
    if (!scanTimer) scanTimer = setTimeout(() => { scanTimer = null; scanMedia(); }, 200);
  }
  function mediaDetails() { scanMedia(); return [...mediaRecords.values()]; }
  function media() { return mediaDetails().map(record => record.url); }
  function probe(snapshot = false) {
    // Only metadata preload on existing video sources. No play(), synthetic clicks or gate acceptance.
    if (gate()) return { blocked: true };
    const roots = scanMedia();
    for (const root of roots) for (const video of root.querySelectorAll('video')) {
      if (primed.has(video) || video.readyState > 0 || !video.paused || !(video.getAttribute('src') || video.querySelector('source[src]'))) continue;
      primed.add(video);
      try { video.preload = 'metadata'; video.load(); } catch (_) {}
    }
    for (const frame of document.querySelectorAll('iframe')) {
      try { frame.contentWindow?.postMessage({ type: 'madar:probe-metadata:v2', snapshot }, '*'); } catch (_) {}
    }
    if (snapshot) for (const [url, record] of mediaRecords) pendingReports.set(url, record);
    reportMedia();
    return { count: mediaRecords.size };
  }
  try {
    const nativeFetch = window.fetch;
    if (typeof nativeFetch === 'function') window.fetch = function(...args) {
      const promise = Reflect.apply(nativeFetch, this, args);
      promise.then(response => {
        try { addMedia(response.url, response.headers.get('content-type') || '', 'fetch MIME'); } catch (_) {}
      }, () => {});
      return promise;
    };
  } catch (_) {}
  try {
    const nativeOpen = XMLHttpRequest.prototype.open, observed = new WeakSet();
    XMLHttpRequest.prototype.open = function(...args) {
      if (!observed.has(this)) {
        observed.add(this);
        this.addEventListener('load', () => {
          try { addMedia(this.responseURL, this.getResponseHeader('content-type') || '', 'XHR MIME'); } catch (_) {}
        });
      }
      return Reflect.apply(nativeOpen, this, args);
    };
  } catch (_) {}
  try {
    new PerformanceObserver(list => {
      for (const entry of list.getEntries()) addMedia(entry.name, '', 'resource observer');
    }).observe({ type: 'resource', buffered: true });
  } catch (_) {}
  try {
    new MutationObserver(scheduleScan).observe(document, { subtree: true, childList: true, attributes: true,
      attributeFilter: ['src', 'type', 'data-src', 'data-file'] });
  } catch (_) {}
  for (const event of ['loadedmetadata', 'loadstart', 'canplay', 'durationchange'])
    document.addEventListener(event, scheduleScan, true);
  window.addEventListener('message', event => {
    if (window !== window.top && event.source === window.parent && event.data?.type === 'madar:probe-metadata:v2') probe(event.data.snapshot === true);
  });
  document.addEventListener('DOMContentLoaded', scheduleScan, { once: true });
  function pickField() {
    function picked(event) {
      const input = event.target.closest('input,textarea');
      if (!input || ['password','email','hidden'].includes(input.type)) return;
      event.preventDefault(); event.stopImmediatePropagation();
      document.removeEventListener('click', picked, true);
      let selector;
      if (input.id) selector = '#' + CSS.escape(input.id);
      else {
        let el = input; const path = [];
        while (el && el.nodeType === 1 && path.length < 8) {
          const tag = el.tagName.toLowerCase();
          const peers = [...(el.parentElement?.children || [])].filter(x => x.tagName === el.tagName);
          path.unshift(`${tag}:nth-of-type(${peers.indexOf(el) + 1})`); el = el.parentElement;
        }
        selector = path.join(' > ');
      }
      window.webkit?.messageHandlers?.mdField?.postMessage({ selector, url: location.href });
    }
    document.addEventListener('click', picked, { capture: true });
    return true;
  }
  window.__madar = { gate, results, search, media, mediaDetails, probe, pickField };
  scheduleScan();
})();
