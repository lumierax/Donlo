/* Madar DOM adapter. Runs inside WebKit, not in the Swift process.
   Never presses consent, age, CAPTCHA, purchase or login controls. */
(() => {
  "use strict";
  if (window.__madar) return;
  const clean = v => String(v || "").replace(/\s+/g, " ").trim();
  const visible = el => {
    if (!el) return false;
    const r = el.getBoundingClientRect(), s = getComputedStyle(el);
    return r.width > 2 && r.height > 2 && s.display !== "none" && s.visibility !== "hidden";
  };
  const absolute = raw => {
    if (typeof raw !== "string" || !raw.trim()) return null;
    try { const u = new URL(raw, document.baseURI); return u.protocol === "https:" && !u.username && !u.password ? u.href : null; }
    catch (_) { return null; }
  };
  const sameSite = raw => {
    try { return new URL(raw).hostname.replace(/^www\./, "") === location.hostname.replace(/^www\./, ""); }
    catch (_) { return false; }
  };
  let drmSeen = false;
  function gate() {
    if (drmSeen) return { kind: "drm", message: "تم اكتشاف حماية DRM/Encrypted Media. أوقف التطبيق الفحص التلقائي ولن يحاول تجاوز الحماية." };
    const title = clean(document.title).toLowerCase();
    const text = clean(document.body?.innerText).slice(0, 18000).toLowerCase();
    const frames = [...document.querySelectorAll('iframe[src*="recaptcha"],iframe[src*="hcaptcha"],iframe[src*="challenges.cloudflare.com"]')];
    const humanText = /verify (?:that )?you are human|checking your browser|performing security verification|أثبت أنك|التحقق من أنك إنسان|تحقق من أنك إنسان/.test(text);
    if (frames.some(visible) || (humanText && (text.length < 4000 || /just a moment|security check|verification/.test(title))))
      return { kind: "human", message: "الموقع يطلب تحققًا بشريًا. أكمله بنفسك داخل نافذة الموقع." };
    const dialogs = [...document.querySelectorAll('[role="dialog"],dialog,[id*="age-gate"],[class*="age-gate"],[id*="ageVerification"]')].filter(visible);
    const gateText = dialogs.map(x => clean(x.innerText)).join(" ") || (text.length < 3000 ? text : "");
    if (/verify your age|confirm your age|age verification|are you (?:18|21)|تأكيد العمر|التحقق من العمر|أكبر من 18/i.test(gateText))
      return { kind: "age", message: "الموقع يطلب إثبات العمر أو موافقتك. لن ينفذ التطبيق هذه الخطوة نيابةً عنك." };
    if (/access denied|request blocked|تم حظر الوصول/i.test(title) && text.length < 5000)
      return { kind: "access", message: "الموقع منع الطلب. يمكنك معاينة الصفحة لمعرفة السبب." };
    return null;
  }
  function fallbackTitle(url) {
    try {
      const u = new URL(url), raw = u.pathname.split('/').filter(Boolean).pop() || u.hostname;
      let suffix = raw; try { suffix = decodeURIComponent(raw); } catch (_) {}
      return `فيديو بدون عنوان · ${clean(suffix).slice(0, 80)}`;
    } catch (_) { return 'فيديو بدون عنوان'; }
  }
  function results(selector = "") {
    const out = [], seen = new Map();
    let nodes;
    try { nodes = [...document.querySelectorAll(selector || 'a[href]')]; }
    catch (_) { throw new Error("محدد النتائج المحفوظ غير صالح."); }
    function add(url, title, thumb, duration) {
      url = absolute(url); title = clean(title);
      if (!url || !sameSite(url)) return;
      if (seen.has(url)) {
        const old = seen.get(url);
        if (old.untitled && title) { old.title = title.slice(0, 300); old.untitled = false; }
        if (!old.thumbnail) old.thumbnail = absolute(thumb || '');
        if (!old.duration) old.duration = clean(duration) || null;
        return;
      }
      if (out.length >= 400) return;
      const item = { url, title: title ? title.slice(0, 300) : fallbackTitle(url), untitled: !title,
        thumbnail: absolute(thumb || '') || null, duration: clean(duration) || null };
      seen.set(url, item); out.push(item);
    }
    for (const node of nodes) {
      const a = node.matches('a[href]') ? node : node.querySelector('a[href]');
      if (!a) continue;
      if (!selector && (/(?:^|\s)(?:next|prev)(?:\s|$)/i.test(a.rel) || a.closest('nav,.pagination,[role="navigation"]'))) continue;
      const parent = a.parentElement && !['BODY', 'HTML', 'NAV', 'MAIN'].includes(a.parentElement.tagName) ? a.parentElement : a;
      let card = a.closest('article,li,[data-video-id],[data-video],[class*="video-card"],[class*="videoBox"],[class*="video-item"],[class*="thumb-block"]') || parent;
      const href = a.getAttribute('href') || '';
      // A shared grid is not a card. Do not borrow another video's heading or poster.
      const mediaLinks = [...(card?.querySelectorAll('a[href]') || [])].filter(link =>
        /\/(?:watch|view_video|clip|movie|videos?|v)(?:[/?._-])/i.test(link.getAttribute('href') || '') || link.querySelector('img'));
      if (new Set(mediaLinks.map(link => absolute(link.getAttribute('href')))).size > 1) card = a;
      const img = a.querySelector('img') || card?.querySelector('img');
      const videoHint = /(?:\/(?:watch|view_video|clip|movie)(?:[/?._-])|\/videos?\/[^/?]+|\/v\/|\.(?:mp4|m4v|mov|webm|m3u8)(?:[?#]|$))/i.test(href) || card?.hasAttribute('data-video-id');
      const duration = card?.querySelector('[class*="duration"],time,[class*="videoDuration"]')?.textContent;
      if (!selector && !videoHint && !(img && duration)) continue;
      const title = clean(a.getAttribute('title')) || clean(a.getAttribute('aria-label')) ||
        clean(a.querySelector('h2,h3,h4,[class*="title"]')?.textContent) ||
        clean(card?.querySelector('h2,h3,h4,[class*="title"]')?.textContent) || clean(img?.getAttribute('alt')) || clean(a.textContent);
      const thumb = img?.getAttribute('data-src') || img?.getAttribute('data-original') || img?.currentSrc || img?.src;
      add(href, title, thumb, duration);
    }
    let visited = 0;
    function walk(x, depth = 0) {
      if (!x || depth > 10 || visited++ > 4000) return;
      if (Array.isArray(x)) { for (const item of x) walk(item, depth + 1); return; }
      if (typeof x !== 'object') return;
      if ([x['@type']].flat().includes('VideoObject')) {
        const main = typeof x.mainEntityOfPage === 'string' ? x.mainEntityOfPage : x.mainEntityOfPage?.['@id'];
        add(x.url || main || location.href, x.name || x.headline,
          Array.isArray(x.thumbnailUrl) ? x.thumbnailUrl[0] : x.thumbnailUrl, x.duration);
      }
      for (const value of Object.values(x)) walk(value, depth + 1);
    }
    for (const el of document.querySelectorAll('script[type="application/ld+json"]')) {
      try { walk(JSON.parse(el.textContent)); } catch (_) {}
    }
    const next = [...document.querySelectorAll('a[rel="next"],a[aria-label],a.next,.pagination a')].find(a =>
      a.rel === 'next' || /^(next|التالي|التالية|›|»|next page)$/i.test(clean(a.getAttribute('aria-label') || a.textContent)));
    const nextURL = next ? absolute(next.href) : null;
    return { items: out, next: nextURL && sameSite(nextURL) ? nextURL : null, url: location.href, title: document.title, gate: gate() };
  }
  // Search is intentionally step-based. Swift owns navigation, timeouts and cancellation;
  // no timer here can click another control after the user stops a search.
  const controlSelector = 'button,a[href],[role="button"],[role="menuitem"],summary,label[for],input[type="button"],div[onclick],span[onclick],[tabindex="0"]';
  const searchWords = /search|query|keyword|magnif|بحث|ابحث|البحث|سيرش/i;
  const menuWords = /menu|hamburger|sidebar|drawer|nav[-_ ]?(?:toggle|trigger)|toggle[-_ ]?nav|قائمة|القائمة|☰/i;
  const sensitiveWords = /log[ -]?(?:in|out)|sign[ -]?(?:in|up|out)|register|password|checkout|purchase|payment|billing|delete|subscribe|consent|cookie|accept|agree|verify|verification|captcha|age[-_ ]?gate|تسجيل|دخول|خروج|شراء|دفع|حذف|اشتراك|موافق|قبول|العمر|تحقق/i;
  let searchState;
  function resetSearch() { searchState = { clicked: new WeakSet(), keys: new Set(), actions: 0 }; return true; }
  resetSearch();
  function searchVisible(el) {
    if (!visible(el) || !el.isConnected || el.matches(':disabled') || el.closest('[inert],[aria-hidden="true"]')) return false;
    for (let p = el; p && p.nodeType === 1; p = p.parentElement) {
      const s = getComputedStyle(p);
      if (s.display === 'none' || s.visibility === 'hidden' || s.visibility === 'collapse' || Number(s.opacity) === 0) return false;
    }
    // Translated off-canvas mobile menus still have a non-zero bounding box.
    const r = el.getBoundingClientRect();
    return r.right > 0 && r.left < innerWidth && r.bottom > 0 && r.top < innerHeight;
  }
  function controlLabel(el) {
    return clean(el.getAttribute('aria-label') || el.getAttribute('title') ||
      el.querySelector('svg title')?.textContent || el.textContent).slice(0, 100);
  }
  function controlWords(el) {
    return `${controlLabel(el)} ${el.id} ${el.getAttribute('class') || ''} ${el.getAttribute('aria-controls') || ''} ${el.getAttribute('data-target') || ''} ${el.querySelector('use')?.getAttribute('href') || el.querySelector('use')?.getAttribute('xlink:href') || ''} ${el.querySelector('svg,i,span')?.getAttribute('class') || ''}`;
  }
  function searchControlHint(el) {
    const label = controlLabel(el), words = controlWords(el);
    if (/close|dismiss|cancel|إغلاق|اغلاق|إلغاء|الغاء/i.test(words)) return false;
    if (el.tagName === 'A' && (el.closest('article,[data-video-id],[class*="video-card"]') ||
        /\/(?:watch|view_video|clip|movie|videos?|v)\/[^/?]+/i.test(el.getAttribute('href') || ''))) return false;
    const direct = /^(?:(?:open|show|toggle)\s+)?(?:(?:site|video|global)\s+)?search(?:\s+(?:this site|this website|videos|site|website|menu|box|form))?[. …]*$|^(?:بحث|ابحث|البحث|سيرش|فتح البحث|إظهار البحث|ابحث هنا)$/i.test(label);
    // Icons/classes are stronger evidence than the text of an arbitrary article link.
    const metadata = `${el.id} ${el.getAttribute('class') || ''} ${el.getAttribute('aria-controls') || ''} ${el.getAttribute('data-target') || ''} ${el.querySelector('use')?.getAttribute('href') || el.querySelector('use')?.getAttribute('xlink:href') || ''} ${el.querySelector('svg,i,span')?.getAttribute('class') || ''}`;
    return direct || searchWords.test(metadata);
  }
  function safeControl(el, submit = false) {
    if (!el || !searchVisible(el) || el.getAttribute('aria-disabled') === 'true' || el.hasAttribute('download')) return false;
    if (sensitiveWords.test(controlWords(el)) || el.closest('[data-age-gate],[id*="consent" i],[class*="consent" i]')) return false;
    const dialog = el.closest('dialog,[role="dialog"]');
    if (dialog && sensitiveWords.test(clean(dialog.innerText).slice(0, 4000))) return false;
    if (el.closest('form')?.querySelector('input[type="password"],input[type="email"],input[autocomplete="username"]')) return false;
    if (!submit && el.form && /^(submit|image)$/i.test(el.type || '')) return false;
    if (el.tagName === 'LABEL') {
      const target = document.getElementById(el.htmlFor);
      if (!target || !['checkbox','radio'].includes(target.type) || sensitiveWords.test(`${target.id} ${target.name}`)) return false;
    }
    if (el.tagName === 'A') {
      const raw = el.getAttribute('href') || '';
      if (raw && !raw.startsWith('#')) {
        const url = absolute(raw);
        if (!url || !sameSite(url) || sensitiveWords.test(new URL(url).pathname)) return false;
      }
    }
    return true;
  }
  function safeField(el) {
    return !!el && ['INPUT','TEXTAREA'].includes(el.tagName) &&
      (el.tagName === 'TEXTAREA' || ['text','search',''].includes(el.type)) && !el.readOnly && searchVisible(el) &&
      !sensitiveWords.test(`${el.name} ${el.id} ${el.autocomplete}`) &&
      !el.form?.querySelector('input[type="password"],input[type="email"],input[autocomplete="username"]');
  }
  function selectAll(selector) {
    if (typeof selector !== 'string' || !selector.trim() || selector.length >= 1000) return [];
    try { return [...document.querySelectorAll(selector)]; } catch (_) { return []; }
  }
  function stableSelector(el) {
    const tag = el.tagName.toLowerCase(), candidates = [];
    if (el.id) candidates.push('#' + CSS.escape(el.id));
    for (const attr of ['data-testid','data-test','name','aria-label','aria-controls','title']) {
      const value = el.getAttribute(attr);
      if (value && value.length < 120) candidates.push(`${tag}[${attr}="${CSS.escape(value)}"]`);
    }
    const classes = [...el.classList].filter(c => c.length < 50 && !/\d{4,}|^(active|open|show|hidden|collapsed|expanded|is-)/i.test(c)).slice(0, 3);
    if (classes.length) candidates.push(tag + classes.map(c => '.' + CSS.escape(c)).join(''));
    for (const candidate of candidates) if (selectAll(candidate).length === 1) return candidate;
    const path = []; let node = el;
    while (node && node.nodeType === 1 && path.length < 12) {
      if (node !== el && node.id && selectAll('#' + CSS.escape(node.id)).length === 1) {
        path.unshift('#' + CSS.escape(node.id)); break;
      }
      const peers = [...(node.parentElement?.children || [])].filter(x => x.tagName === node.tagName);
      path.unshift(`${node.tagName.toLowerCase()}:nth-of-type(${Math.max(1, peers.indexOf(node) + 1)})`);
      node = node.parentElement;
    }
    const result = path.join(' > ');
    return selectAll(result).length === 1 && result.length < 1000 ? result : '';
  }
  function inputScore(el) {
    const words = `${el.name} ${el.id} ${el.placeholder} ${el.getAttribute('aria-label') || ''} ${[...(el.labels || [])].map(x => clean(x.textContent)).join(' ')}`;
    return (el.type === 'search' ? 200 : 0) + (/^(q|s|query|search|keyword|term)$/i.test(el.name) ? 150 : 0) +
      (searchWords.test(words) ? 100 : 0) + (el.closest('form[role="search"],[role="search"]') ? 100 : 0) +
      (el.enterKeyHint === 'search' ? 60 : 0) + (el.closest('header') ? 10 : 0);
  }
  function findSearchInput(selector = '', strict = false) {
    if (selector) {
      const saved = selectAll(selector).filter(safeField);
      if (saved.length === 1) return { input: saved[0] };
      if (saved.length > 1) return { ambiguous: true, reason: 'المحدد المحفوظ يطابق أكثر من خانة ظاهرة.' };
      if (strict) return {};
    }
    const ranked = [...document.querySelectorAll('input,textarea')].filter(safeField)
      .map(el => ({ el, score: inputScore(el) })).filter(x => x.score >= 60).sort((a,b) => b.score - a.score);
    if (ranked.length > 1 && ranked[0].score - ranked[1].score < 20)
      return { ambiguous: true, reason: 'وجدت أكثر من خانة بحث محتملة. حدّد الخانة أو علّم الخطوات.' };
    return { input: ranked[0]?.el };
  }
  function triggerScore(el) {
    const words = controlWords(el), label = controlLabel(el);
    if (!safeControl(el) || el.getAttribute('aria-expanded') === 'true' ||
        (el.tagName === 'SUMMARY' && el.parentElement?.open) || searchState.clicked.has(el)) return 0;
    const key = stableSelector(el);
    if (key && searchState.keys.has(key)) return 0;
    // A search link may navigate to the site's real search page; menu guesses must stay put.
    if (el.tagName === 'A' && !searchControlHint(el)) {
      const href = el.getAttribute('href') || '';
      if (href && !href.startsWith('#')) return 0;
    }
    if (searchControlHint(el)) return 200 + (searchWords.test(label) ? 80 : 0) + (el.closest('header,nav') ? 10 : 0);
    if (menuWords.test(words)) return 100 + (menuWords.test(label) ? 30 : 0);
    const target = document.getElementById(el.getAttribute('aria-controls') || '');
    if (el.getAttribute('aria-expanded') === 'false' && target?.matches('nav,[role="navigation"],[role="search"]')) return 90;
    return 0;
  }
  function findSearchTrigger() {
    return [...document.querySelectorAll(controlSelector)].slice(0, 1000)
      .map(el => ({ el, score: triggerScore(el) })).filter(x => x.score > 0).sort((a,b) => b.score - a.score)[0]?.el;
  }
  function inspectSearch(selector = '', strict = false) {
    const block = gate(); if (block) return { gate: block };
    const found = findSearchInput(selector, strict);
    return { field: !!found.input, ambiguous: !!found.ambiguous, reason: found.reason || '',
      trigger: !strict && !found.input && !found.ambiguous && !!findSearchTrigger() };
  }
  function clickControl(el) {
    const key = stableSelector(el);
    if (searchState.actions >= 8 || searchState.clicked.has(el) || (key && searchState.keys.has(key)))
      return { submitted: false, reason: 'توقفت لتجنب تكرار الضغطات. علّم خطوات البحث من البداية.' };
    searchState.clicked.add(el); if (key) searchState.keys.add(key); searchState.actions++;
    el.click();
    return { opened: true, submitted: false, label: controlLabel(el), actions: searchState.actions };
  }
  function clickSearchStep(selector) {
    const block = gate(); if (block) return { gate: block };
    const nodes = selectAll(selector).filter(searchVisible);
    if (nodes.length !== 1) return { missing: nodes.length === 0, ambiguous: nodes.length > 1,
      reason: nodes.length > 1 ? 'الخطوة تطابق أكثر من عنصر ظاهر.' : 'لم يظهر عنصر الخطوة المحفوظة.' };
    const el = nodes[0];
    if (!el.matches(controlSelector) || !safeControl(el)) return { blocked: true, reason: 'الخطوة ليست زر فتح آمنًا. أكملها بنفسك.' };
    if (el.getAttribute('aria-expanded') === 'true' || (el.tagName === 'SUMMARY' && el.parentElement?.open)) return { skipped: true };
    return clickControl(el);
  }
  function waitForSearch(target = '', fieldSelector = '', timeout = 5000, strict = false) {
    // Observe DOM insertion/visibility, and poll CSS animations as well. Never clicks.
    timeout = Math.max(300, Math.min(12000, Number(timeout) || 5000));
    return new Promise(resolve => {
      const start = performance.now(); let done = false, observer, timer, deadline;
      const finish = value => { if (done) return; done = true; observer?.disconnect(); clearInterval(timer); clearTimeout(deadline); resolve(value); };
      const check = () => {
        if (performance.now() - start < 300) return;
        const block = gate(); if (block) return finish({ gate: block });
        const found = findSearchInput(fieldSelector, strict);
        if (found.input || found.ambiguous) return finish({ ready: !!found.input, ambiguous: !!found.ambiguous });
        if (target ? selectAll(target).some(searchVisible) : (!strict && !!findSearchTrigger())) finish({ ready: true });
      };
      observer = new MutationObserver(check);
      observer.observe(document, { subtree: true, childList: true, attributes: true,
        attributeFilter: ['class','style','hidden','aria-hidden','aria-expanded','disabled','open'] });
      timer = setInterval(check, 140); deadline = setTimeout(() => finish({ timeout: true }), timeout);
      check();
    });
  }
  function searchSnapshot(selector = '') {
    const r = results(selector);
    return { url: location.href, items: r.items.map(x => `${x.url}|${x.title}`).join('\n') };
  }
  function submitSearch(input, keyword) {
    const form = input.form;
    const allowedAction = raw => { const url = absolute(raw || location.href); return !!url && sameSite(url); };
    if (form && (!allowedAction(form.getAttribute('action')) || sensitiveWords.test(form.getAttribute('action') || ''))) return { submitted: false, reason: 'نموذج البحث يرسل إلى نطاق مختلف أو رابط غير آمن. استخدم النافذة اليدوية.' };
    // Do not focus background WebKit content, which would summon a second keyboard.
    const proto = input.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
    setter ? setter.call(input, keyword) : input.value = keyword;
    input.dispatchEvent(new Event('input', { bubbles: true }));
    input.dispatchEvent(new Event('change', { bubbles: true }));
    if (!input.isConnected) return { submitted: false, reason: 'استبدل الموقع الخانة أثناء الكتابة. أكمل البحث يدويًا أو أعد المحاولة.' };
    const block = gate(); if (block) return { submitted: false, gate: block };
    if (form) {
      const submitters = [...form.elements].filter(el => /^(submit|image)$/.test(el.type || ''));
      const buttons = submitters.filter(el => safeControl(el, true));
      if (submitters.length && !buttons.length) return { submitted: false, reason: 'لا يوجد زر إرسال ظاهر وآمن في هذا النموذج. أكمل البحث يدويًا.' };
      const button = buttons.find(el => searchWords.test(controlWords(el))) || (buttons.length === 1 ? buttons[0] : null);
      if (button?.hasAttribute('formaction') && !allowedAction(button.getAttribute('formaction')))
        return { submitted: false, reason: 'زر البحث يرسل إلى نطاق مختلف. استخدم النافذة اليدوية.' };
      if (buttons.length > 1 && !button) return { submitted: false, reason: 'يوجد أكثر من زر إرسال؛ أكمل البحث يدويًا.' };
      if (!form.checkValidity()) return { submitted: false, reason: 'الموقع يطلب إكمال حقول أخرى. أكملها بنفسك.' };
      if (button) button.click(); // Preserve click handlers and submitter name/value.
      else HTMLFormElement.prototype.requestSubmit.call(form);
      return { submitted: true, method: button ? 'button' : 'form' };
    }
    const container = input.closest('[role="search"]') || input.parentElement;
    const buttons = [...(container?.querySelectorAll('button,input[type="submit"],[role="button"]') || [])]
      .filter(el => safeControl(el, true) && (el.type === 'submit' || searchControlHint(el)));
    if (buttons.length === 1) { buttons[0].click(); return { submitted: true, method: 'button' }; }
    // Some sites reject synthetic Enter; Swift verifies a result/URL change before returning cards.
    for (const type of ['keydown','keypress','keyup']) input.dispatchEvent(new KeyboardEvent(type,
      { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true }));
    return { submitted: true, method: 'enter' };
  }
  function search(keyword, selector = '', options = {}) {
    const block = gate(); if (block) return { submitted: false, gate: block };
    const found = findSearchInput(selector, options.strict === true);
    if (found.ambiguous) return { submitted: false, ambiguous: true, reason: found.reason };
    if (found.input) return submitSearch(found.input, keyword);
    if (options.allowOpen !== false) {
      const trigger = findSearchTrigger();
      if (trigger) return clickControl(trigger);
    }
    return { submitted: false, missing: true, reason: 'لم تظهر خانة بحث آمنة. استخدم «تعليم خطوات البحث».' };
  }
  // Protection gate: observe EME/encrypted-media use without reading keys or changing the site's request.
  try {
    const nativeKeyAccess = navigator.requestMediaKeySystemAccess?.bind(navigator);
    if (nativeKeyAccess) navigator.requestMediaKeySystemAccess = function(...args) { drmSeen = true; return nativeKeyAccess(...args); };
  } catch (_) {}
  document.addEventListener('encrypted', () => { drmSeen = true; }, true);
  function duration() {
    const values = [];
    for (const v of document.querySelectorAll('video')) if (Number.isFinite(v.duration) && v.duration > 0) values.push(v.duration);
    if (!values.length) return '';
    const seconds = Math.round(Math.max(...values)), h = Math.floor(seconds / 3600), m = Math.floor((seconds % 3600) / 60), sec = seconds % 60;
    return h > 0 ? `${h}:${String(m).padStart(2,'0')}:${String(sec).padStart(2,'0')}` : `${m}:${String(sec).padStart(2,'0')}`;
  }
  // Installed at document start, before a player's initial fetch/XHR when WebKit permits it.
  // Observe only URL + Content-Type, not response bodies, credential fields or DRM keys.
  // Signed URLs can contain authorization data; records stay in this ephemeral session.
  const mediaRecords = new Map(), pendingReports = new Map(), primed = new WeakSet();
  let reportTimer = null, scanTimer = null;
  function kindFor(url, mime = '') {
    const type = clean(mime).split(';')[0].trim().toLowerCase();
    if (['application/vnd.apple.mpegurl','application/x-mpegurl','audio/mpegurl','audio/x-mpegurl','hls'].includes(type)) return 'hls';
    if (type === 'application/dash+xml') return 'dash';
    if (['video/mp4','video/x-m4v','video/quicktime','video/webm'].includes(type)) return 'file';
    if (type && /^(?:text\/|audio\/|image\/)|(?:json|xml|mp2t)/.test(type)) return null;
    let path; try { path = new URL(url).pathname; } catch (_) { return null; }
    if (/\.m3u8$/i.test(path)) return 'hls';
    if (/\.mpd$/i.test(path)) return 'dash';
    if (/\.(?:mp4|m4v|mov|webm)$/i.test(path)) return 'file';
    return null;
  }
  function addMedia(raw, mime = '', evidence = 'DOM', assumeVideo = false) {
    const url = absolute(raw);
    if (!url) return;
    const kind = kindFor(url, mime) || (!mime && assumeVideo ? 'file' : null);
    if (!kind) return;
    const previous = mediaRecords.get(url);
    if (!previous && mediaRecords.size >= 600) return;
    if (previous && (previous.kind === kind || kind === 'file')) return;
    const record = { url, kind, referer: location.href, evidence: `WebKit ${evidence}` };
    mediaRecords.set(url, record); pendingReports.set(url, record);
    if (!reportTimer) reportTimer = setTimeout(reportMedia, 100);
  }
  function reportMedia() {
    reportTimer = null;
    if (!pendingReports.size) return;
    const batch = [...pendingReports.values()].slice(0, 100);
    batch.forEach(record => pendingReports.delete(record.url));
    try { window.webkit?.messageHandlers?.mdMedia?.postMessage(batch); } catch (_) {}
    if (pendingReports.size && !reportTimer) reportTimer = setTimeout(reportMedia, 100);
  }
  function scanMedia() {
    const roots = [document];
    // Bounded traversal also covers players using open shadow roots.
    for (let i = 0; i < roots.length && i < 24; i++) {
      const root = roots[i];
      for (const el of [...root.querySelectorAll('video,source')].slice(0, 500)) {
        if (el.tagName === 'SOURCE' && el.closest('audio')) continue;
        const video = el.tagName === 'VIDEO' || !!el.closest('video');
        const type = el.getAttribute('type') || '';
        for (const raw of [el.currentSrc, el.src, el.getAttribute('data-src'), el.getAttribute('data-file')])
          addMedia(raw, type, 'media element', video);
      }
      for (const el of [...root.querySelectorAll('[data-src],[data-file],a[download]')].slice(0, 500))
        addMedia(el.getAttribute('data-file') || el.getAttribute('data-src') || el.getAttribute('href'), '', 'lazy attribute');
      for (const el of [...root.querySelectorAll('*')].slice(0, 2000)) {
        if (el.shadowRoot && roots.length < 24) roots.push(el.shadowRoot);
      }
    }
    try { for (const entry of performance.getEntriesByType('resource')) addMedia(entry.name, '', 'resource'); } catch (_) {}
    return roots;
  }
  function scheduleScan() {
    if (!scanTimer) scanTimer = setTimeout(() => { scanTimer = null; scanMedia(); }, 200);
  }
  function mediaDetails() { scanMedia(); return [...mediaRecords.values()]; }
  function media() { return mediaDetails().map(record => record.url); }
  function probe(snapshot = false) {
    // Only metadata preload on existing video sources. No play(), synthetic clicks or gate acceptance.
    if (gate()) return { blocked: true };
    const roots = scanMedia();
    for (const root of roots) for (const video of root.querySelectorAll('video')) {
      if (primed.has(video) || video.readyState > 0 || !video.paused || !(video.getAttribute('src') || video.querySelector('source[src]'))) continue;
      primed.add(video);
      try { video.preload = 'metadata'; video.load(); } catch (_) {}
    }
    for (const frame of document.querySelectorAll('iframe')) {
      try { frame.contentWindow?.postMessage({ type: 'madar:probe-metadata:v2', snapshot }, '*'); } catch (_) {}
    }
    if (snapshot) for (const [url, record] of mediaRecords) pendingReports.set(url, record);
    reportMedia();
    return { count: mediaRecords.size };
  }
  try {
    const nativeFetch = window.fetch;
    if (typeof nativeFetch === 'function') window.fetch = function(...args) {
      const promise = Reflect.apply(nativeFetch, this, args);
      promise.then(response => {
        try { addMedia(response.url, response.headers.get('content-type') || '', 'fetch MIME'); } catch (_) {}
      }, () => {});
      return promise;
    };
  } catch (_) {}
  try {
    const nativeOpen = XMLHttpRequest.prototype.open, observed = new WeakSet();
    XMLHttpRequest.prototype.open = function(...args) {
      if (!observed.has(this)) {
        observed.add(this);
        this.addEventListener('load', () => {
          try { addMedia(this.responseURL, this.getResponseHeader('content-type') || '', 'XHR MIME'); } catch (_) {}
        });
      }
      return Reflect.apply(nativeOpen, this, args);
    };
  } catch (_) {}
  try {
    new PerformanceObserver(list => {
      for (const entry of list.getEntries()) addMedia(entry.name, '', 'resource observer');
    }).observe({ type: 'resource', buffered: true });
  } catch (_) {}
  try {
    new MutationObserver(scheduleScan).observe(document, { subtree: true, childList: true, attributes: true,
      attributeFilter: ['src', 'type', 'data-src', 'data-file'] });
  } catch (_) {}
  for (const event of ['loadedmetadata', 'loadstart', 'canplay', 'durationchange'])
    document.addEventListener(event, scheduleScan, true);
  window.addEventListener('message', event => {
    if (window !== window.top && event.source === window.parent && event.data?.type === 'madar:probe-metadata:v2') probe(event.data.snapshot === true);
  });
  document.addEventListener('DOMContentLoaded', scheduleScan, { once: true });
  let pickingHandler = null, recordingHandler = null, recordingToken = null;
  function cancelSearchTeaching() {
    if (pickingHandler) document.removeEventListener('click', pickingHandler, true);
    if (recordingHandler) document.removeEventListener('click', recordingHandler, true);
    pickingHandler = null; recordingHandler = null; recordingToken = null;
    return true;
  }
  function pickField(token = '') {
    cancelSearchTeaching();
    pickingHandler = event => {
      if (!event.isTrusted || gate()) return;
      const input = event.target instanceof Element ? event.target.closest('input,textarea') : null;
      if (!safeField(input)) return;
      const selector = stableSelector(input); if (!selector) return;
      event.preventDefault(); event.stopImmediatePropagation(); cancelSearchTeaching();
      window.webkit?.messageHandlers?.mdField?.postMessage({ selector, url: location.href, token });
    };
    document.addEventListener('click', pickingHandler, true);
    return true;
  }
  function startSearchRecording(token) {
    if (recordingToken === token && recordingHandler) return true;
    cancelSearchTeaching(); recordingToken = token;
    recordingHandler = event => {
      if (!event.isTrusted || gate() || !(event.target instanceof Element)) return;
      const input = event.target.closest('input,textarea');
      if (input) {
        if (!safeField(input)) return;
        const selector = stableSelector(input); if (!selector) return;
        event.preventDefault(); event.stopImmediatePropagation(); cancelSearchTeaching();
        window.webkit?.messageHandlers?.mdField?.postMessage({ selector, url: location.href, token });
        return;
      }
      const control = event.target.closest(controlSelector);
      if (!safeControl(control)) return;
      const selector = stableSelector(control); if (!selector) return;
      // Only selector + short control description; never input values or keyboard events.
      window.webkit?.messageHandlers?.mdSearchStep?.postMessage({ selector, label: controlLabel(control), url: location.href, token });
      // Let this real user click open the menu or navigate normally.
    };
    document.addEventListener('click', recordingHandler, true);
    return true;
  }
  window.__madar = { gate, results, search, media, mediaDetails, probe, duration, pickField, resetSearch, inspectSearch, clickSearchStep, waitForSearch,
    searchSnapshot, startSearchRecording, cancelSearchTeaching };
  scheduleScan();
})();
