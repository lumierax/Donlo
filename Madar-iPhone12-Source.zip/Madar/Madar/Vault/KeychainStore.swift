import Foundation
import Security
import LocalAuthentication

/// A biometric convenience copy. The passphrase-wrapped key remains the recovery path.
enum BiometricKeychain {
    static let service = "app.madar.private.biometric.v1"
    static var query: [String: Any] {
        [kSecClass as String: kSecClassGenericPassword, kSecAttrService as String: service,
         kSecAttrAccount as String: "master"]
    }
    static func put(_ data: Data) throws {
        let context = LAContext(); var error: NSError?
        guard context.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: &error) else {
            throw MadarError.message("Face ID غير متاح أو لم يُضبط على الجهاز.")
        }
        var failure: Unmanaged<CFError>?
        guard let access = SecAccessControlCreateWithFlags(nil, kSecAttrAccessibleWhenUnlockedThisDeviceOnly, .biometryCurrentSet, &failure) else {
            throw MadarError.message("تعذر إعداد حماية Face ID.")
        }
        remove()
        var q = query; q[kSecAttrAccessControl as String] = access; q[kSecValueData as String] = data
        guard SecItemAdd(q as CFDictionary, nil) == errSecSuccess else { throw MadarError.message("تعذر حفظ مفتاح Face ID.") }
    }
    static func read() throws -> Data {
        var q = query; let context = LAContext()
        context.localizedReason = "فتح المساحة الخاصة في مدار"
        context.localizedFallbackTitle = ""
        q[kSecUseAuthenticationContext as String] = context
        q[kSecReturnData as String] = true
        q[kSecMatchLimit as String] = kSecMatchLimitOne
        var item: CFTypeRef?
        let status = SecItemCopyMatching(q as CFDictionary, &item)
        guard status == errSecSuccess, let data = item as? Data, data.count == 32 else {
            throw MadarError.message("لم يُفتح Face ID. استخدم رمزك؛ تغيير بصمة الوجه قد يلغي المفتاح الحيوي.")
        }
        return data
    }
    static func remove() { SecItemDelete(query as CFDictionary) }
}
