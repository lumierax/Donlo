import Foundation
import Combine
import CryptoKit

private struct KeyEnvelope: Codable {
    var version = 1
    var salt: Data
    var rounds: UInt32
    var wrappedKey: Data
    var biometricEnabled = false
    var failures = 0
    var retryAfter: Date?
}

@MainActor
final class VaultStore: ObservableObject {
    @Published private(set) var isConfigured = false
    @Published private(set) var isUnlocked = false
    @Published private(set) var index = VaultIndex()
    @Published private(set) var biometricEnabled = false
    @Published private(set) var isUpdatingBiometrics = false
    let paths: PrivatePaths
    private var master: SymmetricKey?
    private var generation = UUID()
    var beforeLock: (() -> Void)?

    init(paths: PrivatePaths) {
        self.paths = paths
        paths.purgeStaging()
        isConfigured = FileManager.default.fileExists(atPath: paths.envelope.path)
        biometricEnabled = (try? loadEnvelope())?.biometricEnabled ?? false
    }
    private func loadEnvelope() throws -> KeyEnvelope {
        try JSONDecoder().decode(KeyEnvelope.self, from: Data(contentsOf: paths.envelope))
    }
    private func saveEnvelope(_ envelope: KeyEnvelope) throws { try PrivatePaths.write(JSONEncoder().encode(envelope), to: paths.envelope) }
    func configure(passphrase: String) async throws {
        guard !isConfigured else { throw MadarError.message("الحماية معدّة بالفعل.") }
        guard passphrase.count >= 8, passphrase.utf8.count <= 256 else { throw MadarError.message("استخدم رمزًا أو عبارة من 8 أحرف على الأقل، وبحد أقصى 256 بايت.") }
        let stamp = generation
        let (envelope, bytes) = try await Task.detached(priority: .userInitiated) {
            let bytes = try VaultCrypto.random(32), salt = try VaultCrypto.random(16)
            let derived = try VaultCrypto.derive(passphrase: passphrase, salt: salt)
            let wrapped = try VaultCrypto.seal(bytes, key: derived, context: "Madar.pin.v1")
            return (KeyEnvelope(salt: salt, rounds: VaultCrypto.rounds, wrappedKey: wrapped), bytes)
        }.value
        try Task.checkCancellation()
        guard stamp == generation else { throw CancellationError() }
        let key = SymmetricKey(data: bytes)
        let empty = try VaultCrypto.seal(JSONEncoder().encode(VaultIndex()), key: key, context: "Madar.index.v1")
        try PrivatePaths.write(empty, to: paths.index)
        try saveEnvelope(envelope)
        master = key; isConfigured = true; isUnlocked = true; index = VaultIndex()
    }
    func unlock(passphrase: String) async throws {
        guard isConfigured else { throw MadarError.locked }
        var envelope = try loadEnvelope()
        if let retry = envelope.retryAfter, retry > Date() {
            throw MadarError.message("محاولات كثيرة. حاول بعد \(Int(ceil(retry.timeIntervalSinceNow))) ثانية.")
        }
        let stamp = generation
        let bytes: Data
        let salt = envelope.salt, rounds = envelope.rounds, wrapped = envelope.wrappedKey
        do {
            bytes = try await Task.detached(priority: .userInitiated) {
                let derived = try VaultCrypto.derive(passphrase: passphrase, salt: salt, rounds: rounds)
                return try VaultCrypto.open(wrapped, key: derived, context: "Madar.pin.v1")
            }.value
        } catch {
            try Task.checkCancellation()
            guard stamp == generation else { throw CancellationError() }
            envelope.failures += 1
            if envelope.failures >= 5 { envelope.retryAfter = Date().addingTimeInterval(min(300, pow(2, Double(min(envelope.failures - 5, 8))) * 5)) }
            try saveEnvelope(envelope)
            throw MadarError.message("الرمز غير صحيح، أو ملف الحماية تالف. لم تُحذف أي فيديوهات.")
        }
        try Task.checkCancellation()
        guard stamp == generation else { throw CancellationError() }
        try openIndex(bytes: bytes)
        envelope.failures = 0; envelope.retryAfter = nil; try saveEnvelope(envelope)
    }
    func unlockBiometric() async throws {
        let stamp = generation
        let bytes = try await Task.detached(priority: .userInitiated) { try BiometricKeychain.read() }.value
        try Task.checkCancellation()
        guard stamp == generation else { throw CancellationError() }
        try openIndex(bytes: bytes)
    }
    private func openIndex(bytes: Data) throws {
        let key = SymmetricKey(data: bytes)
        let plain = try VaultCrypto.open(Data(contentsOf: paths.index), key: key, context: "Madar.index.v1")
        let decoded = try JSONDecoder().decode(VaultIndex.self, from: plain)
        master = key; index = decoded; isUnlocked = true
        // Clean only unreferenced, already-encrypted interrupted imports.
        let known = Set(decoded.entries.map(\.fileName))
        for url in (try? FileManager.default.contentsOfDirectory(at: paths.files, includingPropertiesForKeys: nil)) ?? [] {
            if !known.contains(url.lastPathComponent) { try? FileManager.default.removeItem(at: url) }
        }
    }
    func lock() {
        generation = UUID(); beforeLock?()
        master = nil; index = VaultIndex(); isUnlocked = false
        paths.purgeStaging()
    }
    func key() throws -> SymmetricKey { guard let master, isUnlocked else { throw MadarError.locked }; return master }
    private func persist(_ next: VaultIndex) throws {
        let encrypted = try VaultCrypto.seal(JSONEncoder().encode(next), key: key(), context: "Madar.index.v1")
        try PrivatePaths.write(encrypted, to: paths.index); index = next
    }
    func setBiometric(_ enabled: Bool) async throws {
        guard !isUpdatingBiometrics else { throw MadarError.message("تحديث إعداد Face ID قيد التنفيذ.") }
        isUpdatingBiometrics = true; defer { isUpdatingBiometrics = false }
        let key = try key(); let stamp = generation
        if enabled {
            let bytes = key.withUnsafeBytes { Data($0) }
            try await Task.detached { try BiometricKeychain.put(bytes) }.value
        } else { BiometricKeychain.remove() }
        guard stamp == generation else { BiometricKeychain.remove(); throw CancellationError() }
        var envelope = try loadEnvelope(); envelope.biometricEnabled = enabled
        try saveEnvelope(envelope); biometricEnabled = enabled
    }
    func addFolder(_ raw: String) throws -> UUID {
        let name = String(raw.trimmingCharacters(in: .whitespacesAndNewlines).prefix(60))
        guard !name.isEmpty else { throw MadarError.message("اكتب اسم المجلد.") }
        if let existing = index.folders.first(where: { $0.name == name }) { return existing.id }
        let folder = VaultFolder(name: name); var next = index; next.folders.append(folder); try persist(next); return folder.id
    }
    func removeFolder(_ id: UUID) throws {
        var next = index; next.folders.removeAll { $0.id == id }
        for i in next.entries.indices where next.entries[i].folderID == id { next.entries[i].folderID = nil }
        try persist(next)
    }
    func move(_ id: UUID, folder: UUID?) throws {
        var next = index
        guard let i = next.entries.firstIndex(where: { $0.id == id }) else { return }
        next.entries[i].folderID = folder; try persist(next)
    }
    func rename(_ id: UUID, title: String) throws {
        let clean = title.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !clean.isEmpty else { return }
        var next = index; guard let i = next.entries.firstIndex(where: { $0.id == id }) else { return }
        next.entries[i].title = String(clean.prefix(300)); try persist(next)
    }
    func remove(_ id: UUID) throws {
        guard let item = index.entries.first(where: { $0.id == id }) else { return }
        var next = index; next.entries.removeAll { $0.id == id }
        try persist(next)
        try FileManager.default.removeItem(at: paths.files.appendingPathComponent(item.fileName))
    }
    func importFile(_ url: URL, title: String, ext: String, quality: String, folder: UUID?, progress: @escaping @Sendable (Double) -> Void) async throws -> VaultEntry {
        let key = try key(), stamp = generation, id = UUID()
        let destination = paths.files.appendingPathComponent(id.uuidString + ".mdv")
        let job = Task.detached(priority: .utility) { try ChunkCipher.encrypt(input: url, output: destination, key: key, progress: progress) }
        let bytes = try await withTaskCancellationHandler { try await job.value } onCancel: { job.cancel() }
        guard stamp == generation, isUnlocked, !Task.isCancelled else {
            try? FileManager.default.removeItem(at: destination); throw CancellationError()
        }
        try FileManager.default.setAttributes([.protectionKey: FileProtectionType.complete], ofItemAtPath: destination.path)
        let entry = VaultEntry(id: id, title: title, fileExtension: ext, bytes: Int64(bytes), folderID: folder, quality: quality)
        var next = index; next.entries.insert(entry, at: 0)
        do { try persist(next) }
        catch { try? FileManager.default.removeItem(at: destination); throw error }
        return entry
    }
}
