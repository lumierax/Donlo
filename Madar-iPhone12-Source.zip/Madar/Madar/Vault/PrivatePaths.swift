import Foundation

struct PrivatePaths {
    let root: URL
    let files: URL
    let staging: URL
    let index: URL
    let envelope: URL
    init() throws {
        let support = try FileManager.default.url(for: .applicationSupportDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
        root = support.appendingPathComponent(".MadarStore", isDirectory: true)
        files = root.appendingPathComponent("objects", isDirectory: true)
        staging = root.appendingPathComponent("staging", isDirectory: true)
        index = root.appendingPathComponent("index.sealed")
        envelope = root.appendingPathComponent("gate.json")
        for url in [root, files, staging] {
            try FileManager.default.createDirectory(at: url, withIntermediateDirectories: true,
                attributes: [.protectionKey: FileProtectionType.complete])
            var u = url; var values = URLResourceValues(); values.isExcludedFromBackup = true
            try u.setResourceValues(values)
        }
    }
    static func write(_ data: Data, to url: URL) throws {
        try data.write(to: url, options: [.atomic, .completeFileProtection])
        var url = url; var values = URLResourceValues(); values.isExcludedFromBackup = true
        try url.setResourceValues(values)
    }
    func purgeStaging() {
        for url in (try? FileManager.default.contentsOfDirectory(at: staging, includingPropertiesForKeys: nil)) ?? [] {
            try? FileManager.default.removeItem(at: url)
        }
    }
}
