import Foundation
import AVFoundation
import CryptoKit
import UniformTypeIdentifiers
import Combine

final class EncryptedAssetLoader: NSObject, AVAssetResourceLoaderDelegate, @unchecked Sendable {
    let queue = DispatchQueue(label: "app.madar.vault.playback", qos: .userInitiated)
    private var key: SymmetricKey?
    private let stateLock = NSLock()
    private var invalidated = false
    private var isInvalidated: Bool { stateLock.lock(); defer { stateLock.unlock() }; return invalidated }
    private let file: FileHandle
    private let header: ChunkCipher.Header
    private let contentType: String
    init(url: URL, key: SymmetricKey, ext: String) throws {
        file = try FileHandle(forReadingFrom: url)
        header = try ChunkCipher.readHeader(file)
        self.key = key
        contentType = UTType(filenameExtension: ext)?.identifier ?? UTType.mpeg4Movie.identifier
        super.init()
    }
    func invalidate() {
        stateLock.lock(); invalidated = true; stateLock.unlock()
        queue.async { [self] in key = nil; try? file.close() }
    }
    deinit { try? file.close() }
    func resourceLoader(_ resourceLoader: AVAssetResourceLoader, shouldWaitForLoadingOfRequestedResource request: AVAssetResourceLoadingRequest) -> Bool {
        do {
            guard let key, !isInvalidated else { throw MadarError.locked }
            if let info = request.contentInformationRequest {
                info.contentLength = Int64(header.size)
                info.contentType = contentType
                info.isByteRangeAccessSupported = true
            }
            if let dataRequest = request.dataRequest {
                let initial = dataRequest.currentOffset > 0 ? dataRequest.currentOffset : dataRequest.requestedOffset
                guard initial >= 0, UInt64(initial) <= header.size, dataRequest.requestedOffset >= 0 else { throw MadarError.unsupported }
                let start = UInt64(initial)
                let end: UInt64
                if dataRequest.requestsAllDataToEndOfResource { end = header.size }
                else {
                    let wanted = UInt64(dataRequest.requestedOffset).addingReportingOverflow(UInt64(max(0, dataRequest.requestedLength)))
                    guard !wanted.overflow else { throw MadarError.unsupported }
                    end = min(header.size, wanted.partialValue)
                }
                var offset = start
                while offset < end, !request.isCancelled {
                    guard !isInvalidated else { throw MadarError.locked }
                    let count = Int(min(UInt64(ChunkCipher.chunkSize), end - offset))
                    let bytes = try ChunkCipher.read(file: file, header: header, key: key, offset: offset, count: count)
                    dataRequest.respond(with: bytes); offset += UInt64(bytes.count)
                }
            }
            if !request.isCancelled { request.finishLoading() }
        } catch { if !request.isCancelled { request.finishLoading(with: error) } }
        return true
    }
}

@MainActor
final class PlaybackSession: ObservableObject, Identifiable {
    let id = UUID()
    let player: AVPlayer
    let title: String
    @Published private(set) var error: String?
    private var observation: NSKeyValueObservation?
    private let loader: EncryptedAssetLoader
    init(entry: VaultEntry, vault: VaultStore) throws {
        title = entry.title
        loader = try EncryptedAssetLoader(url: vault.paths.files.appendingPathComponent(entry.fileName), key: vault.key(), ext: entry.fileExtension)
        guard let url = URL(string: "madar-vault://\(entry.id.uuidString)/media.\(entry.fileExtension)") else { throw MadarError.invalidURL }
        let asset = AVURLAsset(url: url)
        asset.resourceLoader.setDelegate(loader, queue: loader.queue)
        player = AVPlayer(playerItem: AVPlayerItem(asset: asset))
        player.allowsExternalPlayback = false
        observation = player.currentItem?.observe(\.status, options: [.new]) { [weak self] item, _ in
            guard item.status == .failed else { return }
            let description = item.error?.localizedDescription ?? "تعذر تشغيل هذا الفيديو على الجهاز."
            Task { @MainActor [weak self] in self?.error = description }
        }
    }
    func stop() { observation = nil; player.pause(); player.replaceCurrentItem(with: nil); loader.invalidate() }
}
