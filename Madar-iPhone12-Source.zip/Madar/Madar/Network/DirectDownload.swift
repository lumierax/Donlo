import Foundation

/// One foreground transfer per instance. URLSession owns its temporary file only until
/// didFinishDownloadingTo returns, so move it synchronously in that delegate callback.
final class DirectDownload: NSObject, URLSessionDownloadDelegate, @unchecked Sendable {
    private var session: URLSession!
    private let lock = NSLock()
    private var task: URLSessionDownloadTask?
    private var continuation: CheckedContinuation<URL, Error>?
    private var destination: URL?
    private var resultURL: URL?
    private var fileError: Error?
    private var cancelled = false
    private var progress: (@Sendable (Double?) -> Void)?

    override init() { super.init() }
    func run(request: URLRequest, cookies: [HTTPCookie], destination: URL, progress: @escaping @Sendable (Double?) -> Void) async throws -> URL {
        try await withTaskCancellationHandler {
            try await withCheckedThrowingContinuation { c in
                lock.lock()
                if cancelled { lock.unlock(); c.resume(throwing: CancellationError()); return }
                self.continuation = c; self.destination = destination; self.progress = progress
                let config = URLSessionConfiguration.ephemeral
                config.urlCache = nil; config.timeoutIntervalForRequest = 60; config.timeoutIntervalForResource = 3600
                config.httpShouldSetCookies = true
                cookies.forEach { config.httpCookieStorage?.setCookie($0) }
                let queue = OperationQueue(); queue.maxConcurrentOperationCount = 1
                session = URLSession(configuration: config, delegate: self, delegateQueue: queue)
                let task = session.downloadTask(with: request); self.task = task
                lock.unlock(); task.resume()
            }
        } onCancel: { self.cancel() }
    }
    func cancel() { lock.lock(); cancelled = true; let task = task; lock.unlock(); task?.cancel() }
    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didWriteData bytesWritten: Int64, totalBytesWritten: Int64, totalBytesExpectedToWrite: Int64) {
        progress?(totalBytesExpectedToWrite > 0 ? Double(totalBytesWritten) / Double(totalBytesExpectedToWrite) : nil)
    }
    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didFinishDownloadingTo location: URL) {
        do {
            guard let http = downloadTask.response as? HTTPURLResponse else { throw MadarError.message("رد التنزيل غير صالح.") }
            guard (200...299).contains(http.statusCode) else { throw HTTPFailure(status: http.statusCode, retryAfter: DownloadPolicy.retryAfter(http.value(forHTTPHeaderField: "Retry-After"))) }
            guard http.url?.scheme == "https" else { throw MadarError.insecureURL }
            let mime = http.mimeType?.lowercased() ?? ""
            guard !mime.contains("html"), !mime.contains("json"), !mime.hasPrefix("text/") else {
                throw DownloadContentError.notVideo
            }
            let bytes = (try FileManager.default.attributesOfItem(atPath: location.path)[.size] as? NSNumber)?.int64Value ?? 0
            guard bytes > 0 else { throw DownloadContentError.empty }
            if http.statusCode == 206 {
                guard DownloadPolicy.completeByteRange(http.value(forHTTPHeaderField: "Content-Range"), bytes: bytes) else { throw DownloadContentError.partial }
            }
            if http.expectedContentLength > 0, http.value(forHTTPHeaderField: "Content-Encoding") == nil,
               bytes != http.expectedContentLength { throw DownloadContentError.partial }
            guard let destination else { throw MadarError.message("وجهة التنزيل مفقودة.") }
            try FileManager.default.moveItem(at: location, to: destination)
            try FileManager.default.setAttributes([.protectionKey: FileProtectionType.complete], ofItemAtPath: destination.path)
            resultURL = destination
        } catch { fileError = error }
    }
    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        lock.lock(); let c = continuation; continuation = nil; let wasCancelled = cancelled; lock.unlock()
        defer { session.finishTasksAndInvalidate() }
        if let error = fileError ?? error { c?.resume(throwing: error) }
        else if wasCancelled { c?.resume(throwing: CancellationError()) }
        else if let url = resultURL { c?.resume(returning: url) }
        else { c?.resume(throwing: MadarError.message("لم يكتمل تنزيل الملف.")) }
    }
    func urlSession(_ session: URLSession, task: URLSessionTask, willPerformHTTPRedirection response: HTTPURLResponse, newRequest request: URLRequest, completionHandler: @escaping (URLRequest?) -> Void) {
        guard let next = request.url, next.scheme == "https", next.user == nil, next.password == nil else { completionHandler(nil); return }
        var safe = request
        if let previous = response.url, !URLTools.sameOrigin(previous, next) {
            safe.setValue(nil, forHTTPHeaderField: "Authorization")
            safe.setValue(nil, forHTTPHeaderField: "Cookie") // Let cookie storage apply domain/path rules.
        }
        completionHandler(safe)
    }
}
