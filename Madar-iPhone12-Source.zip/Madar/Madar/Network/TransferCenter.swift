import Foundation
import Combine
import AVFoundation

struct DownloadChoice: Identifiable {
    let id = UUID()
    var result: VideoResult
    var source: MediaSource
    var folder: UUID?
}
struct TransferItem: Identifiable {
    enum State { case queued, downloading, exporting, encrypting, completed, failed, cancelled }
    let id: UUID
    var choice: DownloadChoice
    var state: State = .queued
    var progress: Double? = 0
    var note: String = "في الانتظار"
    var active: Bool { [.queued, .downloading, .exporting, .encrypting].contains(state) }
}

@MainActor
final class TransferCenter: ObservableObject {
    @Published private(set) var items: [TransferItem] = []
    private var worker: Task<Void, Never>?
    private var activeID: UUID?
    private let vault: VaultStore
    private let resolver: MediaResolver
    var activeCount: Int { items.filter(\.active).count }
    init(vault: VaultStore, resolver: MediaResolver) { self.vault = vault; self.resolver = resolver }
    func enqueue(_ choice: DownloadChoice) throws {
        guard vault.isUnlocked else { throw MadarError.locked }
        guard !items.contains(where: { $0.active && $0.choice.source.id == choice.source.id }) else {
            throw MadarError.message("هذا الفيديو موجود بالفعل في قائمة التنزيل.")
        }
        items.insert(TransferItem(id: choice.id, choice: choice), at: 0); startNext()
    }
    func update(_ id: UUID, state: TransferItem.State? = nil, progress: Double? = nil, note: String? = nil, unknownProgress: Bool = false) {
        guard let i = items.firstIndex(where: { $0.id == id }) else { return }
        if let state { items[i].state = state }
        if let progress { items[i].progress = min(1, max(0, progress)) }
        if unknownProgress { items[i].progress = nil }
        if let note { items[i].note = note }
    }
    func cancel(_ id: UUID) {
        if activeID == id { worker?.cancel() }
        update(id, state: .cancelled, note: "أُلغي التنزيل. إعادة المحاولة تبدأ من جديد.")
    }
    func cancelAllForPrivacy() {
        worker?.cancel()
        for i in items.indices where items[i].active {
            items[i].state = .cancelled; items[i].note = "توقف لحماية الخصوصية. افتح المساحة الخاصة ثم أعد المحاولة."
        }
    }
    func retry(_ id: UUID) throws {
        guard vault.isUnlocked else { throw MadarError.locked }
        guard activeID != id else { throw MadarError.message("انتظر انتهاء إلغاء المحاولة السابقة، ثم أعد المحاولة.") }
        guard let i = items.firstIndex(where: { $0.id == id }), !items[i].active else { return }
        items[i].state = .queued; items[i].note = "إعادة المحاولة"; items[i].progress = 0; startNext()
    }
    func clearFinished() { items.removeAll { !$0.active } }
    private func startNext() {
        guard worker == nil, vault.isUnlocked, let item = items.last(where: { $0.state == .queued }) else { return }
        activeID = item.id
        worker = Task { [weak self] in
            guard let self else { return }
            await perform(item)
            worker = nil; activeID = nil; startNext()
        }
    }
    private func failureInfo(_ error: Error) -> (status: Int?, code: Int?, after: TimeInterval?) {
        var current = error
        for _ in 0..<6 {
            if let http = current as? HTTPFailure { return (http.status, nil, http.retryAfter) }
            if case MadarError.badResponse(let status) = current { return (status, nil, nil) }
            let ns = current as NSError
            if ns.domain == NSURLErrorDomain { return (nil, ns.code, nil) }
            guard let underlying = ns.userInfo[NSUnderlyingErrorKey] as? Error else { break }
            current = underlying
        }
        return (nil, nil, nil)
    }
    private func cookieSignature(_ cookies: [HTTPCookie]) -> [String] {
        cookies.map { "\($0.domain)|\($0.path)|\($0.name)|\($0.value)" }.sorted()
    }
    private func perform(_ item: TransferItem) async {
        var staging: URL?
        defer { if let staging { try? FileManager.default.removeItem(at: staging) } }
        do {
            try Task.checkCancellation()
            let session = await resolver.downloadSession()
            defer { session.browser.stop() }
            var choice = item.choice; var refreshed = false; var completed = false
            var ext = "mp4"
            for attempt in 1...DownloadPolicy.maximumAttempts {
                try Task.checkCancellation()
                guard vault.isUnlocked else { throw MadarError.locked }
                if let staging { try? FileManager.default.removeItem(at: staging) }
                ext = choice.source.kind == .hls ? "mp4" :
                    (["mp4", "mov", "m4v", "webm"].contains(choice.source.url.pathExtension.lowercased()) ? choice.source.url.pathExtension.lowercased() : "mp4")
                let destination = vault.paths.staging.appendingPathComponent(UUID().uuidString).appendingPathExtension(ext)
                staging = destination
                let label = "المحاولة \(attempt)/\(DownloadPolicy.maximumAttempts)"
                do {
                    let cookies = await session.browser.cookies()
                    session.network.replaceCookies(cookies)
                    if choice.source.kind == .hls {
                        update(item.id, state: .exporting, progress: 0, note: "فحص HLS وتجهيز الفيديو · " + label)
                        try await session.validateHLS(choice.source, page: choice.result.pageURL)
                        try await exportHLS(choice.source.url, to: destination, id: item.id, session: session)
                    } else {
                        guard choice.source.kind == .file else { throw MadarError.unsupported }
                        update(item.id, state: .downloading, progress: 0, note: "جارٍ تنزيل الفيديو · " + label)
                        var request = try session.network.request(choice.source.url,
                            referer: choice.source.requestReferer ?? choice.result.pageURL, userAgent: session.browser.userAgent)
                        request.timeoutInterval = 60
                        _ = try await DirectDownload().run(request: request, cookies: cookies, destination: destination) { [weak self] value in
                            Task { @MainActor in
                                guard let self, self.items.first(where: { $0.id == item.id })?.state == .downloading else { return }
                                self.update(item.id, progress: value.map { $0 * 0.85 }, unknownProgress: value == nil)
                            }
                        }
                    }
                    try Task.checkCancellation()
                    let asset = AVURLAsset(url: destination)
                    let videoTracks = try await asset.loadTracks(withMediaType: .video)
                    guard !videoTracks.isEmpty else { throw DownloadContentError.unreadable }
                    completed = true; break
                } catch {
                    try? FileManager.default.removeItem(at: destination)
                    try Task.checkCancellation()
                    let info = failureInfo(error)
                    if info.code == NSURLErrorCancelled || error is CancellationError { throw CancellationError() }
                    let needsRefresh = info.status.map(DownloadPolicy.shouldRefresh) ?? (error is DownloadContentError)
                    if needsRefresh && !refreshed && attempt < DownloadPolicy.maximumAttempts && URLTools.mediaKind(choice.result.pageURL) == nil {
                        refreshed = true
                        update(item.id, state: .downloading, progress: 0, note: "إعادة فحص صفحة الفيديو لتجديد الرابط والجلسة")
                        let oldCookies = cookieSignature(await session.browser.cookies())
                        let resolution = try await session.resolve(choice.result, deep: true)
                        try Task.checkCancellation()
                        let newCookies = cookieSignature(await session.browser.cookies())
                        if var renewed = DownloadPolicy.refreshedSource(for: choice.source, in: resolution.sources),
                           renewed.id != choice.source.id || oldCookies != newCookies {
                            renewed.height = renewed.height ?? choice.source.height
                            renewed.label = renewed.label ?? choice.source.label
                            choice.source = renewed
                            if let i = items.firstIndex(where: { $0.id == item.id }) { items[i].choice.source = renewed }
                            continue
                        }
                        throw MadarError.message(error.localizedDescription + "\nلم يظهر رابط متجدد للفيديو نفسه. افتح صفحة الفيديو وشغّله ثم أعد فحص الجودات؛ لن نختار فيديو آخر تلقائيًا.")
                    }
                    guard let delay = DownloadPolicy.retryDelay(status: info.status, networkCode: info.code,
                        failedAttempt: attempt, retryAfter: info.after) else { throw error }
                    update(item.id, progress: 0, note: "تعطل مؤقت؛ إعادة تلقائية بعد \(Int(ceil(delay))) ثانية · المحاولة \(attempt + 1)/\(DownloadPolicy.maximumAttempts)")
                    try await Task.sleep(nanoseconds: UInt64(delay * 1_000_000_000))
                }
            }
            guard completed, let staging else { throw MadarError.message("لم يكتمل التنزيل بعد المحاولات المحددة.") }
            try Task.checkCancellation()
            update(item.id, state: .encrypting, progress: 0.86, note: "تشفير الفيديو وحفظه داخليًا")
            _ = try await vault.importFile(staging, title: choice.result.title, ext: ext, quality: choice.source.quality, folder: choice.folder) { [weak self] fraction in
                Task { @MainActor in
                    guard let self, self.items.first(where: { $0.id == item.id })?.state == .encrypting else { return }
                    self.update(item.id, progress: 0.86 + fraction * 0.13)
                }
            }
            update(item.id, state: .completed, progress: 1, note: "اكتمل الحفظ داخل المساحة الخاصة")
        } catch {
            if Task.isCancelled || error is CancellationError || failureInfo(error).code == NSURLErrorCancelled {
                update(item.id, state: .cancelled, note: "توقف التنزيل. إعادة المحاولة تبدأ من جديد.")
            } else { update(item.id, state: .failed, note: error.localizedDescription) }
        }
    }
    private func exportHLS(_ url: URL, to destination: URL, id: UUID, session: MediaResolver) async throws {
        var options: [String: Any] = [AVURLAssetHTTPCookiesKey: await session.browser.cookies()]
        if !session.browser.userAgent.isEmpty { options[AVURLAssetHTTPUserAgentKey] = session.browser.userAgent }
        let asset = AVURLAsset(url: url, options: options)
        let protected = try await asset.load(.hasProtectedContent)
        guard !protected else { throw MadarError.message("الفيديو محمي ولا يُسمح بتصديره.") }
        guard let exporter = AVAssetExportSession(asset: asset, presetName: AVAssetExportPresetHighestQuality), exporter.supportedFileTypes.contains(.mp4) else {
            throw MadarError.message("هذا البث لا يدعم تصدير MP4 عبر AVFoundation. لم يُحفظ ملف ناقص.")
        }
        exporter.outputURL = destination; exporter.outputFileType = .mp4; exporter.shouldOptimizeForNetworkUse = true
        let monitor = Task { [weak self] in
            while !Task.isCancelled {
                self?.update(id, progress: Double(exporter.progress) * 0.85)
                try? await Task.sleep(nanoseconds: 350_000_000)
            }
        }
        defer { monitor.cancel() }
        await withTaskCancellationHandler {
            await withCheckedContinuation { (c: CheckedContinuation<Void, Never>) in exporter.exportAsynchronously { c.resume() } }
        } onCancel: { exporter.cancelExport() }
        try Task.checkCancellation()
        guard exporter.status == .completed else {
            throw MadarError.message("تعذر تجهيز HLS: \(exporter.error?.localizedDescription ?? "المصدر لا يسمح بالتصدير")")
        }
        try FileManager.default.setAttributes([.protectionKey: FileProtectionType.complete], ofItemAtPath: destination.path)
    }
}
