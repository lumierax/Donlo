import Foundation
import Combine
import AVFoundation

struct DownloadChoice: Identifiable {
    let id = UUID()
    var result: VideoResult
    var source: MediaSource
    var folder: UUID?
}
struct TransferItem: Identifiable {
    enum State { case queued, downloading, exporting, encrypting, completed, failed, cancelled }
    let id: UUID
    var choice: DownloadChoice
    var state: State = .queued
    var progress: Double? = 0
    var note: String = "في الانتظار"
    var active: Bool { [.queued, .downloading, .exporting, .encrypting].contains(state) }
}

@MainActor
final class TransferCenter: ObservableObject {
    @Published private(set) var items: [TransferItem] = []
    private var worker: Task<Void, Never>?
    private var activeID: UUID?
    private let vault: VaultStore
    private let resolver: MediaResolver
    var activeCount: Int { items.filter(\.active).count }
    init(vault: VaultStore, resolver: MediaResolver) { self.vault = vault; self.resolver = resolver }
    func enqueue(_ choice: DownloadChoice) throws {
        guard vault.isUnlocked else { throw MadarError.locked }
        guard !items.contains(where: { $0.active && $0.choice.source.id == choice.source.id }) else {
            throw MadarError.message("هذا الفيديو موجود بالفعل في قائمة التنزيل.")
        }
        items.insert(TransferItem(id: choice.id, choice: choice), at: 0); startNext()
    }
    func update(_ id: UUID, state: TransferItem.State? = nil, progress: Double? = nil, note: String? = nil, unknownProgress: Bool = false) {
        guard let i = items.firstIndex(where: { $0.id == id }) else { return }
        if let state { items[i].state = state }
        if let progress { items[i].progress = min(1, max(0, progress)) }
        if unknownProgress { items[i].progress = nil }
        if let note { items[i].note = note }
    }
    func cancel(_ id: UUID) {
        if activeID == id { worker?.cancel() }
        update(id, state: .cancelled, note: "أُلغي التنزيل. إعادة المحاولة تبدأ من جديد.")
    }
    func cancelAllForPrivacy() {
        worker?.cancel()
        for i in items.indices where items[i].active {
            items[i].state = .cancelled; items[i].note = "توقف لحماية الخصوصية. افتح المساحة الخاصة ثم أعد المحاولة."
        }
    }
    func retry(_ id: UUID) throws {
        guard vault.isUnlocked else { throw MadarError.locked }
        guard activeID != id else { throw MadarError.message("انتظر انتهاء إلغاء المحاولة السابقة، ثم أعد المحاولة.") }
        guard let i = items.firstIndex(where: { $0.id == id }), !items[i].active else { return }
        items[i].state = .queued; items[i].note = "إعادة المحاولة"; items[i].progress = 0; startNext()
    }
    func clearFinished() { items.removeAll { !$0.active } }
    private func startNext() {
        guard worker == nil, vault.isUnlocked, let item = items.last(where: { $0.state == .queued }) else { return }
        activeID = item.id
        worker = Task { [weak self] in
            guard let self else { return }
            await perform(item)
            worker = nil; activeID = nil; startNext()
        }
    }
    private func perform(_ item: TransferItem) async {
        let ext: String = item.choice.source.kind == .hls ? "mp4" :
            (["mp4", "mov", "m4v", "webm"].contains(item.choice.source.url.pathExtension.lowercased()) ? item.choice.source.url.pathExtension.lowercased() : "mp4")
        let staging = vault.paths.staging.appendingPathComponent(UUID().uuidString).appendingPathExtension(ext)
        defer { try? FileManager.default.removeItem(at: staging) }
        do {
            let choice = item.choice
            if choice.source.kind == .hls {
                update(item.id, state: .exporting, note: "فحص HLS وتجهيز الفيديو")
                try await resolver.validateHLS(choice.source, page: choice.result.pageURL)
                try await exportHLS(choice.source.url, to: staging, id: item.id)
            } else {
                guard choice.source.kind == .file else { throw MadarError.unsupported }
                update(item.id, state: .downloading, note: "جارٍ تنزيل الفيديو")
                let request = try resolver.network.request(choice.source.url, referer: choice.result.pageURL, userAgent: resolver.browser.userAgent)
                let downloader = DirectDownload()
                _ = try await downloader.run(request: request, cookies: await resolver.browser.cookies(), destination: staging) { [weak self] value in
                    Task { @MainActor in
                        guard let self, self.items.first(where: { $0.id == item.id })?.state == .downloading else { return }
                        self.update(item.id, progress: value.map { $0 * 0.85 }, unknownProgress: value == nil)
                    }
                }
            }
            try Task.checkCancellation()
            let asset = AVURLAsset(url: staging)
            let videoTracks = try await asset.loadTracks(withMediaType: .video)
            guard !videoTracks.isEmpty else {
                throw MadarError.message("الملف ليس فيديو قابلًا للقراءة على هذا الجهاز. لم يُحفظ في المساحة الخاصة.")
            }
            update(item.id, state: .encrypting, progress: 0.86, note: "تشفير الفيديو وحفظه داخليًا")
            _ = try await vault.importFile(staging, title: choice.result.title, ext: ext, quality: choice.source.quality, folder: choice.folder) { [weak self] fraction in
                Task { @MainActor in
                    guard let self, self.items.first(where: { $0.id == item.id })?.state == .encrypting else { return }
                    self.update(item.id, progress: 0.86 + fraction * 0.13)
                }
            }
            update(item.id, state: .completed, progress: 1, note: "اكتمل الحفظ داخل المساحة الخاصة")
        } catch {
            if Task.isCancelled || error is CancellationError || (error as NSError).code == NSURLErrorCancelled {
                update(item.id, state: .cancelled, note: "توقف التنزيل. إعادة المحاولة تبدأ من جديد.")
            } else { update(item.id, state: .failed, note: error.localizedDescription) }
        }
    }
    private func exportHLS(_ url: URL, to destination: URL, id: UUID) async throws {
        let asset = AVURLAsset(url: url, options: [AVURLAssetHTTPCookiesKey: await resolver.browser.cookies()])
        let protected = try await asset.load(.hasProtectedContent)
        guard !protected else { throw MadarError.message("الفيديو محمي ولا يُسمح بتصديره.") }
        guard let exporter = AVAssetExportSession(asset: asset, presetName: AVAssetExportPresetHighestQuality), exporter.supportedFileTypes.contains(.mp4) else {
            throw MadarError.message("هذا البث لا يدعم تصدير MP4 عبر AVFoundation. لم يُحفظ ملف ناقص.")
        }
        exporter.outputURL = destination; exporter.outputFileType = .mp4; exporter.shouldOptimizeForNetworkUse = true
        let monitor = Task { [weak self] in
            while !Task.isCancelled {
                self?.update(id, progress: Double(exporter.progress) * 0.85)
                try? await Task.sleep(nanoseconds: 350_000_000)
            }
        }
        defer { monitor.cancel() }
        await withTaskCancellationHandler {
            await withCheckedContinuation { (c: CheckedContinuation<Void, Never>) in exporter.exportAsynchronously { c.resume() } }
        } onCancel: { exporter.cancelExport() }
        try Task.checkCancellation()
        guard exporter.status == .completed else {
            throw MadarError.message("تعذر تجهيز HLS: \(exporter.error?.localizedDescription ?? "المصدر لا يسمح بالتصدير")")
        }
        try FileManager.default.setAttributes([.protectionKey: FileProtectionType.complete], ofItemAtPath: destination.path)
    }
}
