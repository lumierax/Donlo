import Foundation

final class NetworkClient: @unchecked Sendable {
    private let session: URLSession
    let cookieStorage: HTTPCookieStorage?
    init() {
        let config = URLSessionConfiguration.ephemeral
        config.urlCache = nil; config.requestCachePolicy = .reloadIgnoringLocalCacheData
        config.timeoutIntervalForRequest = 25; config.timeoutIntervalForResource = 90
        config.httpMaximumConnectionsPerHost = 3
        cookieStorage = config.httpCookieStorage
        session = URLSession(configuration: config)
    }
    func replaceCookies(_ cookies: [HTTPCookie]) {
        cookieStorage?.cookies?.forEach { cookieStorage?.deleteCookie($0) }
        cookies.forEach { cookieStorage?.setCookie($0) }
    }
    func request(_ url: URL, referer: URL?, userAgent: String) throws -> URLRequest {
        guard url.scheme?.lowercased() == "https", url.user == nil, url.password == nil else { throw MadarError.insecureURL }
        var request = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 25)
        request.setValue("en-US,en;q=0.8,ar;q=0.7", forHTTPHeaderField: "Accept-Language")
        if !userAgent.isEmpty { request.setValue(userAgent, forHTTPHeaderField: "User-Agent") }
        if let referer { request.setValue(referer.absoluteString, forHTTPHeaderField: "Referer") }
        return request
    }
    func text(_ url: URL, referer: URL? = nil, userAgent: String = "", maxBytes: Int = 6_000_000) async throws -> (String, URL) {
        let request = try request(url, referer: referer, userAgent: userAgent)
        let (bytes, response) = try await session.bytes(for: request)
        guard let http = response as? HTTPURLResponse else { throw MadarError.message("رد خادم غير مفهوم.") }
        guard (200...299).contains(http.statusCode) else { throw MadarError.badResponse(http.statusCode) }
        guard http.url?.scheme == "https" else { throw MadarError.insecureURL }
        guard response.expectedContentLength < Int64(maxBytes) || response.expectedContentLength == -1 else { throw MadarError.message("الصفحة أكبر من حد الفحص الآمن.") }
        var data = Data(); data.reserveCapacity(min(maxBytes, 256_000))
        for try await byte in bytes {
            if data.count >= maxBytes { throw MadarError.message("تجاوزت الصفحة حد الفحص الآمن.") }
            data.append(byte)
            if data.count % 65_536 == 0 { try Task.checkCancellation() }
        }
        guard let string = String(data: data, encoding: .utf8) ?? String(data: data, encoding: .isoLatin1) else {
            throw MadarError.message("تعذر قراءة ترميز الصفحة.")
        }
        return (string, response.url ?? url)
    }
    func image(_ url: URL, referer: URL, userAgent: String = "") async throws -> Data {
        let request = try request(url, referer: referer, userAgent: userAgent)
        let (bytes, response) = try await session.bytes(for: request)
        guard let http = response as? HTTPURLResponse, (200...299).contains(http.statusCode), http.url?.scheme == "https",
              response.mimeType?.hasPrefix("image/") == true else { throw MadarError.unsupported }
        var data = Data()
        for try await byte in bytes { guard data.count < 5_000_000 else { throw MadarError.unsupported }; data.append(byte) }
        return data
    }
}
