import Foundation

struct MediaResolution { var sources: [MediaSource]; var note: String? }

@MainActor
final class MediaResolver {
    let browser: BrowserEngine
    let network: NetworkClient
    init(browser: BrowserEngine, network: NetworkClient) { self.browser = browser; self.network = network }
    func resolve(_ result: VideoResult, useCurrentBrowser: Bool = false) async throws -> MediaResolution {
        network.replaceCookies(await browser.cookies())
        var sources: [MediaSource] = []
        if let kind = URLTools.mediaKind(result.pageURL) {
            sources = [MediaSource(url: result.pageURL, kind: kind, height: URLTools.height(result.pageURL.absoluteString), evidence: "direct input")]
        } else if !useCurrentBrowser {
            do {
                let (html, finalURL) = try await network.text(result.pageURL, referer: result.pageURL, userAgent: browser.userAgent)
                sources = await Task.detached(priority: .userInitiated) { MediaExtractor.extract(html, base: finalURL) }.value
            } catch is CancellationError { throw CancellationError() }
            catch { /* Rendered WebKit is the fallback, not a silent final failure. */ }
        }
        if sources.isEmpty || useCurrentBrowser {
            sources = try await browser.renderedMedia(for: result.pageURL, useCurrent: useCurrentBrowser)
            network.replaceCookies(await browser.cookies())
        }
        try Task.checkCancellation()
        if sources.isEmpty {
            throw BrowserIssue(kind: .player, message: "لم يظهر مصدر قابل للتنزيل. قد يحتاج المشغّل ضغطة تشغيل منك، أو يستخدم صيغة محمية أو غير مدعومة.")
        }
        var expanded: [MediaSource] = []; var notes: [String] = []
        for source in sources.prefix(24) {
            try Task.checkCancellation()
            if source.kind == .dash { notes.append("DASH غير مدعوم في هذا الإصدار."); continue }
            guard source.kind == .hls else { expanded.append(source); continue }
            do {
                let (text, final) = try await network.text(source.url, referer: result.pageURL, userAgent: browser.userAgent, maxBytes: 1_000_000)
                let manifest = try HLSManifest.parse(text, base: final)
                if manifest.encrypted { notes.append("استُبعد بث مشفّر؛ لا يُفك DRM أو مفاتيح البث."); continue }
                if manifest.isLive { notes.append("البث المباشر غير المحدود غير مدعوم."); continue }
                if manifest.hasExternalAudio {
                    var master = source; master.label = "HLS · تلقائي مع الصوت"; master.height = nil
                    expanded.append(master)
                    notes.append("أُبقيت قائمة HLS الرئيسية للحفاظ على مسار الصوت المنفصل.")
                } else { expanded.append(contentsOf: manifest.variants.isEmpty ? [source] : manifest.variants) }
            } catch is CancellationError { throw CancellationError() }
            catch {
                expanded.append(source)
                notes.append("إحدى قوائم HLS لم تُفحص بعد؛ سيُعاد التحقق قبل التنزيل.")
            }
        }
        let uniqueNotes = Array(Set(notes)).sorted()
        return MediaResolution(sources: URLTools.unique(expanded), note: uniqueNotes.isEmpty ? nil : uniqueNotes.joined(separator: "\n"))
    }
    func validateHLS(_ source: MediaSource, page: URL) async throws {
        let (text, final) = try await network.text(source.url, referer: page, userAgent: browser.userAgent, maxBytes: 1_000_000)
        let manifest = try HLSManifest.parse(text, base: final)
        guard !manifest.encrypted else { throw MadarError.message("هذا البث مشفّر. لا يدعم التطبيق تجاوز حمايته.") }
        guard !manifest.isLive else { throw MadarError.message("هذا بث مباشر غير محدود، وليس فيديو جاهزًا للحفظ.") }
        // Check every child the exporter may select, including external audio playlists.
        var children = manifest.variants.map(\.url)
        for row in URLTools.matches(#"#EXT-X-MEDIA:[^\r\n]*URI=\"([^\"]+)\""#, text) {
            if let url = URLTools.candidate(row[1], base: final) { children.append(url) }
        }
        guard children.count <= 24 else { throw MadarError.message("قائمة HLS معقدة أكثر من حد هذا الإصدار.") }
        for url in children {
            let (child, childURL) = try await network.text(url, referer: page, userAgent: browser.userAgent, maxBytes: 1_000_000)
            let m = try HLSManifest.parse(child, base: childURL)
            guard !m.encrypted, !m.isLive, m.variants.isEmpty else {
                throw MadarError.message("أحد مسارات البث مشفّر، مباشر، أو متداخل بصيغة غير مدعومة.")
            }
        }
    }
}
