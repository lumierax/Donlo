import Foundation

struct MediaResolution { var sources: [MediaSource]; var note: String? }

@MainActor
final class MediaResolver {
    let browser: BrowserEngine
    let network: NetworkClient
    init(browser: BrowserEngine, network: NetworkClient) { self.browser = browser; self.network = network }

    /// Separate WebView, same ephemeral website data: preserve cookies and localStorage without
    /// navigating the user's search page or creating a persistent browser session.
    func downloadSession() async -> MediaResolver {
        let isolated = BrowserEngine(dataStore: browser.webView.configuration.websiteDataStore)
        await isolated.inheritSession(from: browser)
        let client = NetworkClient()
        client.replaceCookies(await isolated.cookies())
        return MediaResolver(browser: isolated, network: client)
    }
    func resolve(_ result: VideoResult, useCurrentBrowser: Bool = false, deep: Bool = false) async throws -> MediaResolution {
        await browser.prepareUserAgent()
        network.replaceCookies(await browser.cookies())
        var sources: [MediaSource] = []; var notes: [String] = []
        var directKind = URLTools.mediaKind(result.pageURL)
        if directKind == nil && !useCurrentBrowser {
            directKind = try? await network.contentKind(result.pageURL, referer: result.pageURL, userAgent: browser.userAgent)
        }
        try Task.checkCancellation()
        if let kind = directKind {
            sources = [MediaSource(url: result.pageURL, kind: kind, height: URLTools.height(result.pageURL.absoluteString), evidence: "direct input", requestReferer: result.pageURL)]
        } else {
            if !useCurrentBrowser {
                do {
                    let (html, finalURL) = try await network.text(result.pageURL, referer: result.pageURL, userAgent: browser.userAgent)
                    sources = await Task.detached(priority: .userInitiated) { MediaExtractor.extract(html, base: finalURL) }.value
                } catch is CancellationError { throw CancellationError() }
                catch { /* The rendered page below is a separate discovery path. */ }
            }
            // Static HTML is not a reason to skip runtime discovery: it can expose only a preview.
            do {
                let rendered = try await browser.renderedMedia(for: result.pageURL, useCurrent: useCurrentBrowser, deep: deep)
                sources = URLTools.unique(sources + rendered)
            } catch is CancellationError { throw CancellationError() }
            catch let issue as BrowserIssue { throw issue }
            catch {
                if sources.isEmpty { throw error }
                notes.append("لم يكتمل فحص الصفحة الديناميكية؛ أُبقيت المصادر التي اكتُشفت بالفعل.")
            }
            network.replaceCookies(await browser.cookies())
        }
        try Task.checkCancellation()
        if sources.isEmpty {
            throw BrowserIssue(kind: .player, message: "لم يظهر مصدر بعد الفحص المتكرر. افتح المشغّل واضغط تشغيل بنفسك ثم «متابعة». لا يمكن حفظ مصدر محمي أو غير مدعوم.")
        }
        var expanded: [MediaSource] = []
        if sources.count > 96 { notes.append("ظهرت مصادر كثيرة؛ فُحص أول 96 مصدرًا فقط. افتح صفحة الفيديو نفسه لتقليل المصادر غير المتعلقة به.") }
        for var source in sources.prefix(96) {
            try Task.checkCancellation()
            let referer = source.requestReferer ?? result.pageURL
            if source.kind == .file && URLTools.mediaKind(source.url) == nil {
                if let detected = try? await network.contentKind(source.url, referer: referer, userAgent: browser.userAgent) { source.kind = detected }
            }
            try Task.checkCancellation()
            if source.kind == .dash { notes.append("DASH غير مدعوم في هذا الإصدار."); continue }
            guard source.kind == .hls else { expanded.append(source); continue }
            do {
                let (text, final) = try await network.text(source.url, referer: referer, userAgent: browser.userAgent, maxBytes: 1_000_000)
                let manifest = try HLSManifest.parse(text, base: final)
                if manifest.encrypted { notes.append("استُبعد بث مشفّر؛ لا يُفك DRM أو مفاتيح البث."); continue }
                if manifest.isLive { notes.append("البث المباشر غير المحدود غير مدعوم."); continue }
                if manifest.hasExternalAudio {
                    var master = source; master.label = "HLS · تلقائي مع الصوت"; master.height = nil
                    expanded.append(master)
                    notes.append("أُبقيت قائمة HLS الرئيسية للحفاظ على مسار الصوت المنفصل.")
                } else if manifest.variants.isEmpty { expanded.append(source) }
                else {
                    expanded.append(contentsOf: manifest.variants.map { variant in
                        var child = variant; child.requestReferer = referer; return child
                    })
                }
            } catch is CancellationError { throw CancellationError() }
            catch {
                expanded.append(source)
                notes.append("إحدى قوائم HLS لم تُفحص بعد؛ سيُعاد التحقق قبل التنزيل.")
            }
        }
        try Task.checkCancellation()
        let uniqueNotes = Array(Set(notes)).sorted()
        return MediaResolution(sources: URLTools.unique(expanded), note: uniqueNotes.isEmpty ? nil : uniqueNotes.joined(separator: "\n"))
    }
    func validateHLS(_ source: MediaSource, page: URL) async throws {
        let referer = source.requestReferer ?? page
        let (text, final) = try await network.text(source.url, referer: referer, userAgent: browser.userAgent, maxBytes: 1_000_000)
        let manifest = try HLSManifest.parse(text, base: final)
        guard !manifest.encrypted else { throw MadarError.message("هذا البث مشفّر. لا يدعم التطبيق تجاوز حمايته.") }
        guard !manifest.isLive else { throw MadarError.message("هذا بث مباشر غير محدود، وليس فيديو جاهزًا للحفظ.") }
        var children = manifest.variants.map(\.url)
        for row in URLTools.matches(#"#EXT-X-MEDIA:[^\r\n]*URI=\"([^\"]+)\""#, text) {
            if let url = URLTools.candidate(row[1], base: final) { children.append(url) }
        }
        children = Array(Set(children))
        guard children.count <= 64 else { throw MadarError.message("قائمة HLS معقدة أكثر من حد الفحص الآمن (64 مسارًا).") }
        for url in children {
            try Task.checkCancellation()
            let (child, childURL) = try await network.text(url, referer: referer, userAgent: browser.userAgent, maxBytes: 1_000_000)
            let m = try HLSManifest.parse(child, base: childURL)
            guard !m.encrypted, !m.isLive, m.variants.isEmpty else {
                throw MadarError.message("أحد مسارات البث مشفّر، مباشر، أو متداخل بصيغة غير مدعومة.")
            }
        }
    }
}
