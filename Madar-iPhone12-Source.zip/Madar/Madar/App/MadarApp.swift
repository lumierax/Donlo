import SwiftUI

@MainActor
final class Bootstrap: ObservableObject {
    let model: AppModel?
    let error: String?
    init() {
        do { model = try AppModel(); error = nil }
        catch { model = nil; self.error = error.localizedDescription }
    }
}
@main
struct MadarApp: App {
    @StateObject private var bootstrap = Bootstrap()
    var body: some Scene {
        WindowGroup {
            if let model = bootstrap.model {
                RootView(app: model)
                    .environmentObject(model)
                    .environmentObject(model.vault)
                    .environmentObject(model.transfers)
                    .environmentObject(model.browser)
                    .environment(\.layoutDirection, .rightToLeft)
                    .preferredColorScheme(.dark)
                    .tint(Palette.accent)
            } else {
                ContentUnavailableView("تعذر بدء مدار", systemImage: "exclamationmark.shield", description: Text(bootstrap.error ?? "خطأ في التخزين الداخلي"))
                    .preferredColorScheme(.dark)
            }
        }
    }
}
