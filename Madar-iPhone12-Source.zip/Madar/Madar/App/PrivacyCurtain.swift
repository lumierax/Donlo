import UIKit

/// Covers the entire app window, including presented sheets and the video controller,
/// before iOS captures the app-switcher snapshot. This cannot block an active screenshot.
@MainActor
final class PrivacyCurtain {
    static let shared = PrivacyCurtain()
    private var covers: [UIView] = []
    private init() {}
    func show() {
        guard covers.isEmpty else { return }
        for scene in UIApplication.shared.connectedScenes.compactMap({ $0 as? UIWindowScene }) {
            for window in scene.windows where !window.isHidden {
                let cover = UIView(frame: window.bounds)
                cover.backgroundColor = UIColor(red: 0.04, green: 0.05, blue: 0.09, alpha: 1)
                cover.autoresizingMask = [.flexibleWidth, .flexibleHeight]
                let mark = UILabel(); mark.text = "مدار"; mark.font = .systemFont(ofSize: 32, weight: .bold); mark.textColor = .white
                mark.translatesAutoresizingMaskIntoConstraints = false; cover.addSubview(mark)
                NSLayoutConstraint.activate([mark.centerXAnchor.constraint(equalTo: cover.centerXAnchor), mark.centerYAnchor.constraint(equalTo: cover.centerYAnchor)])
                window.addSubview(cover); covers.append(cover)
            }
        }
    }
    func hide() { covers.forEach { $0.removeFromSuperview() }; covers = [] }
}
