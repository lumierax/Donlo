import Foundation
import Combine
import UIKit

enum AppSheet: Identifiable {
    case welcome, settings, transfers, unlock, vault, browser, details(String)
    var id: String {
        switch self {
        case .welcome: return "welcome"
        case .settings: return "settings"
        case .transfers: return "transfers"
        case .unlock: return "unlock"
        case .vault: return "vault"
        case .browser: return "browser"
        case .details(let id): return "details-" + id
        }
    }
}
enum UnlockDestination { case vault, download(DownloadChoice), details(String), transfers }

@MainActor
final class AppModel: ObservableObject {
    enum InputMode: String, CaseIterable { case search = "بحث في موقع", link = "رابط فيديو" }
    @Published var site = ""
    @Published var keyword = ""
    @Published var inputMode: InputMode = .search
    @Published var results: [VideoResult] = []
    @Published var isSearching = false
    @Published var status = "جاهز عندما تكون جاهزًا"
    @Published var sheet: AppSheet?
    @Published var alert: String?
    @Published var notice: String?
    @Published var interaction: BrowserIssue?
    @Published var settings: LocalSettings
    @Published var playback: PlaybackSession?
    @Published private(set) var nextPage: URL?
    let browser: BrowserEngine
    let vault: VaultStore
    let network: NetworkClient
    let resolver: MediaResolver
    let transfers: TransferCenter
    private let settingsStore: SettingsStore
    private var work: Task<Void, Never>?
    private var generation = UUID()
    private var unlockDestination: UnlockDestination = .vault
    private var pendingResolution: String?
    private var lastBase: URL?
    private var lastQuery = ""

    init() throws {
        let paths = try PrivatePaths()
        settingsStore = SettingsStore(paths: paths); settings = settingsStore.value
        browser = BrowserEngine(); network = NetworkClient(); vault = VaultStore(paths: paths)
        resolver = MediaResolver(browser: browser, network: network)
        transfers = TransferCenter(vault: vault, resolver: resolver)
        browser.onPickedField = { [weak self] selector, url in
            guard let self else { return }
            if let base = self.lastBase, !URLTools.sameSite(base, url) { return }
            let host = self.normalizedHost(url)
            var profile = self.profile(host) ?? SiteProfile(host: host)
            profile.searchSelector = selector
            profile.searchTemplate = nil // An explicit correction must not be masked by an old learned URL.
            self.saveProfile(profile)
        }
        browser.onPickedSearchWorkflow = { [weak self] selector, start, steps in
            guard let self else { return }
            if let base = self.lastBase, !URLTools.sameSite(base, start) { return }
            let host = self.normalizedHost(start)
            var profile = self.profile(host) ?? SiteProfile(host: host)
            profile.searchSelector = selector; profile.searchSteps = steps
            profile.searchStartURL = start.absoluteString; profile.searchTemplate = nil
            self.saveProfile(profile)
        }
        vault.beforeLock = { [weak self] in self?.transfers.cancelAllForPrivacy(); self?.playback?.stop(); self?.playback = nil }
    }
    func start() {
        guard !settings.sawWelcome else { return }
        sheet = .welcome
    }
    func welcomeDone(setup: Bool) {
        settings.sawWelcome = true; saveSettings()
        if setup { requestUnlock(.vault) } else { sheet = nil }
    }
    func saveSettings() {
        do { try settingsStore.save(settings) } catch { alert = "تعذر حفظ الإعدادات: " + error.localizedDescription }
    }
    func normalizedHost(_ url: URL) -> String {
        (url.host ?? "").lowercased().replacingOccurrences(of: #"^www\."#, with: "", options: .regularExpression)
    }
    func profile(_ host: String) -> SiteProfile? { settings.profiles.first { $0.host == host } }
    func saveProfile(_ profile: SiteProfile) {
        settings.profiles.removeAll { $0.host == profile.host }
        settings.profiles.append(profile); saveSettings()
    }
    func clearResults() {
        stop(); results = []; nextPage = nil; interaction = nil; status = "جاهز عندما تكون جاهزًا"
        keyword = ""; pendingResolution = nil
        ThumbnailCache.shared.clear()
    }
    func stop() {
        generation = UUID(); work?.cancel(); work = nil; browser.stop(); isSearching = false
        for i in results.indices where results[i].state == .resolving { results[i].state = .pending; results[i].note = "أُوقف الفحص. يمكنك إعادة المحاولة." }
        if !results.isEmpty { status = "توقف البحث؛ النتائج المكتشفة باقية" }
    }
    func beginSearch() {
        do {
            let base = try URLTools.website(site)
            let query = keyword.trimmingCharacters(in: .whitespacesAndNewlines)
            if inputMode == .search && query.isEmpty { throw MadarError.message("اكتب كلمة البحث أولًا.") }
            stop(); results = []; nextPage = nil; interaction = nil; pendingResolution = nil
            lastBase = base; lastQuery = query
            if inputMode == .link {
                let title = base.lastPathComponent.isEmpty ? (base.host ?? "فيديو") : base.lastPathComponent
                let result = VideoResult(pageURL: base, title: title)
                results = [result]; sheet = .details(result.id); resolve(result.id); return
            }
            search(base: base, query: query, resume: false)
        } catch { alert = error.localizedDescription }
    }
    private func search(base: URL, query: String, resume: Bool) {
        let stamp = UUID(); generation = stamp; isSearching = true; status = "اكتشاف البحث داخل الموقع"
        let profile = profile(normalizedHost(base))
        work = Task { [weak self] in
            guard let self else { return }
            do {
                var batch = try await browser.search(base: base, query: query, profile: profile, resumeCurrent: resume)
                var seenPages = Set<String>()
                for pageNumber in 1...max(1, settings.pageLimit) {
                    try Task.checkCancellation(); guard generation == stamp else { return }
                    network.replaceCookies(await browser.cookies())
                    append(batch)
                    if pageNumber == 1, let template = SearchTemplate.learned(from: batch.page, keyword: query), URLTools.sameSite(base, batch.page) {
                        var saved = profile ?? SiteProfile(host: normalizedHost(base))
                        if saved.searchTemplate == nil, saved.searchStartURL == nil, (saved.searchSteps ?? []).isEmpty {
                            saved.searchTemplate = template; saveProfile(saved)
                        }
                    }
                    status = "\(results.count) نتيجة · الصفحة \(pageNumber)"
                    guard pageNumber < settings.pageLimit, let next = batch.next,
                          seenPages.insert(next.absoluteString).inserted, URLTools.sameSite(base, next), results.count < 400 else { break }
                    try await Task.sleep(nanoseconds: 650_000_000)
                    try await browser.load(next)
                    batch = try await browser.batch(selector: profile?.resultSelector)
                }
                network.replaceCookies(await browser.cookies())
                guard generation == stamp else { return }
                if results.isEmpty {
                    status = "لم تظهر بطاقات فيديو قابلة للقراءة"
                    interaction = BrowserIssue(kind: .search, message: "قد تكون النتائج فارغة أو بتصميم خاص. افتح الصفحة لتحديد البحث، أو احفظ محدد النتائج من الإعدادات.")
                } else { status = "\(results.count) نتيجة · اختر فيديو لفحص الجودات" }
            } catch {
                guard generation == stamp else { return }
                if error is CancellationError { status = "توقف البحث؛ النتائج المكتشفة باقية" }
                else if let issue = error as? BrowserIssue { interaction = issue; status = issue.message }
                else { status = error.localizedDescription; alert = error.localizedDescription }
            }
            if generation == stamp { isSearching = false; work = nil }
        }
    }
    private func append(_ batch: SearchBatch) {
        var known = Set(results.map(\.id))
        for item in batch.items where known.insert(item.id).inserted { results.append(item) }
        nextPage = batch.next
    }
    func loadMore() {
        guard let nextPage, !isSearching else { return }
        stop(); let stamp = UUID(); generation = stamp; isSearching = true
        work = Task { [weak self] in
            guard let self else { return }
            do {
                try await browser.load(nextPage)
                let batch = try await browser.batch(selector: lastBase.flatMap { profile(normalizedHost($0)) }?.resultSelector)
                guard generation == stamp else { return }; append(batch); status = "\(results.count) نتيجة"
            } catch {
                if generation == stamp {
                    if let issue = error as? BrowserIssue { interaction = issue }
                    else if !(error is CancellationError) { alert = error.localizedDescription }
                }
            }
            if generation == stamp { isSearching = false; work = nil }
        }
    }
    func result(_ id: String) -> VideoResult? { results.first { $0.id == id } }
    func resolve(_ id: String, useCurrent: Bool = false, deep: Bool = true) {
        guard let result = result(id) else { return }
        stop(); interaction = nil; pendingResolution = id
        let stamp = UUID(); generation = stamp
        if let i = results.firstIndex(where: { $0.id == id }) { results[i].state = .resolving; results[i].note = nil }
        work = Task { [weak self] in
            guard let self else { return }
            do {
                let resolution = try await resolver.resolve(result, useCurrentBrowser: useCurrent, deep: deep || useCurrent)
                guard generation == stamp, let i = results.firstIndex(where: { $0.id == id }) else { return }
                results[i].sources = resolution.sources; results[i].note = resolution.note; if let duration = resolution.duration { results[i].duration = duration }
                results[i].state = resolution.sources.isEmpty ? .unavailable : .ready
                pendingResolution = nil
            } catch {
                guard generation == stamp, let i = results.firstIndex(where: { $0.id == id }) else { return }
                if let issue = error as? BrowserIssue {
                    results[i].note = issue.message
                    if issue.kind == .drm { results[i].state = .unavailable; interaction = nil }
                    else { results[i].state = .needsInteraction; interaction = issue }
                } else if error is CancellationError { results[i].state = .pending }
                else { results[i].state = .failed; results[i].note = error.localizedDescription }
            }
            if generation == stamp { work = nil }
        }
    }
    func openPlayer(_ id: String) {
        guard let result = result(id) else { return }
        stop(); pendingResolution = id
        interaction = BrowserIssue(kind: .player, message: "شغّل الفيديو بنفسك داخل الموقع، ثم اضغط «متابعة» لالتقاط المصادر الظاهرة.")
        browser.visible = true; sheet = .browser
        guard browser.webView.url != result.pageURL else { return }
        let stamp = generation
        work = Task { [weak self] in
            guard let self else { return }
            do { try await browser.load(result.pageURL) }
            catch { if generation == stamp && !(error is CancellationError) { alert = error.localizedDescription } }
            if generation == stamp { work = nil }
        }
    }
    func recheckDownload(_ choice: DownloadChoice) {
        if result(choice.result.id) == nil { results.append(choice.result) }
        sheet = .details(choice.result.id)
        resolve(choice.result.id, deep: true)
    }
    func showRecoveryBrowser() {
        guard interaction != nil else { return }
        stop(); browser.visible = true; sheet = .browser
    }
    func teachSearch() async {
        guard let base = lastBase, pendingResolution == nil else { return }
        await browser.beginSearchRecording(from: base)
    }
    func retrySearchFromStart() {
        guard let base = lastBase, pendingResolution == nil else { return }
        browser.cancelSearchTeaching(); browser.visible = false; interaction = nil; sheet = nil
        stop(); results = []; nextPage = nil
        search(base: base, query: lastQuery, resume: false)
    }
    /// Explicit user action for AJAX pages whose results cannot be verified from URL changes.
    func useCurrentSearchResults() {
        guard let base = lastBase, pendingResolution == nil, let page = browser.webView.url,
              URLTools.sameSite(base, page) else { return }
        browser.cancelSearchTeaching(); browser.visible = false; sheet = nil
        stop(); let stamp = UUID(); generation = stamp; isSearching = true
        let selector = profile(normalizedHost(base))?.resultSelector
        work = Task { [weak self] in
            guard let self else { return }
            do {
                let batch = try await browser.batch(selector: selector)
                try Task.checkCancellation(); guard generation == stamp else { return }
                network.replaceCookies(await browser.cookies())
                guard generation == stamp else { return }
                results = []; append(batch); interaction = nil
                status = "\(results.count) نتيجة من الصفحة التي اخترتها يدويًا"
                if results.isEmpty { interaction = BrowserIssue(kind: .search, message: "لم أجد بطاقات نتائج قابلة للقراءة في الصفحة الحالية. قد تحتاج محدد نتائج خاصًا.") }
            } catch {
                guard generation == stamp else { return }
                if let issue = error as? BrowserIssue { interaction = issue; status = issue.message }
                else if !(error is CancellationError) { alert = error.localizedDescription }
            }
            if generation == stamp { isSearching = false; work = nil }
        }
    }
    func continueFromBrowser() {
        browser.visible = false; interaction = nil; sheet = nil
        if let id = pendingResolution { sheet = .details(id); resolve(id, useCurrent: true) }
        else if let base = lastBase { search(base: base, query: lastQuery, resume: true) }
    }
    func requestUnlock(_ destination: UnlockDestination) {
        unlockDestination = destination
        if vault.isUnlocked { unlockFinished() } else { sheet = .unlock }
    }
    func unlockFinished() {
        switch unlockDestination {
        case .vault: sheet = .vault
        case .details(let id): sheet = .details(id)
        case .transfers: sheet = .transfers
        case .download(let choice):
            do { try transfers.enqueue(choice); sheet = .transfers }
            catch { alert = error.localizedDescription }
        }
    }
    func download(_ choice: DownloadChoice) { requestUnlock(.download(choice)) }
    func cancelUnlock() { vault.lock(); sheet = nil }
    func lockVault() { vault.lock(); sheet = nil }
    func play(_ entry: VaultEntry) {
        do { playback?.stop(); playback = try PlaybackSession(entry: entry, vault: vault) }
        catch { alert = error.localizedDescription }
    }
    func sheetChanged(from old: String?, to new: String?) {
        if old == "vault" && new != "vault" { vault.lock() }
        if old == "unlock" && new == nil { vault.lock() }
        if old == "browser" && new != "browser" { browser.cancelSearchTeaching(); browser.visible = false }
    }
    func enteredBackground() {
        browser.cancelSearchTeaching(); stop(); vault.lock(); ThumbnailCache.shared.clear()
        if sheet?.id == "vault" || sheet?.id == "unlock" { sheet = nil }
    }
    func toast(_ message: String) {
        notice = message
        Task { [weak self] in
            try? await Task.sleep(nanoseconds: 3_000_000_000)
            if self?.notice == message { self?.notice = nil }
        }
    }
}
