import Foundation

struct LocalSettings: Codable {
    var profiles: [SiteProfile] = []
    var grid = false
    var pageLimit = 3
    var sawWelcome = false
}
@MainActor
final class SettingsStore {
    private let url: URL
    var value: LocalSettings
    init(paths: PrivatePaths) {
        url = paths.root.appendingPathComponent("preferences.json")
        value = (try? JSONDecoder().decode(LocalSettings.self, from: Data(contentsOf: url))) ?? LocalSettings()
    }
    func save(_ settings: LocalSettings) throws { try PrivatePaths.write(JSONEncoder().encode(settings), to: url); value = settings }
}
