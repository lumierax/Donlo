import Foundation
import Combine
import WebKit
import UIKit

struct BrowserIssue: Error, LocalizedError, Identifiable {
    enum Kind: String { case age, human, access, search, player, drm }
    var kind: Kind
    var message: String
    var id: String { kind.rawValue }
    var errorDescription: String? { message }
}
struct SearchBatch { var items: [VideoResult]; var next: URL?; var page: URL }

@MainActor
final class BrowserEngine: NSObject, ObservableObject, WKNavigationDelegate, WKUIDelegate, WKScriptMessageHandler {
    let webView: WKWebView
    @Published var address = ""
    @Published var progress = 0.0
    @Published var fieldNotice: String?
    var onPickedField: ((String, URL) -> Void)?
    var onPickedSearchWorkflow: ((String, URL, [SearchStep]) -> Void)?
    @Published private(set) var isRecordingSearch = false
    @Published private(set) var isPreparingSearchRecording = false
    @Published private(set) var recordedSearchSteps: [SearchStep] = []
    private var recordingBase: URL?
    private var recordingToken: String?
    private var pickerToken: String?
    private var navigationError: Error?
    private var observed: NSKeyValueObservation?
    private var frameSources: [MediaSource] = []
    private var script: String
    private(set) var userAgent = ""
    var visible = false

    override convenience init() { self.init(dataStore: .nonPersistent()) }
    init(dataStore: WKWebsiteDataStore) {
        let configuration = WKWebViewConfiguration()
        configuration.websiteDataStore = dataStore
        configuration.allowsInlineMediaPlayback = true
        configuration.mediaTypesRequiringUserActionForPlayback = [.audio, .video]
        configuration.defaultWebpagePreferences.allowsContentJavaScript = true
        let url = Bundle.main.url(forResource: "bridge", withExtension: "js")
        script = url.flatMap { try? String(contentsOf: $0, encoding: .utf8) } ?? ""
        configuration.userContentController.addUserScript(WKUserScript(source: script, injectionTime: .atDocumentStart, forMainFrameOnly: false))
        webView = WKWebView(frame: .zero, configuration: configuration)
        super.init()
        webView.navigationDelegate = self; webView.uiDelegate = self
        configuration.userContentController.add(WeakScriptHandler(self), name: "mdField")
        configuration.userContentController.add(WeakScriptHandler(self), name: "mdSearchStep")
        configuration.userContentController.add(WeakScriptHandler(self), name: "mdMedia")
        webView.isInspectable = false
        webView.scrollView.contentInsetAdjustmentBehavior = .automatic
        observed = webView.observe(\.estimatedProgress, options: [.new]) { [weak self] view, _ in
            Task { @MainActor [weak self] in self?.progress = view.estimatedProgress }
        }
    }
    func javascript(_ source: String) async throws -> Any? {
        try await withCheckedThrowingContinuation { continuation in
            webView.evaluateJavaScript(source) { value, error in
                if let error { continuation.resume(throwing: error) }
                else { continuation.resume(returning: value) }
            }
        }
    }
    func literal(_ value: String) -> String {
        guard let data = try? JSONSerialization.data(withJSONObject: value, options: .fragmentsAllowed),
              let string = String(data: data, encoding: .utf8) else { return "\"\"" }
        return string
    }
    func load(_ url: URL) async throws {
        try Task.checkCancellation()
        guard url.scheme == "https" else { throw MadarError.insecureURL }
        navigationError = nil; frameSources = []
        webView.load(URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 25))
        try await settle(minimum: 0.6, timeout: 26)
        if let navigationError { throw navigationError }
        _ = try? await javascript(script)
        if userAgent.isEmpty { userAgent = (try? await javascript("navigator.userAgent")) as? String ?? "" }
    }
    func settle(minimum: TimeInterval = 0.7, timeout: TimeInterval = 15) async throws {
        let start = Date(); var quiet = 0
        repeat {
            try Task.checkCancellation()
            try await Task.sleep(nanoseconds: 200_000_000)
            if webView.isLoading { quiet = 0 } else { quiet += 1 }
            if Date().timeIntervalSince(start) >= minimum, quiet >= 3 { return }
            if let navigationError { throw navigationError }
        } while Date().timeIntervalSince(start) < timeout
        webView.stopLoading()
        throw MadarError.message("انتهت مهلة تحميل الصفحة. النتائج السابقة ما زالت محفوظة في الشاشة.")
    }
    func issue(from value: Any?) -> BrowserIssue? {
        guard let d = value as? [String: Any], let raw = d["kind"] as? String,
              let kind = BrowserIssue.Kind(rawValue: raw), let message = d["message"] as? String else { return nil }
        return BrowserIssue(kind: kind, message: message)
    }
    func gate() async throws -> BrowserIssue? { issue(from: try await javascript("window.__madar?.gate()")) }
    /// Use callAsyncJavaScript for promise-returning DOM waits. evaluateJavaScript does not await them.
    private func waitForSearch(target: String = "", field: String = "", timeout: Double = 5, strict: Bool = false) async throws {
        try Task.checkCancellation()
        do {
            let value = try await webView.callAsyncJavaScript(
                "return await window.__madar.waitForSearch(target, field, timeout, strict)",
                arguments: ["target": target, "field": field, "timeout": timeout * 1000, "strict": strict],
                in: nil, contentWorld: .page)
            try Task.checkCancellation()
            if let d = value as? [String: Any], let problem = issue(from: d["gate"]) { throw problem }
        } catch {
            try Task.checkCancellation()
            if error is BrowserIssue { throw error }
            // A real navigation destroys the old document and its Promise. Settle the new page.
            if webView.isLoading { try await settle(minimum: 0.4) }
            else { try await Task.sleep(nanoseconds: 300_000_000) }
            _ = try await javascript(script)
        }
    }
    private func enforceSearchSite(_ base: URL) throws {
        guard let current = webView.url, current.scheme == "https", URLTools.sameSite(base, current) else {
            throw BrowserIssue(kind: .search, message: "انتقل البحث إلى نطاق آخر. لن أرسل كلمة البحث إليه تلقائيًا؛ افتح الصفحة يدويًا.")
        }
    }
    private func savedFieldReady(_ selector: String) async throws -> Bool {
        guard !selector.isEmpty else { return false }
        let d = try await javascript("window.__madar.inspectSearch(\(literal(selector)), true)") as? [String: Any]
        if let problem = issue(from: d?["gate"]) { throw problem }
        if d?["ambiguous"] as? Bool == true {
            throw BrowserIssue(kind: .search, message: "محدد الخانة يطابق أكثر من عنصر ظاهر. أعد تحديد الخانة.")
        }
        return d?["field"] as? Bool == true
    }
    private func replaySearchSteps(_ steps: [SearchStep], field: String, base: URL, timeout: Double) async throws {
        for (index, step) in steps.enumerated() {
            try Task.checkCancellation(); try enforceSearchSite(base)
            if try await savedFieldReady(field) { return } // Already open: do not toggle the menu closed.
            setSearchNotice("فتح البحث: الخطوة \(index + 1) من \(steps.count)")
            try await waitForSearch(target: step.selector, field: field, timeout: timeout, strict: true)
            try Task.checkCancellation(); try enforceSearchSite(base)
            if try await savedFieldReady(field) { return }
            let d = try await javascript("window.__madar.clickSearchStep(\(literal(step.selector)))") as? [String: Any]
            if let problem = issue(from: d?["gate"]) { throw problem }
            guard d?["opened"] as? Bool == true || d?["skipped"] as? Bool == true else {
                let reason = d?["reason"] as? String ?? "تعذر تنفيذ الخطوة المحفوظة."
                throw BrowserIssue(kind: .search, message: "توقفت عند خطوة البحث \(index + 1): \(reason) أعد تعليم الخطوات من البداية.")
            }
            // Let click handlers start navigation before looking for the next element.
            try await Task.sleep(nanoseconds: 300_000_000)
            if webView.isLoading { try await settle(minimum: 0.4) }
            _ = try await javascript(script)
        }
        try await waitForSearch(field: field, timeout: timeout, strict: true)
        try enforceSearchSite(base)
        guard try await savedFieldReady(field) else {
            throw BrowserIssue(kind: .search, message: "نُفذت خطوات الفتح لكن الخانة المحفوظة لم تظهر. أعد تعليم الخطوات أو زِد مهلة الانتظار من تعريف الموقع.")
        }
    }
    private func setSearchNotice(_ message: String) { fieldNotice = message }
    func search(base: URL, query: String, profile: SiteProfile?, resumeCurrent: Bool = false) async throws -> SearchBatch {
        cancelSearchTeaching()
        let steps = profile?.searchSteps ?? [], field = profile?.searchSelector ?? ""
        let timeout = SearchWorkflow.timeout(profile?.searchStepTimeout)
        let hasWorkflow = !steps.isEmpty || profile?.searchStartURL != nil
        if hasWorkflow && field.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            throw BrowserIssue(kind: .search, message: "مسار البحث المحفوظ يحتاج تحديد الخانة النهائية. أعد تعليمه من نافذة الموقع.")
        }
        if !resumeCurrent {
            if let template = profile?.searchTemplate, !template.isEmpty {
                try await load(SearchTemplate.url(template: template, keyword: query, base: base))
                try enforceSearchSite(base)
                return try await batch(selector: profile?.resultSelector)
            }
            try SearchWorkflow.validate(steps: steps, field: field)
            try await load(SearchWorkflow.startURL(stored: profile?.searchStartURL, base: base))
        }
        try enforceSearchSite(base)
        if let gate = try await gate() { throw gate }
        if resumeCurrent {
            let snapshot = try await batch(selector: profile?.resultSelector)
            let current = webView.url ?? base
            let queryInURL = URLComponents(url: current, resolvingAgainstBaseURL: false)?.queryItems?.contains(where: { $0.value == query }) == true
            let queryInPath = !query.isEmpty && current.path.localizedCaseInsensitiveContains(query) && current.path != base.path
            if !snapshot.items.isEmpty && (queryInURL || queryInPath) { return snapshot }
        }
        _ = try await javascript("window.__madar.resetSearch()")
        // Preserve manual work on resume; replay only when its selected field is still unavailable.
        let workflowFieldReady = hasWorkflow ? try await savedFieldReady(field) : false
        if hasWorkflow && !workflowFieldReady {
            try SearchWorkflow.validate(steps: steps, field: field)
            try await replaySearchSteps(steps, field: field, base: base, timeout: timeout)
        }
        let snapshotCommand = "window.__madar.searchSnapshot(\(literal(profile?.resultSelector ?? "")))"
        let before = try await javascript(snapshotCommand) as? [String: String]
        let options = hasWorkflow ? "{allowOpen:false,strict:true}" : "{allowOpen:true}"
        let command = "window.__madar.search(\(literal(query)), \(literal(field)), \(options))"
        var submitted = false
        // Each iteration takes at most one action and rescans the actual rendered page.
        for attempt in 0...8 {
            try Task.checkCancellation(); try enforceSearchSite(base)
            let value = try await javascript(command) as? [String: Any]
            if let problem = issue(from: value?["gate"]) { throw problem }
            if value?["submitted"] as? Bool == true { submitted = true; break }
            if value?["opened"] as? Bool == true {
                fieldNotice = "فتح البحث: \(value?["label"] as? String ?? "قائمة الموقع")"
                try await Task.sleep(nanoseconds: 300_000_000)
                if webView.isLoading { try await settle(minimum: 0.4) }
                _ = try await javascript(script)
                try await waitForSearch(field: field, timeout: timeout)
                continue
            }
            // Give lazily inserted initial controls a bounded chance to appear.
            if attempt == 0 && value?["missing"] as? Bool == true && !hasWorkflow {
                try await waitForSearch(field: field, timeout: timeout); continue
            }
            let reason = value?["reason"] as? String ?? "لم أجد خانة البحث."
            throw BrowserIssue(kind: .search, message: reason + " افتح نافذة الموقع واختر «تعليم خطوات البحث»، أو احفظ رابط البحث من الإعدادات.")
        }
        guard submitted else { throw BrowserIssue(kind: .search, message: "وصلت إلى حد محاولات فتح البحث. علّم الخطوات مرة واحدة للموقع.") }
        try await settle(minimum: 1.8)
        _ = try await javascript(script)
        // A dispatched Enter/click is not proof that the site performed a search.
        // Do not silently return unchanged home-page recommendations as search results.
        let deadline = Date().addingTimeInterval(timeout)
        repeat {
            try Task.checkCancellation(); try enforceSearchSite(base)
            if let gate = try await gate() { throw gate }
            let after = try await javascript(snapshotCommand) as? [String: String]
            if let before, let after, before["url"] != after["url"] || before["items"] != after["items"] {
                let batch = try await batch(selector: profile?.resultSelector)
                if !batch.items.isEmpty || Date() >= deadline { fieldNotice = nil; return batch }
            }
            try await Task.sleep(nanoseconds: 350_000_000)
            if webView.isLoading { try await settle(minimum: 0.4); _ = try await javascript(script) }
        } while Date() < deadline
        // URL changes with empty results are still a valid search. Unchanged AJAX empty searches
        // remain unconfirmed and are handed to the user rather than labelled successful.
        let after = try await javascript(snapshotCommand) as? [String: String]
        if let before, let after, before != after { return try await batch(selector: profile?.resultSelector) }
        throw BrowserIssue(kind: .search, message: "أرسلت أمر البحث، لكن لم أتمكن من تأكيد تغير الصفحة أو النتائج. أكمل البحث بنفسك في نافذة الموقع ثم اضغط متابعة.")
    }
    func batch(selector: String?) async throws -> SearchBatch {
        guard let d = try await javascript("window.__madar.results(\(literal(selector ?? "")))") as? [String: Any],
              let page = webView.url else { throw MadarError.message("تعذر قراءة نتائج الصفحة.") }
        if let problem = issue(from: d["gate"]) { throw problem }
        let items = (d["items"] as? [[String: Any]] ?? []).compactMap { row -> VideoResult? in
            guard let raw = row["url"] as? String, let url = URLTools.candidate(raw, base: page),
                  URLTools.sameSite(url, page) else { return nil }
            return VideoResult(pageURL: url, title: row["title"] as? String ?? "",
                thumbnailURL: (row["thumbnail"] as? String).flatMap { URLTools.candidate($0, base: page) }, duration: row["duration"] as? String)
        }
        let next = (d["next"] as? String).flatMap { URLTools.candidate($0, base: page) }
        return SearchBatch(items: items, next: next, page: page)
    }
    private func mediaSources(_ rows: [[String: Any]], base: URL, frame: URL? = nil) -> [MediaSource] {
        rows.prefix(600).compactMap { row in
            guard let raw = row["url"] as? String, let url = URLTools.candidate(raw, base: base),
                  let rawKind = row["kind"] as? String, let kind = MediaKind(rawValue: rawKind) else { return nil }
            let context = frame ?? (row["referer"] as? String).flatMap { URLTools.candidate($0, base: base) } ?? base
            return MediaSource(url: url, kind: kind, height: URLTools.height(raw),
                evidence: "WebKit DOM/network", requestReferer: context)
        }
    }
    func renderedMedia(for url: URL, useCurrent: Bool = false, deep: Bool = false) async throws -> [MediaSource] {
        if !useCurrent { try await load(url) }
        try Task.checkCancellation()
        if let gate = try await gate() { throw gate }
        let start = Date(), timeout: TimeInterval = deep ? 20 : 12
        var gathered: [MediaSource] = []; var firstProbe = true
        repeat {
            try Task.checkCancellation()
            if let gate = try await gate() { throw gate }
            _ = try? await javascript("window.__madar?.probe(\(firstProbe ? "true" : "false"))")
            firstProbe = false
            let base = webView.url ?? url
            if let rows = try? await javascript("window.__madar?.mediaDetails()") as? [[String: Any]] {
                gathered = URLTools.unique(gathered + mediaSources(rows, base: base) + frameSources)
            } else { gathered = URLTools.unique(gathered + frameSources) }
            // Keep watching even after the first source: it may be a preview, not the main player.
            try await Task.sleep(nanoseconds: 750_000_000)
        } while Date().timeIntervalSince(start) < timeout
        try Task.checkCancellation()
        // Parse the final DOM, not only the first snapshot before lazy players initialize.
        let base = webView.url ?? url
        let html = (try? await javascript("document.documentElement.outerHTML")) as? String ?? ""
        let parsed = await Task.detached(priority: .userInitiated) { MediaExtractor.extract(html, base: base) }.value
        try Task.checkCancellation()
        return URLTools.unique(parsed + gathered + frameSources)
    }
    func renderedDuration() async -> String? {
        guard let raw = try? await javascript("window.__madar?.duration?.()") as? String else { return nil }
        let value = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        return value.isEmpty ? nil : value
    }
    func prepareUserAgent() async {
        if userAgent.isEmpty { userAgent = (try? await javascript("navigator.userAgent")) as? String ?? "" }
    }
    func inheritSession(from other: BrowserEngine) async {
        await other.prepareUserAgent()
        let cookies = webView.configuration.websiteDataStore === other.webView.configuration.websiteDataStore ? [] : await other.cookies()
        for cookie in cookies {
            await withCheckedContinuation { (c: CheckedContinuation<Void, Never>) in
                webView.configuration.websiteDataStore.httpCookieStore.setCookie(cookie) { c.resume() }
            }
        }
        if !other.userAgent.isEmpty { userAgent = other.userAgent; webView.customUserAgent = other.userAgent }
    }
    func cookies() async -> [HTTPCookie] {
        await withCheckedContinuation { c in webView.configuration.websiteDataStore.httpCookieStore.getAllCookies { c.resume(returning: $0) } }
    }
    func chooseSearchField() async {
        cancelSearchTeaching()
        guard visible else { return }
        let token = UUID().uuidString; pickerToken = token
        do {
            _ = try await javascript("window.__madar.pickField(\(literal(token)))")
            guard pickerToken == token, visible else { return }
            fieldNotice = "افتح القوائم بنفسك، ثم اضغط خانة البحث. هذا الخيار يحفظ الخانة فقط؛ لتذكر ضغطات الفتح اختر تعليم الخطوات."
        } catch { cancelSearchTeaching(); fieldNotice = error.localizedDescription }
    }
    func beginSearchRecording(from base: URL) async {
        cancelSearchTeaching()
        guard visible else { return }
        let token = UUID().uuidString; recordingToken = token; isPreparingSearchRecording = true
        fieldNotice = "فتح صفحة البداية لتعليم البحث…"
        defer { if recordingToken == token { isPreparingSearchRecording = false } }
        do {
            let start = try SearchWorkflow.startURL(stored: nil, base: base)
            try await load(start)
            guard recordingToken == token, visible else { return }
            try enforceSearchSite(base)
            if let problem = try await gate() { throw problem }
            recordingBase = try SearchWorkflow.startURL(stored: webView.url?.absoluteString, base: base)
            isRecordingSearch = true
            _ = try await javascript("window.__madar.startSearchRecording(\(literal(token)))")
            guard recordingToken == token, visible else { return }
            fieldNotice = "التعليم يعمل: افتح القائمة، ثم Search، ثم اضغط داخل خانة البحث لحفظ المسار. لا تكتب كلمة البحث أثناء التعليم."
        } catch {
            guard recordingToken == token else { return }
            cancelSearchTeaching(); fieldNotice = error.localizedDescription
        }
    }
    func cancelSearchTeaching(clearNotice: Bool = true) {
        let wasPreparing = isPreparingSearchRecording
        recordingToken = nil; pickerToken = nil; recordingBase = nil
        isRecordingSearch = false; isPreparingSearchRecording = false; recordedSearchSteps = []
        if clearNotice { fieldNotice = nil }
        if wasPreparing { webView.stopLoading() }
        webView.evaluateJavaScript("window.__madar?.cancelSearchTeaching()", completionHandler: nil)
    }
    private func resumeSearchRecordingAfterNavigation() {
        guard visible, isRecordingSearch, let token = recordingToken, let base = recordingBase else { return }
        guard let current = webView.url, URLTools.sameSite(base, current), current.scheme == "https" else {
            cancelSearchTeaching(); fieldNotice = "توقف التعليم لأن الصفحة انتقلت إلى نطاق مختلف."; return
        }
        webView.evaluateJavaScript("window.__madar?.startSearchRecording(\(literal(token)))") { [weak self] _, error in
            guard let self, self.recordingToken == token, let error else { return }
            self.cancelSearchTeaching(); self.fieldNotice = error.localizedDescription
        }
    }
    func stop() { webView.stopLoading() }
    func clearSession() async {
        cancelSearchTeaching(); stop()
        await withCheckedContinuation { (c: CheckedContinuation<Void, Never>) in
            webView.configuration.websiteDataStore.removeData(ofTypes: WKWebsiteDataStore.allWebsiteDataTypes(), modifiedSince: .distantPast) { c.resume() }
        }
        webView.loadHTMLString("<html><body></body></html>", baseURL: nil)
        frameSources = []; address = ""
    }
    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) { frameSources = [] }
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        address = webView.url?.absoluteString ?? ""
        resumeSearchRecordingAfterNavigation()
    }
    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) { if (error as NSError).code != NSURLErrorCancelled { navigationError = error } }
    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) { if (error as NSError).code != NSURLErrorCancelled { navigationError = error } }
    func webViewWebContentProcessDidTerminate(_ webView: WKWebView) { navigationError = MadarError.message("توقف محرك الصفحة. أعد المحاولة؛ النتائج لم تُحذف.") }
    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let url = navigationAction.request.url else { decisionHandler(.cancel); return }
        guard url.scheme == "https" || url.absoluteString == "about:blank" else { decisionHandler(.cancel); return }
        if navigationAction.targetFrame == nil {
            // No automatic advertising popups; deliberate links in the recovery browser stay in one tab.
            if visible && navigationAction.navigationType == .linkActivated { webView.load(navigationAction.request) }
            decisionHandler(.cancel); return
        }
        decisionHandler(.allow)
    }
    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        if message.name == "mdMedia", let rows = message.body as? [[String: Any]] {
            var context = message.frameInfo.request.url
            if context?.scheme != "https" {
                // srcdoc/about:blank frames can inherit a real HTTPS origin.
                let origin = message.frameInfo.securityOrigin
                guard origin.protocol == "https", !origin.host.isEmpty else { return }
                var components = URLComponents(); components.scheme = "https"; components.host = origin.host
                if origin.port > 0 { components.port = origin.port }
                components.path = "/"
                context = components.url
                if let current = webView.url, let inherited = context, URLTools.sameOrigin(current, inherited) { context = current }
            }
            guard let frame = context, frame.scheme == "https" else { return }
            let incoming = mediaSources(rows, base: frame, frame: frame)
            // Merge before bounding, so repeated reports cannot crowd out late iframe sources.
            frameSources = Array(URLTools.unique(frameSources + incoming).suffix(600)); return
        }
        if message.name == "mdSearchStep", visible, isRecordingSearch, message.frameInfo.isMainFrame,
           let d = message.body as? [String: String], d["token"] == recordingToken,
           let selector = d["selector"], !selector.isEmpty, selector.count < 1000,
           let raw = d["url"], let url = URL(string: raw), let base = recordingBase,
           let frame = message.frameInfo.request.url, URLTools.sameSite(base, frame),
           url.scheme == "https", URLTools.sameSite(base, url) {
            guard recordedSearchSteps.count < SearchWorkflow.maximumSteps else {
                cancelSearchTeaching(); fieldNotice = "تجاوزت ثماني ضغطات. أعد التعليم بمسار أقصر، أو احفظ رابط البحث."; return
            }
            let step = SearchStep(selector: selector, label: String((d["label"] ?? "فتح عنصر").prefix(100)))
            recordedSearchSteps.append(step)
            fieldNotice = "الخطوة \(recordedSearchSteps.count): \(step.label.isEmpty ? "فتح عنصر" : step.label). تابع حتى تضغط خانة البحث للحفظ."
            return
        }
        if message.name == "mdField", visible, message.frameInfo.isMainFrame,
           let d = message.body as? [String: String], let token = d["token"],
           let selector = d["selector"], !selector.isEmpty, selector.count < 1000,
           let raw = d["url"], let url = URL(string: raw), let current = webView.url,
           let frame = message.frameInfo.request.url, URLTools.sameSite(frame, current),
           url.scheme == "https", URLTools.sameSite(current, url) {
            if isRecordingSearch, token == recordingToken, let base = recordingBase, URLTools.sameSite(base, url) {
                let steps = recordedSearchSteps
                do { try SearchWorkflow.validate(steps: steps, field: selector) }
                catch { cancelSearchTeaching(); fieldNotice = error.localizedDescription; return }
                cancelSearchTeaching()
                onPickedSearchWorkflow?(selector, base, steps)
                fieldNotice = "تم حفظ خانة البحث و\(steps.count) من خطوات الفتح لهذا الموقع. اضغط «متابعة»، أو اختبر المسار من قائمة إعداد البحث."
            } else if token == pickerToken {
                cancelSearchTeaching()
                onPickedField?(selector, url); fieldNotice = "تم حفظ الخانة. اضغط «متابعة» لإكمال البحث."
            }
        }
    }

    private func dialogPresenter() -> UIViewController? {
        guard visible, let root = webView.window?.rootViewController else { return nil }
        var presenter = root
        while let next = presenter.presentedViewController { presenter = next }
        return presenter is UIAlertController ? nil : presenter
    }
    func webView(_ webView: WKWebView, runJavaScriptAlertPanelWithMessage message: String, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping () -> Void) {
        guard let presenter = dialogPresenter() else { completionHandler(); return }
        let alert = UIAlertController(title: frame.securityOrigin.host, message: String(message.prefix(2000)), preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "حسنًا", style: .default) { _ in completionHandler() })
        presenter.present(alert, animated: true)
    }
    func webView(_ webView: WKWebView, runJavaScriptConfirmPanelWithMessage message: String, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (Bool) -> Void) {
        guard let presenter = dialogPresenter() else { completionHandler(false); return }
        let alert = UIAlertController(title: frame.securityOrigin.host, message: String(message.prefix(2000)), preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "إلغاء", style: .cancel) { _ in completionHandler(false) })
        alert.addAction(UIAlertAction(title: "موافقة", style: .default) { _ in completionHandler(true) })
        presenter.present(alert, animated: true)
    }
    func webView(_ webView: WKWebView, runJavaScriptTextInputPanelWithPrompt prompt: String, defaultText: String?, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (String?) -> Void) {
        guard let presenter = dialogPresenter() else { completionHandler(nil); return }
        let alert = UIAlertController(title: frame.securityOrigin.host, message: String(prompt.prefix(2000)), preferredStyle: .alert)
        alert.addTextField { field in field.text = defaultText; field.autocorrectionType = .no }
        alert.addAction(UIAlertAction(title: "إلغاء", style: .cancel) { _ in completionHandler(nil) })
        alert.addAction(UIAlertAction(title: "إرسال", style: .default) { [weak alert] _ in completionHandler(alert?.textFields?.first?.text) })
        presenter.present(alert, animated: true)
    }
    // Camera and microphone access are denied. A camera-based verification must use an external browser.
    func webView(_ webView: WKWebView, requestMediaCapturePermissionFor origin: WKSecurityOrigin, initiatedByFrame frame: WKFrameInfo, type: WKMediaCaptureType, decisionHandler: @escaping (WKPermissionDecision) -> Void) {
        decisionHandler(.deny)
    }
}
private final class WeakScriptHandler: NSObject, WKScriptMessageHandler {
    weak var delegate: WKScriptMessageHandler?
    init(_ delegate: WKScriptMessageHandler) { self.delegate = delegate }
    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        delegate?.userContentController(userContentController, didReceive: message)
    }
}
