import Foundation
import Combine
import WebKit
import UIKit

struct BrowserIssue: Error, LocalizedError, Identifiable {
    enum Kind: String { case age, human, access, search, player }
    var kind: Kind
    var message: String
    var id: String { kind.rawValue }
    var errorDescription: String? { message }
}
struct SearchBatch { var items: [VideoResult]; var next: URL?; var page: URL }

@MainActor
final class BrowserEngine: NSObject, ObservableObject, WKNavigationDelegate, WKUIDelegate, WKScriptMessageHandler {
    let webView: WKWebView
    @Published var address = ""
    @Published var progress = 0.0
    @Published var fieldNotice: String?
    var onPickedField: ((String, URL) -> Void)?
    private var navigationError: Error?
    private var observed: NSKeyValueObservation?
    private var frameSources: [MediaSource] = []
    private var script: String
    private(set) var userAgent = ""
    var visible = false

    override convenience init() { self.init(dataStore: .nonPersistent()) }
    init(dataStore: WKWebsiteDataStore) {
        let configuration = WKWebViewConfiguration()
        configuration.websiteDataStore = dataStore
        configuration.allowsInlineMediaPlayback = true
        configuration.mediaTypesRequiringUserActionForPlayback = [.audio, .video]
        configuration.defaultWebpagePreferences.allowsContentJavaScript = true
        let url = Bundle.main.url(forResource: "bridge", withExtension: "js")
        script = url.flatMap { try? String(contentsOf: $0, encoding: .utf8) } ?? ""
        configuration.userContentController.addUserScript(WKUserScript(source: script, injectionTime: .atDocumentStart, forMainFrameOnly: false))
        webView = WKWebView(frame: .zero, configuration: configuration)
        super.init()
        webView.navigationDelegate = self; webView.uiDelegate = self
        configuration.userContentController.add(WeakScriptHandler(self), name: "mdField")
        configuration.userContentController.add(WeakScriptHandler(self), name: "mdMedia")
        webView.isInspectable = false
        webView.scrollView.contentInsetAdjustmentBehavior = .automatic
        observed = webView.observe(\.estimatedProgress, options: [.new]) { [weak self] view, _ in
            Task { @MainActor [weak self] in self?.progress = view.estimatedProgress }
        }
    }
    func javascript(_ source: String) async throws -> Any? {
        try await withCheckedThrowingContinuation { continuation in
            webView.evaluateJavaScript(source) { value, error in
                if let error { continuation.resume(throwing: error) }
                else { continuation.resume(returning: value) }
            }
        }
    }
    func literal(_ value: String) -> String {
        guard let data = try? JSONSerialization.data(withJSONObject: value, options: .fragmentsAllowed),
              let string = String(data: data, encoding: .utf8) else { return "\"\"" }
        return string
    }
    func load(_ url: URL) async throws {
        try Task.checkCancellation()
        guard url.scheme == "https" else { throw MadarError.insecureURL }
        navigationError = nil; frameSources = []
        webView.load(URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 25))
        try await settle(minimum: 0.6, timeout: 26)
        if let navigationError { throw navigationError }
        _ = try? await javascript(script)
        if userAgent.isEmpty { userAgent = (try? await javascript("navigator.userAgent")) as? String ?? "" }
    }
    func settle(minimum: TimeInterval = 0.7, timeout: TimeInterval = 15) async throws {
        let start = Date(); var quiet = 0
        repeat {
            try Task.checkCancellation()
            try await Task.sleep(nanoseconds: 200_000_000)
            if webView.isLoading { quiet = 0 } else { quiet += 1 }
            if Date().timeIntervalSince(start) >= minimum, quiet >= 3 { return }
            if let navigationError { throw navigationError }
        } while Date().timeIntervalSince(start) < timeout
        webView.stopLoading()
        throw MadarError.message("انتهت مهلة تحميل الصفحة. النتائج السابقة ما زالت محفوظة في الشاشة.")
    }
    func issue(from value: Any?) -> BrowserIssue? {
        guard let d = value as? [String: Any], let raw = d["kind"] as? String,
              let kind = BrowserIssue.Kind(rawValue: raw), let message = d["message"] as? String else { return nil }
        return BrowserIssue(kind: kind, message: message)
    }
    func gate() async throws -> BrowserIssue? { issue(from: try await javascript("window.__madar?.gate()")) }
    func search(base: URL, query: String, profile: SiteProfile?, resumeCurrent: Bool = false) async throws -> SearchBatch {
        if !resumeCurrent {
            if let template = profile?.searchTemplate, !template.isEmpty {
                try await load(SearchTemplate.url(template: template, keyword: query, base: base))
                return try await batch(selector: profile?.resultSelector)
            }
            try await load(base)
        }
        if let gate = try await gate() { throw gate }
        if resumeCurrent {
            let snapshot = try await batch(selector: profile?.resultSelector)
            // Keep the user's manually submitted search page instead of replacing it.
            let current = webView.url ?? base
            let queryInURL = URLComponents(url: current, resolvingAgainstBaseURL: false)?.queryItems?.contains(where: { $0.value == query }) == true
            let queryInPath = !query.isEmpty && current.path.localizedCaseInsensitiveContains(query) && current.path != base.path
            if !snapshot.items.isEmpty && (queryInURL || queryInPath) { return snapshot }
        }
        let command = "window.__madar.search(\(literal(query)), \(literal(profile?.searchSelector ?? "")))"
        var value = try await javascript(command) as? [String: Any]
        if value?["opened"] as? Bool == true {
            try await Task.sleep(nanoseconds: 600_000_000)
            value = try await javascript(command) as? [String: Any]
        }
        if let problem = issue(from: value?["gate"]) { throw problem }
        guard value?["submitted"] as? Bool == true else {
            throw BrowserIssue(kind: .search, message: "لم أجد خانة البحث. افتح الموقع وحدد الخانة مرة واحدة، أو أضف رابط البحث في إعدادات الموقع.")
        }
        try await settle(minimum: 1.8)
        _ = try? await javascript(script)
        return try await batch(selector: profile?.resultSelector)
    }
    func batch(selector: String?) async throws -> SearchBatch {
        guard let d = try await javascript("window.__madar.results(\(literal(selector ?? "")))") as? [String: Any],
              let page = webView.url else { throw MadarError.message("تعذر قراءة نتائج الصفحة.") }
        if let problem = issue(from: d["gate"]) { throw problem }
        let items = (d["items"] as? [[String: Any]] ?? []).compactMap { row -> VideoResult? in
            guard let raw = row["url"] as? String, let url = URLTools.candidate(raw, base: page),
                  URLTools.sameSite(url, page) else { return nil }
            return VideoResult(pageURL: url, title: row["title"] as? String ?? "",
                thumbnailURL: (row["thumbnail"] as? String).flatMap { URLTools.candidate($0, base: page) }, duration: row["duration"] as? String)
        }
        let next = (d["next"] as? String).flatMap { URLTools.candidate($0, base: page) }
        return SearchBatch(items: items, next: next, page: page)
    }
    private func mediaSources(_ rows: [[String: Any]], base: URL, frame: URL? = nil) -> [MediaSource] {
        rows.prefix(600).compactMap { row in
            guard let raw = row["url"] as? String, let url = URLTools.candidate(raw, base: base),
                  let rawKind = row["kind"] as? String, let kind = MediaKind(rawValue: rawKind) else { return nil }
            let context = frame ?? (row["referer"] as? String).flatMap { URLTools.candidate($0, base: base) } ?? base
            return MediaSource(url: url, kind: kind, height: URLTools.height(raw),
                evidence: "WebKit DOM/network", requestReferer: context)
        }
    }
    func renderedMedia(for url: URL, useCurrent: Bool = false, deep: Bool = false) async throws -> [MediaSource] {
        if !useCurrent { try await load(url) }
        try Task.checkCancellation()
        if let gate = try await gate() { throw gate }
        let start = Date(), timeout: TimeInterval = deep ? 20 : 12
        var gathered: [MediaSource] = []; var firstProbe = true
        repeat {
            try Task.checkCancellation()
            if let gate = try await gate() { throw gate }
            _ = try? await javascript("window.__madar?.probe(\(firstProbe ? "true" : "false"))")
            firstProbe = false
            let base = webView.url ?? url
            if let rows = try? await javascript("window.__madar?.mediaDetails()") as? [[String: Any]] {
                gathered = URLTools.unique(gathered + mediaSources(rows, base: base) + frameSources)
            } else { gathered = URLTools.unique(gathered + frameSources) }
            // Keep watching even after the first source: it may be a preview, not the main player.
            try await Task.sleep(nanoseconds: 750_000_000)
        } while Date().timeIntervalSince(start) < timeout
        try Task.checkCancellation()
        // Parse the final DOM, not only the first snapshot before lazy players initialize.
        let base = webView.url ?? url
        let html = (try? await javascript("document.documentElement.outerHTML")) as? String ?? ""
        let parsed = await Task.detached(priority: .userInitiated) { MediaExtractor.extract(html, base: base) }.value
        try Task.checkCancellation()
        return URLTools.unique(parsed + gathered + frameSources)
    }
    func prepareUserAgent() async {
        if userAgent.isEmpty { userAgent = (try? await javascript("navigator.userAgent")) as? String ?? "" }
    }
    func inheritSession(from other: BrowserEngine) async {
        await other.prepareUserAgent()
        let cookies = webView.configuration.websiteDataStore === other.webView.configuration.websiteDataStore ? [] : await other.cookies()
        for cookie in cookies {
            await withCheckedContinuation { (c: CheckedContinuation<Void, Never>) in
                webView.configuration.websiteDataStore.httpCookieStore.setCookie(cookie) { c.resume() }
            }
        }
        if !other.userAgent.isEmpty { userAgent = other.userAgent; webView.customUserAgent = other.userAgent }
    }
    func cookies() async -> [HTTPCookie] {
        await withCheckedContinuation { c in webView.configuration.websiteDataStore.httpCookieStore.getAllCookies { c.resume(returning: $0) } }
    }
    func chooseSearchField() async {
        do { _ = try await javascript("window.__madar.pickField()"); fieldNotice = "اضغط خانة البحث داخل الموقع الآن." }
        catch { fieldNotice = error.localizedDescription }
    }
    func stop() { webView.stopLoading() }
    func clearSession() async {
        stop()
        await withCheckedContinuation { (c: CheckedContinuation<Void, Never>) in
            webView.configuration.websiteDataStore.removeData(ofTypes: WKWebsiteDataStore.allWebsiteDataTypes(), modifiedSince: .distantPast) { c.resume() }
        }
        webView.loadHTMLString("<html><body></body></html>", baseURL: nil)
        frameSources = []; address = ""
    }
    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) { frameSources = [] }
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) { address = webView.url?.absoluteString ?? "" }
    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) { if (error as NSError).code != NSURLErrorCancelled { navigationError = error } }
    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) { if (error as NSError).code != NSURLErrorCancelled { navigationError = error } }
    func webViewWebContentProcessDidTerminate(_ webView: WKWebView) { navigationError = MadarError.message("توقف محرك الصفحة. أعد المحاولة؛ النتائج لم تُحذف.") }
    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let url = navigationAction.request.url else { decisionHandler(.cancel); return }
        guard url.scheme == "https" || url.absoluteString == "about:blank" else { decisionHandler(.cancel); return }
        if navigationAction.targetFrame == nil {
            // No automatic advertising popups; deliberate links in the recovery browser stay in one tab.
            if visible && navigationAction.navigationType == .linkActivated { webView.load(navigationAction.request) }
            decisionHandler(.cancel); return
        }
        decisionHandler(.allow)
    }
    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        if message.name == "mdMedia", let rows = message.body as? [[String: Any]] {
            var context = message.frameInfo.request.url
            if context?.scheme != "https" {
                // srcdoc/about:blank frames can inherit a real HTTPS origin.
                let origin = message.frameInfo.securityOrigin
                guard origin.protocol == "https", !origin.host.isEmpty else { return }
                var components = URLComponents(); components.scheme = "https"; components.host = origin.host
                if origin.port > 0 { components.port = origin.port }
                components.path = "/"
                context = components.url
                if let current = webView.url, let inherited = context, URLTools.sameOrigin(current, inherited) { context = current }
            }
            guard let frame = context, frame.scheme == "https" else { return }
            let incoming = mediaSources(rows, base: frame, frame: frame)
            // Merge before bounding, so repeated reports cannot crowd out late iframe sources.
            frameSources = Array(URLTools.unique(frameSources + incoming).suffix(600)); return
        }
        if message.name == "mdField", visible,
           let d = message.body as? [String: String], let selector = d["selector"], selector.count < 1000,
           let raw = d["url"], let url = URL(string: raw), let current = webView.url, URLTools.sameSite(current, url) {
            onPickedField?(selector, url); fieldNotice = "تم حفظ الخانة. اضغط «متابعة» لإكمال البحث."
        }
    }
    private func dialogPresenter() -> UIViewController? {
        guard visible, let root = webView.window?.rootViewController else { return nil }
        var presenter = root
        while let next = presenter.presentedViewController { presenter = next }
        return presenter is UIAlertController ? nil : presenter
    }
    func webView(_ webView: WKWebView, runJavaScriptAlertPanelWithMessage message: String, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping () -> Void) {
        guard let presenter = dialogPresenter() else { completionHandler(); return }
        let alert = UIAlertController(title: frame.securityOrigin.host, message: String(message.prefix(2000)), preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "حسنًا", style: .default) { _ in completionHandler() })
        presenter.present(alert, animated: true)
    }
    func webView(_ webView: WKWebView, runJavaScriptConfirmPanelWithMessage message: String, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (Bool) -> Void) {
        guard let presenter = dialogPresenter() else { completionHandler(false); return }
        let alert = UIAlertController(title: frame.securityOrigin.host, message: String(message.prefix(2000)), preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "إلغاء", style: .cancel) { _ in completionHandler(false) })
        alert.addAction(UIAlertAction(title: "موافقة", style: .default) { _ in completionHandler(true) })
        presenter.present(alert, animated: true)
    }
    func webView(_ webView: WKWebView, runJavaScriptTextInputPanelWithPrompt prompt: String, defaultText: String?, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (String?) -> Void) {
        guard let presenter = dialogPresenter() else { completionHandler(nil); return }
        let alert = UIAlertController(title: frame.securityOrigin.host, message: String(prompt.prefix(2000)), preferredStyle: .alert)
        alert.addTextField { field in field.text = defaultText; field.autocorrectionType = .no }
        alert.addAction(UIAlertAction(title: "إلغاء", style: .cancel) { _ in completionHandler(nil) })
        alert.addAction(UIAlertAction(title: "إرسال", style: .default) { [weak alert] _ in completionHandler(alert?.textFields?.first?.text) })
        presenter.present(alert, animated: true)
    }
    // Camera and microphone access are denied. A camera-based verification must use an external browser.
    func webView(_ webView: WKWebView, requestMediaCapturePermissionFor origin: WKSecurityOrigin, initiatedByFrame frame: WKFrameInfo, type: WKMediaCaptureType, decisionHandler: @escaping (WKPermissionDecision) -> Void) {
        decisionHandler(.deny)
    }
}
private final class WeakScriptHandler: NSObject, WKScriptMessageHandler {
    weak var delegate: WKScriptMessageHandler?
    init(_ delegate: WKScriptMessageHandler) { self.delegate = delegate }
    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        delegate?.userContentController(userContentController, didReceive: message)
    }
}
