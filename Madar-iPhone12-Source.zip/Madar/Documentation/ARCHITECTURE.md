# Madar architecture

## Product flow

`SwiftUI Home → site/query or direct URL → hidden WKWebView search → early result cards → on-demand MediaResolver → quality/folder → authenticated TransferCenter → encrypted VaultStore → range-based private player`

The source tree is new. The old application is not added as a target or dependency. There is one iPhone application target, a dependency-free Swift package for shared core tests, and one bundled DOM adapter. No backend, Node server or external application library is needed to build the app.

## Modules

| Area | Responsibility |
|---|---|
| `App` | Scene bootstrap, observable application state, sheet routing, settings, cancellation generations, privacy curtain. |
| `Core` | Codable models, URL hygiene, search templates, static source reconstruction, HLS parsing, authenticated chunk format. Plain parsing runs under SwiftPM on Linux; crypto requires Apple modules. |
| `Web` + `Scripts/bridge.js` | Single ephemeral WKWebView; search-field detection/picking, generic video cards and JSON-LD, gate notices, runtime media evidence, controlled recovery UI. |
| `Network` | Bounded HTML/image fetches, cookie context, source resolution, download delegates and transfer queue, conditional HLS export. |
| `Vault` | Protected internal paths, biometric key access, encrypted index and file lifecycle, AVPlayer custom resource loader. |
| `UI` | Native Arabic screens, result cards, source/folder selection, unlock flow, library, transfers, recovery browser and settings. |

## Results before downloads

The app publishes search cards as each page is discovered. Cards are not delayed for media-link probes. Selecting a card cancels the current discovery operation if necessary and resolves only that result. Already discovered results remain visible. A generation token rejects late async work from an abandoned search or resolution. The queue is separate from the current search task.

Generic discovery is heuristic. Its confidence comes from real search fields, video-like links with nearby card metadata and schema.org VideoObject data. Saved site-specific CSS selectors or a search template can override these assumptions. Templates must stay on the same HTTPS host. Learning avoids URLs containing obviously sensitive token/session parameter names. Pagination is bounded and same-host, not an unlimited crawler.

## Extraction lineage

`MediaExtractor.swift` reimplements direct URL/attribute/player metadata discovery and statically reconstructs split string expressions from the supplied references. Reconstruction uses a bounded constant environment and never calls eval in Swift. It is not a general JavaScript interpreter. The bundled browser script can observe video/source elements and page resource entries after normal rendering; inaccessible internals, blobs, protected players and undisclosed JSON endpoints remain limitations.

`MediaResolver.swift` checks HLS playlists, expands independent variants, and keeps an audio-linked master playlist intact to avoid deliberately selecting a silent video-only stream. All children the exporter may choose are checked within a complexity cap. AES-encrypted HLS, DRM, DASH and infinite live streams are outside this version.

## Download and cancellation

The direct path uses URLSessionDownloadDelegate. The temporary download file is moved during `didFinishDownloadingTo`, before URLSession deletes it. The response status/MIME are checked; local AVFoundation track inspection runs before vault import. Progress is genuinely unknown if the server omits length. Encoding/import has a separate final progress phase.

HLS is an AVAssetExportSession attempt, not a general muxer. The exporter receives session cookies through the supported asset option. It may not support a particular URL, codec, Referer requirement or adaptive audio layout. Unsupported export is a failure, not a saved playlist disguised as a video.

The queue is serial and foreground-only. Cancellation propagates to the active download/export/encryption. Retry starts over. Queue state is not persisted across process death. This avoids claiming background behavior while the vault key is meant to be locked, but it is a product limitation.

## Layout and system integration

The application uses SwiftUI TextField/SecureField, URL/default system keyboard types, safe-area insets, flexible scroll layouts and standard sheets. There are no old screen-coordinate offsets, manual keyboard height calculations, or web-form keyboards used as the main search interface. `UILaunchScreen` names a launch background color; the iPhone-only target and app icon are explicit. Both portrait and landscape are declared; real iPhone 12 notch, keyboard and rotation behavior still need device verification.

The search surface uses dark navy panels with violet/mint accents, rounded result cards, a grid/list toggle and consistent primary actions. The source does not include screenshots claimed to be a running app.

## Boundaries and future work

This version deliberately omits resumable/background transfer, encrypted export/backup, a forgotten-password reset path, full JavaScript deobfuscation, arbitrary DRM support, a built-in Brave engine, universal website adapters and automatic cloud verification. Additions need their own implementation and tests; none should be inferred from the presence of a generic search box or build workflow.


## Search workflow revision — 2026-10-01

`SiteProfile` now optionally stores `searchSteps`, `searchStartURL`, and `searchStepTimeout`. Optional fields preserve decoding of old profiles. `SearchWorkflow` in Core validates scope, size and timing. BrowserEngine owns the bounded replay loop and navigation; `bridge.js` executes one validated action per call and offers promise-returning, non-clicking DOM waits. The recovery browser records user opening clicks followed by selection of the final field. State is kept natively across same-site main-frame navigations. `mdSearchStep` and `mdField` are accepted only during an active teaching/picking mode, with a session token and main-frame/scope checks.

Stored CSS is not executable JavaScript. It is passed as a quoted string to bounded selector queries. CSS selector validity, uniqueness, visibility and control safety are rechecked on replay. A failing recorded route requests manual repair rather than inventing alternative clicks. Direct URL templates retain priority; new teaching clears an old template and suppresses automatic template learning for that workflow.

See SEARCH_WORKFLOW_AR.md for tests and unsupported cases. Neither Linux syntax checks nor Chromium DOM tests validate the iOS SDK integration or SwiftUI runtime.
