#!/usr/bin/env bash
# Build a REAL unsigned device app, then package it. Does not sign or install.
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
if [[ "$(uname -s)" != "Darwin" ]] || ! command -v xcodebuild >/dev/null 2>&1; then
  echo "A Mac with full Xcode and the iOS 18.5 SDK or newer is required. No IPA was created." >&2
  exit 2
fi
xcodebuild -version
SDK_VERSION="$(xcrun --sdk iphoneos --show-sdk-version)"
python3 - "$SDK_VERSION" <<'PY'
import sys
v=tuple(int(x) for x in sys.argv[1].split('.')[:2])
if v < (18,5): raise SystemExit('The selected Xcode iOS SDK is older than 18.5.')
PY
OUT="$ROOT/build"
mkdir -p "$OUT"
xcodebuild -project Madar.xcodeproj -scheme Madar -configuration Release \
  -destination 'generic/platform=iOS' -derivedDataPath "$OUT/DerivedData" \
  CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO CODE_SIGN_IDENTITY='' \
  build 2>&1 | tee "$OUT/device-build.log"
APP="$OUT/DerivedData/Build/Products/Release-iphoneos/Madar.app"
[[ -d "$APP" && -f "$APP/Madar" ]] || { echo 'Build did not produce a Madar executable.' >&2; exit 3; }
# A clean staging directory prevents old or unrelated files entering the IPA.
STAGE="$(mktemp -d "$OUT/package.XXXXXX")"
trap 'rm -rf "$STAGE"' EXIT
mkdir -p "$STAGE/Payload"
ditto "$APP" "$STAGE/Payload/Madar.app"
rm -rf "$STAGE/Payload/Madar.app/_CodeSignature"
rm -f "$STAGE/Payload/Madar.app/embedded.mobileprovision"
rm -f "$OUT/Madar-unsigned.ipa"
(cd "$STAGE" && ditto -c -k --sequesterRsrc --keepParent Payload "$OUT/Madar-unsigned.ipa")
python3 - "$OUT/Madar-unsigned.ipa" <<'PY'
import sys,zipfile
with zipfile.ZipFile(sys.argv[1]) as z:
    assert z.testzip() is None, 'Corrupt archive'
    assert 'Payload/Madar.app/Madar' in z.namelist(), 'Missing real executable'
    assert 'Payload/Madar.app/Info.plist' in z.namelist(), 'Missing app metadata'
print('Created:', sys.argv[1])
print('Unsigned: signing with a valid identity/provisioning is still required to install on an iPhone.')
PY
