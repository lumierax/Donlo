#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
if [[ "$(uname -s)" != "Darwin" ]] || ! command -v xcodebuild >/dev/null 2>&1; then
  echo 'A Mac with full Xcode is required.' >&2; exit 2
fi
mkdir -p build
xcodebuild -project Madar.xcodeproj -scheme Madar -configuration Debug \
  -destination 'generic/platform=iOS Simulator' -derivedDataPath "$ROOT/build/SimulatorDerivedData" \
  CODE_SIGNING_ALLOWED=NO build 2>&1 | tee build/simulator-build.log
