#!/usr/bin/env python3
"""Check bundle metadata, project membership, asset files and privacy invariants.
This is a structural check, not an Xcode compiler or a privacy certification.
"""
from pathlib import Path
import json, plistlib, re, subprocess, sys
import xml.etree.ElementTree as ET
ROOT = Path(__file__).resolve().parents[1]

def main():
    project = ROOT / 'Madar.xcodeproj/project.pbxproj'
    result = subprocess.run(['plutil','-convert','json','-o','-','--',str(project)], check=True, capture_output=True, text=True)
    data = json.loads(result.stdout)
    objects=data['objects']
    project_object=objects[data['rootObject']]
    assert project_object['isa']=='PBXProject'
    targets=[x for x in objects.values() if x.get('isa')=='PBXNativeTarget']
    assert len(targets)==1 and targets[0]['name']=='Madar'
    refs={i:x for i,x in objects.items() if x.get('isa')=='PBXFileReference'}
    for x in refs.values():
        if x.get('sourceTree')=='<group>':
            assert (ROOT/x['path']).exists(), 'Missing file: '+x['path']
    phase=next(x for x in objects.values() if x.get('isa')=='PBXSourcesBuildPhase')
    compiled={refs[objects[i]['fileRef']]['path'] for i in phase['files']}
    actual={p.relative_to(ROOT).as_posix() for p in (ROOT/'Madar').rglob('*.swift')}
    assert compiled==actual, ('Project/source mismatch', compiled^actual)
    resource_phase=next(x for x in objects.values() if x.get('isa')=='PBXResourcesBuildPhase')
    resources={refs[objects[i]['fileRef']]['path'] for i in resource_phase['files']}
    assert {'Madar/Assets.xcassets','Madar/Scripts/bridge.js','Madar/PrivacyInfo.xcprivacy'} <= resources
    info=plistlib.loads((ROOT/'Madar/Info.plist').read_bytes())
    assert info.get('UILaunchScreen',{}).get('UIColorName')=='LaunchBackground'
    assert info.get('UIFileSharingEnabled') is False
    assert info.get('LSSupportsOpeningDocumentsInPlace') is False
    assert not any(k.startswith('NSPhotoLibrary') for k in info)
    assert not info.get('UIBackgroundModes')
    assert 'NSFaceIDUsageDescription' in info
    assert not info.get('NSAppTransportSecurity',{}).get('NSAllowsArbitraryLoads',False)
    privacy=plistlib.loads((ROOT/'Madar/PrivacyInfo.xcprivacy').read_bytes())
    assert privacy['NSPrivacyTracking'] is False
    for config in objects.values():
        if config.get('isa')=='XCBuildConfiguration':
            assert config['buildSettings']['IPHONEOS_DEPLOYMENT_TARGET']=='18.5'
            if 'PRODUCT_BUNDLE_IDENTIFIER' in config['buildSettings']:
                assert config['buildSettings']['TARGETED_DEVICE_FAMILY']=='1'
    for p in (ROOT/'Madar/Assets.xcassets').rglob('Contents.json'):
        value=json.loads(p.read_text())
        for item in value.get('images',[]):
            if 'filename' in item: assert (p.parent/item['filename']).is_file()
    ET.parse(ROOT/'Madar.xcodeproj/xcshareddata/xcschemes/Madar.xcscheme')
    ET.parse(ROOT/'Madar.xcodeproj/project.xcworkspace/contents.xcworkspacedata')
    source='\n'.join((ROOT/p).read_text() for p in actual)
    assert not re.search(r'\bimport\s+(Photos|PhotosUI)\b', source)
    assert 'UIImageWriteToSavedPhotosAlbum' not in source
    assert 'UISaveVideoAtPathToSavedPhotosAlbum' not in source
    assert '.nonPersistent()' in source
    assert 'minimumDuration: 1.8' in source
    print(f'PASS: {len(compiled)} Swift app sources referenced by the project.')
    print('PASS: bundle/launch/asset/scheme/resource metadata and file existence.')
    print('PASS: iPhone family, iOS 18.5, no Photos access, no file sharing, no broad ATS exception.')
    print('PASS: privacy metadata, ephemeral WebKit and hidden entry gesture present.')
    print('LIMITATION: no iOS SDK compilation or runtime validation is performed by this script.')
if __name__=='__main__':
    try: main()
    except (AssertionError, OSError, ValueError, subprocess.CalledProcessError) as error:
        print('FAIL:', error, file=sys.stderr); raise SystemExit(1)
