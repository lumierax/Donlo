#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
python3 Scripts/validate_structure.py
swift test
# Parsing is NOT an iOS build. The separate simulator/device scripts use the iOS SDK.
find Madar -name '*.swift' -print0 | xargs -0 swiftc -frontend -parse
if command -v node >/dev/null 2>&1; then node --check Madar/Scripts/bridge.js; fi
for file in Scripts/*.sh; do bash -n "$file"; done
echo "PASS: Swift/JavaScript syntax and shell syntax (not an iOS build)."
if [[ "${DOM_TESTS:-0}" == "1" ]]; then python3 Scripts/test_dom.py; fi
