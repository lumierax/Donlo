#!/usr/bin/env python3
"""Offline DOM regression tests. Uses Chromium via Playwright, NOT iOS WebKit.
All requests are blocked. Fixtures use set_content and a lexical mock location; no site is contacted.
Usage: python3 Scripts/test_dom.py --browser /usr/bin/chromium
"""
import argparse
import json
import shutil
from pathlib import Path
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = (ROOT / "Madar/Scripts/bridge.js").read_text(encoding="utf-8")
parser = argparse.ArgumentParser()
parser.add_argument("--browser", default=None, help="Optional Chromium executable; otherwise use system or Playwright bundled Chromium")
args = parser.parse_args()
results = []

def record(name, body):
    try:
        body()
        results.append({"test": name, "passed": True})
        print("PASS", name)
    except Exception as exc:
        results.append({"test": name, "passed": False, "error": str(exc)})
        print("FAIL", name, str(exc))

def require(condition, message="assertion failed"):
    if not condition:
        raise AssertionError(message)

with sync_playwright() as p:
    browser = p.chromium.launch(executable_path=args.browser or shutil.which("chromium") or shutil.which("chromium-browser"), headless=True, args=["--no-sandbox"])
    page = browser.new_page(viewport={"width": 390, "height": 844})
    page.route("**/*", lambda route: route.abort())
    def load(html):
        page.set_content('<!doctype html><base href="https://fixture.example/"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">' + html, wait_until="domcontentloaded")
        page.evaluate("delete window.__madar; delete window.sent; delete window.accepted; delete window.picked;")
        # The sandbox disallows external navigations, including intercepted dummy URLs.
        # Only location is mocked; the real Chromium DOM runs the unchanged production script.
        page.evaluate("script => (new Function('location', script))(new URL('https://fixture.example/'))", SCRIPT)
    def test_cards():
        load('''<nav><a href="/videos">Videos</a></nav>
        <article><a href="/watch/1" title="رحلة البحر"><img data-src="/thumb.jpg"></a><time>03:20</time></article>
        <article><a href="/watch/1" title="duplicate"><img src="/thumb.jpg"></a></article>
        <article><a href="https://outside.example/watch/7" title="external"><img src="/thumb.jpg"></a></article>
        <a rel="next" href="/search?page=2">Next</a>''')
        r = page.evaluate("window.__madar.results()")
        require(len(r['items']) == 1, str(r))
        require(r['items'][0]['title'] == 'رحلة البحر')
        require(r['items'][0]['thumbnail'] == 'https://fixture.example/thumb.jpg')
        require(r['items'][0]['duration'] == '03:20')
        require(r['next'] == 'https://fixture.example/search?page=2')
    record("cards_before_media_checks_dedup_scope_and_pagination", test_cards)
    def test_missing_image():
        load('<a href="/watch/7" title="No thumbnail">Video</a>')
        r = page.evaluate("window.__madar.results()")
        require(len(r['items']) == 1)
        require(r['items'][0]['thumbnail'] is None, str(r))
    record("missing_thumbnail_stays_null", test_missing_image)
    def test_false_gate():
        load('<title>Videos</title><script>var ad="captcha verify your age";</script><h1>Ordinary page</h1>')
        require(page.evaluate("window.__madar.gate()") is None)
    record("script_keywords_are_not_access_gates", test_false_gate)
    def test_age():
        load('<dialog open><p>Confirm your age</p><button onclick="window.accepted=true">I am 18</button></dialog>')
        r = page.evaluate("window.__madar.search('hello')")
        require(r['gate']['kind'] == 'age'); require(not r['submitted'])
        require(page.evaluate("window.accepted === true") is False)
    record("age_gate_requires_user_no_auto_accept", test_age)
    def test_human():
        load('<iframe style="width:300px;height:100px" src="https://challenges.cloudflare.com/widget"></iframe>')
        require(page.evaluate("window.__madar.gate()?.kind") == 'human')
    record("visible_human_verification_is_detected", test_human)
    def test_hidden_human():
        load('<iframe style="display:none" src="https://challenges.cloudflare.com/widget"></iframe><h1>Video results</h1>')
        require(page.evaluate("window.__madar.gate()") is None)
    record("hidden_verification_frame_does_not_block_results", test_hidden_human)
    def test_search():
        load('''<form role="search" onsubmit="event.preventDefault();window.sent=document.querySelector('input').value">
        <input type="search" name="q"><button type="submit">Search</button></form>''')
        r = page.evaluate("window.__madar.search('hello & مرحبا')")
        require(r['submitted']); require(page.evaluate("window.sent") == 'hello & مرحبا')
        require(page.evaluate("document.activeElement.tagName") != 'INPUT', 'Hidden input stole keyboard focus')
    record("search_preserves_unicode_and_does_not_steal_keyboard", test_search)
    def test_hidden_search_trigger():
        load('''<button aria-label="Open search" onclick="document.querySelector('form').style.display='block'">S</button>
        <form style="display:none" onsubmit="event.preventDefault();window.sent=this.elements.q.value"><input type="search" name="q"></form>''')
        require(page.evaluate("window.__madar.search('sea').opened") is True)
        require(page.evaluate("window.__madar.search('sea').submitted") is True)
        require(page.evaluate("window.sent") == 'sea')
    record("collapsed_search_can_be_opened_without_browser_ui", test_hidden_search_trigger)
    def test_no_login():
        load('<form><input type="email" name="email"><input type="password"><button>Log in</button></form>')
        r = page.evaluate("window.__madar.search('anything')")
        require(r.get('missing') is True); require(r['submitted'] is False)
    record("login_fields_are_not_used_for_search", test_no_login)
    def test_selector():
        load('''<form onsubmit="event.preventDefault();window.sent=this.elements.unusual.value"><input name="unusual" id="chosen"><button>Go</button></form>''')
        require(page.evaluate("window.__madar.search('x', '#chosen').submitted") is True)
        require(page.evaluate("window.sent") == 'x')
    record("saved_search_selector_is_respected", test_selector)
    def test_pick():
        load('<input id="query-special" type="search">')
        page.evaluate("window.webkit={messageHandlers:{mdField:{postMessage:m=>window.picked=m}}}")
        page.evaluate("window.__madar.pickField()")
        page.locator('#query-special').click()
        picked = page.evaluate("window.picked")
        require(picked['selector'] == '#query-special'); require(picked['url'] == 'https://fixture.example/')
    record("user_picks_search_field_and_receives_selector", test_pick)
    def test_custom_results():
        load('<div class="special"><a href="/content/1"><h3>Custom card</h3></a></div>')
        r = page.evaluate("window.__madar.results('.special')")
        require(r['items'][0]['title'] == 'Custom card')
    record("custom_result_selector", test_custom_results)
    def test_schema():
        load('''<script type="application/ld+json">{"@type":"VideoObject","name":"Structured video","url":"/watch/11","thumbnailUrl":["/poster.jpg"],"duration":"PT2M"}</script>''')
        r = page.evaluate("window.__madar.results()")
        require(r['items'][0]['title'] == 'Structured video'); require(r['items'][0]['thumbnail'] == 'https://fixture.example/poster.jpg')
    record("jsonld_results", test_schema)
    def test_media():
        load('<video><source src="https://cdn.example/video_720p.mp4"><source src="blob:https://fixture.example/secret"></video>')
        r = page.evaluate("window.__madar.media()")
        require(r == ['https://cdn.example/video_720p.mp4'], str(r))
    record("runtime_media_only_supported_https_urls", test_media)
    browser.close()

report = {"engine": "Chromium; not iOS WebKit", "network": "all requests aborted; set_content fixtures with a lexical mock location", "tests": results,
          "passed": sum(r['passed'] for r in results), "failed": sum(not r['passed'] for r in results)}
output = ROOT / "Documentation/dom-test-report.json"
output.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
print(f"\n{report['passed']} passed; {report['failed']} failed")
raise SystemExit(1 if report['failed'] else 0)
