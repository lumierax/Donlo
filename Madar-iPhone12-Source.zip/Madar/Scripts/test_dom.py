#!/usr/bin/env python3
"""Offline DOM regression tests. Uses Chromium via Playwright, NOT iOS WebKit.
All requests are blocked. Fixtures use set_content and a lexical mock location; no site is contacted.
Usage: python3 Scripts/test_dom.py --browser /usr/bin/chromium
"""
import argparse
import json
import shutil
from pathlib import Path
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = (ROOT / "Madar/Scripts/bridge.js").read_text(encoding="utf-8")
parser = argparse.ArgumentParser()
parser.add_argument("--browser", default=None, help="Optional Chromium executable; otherwise use system or Playwright bundled Chromium")
args = parser.parse_args()
results = []

def record(name, body):
    try:
        body()
        results.append({"test": name, "passed": True})
        print("PASS", name)
    except Exception as exc:
        results.append({"test": name, "passed": False, "error": str(exc)})
        print("FAIL", name, str(exc))

def require(condition, message="assertion failed"):
    if not condition:
        raise AssertionError(message)

with sync_playwright() as p:
    browser = p.chromium.launch(executable_path=args.browser or shutil.which("chromium") or shutil.which("chromium-browser"), headless=True, args=["--no-sandbox"])
    page = browser.new_page(viewport={"width": 390, "height": 844})
    page.route("**/*", lambda route: route.abort())
    def load(html, setup=None):
        page.goto("about:blank")  # Fresh document removes previous test observers and wrappers.
        page.set_content('<!doctype html><base href="https://fixture.example/"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">' + html, wait_until="domcontentloaded")
        page.evaluate("delete window.__madar; delete window.sent; delete window.accepted; delete window.picked;")
        if setup:
            page.evaluate(setup)
        # The sandbox disallows external navigations, including intercepted dummy URLs.
        # Only location is mocked; the real Chromium DOM runs the unchanged production script.
        page.evaluate("script => (new Function('location', script))(new URL('https://fixture.example/'))", SCRIPT)
    def test_cards():
        load('''<nav><a href="/videos">Videos</a></nav>
        <article><a href="/watch/1" title="رحلة البحر"><img data-src="/thumb.jpg"></a><time>03:20</time></article>
        <article><a href="/watch/1" title="duplicate"><img src="/thumb.jpg"></a></article>
        <article><a href="https://outside.example/watch/7" title="external"><img src="/thumb.jpg"></a></article>
        <a rel="next" href="/search?page=2">Next</a>''')
        r = page.evaluate("window.__madar.results()")
        require(len(r['items']) == 1, str(r))
        require(r['items'][0]['title'] == 'رحلة البحر')
        require(r['items'][0]['thumbnail'] == 'https://fixture.example/thumb.jpg')
        require(r['items'][0]['duration'] == '03:20')
        require(r['next'] == 'https://fixture.example/search?page=2')
    record("cards_before_media_checks_dedup_scope_and_pagination", test_cards)
    def test_missing_image():
        load('<a href="/watch/7" title="No thumbnail">Video</a>')
        r = page.evaluate("window.__madar.results()")
        require(len(r['items']) == 1)
        require(r['items'][0]['thumbnail'] is None, str(r))
    record("missing_thumbnail_stays_null", test_missing_image)
    def test_false_gate():
        load('<title>Videos</title><script>var ad="captcha verify your age";</script><h1>Ordinary page</h1>')
        require(page.evaluate("window.__madar.gate()") is None)
    record("script_keywords_are_not_access_gates", test_false_gate)
    def test_age():
        load('<dialog open><p>Confirm your age</p><button onclick="window.accepted=true">I am 18</button></dialog>')
        r = page.evaluate("window.__madar.search('hello')")
        require(r['gate']['kind'] == 'age'); require(not r['submitted'])
        require(page.evaluate("window.accepted === true") is False)
    record("age_gate_requires_user_no_auto_accept", test_age)
    def test_human():
        load('<iframe style="width:300px;height:100px" src="https://challenges.cloudflare.com/widget"></iframe>')
        require(page.evaluate("window.__madar.gate()?.kind") == 'human')
    record("visible_human_verification_is_detected", test_human)
    def test_hidden_human():
        load('<iframe style="display:none" src="https://challenges.cloudflare.com/widget"></iframe><h1>Video results</h1>')
        require(page.evaluate("window.__madar.gate()") is None)
    record("hidden_verification_frame_does_not_block_results", test_hidden_human)
    def test_search():
        load('''<form role="search" onsubmit="event.preventDefault();window.sent=document.querySelector('input').value">
        <input type="search" name="q"><button type="submit">Search</button></form>''')
        r = page.evaluate("window.__madar.search('hello & مرحبا')")
        require(r['submitted']); require(page.evaluate("window.sent") == 'hello & مرحبا')
        require(page.evaluate("document.activeElement.tagName") != 'INPUT', 'Hidden input stole keyboard focus')
    record("search_preserves_unicode_and_does_not_steal_keyboard", test_search)
    def test_hidden_search_trigger():
        load('''<button aria-label="Open search" onclick="document.querySelector('form').style.display='block'">S</button>
        <form style="display:none" onsubmit="event.preventDefault();window.sent=this.elements.q.value"><input type="search" name="q"></form>''')
        require(page.evaluate("window.__madar.search('sea').opened") is True)
        require(page.evaluate("window.__madar.search('sea').submitted") is True)
        require(page.evaluate("window.sent") == 'sea')
    record("collapsed_search_can_be_opened_without_browser_ui", test_hidden_search_trigger)
    def test_no_login():
        load('<form><input type="email" name="email"><input type="password"><button>Log in</button></form>')
        r = page.evaluate("window.__madar.search('anything')")
        require(r.get('missing') is True); require(r['submitted'] is False)
    record("login_fields_are_not_used_for_search", test_no_login)
    def test_selector():
        load('''<form onsubmit="event.preventDefault();window.sent=this.elements.unusual.value"><input name="unusual" id="chosen"><button>Go</button></form>''')
        require(page.evaluate("window.__madar.search('x', '#chosen').submitted") is True)
        require(page.evaluate("window.sent") == 'x')
    record("saved_search_selector_is_respected", test_selector)
    def test_pick():
        load('<input id="query-special" type="search">')
        page.evaluate("window.webkit={messageHandlers:{mdField:{postMessage:m=>window.picked=m}}}")
        page.evaluate("window.__madar.pickField()")
        page.locator('#query-special').click()
        picked = page.evaluate("window.picked")
        require(picked['selector'] == '#query-special'); require(picked['url'] == 'https://fixture.example/')
    record("user_picks_search_field_and_receives_selector", test_pick)
    def test_custom_results():
        load('<div class="special"><a href="/content/1"><h3>Custom card</h3></a></div>')
        r = page.evaluate("window.__madar.results('.special')")
        require(r['items'][0]['title'] == 'Custom card')
    record("custom_result_selector", test_custom_results)
    def test_schema():
        load('''<script type="application/ld+json">{"@type":"VideoObject","name":"Structured video","url":"/watch/11","thumbnailUrl":["/poster.jpg"],"duration":"PT2M"}</script>''')
        r = page.evaluate("window.__madar.results()")
        require(r['items'][0]['title'] == 'Structured video'); require(r['items'][0]['thumbnail'] == 'https://fixture.example/poster.jpg')
    record("jsonld_results", test_schema)
    def test_media():
        load('<video><source src="https://cdn.example/video_720p.mp4"><source src="blob:https://fixture.example/secret"></video>')
        r = page.evaluate("window.__madar.media()")
        require(r == ['https://cdn.example/video_720p.mp4'], str(r))
    record("runtime_media_only_supported_https_urls", test_media)
    def test_untitled_cards():
        load('<article><a href="/watch/untitled"><img src="/poster.jpg"></a><time>02:30</time></article>')
        r = page.evaluate('window.__madar.results()')
        require(len(r['items']) == 1, str(r))
        require(r['items'][0]['title'] == 'فيديو بدون عنوان · untitled', str(r))
        require(r['items'][0]['untitled'] is True)
    record('untitled_video_is_not_discarded', test_untitled_cards)
    def test_untitled_no_thumbnail():
        load('<a href="/watch/123"></a><a href="/watch/456" title="أ"></a>')
        r = page.evaluate('window.__madar.results()')
        require(len(r['items']) == 2, str(r))
        require(r['items'][0]['title'].startswith('فيديو بدون عنوان'))
        require(r['items'][1]['title'] == 'أ')
    record('no_title_or_thumbnail_and_one_letter_title_stay_visible', test_untitled_no_thumbnail)
    def test_real_title_replaces_fallback():
        load('<a href="/watch/123"><img></a><a href="/watch/123" title="العنوان الحقيقي"></a>')
        r = page.evaluate('window.__madar.results()')
        require(len(r['items']) == 1, str(r))
        require(r['items'][0]['title'] == 'العنوان الحقيقي', str(r))
    record('duplicate_with_real_title_upgrades_untitled_card', test_real_title_replaces_fallback)
    def test_sibling_titles():
        load('<div class="grid"><a href="/watch/1"><h3>الفيديو الأول</h3></a><a href="/watch/2"><h3>الفيديو الثاني</h3></a></div>')
        r = page.evaluate('window.__madar.results()')
        require([i['title'] for i in r['items']] == ['الفيديو الأول', 'الفيديو الثاني'], str(r))
    record('shared_container_does_not_copy_sibling_title', test_sibling_titles)
    def test_untitled_schema():
        load('''<script type="application/ld+json">{"@type":["Thing","VideoObject"],"url":"/watch/untitled"}</script>''')
        r = page.evaluate('window.__madar.results()')
        require(len(r['items']) == 1 and r['items'][0]['untitled'], str(r))
    record('untitled_jsonld_video_is_kept', test_untitled_schema)
    def test_extensionless_media():
        load('<video><source src="https://cdn.example/get?id=42" type="video/mp4"></video>')
        r = page.evaluate('window.__madar.mediaDetails()')
        require(len(r) == 1 and r[0]['kind'] == 'file', str(r))
        require(r[0]['referer'] == 'https://fixture.example/')
    record('typed_extensionless_video_and_context_are_captured', test_extensionless_media)
    def test_extensionless_untyped_video():
        load('<video src="https://cdn.example/deliver?id=42"></video><audio src="https://cdn.example/audio?id=1"></audio>')
        r = page.evaluate('window.__madar.media()')
        require(r == ['https://cdn.example/deliver?id=42'], str(r))
    record('video_context_allows_extensionless_url_without_adding_audio', test_extensionless_untyped_video)
    def test_hls_hash_url():
        load('<video src="https://cdn.example/master.m3u8?token=abc#fragment"></video>')
        r = page.evaluate('window.__madar.mediaDetails()')
        require(len(r) == 1 and r[0]['kind'] == 'hls', str(r))
    record('hls_path_wins_over_generic_video_context', test_hls_hash_url)
    def test_delayed_media():
        load('<div id="player"></div>')
        page.evaluate('''() => setTimeout(() => {
            const v = document.createElement('video'); v.src = 'https://cdn.example/late_720p.mp4';
            document.getElementById('player').append(v);
        }, 4200)''')
        page.wait_for_function("window.__madar.media().includes('https://cdn.example/late_720p.mp4')", timeout=7000)
    record('source_appearing_after_old_3_5_second_frame_window_is_detected', test_delayed_media)
    def test_shadow_root():
        load('<div id="player"></div>')
        page.evaluate('''() => {document.getElementById('player').attachShadow({mode:'open'}).innerHTML = '<video src="https://cdn.example/shadow.mp4"></video>';}''')
        require('https://cdn.example/shadow.mp4' in page.evaluate('window.__madar.media()'))
    record('open_shadow_root_player_is_scanned', test_shadow_root)
    def test_fetch_mime():
        load('<div></div>', setup='''() => {
            const r = new Response('unchanged-body', {headers:{'Content-Type':'application/vnd.apple.mpegurl'}});
            Object.defineProperty(r, 'url', {value:'https://cdn.example/manifest?id=42'});
            window.mockResponse = r; window.mockPromise = Promise.resolve(r);
            window.fetch = () => window.mockPromise;
        }''')
        r = page.evaluate('''async () => {
            const promise = window.fetch('/anything'); const samePromise = promise === window.mockPromise;
            const response = await promise; await Promise.resolve();
            return {samePromise, bodyUsed:response.bodyUsed, records:window.__madar.mediaDetails(), body:await response.text()};
        }''')
        require(r['samePromise'] and not r['bodyUsed'] and r['body'] == 'unchanged-body', str(r))
        require(r['records'][0]['url'] == 'https://cdn.example/manifest?id=42' and r['records'][0]['kind'] == 'hls', str(r))
    record('fetch_mime_detects_extensionless_hls_without_consuming_body', test_fetch_mime)
    def test_xhr_mime():
        load('<div></div>', setup='''() => {
            window.XMLHttpRequest = class extends EventTarget {
                open(method,url) { this.responseURL=url; return 'original-open-result'; }
                getResponseHeader(name) { return 'video/mp4'; }
                send() { this.dispatchEvent(new Event('load')); }
            };
        }''')
        r = page.evaluate('''() => {const x=new XMLHttpRequest(); const result=x.open('GET','https://cdn.example/get?id=42'); x.send(); return {result, records:window.__madar.mediaDetails()};}''')
        require(r['result'] == 'original-open-result', str(r))
        require(r['records'][0]['kind'] == 'file', str(r))
    record('xhr_mime_observer_preserves_open_result', test_xhr_mime)
    def test_probe_never_clicks_gate():
        load('<dialog open>Confirm your age<button onclick="window.accepted=true">Accept</button></dialog><video src="https://cdn.example/test.mp4"></video>')
        page.evaluate('''() => {window.loadCalls=0; document.querySelector('video').load=()=>window.loadCalls++;}''')
        r = page.evaluate('window.__madar.probe()')
        require(r['blocked'] is True)
        require(page.evaluate('window.accepted === true') is False)
        require(page.evaluate('window.loadCalls') == 0)
    record('metadata_probe_stops_at_gate_without_click_or_load', test_probe_never_clicks_gate)
    def test_probe_once_no_play():
        load('<video src="https://cdn.example/test.mp4"></video>')
        page.evaluate('''() => {window.loads=0;window.plays=0;const v=document.querySelector('video');v.load=()=>window.loads++;v.play=()=>window.plays++;}''')
        page.evaluate('window.__madar.probe(); window.__madar.probe();')
        require(page.evaluate('window.loads') == 1)
        require(page.evaluate('window.plays') == 0)
    record('metadata_probe_is_idempotent_and_does_not_start_playback', test_probe_once_no_play)
    def test_iframe_reporting():
        load('<iframe name="player" srcdoc="<video></video>"></iframe>')
        frame = page.frame(name='player')
        require(frame is not None)
        frame.evaluate('''() => {window.reports=[];window.webkit={messageHandlers:{mdMedia:{postMessage:x=>window.reports.push(...x)}}};}''')
        frame.evaluate("script => (new Function('location', script))(new URL('https://player.example/embed/42'))", SCRIPT)
        frame.evaluate("document.querySelector('video').src='https://cdn.example/frame_720p.mp4'")
        frame.wait_for_function("window.reports.some(x=>x.url === 'https://cdn.example/frame_720p.mp4')", timeout=4000)
        reports = frame.evaluate('window.reports')
        require(any(x['referer'] == 'https://player.example/embed/42' for x in reports), str(reports))
    record('child_frame_reports_typed_source_and_its_own_referer', test_iframe_reporting)
    def test_unsafe_urls_and_segments():
        load('''<video src="blob:https://fixture.example/key"></video><source src="https://u:p@cdn.example/a.mp4"><source src="http://cdn.example/a.mp4"><source src="https://cdn.example/part.ts" type="video/mp2t">''')
        require(page.evaluate('window.__madar.media()') == [])
    record('no_blob_credentials_http_or_transport_segments', test_unsafe_urls_and_segments)
    def multi_step():
        load('''<button id="menu" aria-label="Open menu" onclick="window.m=(window.m||0)+1;document.querySelector('nav').hidden=false">☰</button>
        <nav hidden><a id="openSearch" href="#" onclick="event.preventDefault();window.s=(window.s||0)+1;document.querySelector('form').hidden=false">Search</a></nav>
        <form hidden onsubmit="event.preventDefault();window.sent=this.elements.q.value"><input name="q" type="search"><button>Search</button></form>''')
        r = page.evaluate('''async () => {
          let r; for(let i=0;i<4;i++) { r=window.__madar.search('قائمة & search'); if(r.submitted) break;
            if(r.opened) await window.__madar.waitForSearch('', '', 1500); }
          return r;
        }''')
        require(r.get('submitted'), str(r)); require(page.evaluate('window.sent') == 'قائمة & search')
        require(page.evaluate('[window.m,window.s]') == [1,1])
    record('search_menu_then_search_link_then_field', multi_step)

    def delayed_steps():
        load('''<button aria-label="Menu" onclick="window.m=(window.m||0)+1;setTimeout(()=>document.querySelector('nav').hidden=false,1100)">☰</button>
        <nav hidden><button aria-label="Search" onclick="window.s=(window.s||0)+1;setTimeout(()=>document.querySelector('form').hidden=false,1200)">Search</button></nav>
        <form hidden onsubmit="event.preventDefault();window.sent=this.elements.q.value"><input name="q" type="search"></form>''')
        r=page.evaluate('''async () => {
            let r; for(let i=0;i<4;i++) { r=window.__madar.search('delayed'); if(r.submitted) return r;
              await window.__madar.waitForSearch('', '', 2500); } return r;
        }''')
        require(r.get('submitted'), str(r)); require(page.evaluate('window.sent')=='delayed')
        require(page.evaluate('[window.m,window.s]') == [1,1])
    record('search_waits_for_each_delayed_drawer_and_field_over_600ms', delayed_steps)

    def off_canvas():
        load('''<button aria-label="Menu" onclick="document.querySelector('aside').style.transform='none'">☰</button>
        <aside style="position:fixed;left:0;top:50px;width:300px;transform:translateX(-500px)">
        <form onsubmit="event.preventDefault();window.sent=this.elements.q.value"><input id="mobile-search" type="search" name="q"></form></aside>''')
        first=page.evaluate("window.__madar.search('drawer','#mobile-search')")
        require(first.get('opened'),str(first)); require(page.evaluate("document.querySelector('input').value")=='')
        require(page.evaluate("window.__madar.search('drawer','#mobile-search').submitted"))
        require(page.evaluate('window.sent')=='drawer')
    record('offcanvas_saved_field_must_be_revealed_before_typing',off_canvas)

    def invisible_inputs():
        load('''<div style="opacity:0"><input type="search" name="q"></div><input type="search" disabled><input type="search" readonly>
        <form onsubmit="event.preventDefault();window.sent=this.elements.query.value"><input name="query"></form>''')
        require(page.evaluate("window.__madar.search('visible').submitted"))
        require(page.evaluate('window.sent')=='visible')
        require(page.evaluate("[...document.querySelectorAll('input')].slice(0,3).every(x=>x.value==='')"))
    record('search_ignores_transparent_disabled_readonly_fields',invisible_inputs)

    def icon_search():
        load('''<button id="toggle" onclick="document.querySelector('form').hidden=false"><svg width="24" height="24"><use href="#icon-search"/></svg></button>
        <form hidden onsubmit="event.preventDefault();window.sent=this.elements.q.value"><input name="q"></form>''')
        require(page.evaluate("window.__madar.search('icon').opened"))
        require(page.evaluate("window.__madar.search('icon').submitted"))
    record('search_icon_svg_use_without_text_is_detected',icon_search)

    def arabic_menu():
        load('''<button title="فتح القائمة" onclick="document.querySelector('div').hidden=false">☰</button>
        <div hidden><button title="سيرش" onclick="document.querySelector('form').hidden=false">⌕</button></div>
        <form hidden onsubmit="event.preventDefault();window.sent=this.elements.s.value"><input name="s"></form>''')
        require(page.evaluate("window.__madar.search('عربي').opened"))
        require(page.evaluate("window.__madar.search('عربي').opened"))
        require(page.evaluate("window.__madar.search('عربي').submitted"))
    record('arabic_menu_and_search_labels_are_recognized',arabic_menu)

    def unchanged_menu_once():
        load('<button aria-label="Menu" onclick="window.n=(window.n||0)+1">☰</button>')
        require(page.evaluate("window.__madar.search('x').opened"))
        for _ in range(4): require(page.evaluate("window.__madar.search('x').missing"))
        require(page.evaluate('window.n')==1)
        page.evaluate('window.__madar.resetSearch()')
        require(page.evaluate("window.__madar.search('x').opened")); require(page.evaluate('window.n')==2)
    record('automatic_opening_never_reclicks_noop_menu_in_same_attempt',unchanged_menu_once)

    def action_limit():
        load(''.join(f'<button id="menu{i}" aria-label="Menu {i}" onclick="window.n=(window.n||0)+1">☰</button>' for i in range(10)))
        for _ in range(8): require(page.evaluate("window.__madar.search('x').opened"))
        r=page.evaluate("window.__madar.search('x')")
        require(not r.get('opened'),str(r));require(page.evaluate('window.n')==8)
    record('automatic_opening_has_hard_eight_click_limit',action_limit)

    def ambiguous_fields():
        load('<input type="search" name="q"><input type="search" name="q">')
        r=page.evaluate("window.__madar.search('secret')")
        require(r.get('ambiguous'),str(r));require(not r['submitted'])
        require(page.evaluate("[...document.querySelectorAll('input')].every(x=>x.value==='')"))
    record('equally_plausible_fields_require_user_choice',ambiguous_fields)

    def visible_duplicate():
        load('''<input class="q" type="search" name="q" hidden><form onsubmit="event.preventDefault();window.sent=this.elements.q.value"><input class="q" name="q" type="search"></form>''')
        require(page.evaluate("window.__madar.search('mobile','.q').submitted"))
        require(page.evaluate('window.sent')=='mobile')
    record('hidden_desktop_duplicate_does_not_override_visible_mobile_field',visible_duplicate)

    def saved_ambiguous():
        load('<input class="q" type="search"><input class="q" type="search">')
        r=page.evaluate("window.__madar.search('x','.q')")
        require(r.get('ambiguous'),str(r));require(not r['submitted'])
    record('ambiguous_saved_field_is_not_silently_picked',saved_ambiguous)

    def strict_field():
        load('<input type="search" name="q">')
        r=page.evaluate("window.__madar.search('x','#removed',{allowOpen:false,strict:true})")
        require(r.get('missing'),str(r));require(page.evaluate("document.querySelector('input').value")=='')
    record('workflow_does_not_replace_missing_final_field_with_an_unrelated_one',strict_field)

    def stale_plain_selector():
        load('''<form onsubmit="event.preventDefault();window.sent=this.elements.q.value"><input type="search" name="q"></form>''')
        require(page.evaluate("window.__madar.search('new','#old').submitted"))
        require(page.evaluate('window.sent')=='new')
    record('nonworkflow_stale_selector_falls_back_to_unambiguous_search',stale_plain_selector)

    def dangerous_field():
        load('<form><input name="username" id="pickme"><input type="password"><button>Log in</button></form>')
        r=page.evaluate("window.__madar.search('do-not-write','#pickme')")
        require(not r['submitted']); require(page.evaluate("document.querySelector('#pickme').value")=='')
    record('explicit_selector_cannot_force_typing_into_login_form',dangerous_field)

    def safe_opening_only():
        load('''<button aria-label="Search after accepting cookies" onclick="window.accepted=true">Accept</button>
        <a href="https://other.example/search" onclick="window.sent='external'">Search</a>
        <a href="javascript:window.sent='script'">Search</a>''')
        r=page.evaluate("window.__madar.search('x')")
        require(r.get('missing'),str(r));require(page.evaluate('window.accepted===true') is False)
        require(page.evaluate('typeof window.sent')=='undefined')
    record('automatic_search_does_not_click_consent_external_or_javascript_links',safe_opening_only)

    def external_form():
        load('''<form action="https://other.example/search" onsubmit="event.preventDefault();window.sent=true"><input type="search" name="q"></form>''')
        require(not page.evaluate("window.__madar.search('private').submitted"))
        require(page.evaluate("document.querySelector('input').value")=='')
        require(page.evaluate('window.sent===true') is False)
    record('keyword_is_not_sent_to_external_form_action',external_form)

    def unsafe_submitter():
        load('''<form onsubmit="event.preventDefault();window.sent=true"><input type="search" name="q"><button formaction="https://other.example/">Search</button></form>''')
        require(not page.evaluate("window.__madar.search('x').submitted"))
        require(page.evaluate('window.sent===true') is False)
    record('submitter_formaction_cannot_leave_site',unsafe_submitter)

    def sensitive_submitter():
        load('''<form onsubmit="event.preventDefault();window.sent=true"><input type="search" name="q"><button>Delete account</button></form>''')
        require(not page.evaluate("window.__madar.search('x').submitted"))
        require(page.evaluate('window.sent===true') is False)
    record('unsafe_submit_button_is_not_bypassed_with_requestsubmit',sensitive_submitter)

    def click_handler_submit():
        load('''<form onsubmit="event.preventDefault();window.submitter=event.submitter.id;window.sent=this.elements.q.value">
        <input type="search" name="q"><button id="send-search" onclick="window.clicked=true">Search</button></form>''')
        require(page.evaluate("window.__madar.search('click').submitted"))
        require(page.evaluate('window.clicked===true'))
        require(page.evaluate('window.submitter')=='send-search')
        require(page.evaluate('window.sent')=='click')
    record('search_preserves_button_click_handler_and_form_submitter',click_handler_submit)

    def shadowed_requestsubmit():
        load('''<form onsubmit="event.preventDefault();window.sent=this.elements.q.value"><input type="search" name="q"><input type="hidden" name="requestSubmit"></form>''')
        require(page.evaluate("window.__madar.search('prototype').submitted"))
        require(page.evaluate('window.sent')=='prototype')
    record('form_named_requestsubmit_does_not_shadow_native_submit_method',shadowed_requestsubmit)

    def explicit_workflow():
        load('''<button id="drawer" onclick="document.querySelector('#searchLink').hidden=false">☰</button>
        <button hidden id="searchLink" onclick="document.querySelector('form').hidden=false">Open</button>
        <form hidden onsubmit="event.preventDefault();window.sent=this.elements.custom.value"><input name="custom" id="chosen"></form>''')
        require(page.evaluate("window.__madar.clickSearchStep('#drawer').opened"))
        require(page.evaluate("window.__madar.clickSearchStep('#searchLink').opened"))
        require(page.evaluate("window.__madar.inspectSearch('#chosen',true).field"))
        require(page.evaluate("window.__madar.search('trained','#chosen',{allowOpen:false,strict:true}).submitted"))
        require(page.evaluate('window.sent')=='trained')
    record('explicit_workflow_replays_unlabelled_controls_and_custom_field',explicit_workflow)

    def workflow_ambiguous_step():
        load('<button class="menu" onclick="window.sent=true">Menu</button><button class="menu" onclick="window.sent=true">Menu</button>')
        r=page.evaluate("window.__madar.clickSearchStep('.menu')")
        require(r.get('ambiguous'),str(r));require(page.evaluate('window.sent===true') is False)
    record('saved_step_requires_one_visible_element',workflow_ambiguous_step)

    def already_expanded():
        load('<button id="menu" aria-expanded="true" onclick="window.sent=true">Menu</button>')
        require(page.evaluate("window.__madar.clickSearchStep('#menu').skipped"))
        require(page.evaluate('window.sent===true') is False)
    record('already_open_saved_menu_is_not_toggled_closed',already_expanded)

    def invalid_step():
        load('<h1>Ordinary page</h1>')
        require(page.evaluate("window.__madar.clickSearchStep('input[').missing"))
    record('invalid_saved_css_fails_without_javascript_exception',invalid_step)

    def workflow_gate():
        load('<dialog open>Confirm your age<button id="menu" onclick="window.accepted=true">Menu</button></dialog>')
        r=page.evaluate("window.__madar.clickSearchStep('#menu')")
        require(r['gate']['kind']=='age');require(page.evaluate('window.accepted===true') is False)
    record('taught_steps_still_stop_at_age_gate',workflow_gate)

    def wait_timeout():
        load('<p>No search controls</p>')
        r=page.evaluate("window.__madar.waitForSearch('#missing','#field',400,true)")
        require(r.get('timeout'),str(r))
    record('dom_wait_has_a_bounded_timeout',wait_timeout)

    def wait_no_click():
        load('<button aria-label="Menu" onclick="window.sent=true">Menu</button>')
        r=page.evaluate("window.__madar.waitForSearch('', '', 500)")
        require(r.get('ready'),str(r));require(page.evaluate('window.sent===true') is False)
    record('dom_wait_never_clicks_controls_it_only_observes',wait_no_click)

    def recording():
        load('''<button id="menu" onclick="document.querySelector('#searchButton').hidden=false">Menu</button>
        <button id="searchButton" hidden onclick="document.querySelector('#field').hidden=false">Search</button><input id="field" hidden name="q" type="search">''')
        page.evaluate('''() => { window.steps=[];window.webkit={messageHandlers:{mdSearchStep:{postMessage:m=>window.steps.push(m)},mdField:{postMessage:m=>window.picked=m}}};window.__madar.startSearchRecording('native-token'); }''')
        page.locator('#menu').click(); page.locator('#searchButton').click(); page.locator('#field').click()
        steps=page.evaluate('window.steps');picked=page.evaluate('window.picked')
        require([s['selector'] for s in steps]==['#menu','#searchButton'],str(steps))
        require(picked['selector']=='#field');require(picked['token']=='native-token')
        require(all('value' not in s and 'query' not in s for s in steps))
        require(page.evaluate("document.querySelector('#field').value")=='')
    record('trusted_teaching_records_two_openers_and_final_field_not_query_text',recording)

    def ignore_synthetic_recording():
        load('<button id="menu">Menu</button><input type="search" id="field">')
        page.evaluate('''() => {window.steps=[];window.webkit={messageHandlers:{mdSearchStep:{postMessage:m=>window.steps.push(m)},mdField:{postMessage:m=>window.picked=m}}};
          window.__madar.startSearchRecording('t');document.querySelector('#menu').click();document.querySelector('#field').click();}''')
        require(page.evaluate('window.steps.length')==0);require(page.evaluate('typeof window.picked')=='undefined')
    record('teaching_ignores_synthetic_page_clicks',ignore_synthetic_recording)

    def cancel_recording():
        load('<button id="menu">Menu</button><input type="search" id="field">')
        page.evaluate('''() => {window.steps=[];window.webkit={messageHandlers:{mdSearchStep:{postMessage:m=>window.steps.push(m)},mdField:{postMessage:m=>window.picked=m}}};window.__madar.startSearchRecording('t');window.__madar.cancelSearchTeaching();}''')
        page.locator('#menu').click();page.locator('#field').click()
        require(page.evaluate('window.steps.length')==0);require(page.evaluate('typeof window.picked')=='undefined')
    record('cancel_teaching_removes_all_capture_listeners',cancel_recording)

    def idempotent_recording():
        load('<button id="menu">Menu</button>')
        page.evaluate('''() => {window.steps=[];window.webkit={messageHandlers:{mdSearchStep:{postMessage:m=>window.steps.push(m)}}};window.__madar.startSearchRecording('a');window.__madar.startSearchRecording('a');window.__madar.startSearchRecording('b');}''')
        page.locator('#menu').click();steps=page.evaluate('window.steps')
        require(len(steps)==1,str(steps));require(steps[0]['token']=='b')
    record('rearming_teaching_does_not_duplicate_listeners_or_reuse_old_token',idempotent_recording)

    def stable_name_selector():
        load('<div><input name="unusual-search" type="search"></div>')
        page.evaluate('''() => {window.webkit={messageHandlers:{mdField:{postMessage:m=>window.picked=m}}};window.__madar.pickField('t');}''')
        page.locator('input').click();picked=page.evaluate('window.picked')
        require(picked['selector']=='input[name="unusual-search"]',str(picked))
    record('field_picker_prefers_unique_name_over_fragile_coordinates_or_nth_path',stable_name_selector)

    def recording_sensitive():
        load('<button id="accept">Accept cookies</button><form><input id="password" type="password"></form>')
        page.evaluate('''() => {window.steps=[];window.webkit={messageHandlers:{mdSearchStep:{postMessage:m=>window.steps.push(m)},mdField:{postMessage:m=>window.picked=m}}};window.__madar.startSearchRecording('t');}''')
        page.locator('#accept').click();page.locator('#password').click()
        require(page.evaluate('window.steps.length')==0);require(page.evaluate('typeof window.picked')=='undefined')
    record('teaching_does_not_save_consent_actions_or_password_fields',recording_sensitive)

    def custom_snapshot():
        load('<div class="custom-result"><a href="/content/1">Original</a></div>')
        before=page.evaluate("window.__madar.searchSnapshot('.custom-result')")
        page.evaluate("document.querySelector('a').href='/content/2'")
        after=page.evaluate("window.__madar.searchSnapshot('.custom-result')")
        require(before['items']!=after['items'])
    record('submission_snapshot_uses_custom_result_selector',custom_snapshot)

    def article_search_word_is_not_a_trigger():
        load('''<a href="/content/search-and-rescue" onclick="event.preventDefault();window.sent='wrong'">Search and rescue documentary</a>
        <button aria-label="Menu" onclick="window.menu=true">☰</button>''')
        require(page.evaluate("window.__madar.search('x').opened"))
        require(page.evaluate('window.menu===true'))
        require(page.evaluate('typeof window.sent')=='undefined')
    record('search_word_in_article_title_does_not_outrank_menu',article_search_word_is_not_a_trigger)

    def close_search_not_open_or_submit():
        load('<button aria-label="Close search" onclick="window.sent=true">Close</button>')
        require(page.evaluate("window.__madar.search('x').missing"))
        require(page.evaluate('window.sent===true') is False)
        load('''<div role="search"><input type="search"><button type="button" aria-label="Close search" onclick="window.sent=true">Close</button></div>''')
        require(page.evaluate("window.__madar.search('x').method")=='enter')
        require(page.evaluate('window.sent===true') is False)
    record('close_search_button_is_not_opened_or_used_to_submit',close_search_not_open_or_submit)

    browser.close()

report = {"engine": "Chromium; not iOS WebKit", "network": "all requests aborted; set_content fixtures with a lexical mock location", "tests": results,
          "passed": sum(r['passed'] for r in results), "failed": sum(not r['passed'] for r in results)}
output = ROOT / "Documentation/dom-test-report.json"
output.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
print(f"\n{report['passed']} passed; {report['failed']} failed")
raise SystemExit(1 if report['failed'] else 0)
