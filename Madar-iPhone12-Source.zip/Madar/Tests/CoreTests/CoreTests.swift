import XCTest
@testable import MadarCore

final class URLTests: XCTestCase {
    let base = URL(string: "https://example.com/section/page")!
    func testWebsiteAddsHTTPS() throws { XCTAssertEqual(try URLTools.website("example.com/A?Key=X").absoluteString, "https://example.com/A?Key=X") }
    func testHTTPRejected() { XCTAssertThrowsError(try URLTools.website("http://example.com")) }
    func testCredentialsRejected() { XCTAssertThrowsError(try URLTools.website("https://user:pass@example.com")) }
    func testEmptyRejected() { XCTAssertThrowsError(try URLTools.website("  ")) }
    func testRelativeCandidate() { XCTAssertEqual(URLTools.candidate("../v/clip.mp4", base: base)?.absoluteString, "https://example.com/v/clip.mp4") }
    func testProtocolRelative() { XCTAssertEqual(URLTools.candidate("//cdn.example.com/A.mp4", base: base)?.scheme, "https") }
    func testUnsafeCandidates() {
        for raw in ["javascript:alert(1)", "file:///private/data", "blob:https://example.com/id", "http://example.com/a.mp4", "https://user:secret@example.com/a.mp4"] {
            XCTAssertNil(URLTools.candidate(raw, base: base), raw)
        }
    }
    func testEscapedURL() {
        XCTAssertEqual(URLTools.candidate(#"https:\/\/cdn.example.com\/A.mp4?Key=AbC\u0026x=2"#, base: base)?.absoluteString, "https://cdn.example.com/A.mp4?Key=AbC&x=2")
    }
    func testHeightRecognition() {
        XCTAssertEqual(URLTools.height("a_1080P_file.mp4"), 1080)
        XCTAssertEqual(URLTools.height("1920x1080"), 1080)
        XCTAssertNil(URLTools.height("id1720p999"))
    }
    func testSameSite() {
        XCTAssertTrue(URLTools.sameSite(base, URL(string: "https://www.example.com/x")!))
        XCTAssertFalse(URLTools.sameSite(base, URL(string: "https://example.com.attacker.invalid")!))
        XCTAssertFalse(URLTools.sameSite(base, URL(string: "https://other.example.com")!))
    }
    func testDedupeKeepsQuality() {
        let u = URL(string: "https://example.com/file.mp4")!
        let result = URLTools.unique([MediaSource(url: u), MediaSource(url: u, height: 720)])
        XCTAssertEqual(result.count, 1); XCTAssertEqual(result[0].height, 720)
    }
}
final class TemplateTests: XCTestCase {
    let base = URL(string: "https://example.com")!
    func testQueryEncoding() throws {
        let q = "a&b + # عربي"
        let url = try SearchTemplate.url(template: "https://example.com/search?q={query}", keyword: q, base: base)
        XCTAssertEqual(URLComponents(url: url, resolvingAgainstBaseURL: false)?.queryItems?.first?.value, q)
        XCTAssertEqual(URLComponents(url: url, resolvingAgainstBaseURL: false)?.queryItems?.count, 1)
    }
    func testTemplateCannotLeaveSite() {
        XCTAssertThrowsError(try SearchTemplate.url(template: "https://other.com/?q={query}", keyword: "x", base: base))
    }
    func testMissingPlaceholderRejected() { XCTAssertThrowsError(try SearchTemplate.url(template: "/search", keyword: "x", base: base)) }
    func testLearningReplacesOnlyExactValue() {
        let url = URL(string: "https://example.com/Search?q=Cat&page=1")!
        XCTAssertEqual(SearchTemplate.learned(from: url, keyword: "Cat"), "https://example.com/Search?q={query}&page=1")
        XCTAssertNil(SearchTemplate.learned(from: url, keyword: "cat"))
    }
    func testSensitiveTemplatesNotLearned() {
        XCTAssertNil(SearchTemplate.learned(from: URL(string: "https://example.com/?q=cat&session=SECRET")!, keyword: "cat"))
    }
}
final class ExtractorTests: XCTestCase {
    let base = URL(string: "https://example.com/watch/42")!
    func testDirectHTML() {
        let sources = MediaExtractor.extract(#"<video><source src="/video/clip_720p.mp4"></video>"#, base: base)
        XCTAssertEqual(sources.count, 1); XCTAssertEqual(sources.first?.height, 720)
    }
    func testLiteralConcatenationAndForwardReferences() {
        let source = #"var final = root + tail; var root = 'https://cdn.example.com/'; var tail = 'clip_1080p.mp4?Key=Case';"#
        XCTAssertTrue(MediaExtractor.extract(source, base: base).contains { $0.url.absoluteString == "https://cdn.example.com/clip_1080p.mp4?Key=Case" })
    }
    func testNoFunctionEvaluation() {
        XCTAssertNil(MediaExtractor.literalExpression(#"dangerous() + '.mp4'"#, names: [:]))
        XCTAssertNil(MediaExtractor.literalExpression(#"'x'.repeat(1000000)"#, names: [:]))
        XCTAssertNil(MediaExtractor.literalExpression(#"`${run()}`"#, names: [:]))
    }
    func testCycleTerminates() {
        XCTAssertTrue(MediaExtractor.resolveLiteralAssignments("var a = b; var b = a;").isEmpty)
    }
    func testLegacyCommentSplitFormat() {
        let source = #"/*one*/a="https://cdn.example.com/"+"clip_720P_"; /*two*/b="part.mp4?Key=Case"; /*three*/c="https://cdn.example.com/clip_1080P_file.mp4";"#
        let urls = MediaExtractor.extract(source, base: base).map(\.url.absoluteString)
        XCTAssertTrue(urls.contains("https://cdn.example.com/clip_720P_part.mp4?Key=Case"))
        XCTAssertTrue(urls.contains("https://cdn.example.com/clip_1080P_file.mp4"))
    }
    func testStructuredExtensionlessMedia() {
        let html = #"<script type="application/json">{"sources":[{"videoUrl":"https://cdn.example.com/stream?id=ABC","format":"mp4","quality":"1080"}]}</script>"#
        let r = MediaExtractor.extract(html, base: base)
        XCTAssertEqual(r.first?.height, 1080); XCTAssertEqual(r.first?.kind, .file)
    }
    func testPlayerMediaDefinitions() {
        let source = #"var config = { mediaDefinitions: [{"videoUrl":"https://cdn.example.com/a.mp4","quality":720,"format":"mp4"}] };"#
        XCTAssertEqual(MediaExtractor.extract(source, base: base).first?.height, 720)
    }
    func testJSONLDContentURL() {
        let html = #"<script type='application/ld+json'>{"@type":"VideoObject","contentUrl":"https://cdn.example.com/A.MP4?Key=AbC"}</script>"#
        XCTAssertTrue(MediaExtractor.extract(html, base: base).contains { $0.url.absoluteString == "https://cdn.example.com/A.MP4?Key=AbC" })
    }
    func testMoreThanFourQualities() {
        let html = [144, 240, 360, 480, 720, 1080].map { #"<source src="https://cdn.example.com/clip_\#($0)p.mp4">"# }.joined()
        XCTAssertEqual(MediaExtractor.extract(html, base: base).count, 6)
    }
    func testUnsafeMediaNotReturned() {
        let html = #"<source src="file:///tmp/private.mp4"><video src="http://example.com/plain.mp4"><source src="blob:https://example.com/1">"#
        XCTAssertTrue(MediaExtractor.extract(html, base: base).isEmpty)
    }
}
final class HLSTests: XCTestCase {
    let base = URL(string: "https://cdn.example.com/path/master.m3u8?Token=AbC")!
    func testVariantsAndQualityOrder() throws {
        let m = try HLSManifest.parse("#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=1000000,RESOLUTION=1280x720\n720/index.m3u8\n#EXT-X-STREAM-INF:BANDWIDTH=2000000,RESOLUTION=1920x1080\n1080/index.m3u8\n", base: base)
        XCTAssertEqual(m.variants.map(\.height), [1080,720]); XCTAssertFalse(m.isLive)
        XCTAssertEqual(m.variants.last?.url.absoluteString, "https://cdn.example.com/path/720/index.m3u8")
    }
    func testVOD() throws {
        let m = try HLSManifest.parse("#EXTM3U\n#EXTINF:4.0,\npart.ts\n#EXT-X-ENDLIST", base: base)
        XCTAssertFalse(m.isLive); XCTAssertFalse(m.encrypted)
    }
    func testLiveRecognized() throws { XCTAssertTrue(try HLSManifest.parse("#EXTM3U\n#EXTINF:4,\npart.ts", base: base).isLive) }
    func testAESKeyNotBypassed() throws { XCTAssertTrue(try HLSManifest.parse("#EXTM3U\n#EXT-X-KEY:METHOD=AES-128,URI=\"key\"\n#EXT-X-ENDLIST", base: base).encrypted) }
    func testSessionKeyRecognized() throws { XCTAssertTrue(try HLSManifest.parse("#EXTM3U\n#EXT-X-SESSION-KEY:METHOD=SAMPLE-AES,URI=\"skd://key\"", base: base).encrypted) }
    func testMethodNoneAllowed() throws { XCTAssertFalse(try HLSManifest.parse("#EXTM3U\n#EXT-X-KEY:METHOD=NONE\n#EXT-X-ENDLIST", base: base).encrypted) }
    func testExternalAudioDetected() throws { XCTAssertTrue(try HLSManifest.parse("#EXTM3U\n#EXT-X-MEDIA:TYPE=AUDIO,GROUP-ID=\"a\",URI=\"audio.m3u8\"", base: base).hasExternalAudio) }
    func testHTMLResponseRejected() { XCTAssertThrowsError(try HLSManifest.parse("<html>Verify</html>", base: base)) }
}
final class ModelTests: XCTestCase {
    func testRoundTrip() throws {
        var index = VaultIndex(); let folder = VaultFolder(name: "مقاطع")
        index.folders = [folder]
        index.entries = [VaultEntry(id: UUID(), title: "جولة", fileExtension: "mp4", bytes: 1234, folderID: folder.id, quality: "720p")]
        let decoded = try JSONDecoder().decode(VaultIndex.self, from: JSONEncoder().encode(index))
        XCTAssertEqual(decoded.entries.first?.title, "جولة"); XCTAssertEqual(decoded.entries.first?.folderID, folder.id)
    }
}
