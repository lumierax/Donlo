import XCTest
@testable import MadarCore

final class DownloadReliabilityTests: XCTestCase {
    let page = URL(string: "https://example.com/watch/42")!
    func source(_ raw: String, height: Int? = 720) -> MediaSource { MediaSource(url: URL(string: raw)!, height: height) }
    func testExtensionlessMIME() {
        let url = URL(string: "https://cdn.example.com/deliver?id=42")!
        XCTAssertEqual(URLTools.mediaKind(url, mimeType: "video/mp4; charset=binary"), .file)
        XCTAssertEqual(URLTools.mediaKind(url, mimeType: "application/vnd.apple.mpegurl"), .hls)
        XCTAssertEqual(URLTools.mediaKind(url, mimeType: "application/dash+xml"), .dash)
        XCTAssertNil(URLTools.mediaKind(url, mimeType: "application/json"))
    }
    func testSegmentsAndAudioNotCompleteMedia() {
        XCTAssertNil(URLTools.mediaKind(mimeType: "video/mp2t"))
        XCTAssertNil(URLTools.mediaKind(mimeType: "audio/mp4"))
        XCTAssertNil(URLTools.mediaKind(URL(string: "https://cdn.example.com/segment.m4s")!))
    }
    func testTypedExtensionlessVideoSource() {
        let html = #"<video><source type="video/mp4" src="https://cdn.example.com/deliver?id=42"></video>"#
        let result = MediaExtractor.extract(html, base: page)
        XCTAssertEqual(result.count, 1); XCTAssertEqual(result[0].kind, .file)
        XCTAssertEqual(result[0].requestReferer, page)
    }
    func testUntypedExtensionlessVideoElement() {
        XCTAssertEqual(MediaExtractor.extract(#"<video src="/media?id=42"></video>"#, base: page).first?.url.absoluteString, "https://example.com/media?id=42")
    }
    func testUntypedExtensionlessChildSource() {
        XCTAssertEqual(MediaExtractor.extract(#"<video><source src="/deliver?id=42"></video>"#, base: page).first?.kind, .file)
    }
    func testUntypedAudioSourceNotPromoted() {
        XCTAssertTrue(MediaExtractor.extract(#"<audio><source src="/audio?id=42"></audio>"#, base: page).isEmpty)
    }
    func testHLSVideoNotMisclassifiedAsFile() {
        XCTAssertEqual(MediaExtractor.extract(#"<video src="/master.m3u8"></video>"#, base: page).first?.kind, .hls)
        XCTAssertEqual(MediaExtractor.extract(#"<video><source src="/master.m3u8"></video>"#, base: page).first?.kind, .hls)
    }
    func testTypedHLSWithNoExtension() {
        XCTAssertEqual(MediaExtractor.extract(#"<source src="/stream?id=42" type="application/x-mpegurl">"#, base: page).first?.kind, .hls)
    }
    func testVideoMetadataNoExtension() {
        let html = #"<meta property="og:video:type" content="video/mp4"><meta property="og:video:secure_url" content="https://cdn.example.com/get?id=42">"#
        XCTAssertEqual(MediaExtractor.extract(html, base: page).first?.kind, .file)
    }
    func testEmbeddedPlayerHTMLNotPromoted() {
        let html = #"<meta property="og:video:type" content="text/html"><meta property="og:video" content="https://player.example.com/embed/42">"#
        XCTAssertTrue(MediaExtractor.extract(html, base: page).isEmpty)
    }
    func testUntitledVideoObjectHasMedia() {
        let html = #"<script type="application/ld+json">{"@type":"VideoObject","contentUrl":"https://cdn.example.com/get?id=42"}</script>"#
        let result = MediaExtractor.extract(html, base: page)
        XCTAssertEqual(result.count, 1); XCTAssertEqual(result[0].kind, .file)
    }
    func testJSONArrayVideoType() {
        let html = #"<script type="application/ld+json">{"@type":["Thing","VideoObject"],"contentUrl":"/get?id=42"}</script>"#
        XCTAssertEqual(MediaExtractor.extract(html, base: page).count, 1)
    }
    func testVideoObjectPageURLIsNotMedia() {
        let html = #"<script type="application/ld+json">{"@type":"VideoObject","url":"/watch/42"}</script>"#
        XCTAssertTrue(MediaExtractor.extract(html, base: page).isEmpty)
    }
    func testFallbackTitlesNotEmpty() {
        XCTAssertEqual(VideoResult(pageURL: page, title: " \n ").title, "فيديو بدون عنوان · 42")
        XCTAssertEqual(VideoResult(pageURL: page, title: "أ").title, "أ")
        XCTAssertEqual(VideoResult(pageURL: page, title: " اسم\n  فيديو ").title, "اسم فيديو")
    }
    func testTitleDoesNotIncludeSignedQuery() {
        let url = URL(string: "https://example.com/watch/42?token=SECRET")!
        XCTAssertFalse(VideoResult(pageURL: url, title: "").title.contains("SECRET"))
    }
    func testOptionalRefererDecodesOldModel() throws {
        let json = #"{"url":"https://cdn.example.com/a.mp4","kind":"file","evidence":"page"}"#.data(using: .utf8)!
        XCTAssertNil(try JSONDecoder().decode(MediaSource.self, from: json).requestReferer)
    }
    func testDedupePreservesRuntimeRefererAndKind() {
        let url = URL(string: "https://cdn.example.com/stream")!
        let embed = URL(string: "https://player.example.com/embed/42")!
        let result = URLTools.unique([MediaSource(url: url, requestReferer: page), MediaSource(url: url, kind: .hls, evidence: "WebKit fetch MIME", requestReferer: embed)])
        XCTAssertEqual(result.count, 1); XCTAssertEqual(result[0].kind, .hls); XCTAssertEqual(result[0].requestReferer, embed)
    }
    func testTransientHTTPBackoffAndLimit() {
        for status in [408, 425, 429, 500, 502, 503, 504] {
            XCTAssertEqual(DownloadPolicy.retryDelay(status: status, failedAttempt: 1), 1)
            XCTAssertEqual(DownloadPolicy.retryDelay(status: status, failedAttempt: 2), 2)
            XCTAssertEqual(DownloadPolicy.retryDelay(status: status, failedAttempt: 3), 4)
            XCTAssertNil(DownloadPolicy.retryDelay(status: status, failedAttempt: 4))
        }
    }
    func testRefusalsAreNotBlindlyRetried() {
        for status in [400, 401, 403, 404, 410, 451] { XCTAssertNil(DownloadPolicy.retryDelay(status: status, failedAttempt: 1)) }
        XCTAssertTrue(DownloadPolicy.shouldRefresh(status: 403)); XCTAssertFalse(DownloadPolicy.shouldRefresh(status: 451))
    }
    func testOnlyTransientNetworkErrorsRetry() {
        XCTAssertEqual(DownloadPolicy.retryDelay(status: nil, networkCode: URLError.timedOut.rawValue, failedAttempt: 1), 1)
        XCTAssertNil(DownloadPolicy.retryDelay(status: nil, networkCode: URLError.cancelled.rawValue, failedAttempt: 1))
        XCTAssertNil(DownloadPolicy.retryDelay(status: nil, networkCode: URLError.serverCertificateUntrusted.rawValue, failedAttempt: 1))
        XCTAssertNil(DownloadPolicy.retryDelay(status: nil, failedAttempt: 1))
    }
    func testServerWaitIsRespectedWithoutEarlyRetry() {
        XCTAssertEqual(DownloadPolicy.retryDelay(status: 429, failedAttempt: 1, retryAfter: 30), 30)
        XCTAssertNil(DownloadPolicy.retryDelay(status: 429, failedAttempt: 1, retryAfter: 120))
    }
    func testRetryAfterFormats() {
        XCTAssertEqual(DownloadPolicy.retryAfter("12"), 12)
        let now = Date(timeIntervalSince1970: 0)
        XCTAssertEqual(DownloadPolicy.retryAfter("Thu, 01 Jan 1970 00:00:30 GMT", now: now), 30)
        XCTAssertNil(DownloadPolicy.retryAfter("nonsense")); XCTAssertNil(DownloadPolicy.retryAfter("NaN")); XCTAssertNil(DownloadPolicy.retryAfter("-1"))
    }
    func testExpiredSignatureRefreshesSameAsset() {
        let old = source("https://cdn.example.com/video/42.mp4?token=OLD&quality=720")
        let new = source("https://cdn.example.com/video/42.mp4?quality=720&token=NEW")
        XCTAssertEqual(DownloadPolicy.refreshedSource(for: old, in: [new])?.url, new.url)
    }
    func testNewSignaturePreferredOverOldDuplicate() {
        let old = source("https://cdn.example.com/a.mp4?sig=old")
        let new = source("https://cdn.example.com/a.mp4?sig=new")
        XCTAssertEqual(DownloadPolicy.refreshedSource(for: old, in: [old, new])?.id, new.id)
    }
    func testContentIdentityAndQualityNeverStripped() {
        let old = source("https://cdn.example.com/stream?id=42&quality=720&token=OLD")
        let unrelated = source("https://cdn.example.com/stream?id=99&quality=720&token=NEW")
        let differentQuality = source("https://cdn.example.com/stream?id=42&quality=1080&token=NEW", height: 1080)
        XCTAssertNil(DownloadPolicy.refreshedSource(for: old, in: [unrelated, differentQuality]))
    }
    func testOtherHostOrPathNotAutoSelected() {
        let old = source("https://cdn.example.com/a.mp4?token=old")
        let others = [source("https://cdn.example.com/ad.mp4?token=new"), source("https://other.example.com/a.mp4?token=new")]
        XCTAssertNil(DownloadPolicy.refreshedSource(for: old, in: others))
    }
    func testAmbiguousRenewedTokensNotAutoSelected() {
        let old = source("https://cdn.example.com/stream?token=old")
        let first = source("https://cdn.example.com/stream?token=new1")
        let second = source("https://cdn.example.com/stream?token=new2")
        XCTAssertNil(DownloadPolicy.refreshedSource(for: old, in: [first, second]))
    }
    func testCompletePartialContentValidation() {
        XCTAssertTrue(DownloadPolicy.completeByteRange("bytes 0-99/100", bytes: 100))
        XCTAssertFalse(DownloadPolicy.completeByteRange("bytes 10-99/100", bytes: 90))
        XCTAssertFalse(DownloadPolicy.completeByteRange("bytes 0-49/100", bytes: 50))
        XCTAssertFalse(DownloadPolicy.completeByteRange("bytes 0-99/*", bytes: 100))
        XCTAssertFalse(DownloadPolicy.completeByteRange(nil, bytes: 100))
    }
    func testOriginIncludesPort() {
        XCTAssertTrue(URLTools.sameOrigin(page, URL(string: "https://example.com:443/another")!))
        XCTAssertFalse(URLTools.sameOrigin(page, URL(string: "https://example.com:444/another")!))
    }
    func testUnsafeExtensionlessMetadataRejected() {
        for raw in ["blob:https://example.com/1", "http://example.com/get", "https://user:password@example.com/get"] {
            XCTAssertTrue(MediaExtractor.extract("<video src=\"\(raw)\"></video>", base: page).isEmpty)
        }
    }
}
