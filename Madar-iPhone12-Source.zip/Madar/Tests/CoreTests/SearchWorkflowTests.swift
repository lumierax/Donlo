import Foundation
import XCTest
@testable import MadarCore

final class SearchWorkflowTests: XCTestCase {
    private let base = URL(string: "https://example.com/")!

    func testOldProfileDecodesWithoutWorkflowFields() throws {
        let data = Data(##"{"host":"example.com","searchSelector":"#q"}"##.utf8)
        let profile = try JSONDecoder().decode(SiteProfile.self, from: data)
        XCTAssertEqual(profile.searchSelector, "#q")
        XCTAssertNil(profile.searchSteps)
        XCTAssertNil(profile.searchStartURL)
        XCTAssertNil(profile.searchStepTimeout)
    }
    func testNewProfileRoundTripsWorkflow() throws {
        let profile = SiteProfile(host: "example.com", searchSelector: "#q", searchSteps: [
            SearchStep(selector: "#menu", label: "القائمة"),
            SearchStep(selector: "button[aria-label=Search]", label: "Search")
        ], searchStartURL: "https://example.com/mobile/", searchStepTimeout: 8)
        let decoded = try JSONDecoder().decode(SiteProfile.self, from: JSONEncoder().encode(profile))
        XCTAssertEqual(profile, decoded)
    }
    func testRelativeStartURLAndDefaultPage() throws {
        XCTAssertEqual(try SearchWorkflow.startURL(stored: "/mobile/", base: base).absoluteString, "https://example.com/mobile/")
        XCTAssertEqual(try SearchWorkflow.startURL(stored: nil, base: base), base)
    }
    func testStartCannotLeaveSiteOrUseUnsafeScheme() {
        for raw in ["https://other.example/", "http://example.com/", "javascript:alert(1)", "https://user:secret@example.com/"] {
            XCTAssertThrowsError(try SearchWorkflow.startURL(stored: raw, base: base), raw)
        }
    }
    func testStartDoesNotPersistSessionTokens() {
        for raw in ["/?token=secret", "/?session=secret", "/?CSRF=secret", "/?sid=secret", "/?password=secret"] {
            XCTAssertThrowsError(try SearchWorkflow.startURL(stored: raw, base: base), raw)
        }
    }
    func testStartAllowsNonSensitiveQuery() throws {
        XCTAssertEqual(try SearchWorkflow.startURL(stored: "/?lang=ar", base: base).absoluteString, "https://example.com/?lang=ar")
    }
    func testEightStepsAllowedNineRejected() throws {
        let steps = (0..<8).map { SearchStep(selector: "#menu\($0)") }
        XCTAssertNoThrow(try SearchWorkflow.validate(steps: steps, field: "#q"))
        XCTAssertThrowsError(try SearchWorkflow.validate(steps: steps + [SearchStep(selector: "#ninth")], field: "#q"))
    }
    func testWorkflowNeedsFinalField() {
        for field in [nil, "", "   "] as [String?] {
            XCTAssertThrowsError(try SearchWorkflow.validate(steps: [SearchStep(selector: "#menu")], field: field))
        }
    }
    func testEmptyOrOversizedStepRejected() {
        for selector in ["", "  ", String(repeating: "x", count: 1000)] {
            XCTAssertThrowsError(try SearchWorkflow.validate(steps: [SearchStep(selector: selector)], field: "#q"))
        }
        XCTAssertThrowsError(try SearchWorkflow.validate(steps: [SearchStep(selector: "#m", label: String(repeating: "x", count: 101))], field: "#q"))
    }
    func testNoWorkflowRemainsValidForAutomaticDetection() throws {
        XCTAssertNoThrow(try SearchWorkflow.validate(steps: [], field: nil))
    }
    func testWaitTimeoutIsFiniteAndBounded() {
        XCTAssertEqual(SearchWorkflow.timeout(nil), 5)
        XCTAssertEqual(SearchWorkflow.timeout(.nan), 5)
        XCTAssertEqual(SearchWorkflow.timeout(.infinity), 5)
        XCTAssertEqual(SearchWorkflow.timeout(-1), 2)
        XCTAssertEqual(SearchWorkflow.timeout(99), 12)
        XCTAssertEqual(SearchWorkflow.timeout(7), 7)
    }
}
