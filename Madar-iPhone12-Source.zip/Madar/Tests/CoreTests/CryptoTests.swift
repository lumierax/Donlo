import XCTest
@testable import MadarCore
#if canImport(CryptoKit) && canImport(CommonCrypto) && canImport(Security)
import CryptoKit

final class CryptoTests: XCTestCase {
    func testPBKDF2Vector() throws {
        let salt = Data("0123456789abcdef".utf8)
        let key = try VaultCrypto.derive(passphrase: "correct horse battery staple", salt: salt, rounds: 100_000)
        let hex = key.withUnsafeBytes { $0.map { String(format: "%02x", $0) }.joined() }
        XCTAssertEqual(hex, "090105d3788cadab9c12509fa1ba1d46a91a158d7a1779b114322f3fd5a825cb")
    }
    func testSealedIndexAuthentication() throws {
        let key = SymmetricKey(size: .bits256), data = Data("private index".utf8)
        let sealed = try VaultCrypto.seal(data, key: key, context: "index")
        XCTAssertEqual(try VaultCrypto.open(sealed, key: key, context: "index"), data)
        XCTAssertThrowsError(try VaultCrypto.open(sealed, key: key, context: "wrong"))
    }
    func testEmptyPassphraseRejected() { XCTAssertThrowsError(try VaultCrypto.derive(passphrase: "", salt: Data(repeating: 0, count: 16))) }
    func testRandomAccessAndCorruption() throws {
        let dir = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: dir) }
        let source = dir.appendingPathComponent("plain.bin"), target = dir.appendingPathComponent("sealed.mdv")
        let plain = Data((0..<(2 * ChunkCipher.chunkSize + 571)).map { UInt8($0 % 251) })
        try plain.write(to: source)
        let key = SymmetricKey(size: .bits256)
        XCTAssertEqual(try ChunkCipher.encrypt(input: source, output: target, key: key), UInt64(plain.count))
        let file = try FileHandle(forReadingFrom: target); defer { try? file.close() }
        let header = try ChunkCipher.readHeader(file)
        for (offset, count) in [(0, 1), (100, 70), (ChunkCipher.chunkSize - 19, 300), (plain.count - 5, 5)] {
            XCTAssertEqual(try ChunkCipher.read(file: file, header: header, key: key, offset: UInt64(offset), count: count), plain.subdata(in: offset..<(offset + count)))
        }
        XCTAssertThrowsError(try ChunkCipher.read(file: file, header: header, key: SymmetricKey(size: .bits256), offset: 0, count: 10))
        var bytes = try Data(contentsOf: target); bytes[ChunkCipher.headerSize + 50] ^= 0x80; try bytes.write(to: target)
        let damaged = try FileHandle(forReadingFrom: target); defer { try? damaged.close() }
        let damagedHeader = try ChunkCipher.readHeader(damaged)
        XCTAssertThrowsError(try ChunkCipher.read(file: damaged, header: damagedHeader, key: key, offset: 0, count: 100))
    }
    func testTruncatedFileRejected() throws {
        let path = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: path) }
        try Data("MDVLT001".utf8).write(to: path)
        let file = try FileHandle(forReadingFrom: path); defer { try? file.close() }
        XCTAssertThrowsError(try ChunkCipher.readHeader(file))
    }
}
#else
final class CryptoPlatformTests: XCTestCase {
    func testAppleCryptoRequiresAppleSDK() throws { throw XCTSkip("CryptoKit/CommonCrypto tests require macOS or iOS; Linux validates the non-Apple core only.") }
}
#endif
