# Provenance and notices

This is a new SwiftUI application, not a modified copy of the supplied SiteMediaScanner project.

The two user-supplied archives informed the extraction techniques. Their MIT notices are retained here:

- `SiteMediaScanner-iOS-v1.0(2).zip`: direct media discovery, request context and an AVFoundation HLS export attempt. See `SiteMediaScanner-MIT.txt`.
- `PORNHUB-API-master(1).zip`: reconstruction of statically split JavaScript URL strings and resolution hints. See `Reference-API-MIT.txt`.

The new implementation does not execute fetched JavaScript in the native process, bundle the Node API/runtime, or include either archive's scraped fixtures, site artwork or media. The native UI, private vault, transfer queue, browser integration and tests are new. No Brave code or branding is embedded. Apple system frameworks are imported through the SDK, not redistributed here.
