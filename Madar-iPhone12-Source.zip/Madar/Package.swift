// swift-tools-version: 5.9
import PackageDescription
let package = Package(
    name: "MadarCore",
    platforms: [.macOS(.v13), .iOS("18.5")],
    products: [.library(name: "MadarCore", targets: ["MadarCore"])],
    targets: [
        .target(name: "MadarCore", path: "Madar/Core"),
        .testTarget(name: "MadarCoreTests", dependencies: ["MadarCore"], path: "Tests/CoreTests")
    ]
)
